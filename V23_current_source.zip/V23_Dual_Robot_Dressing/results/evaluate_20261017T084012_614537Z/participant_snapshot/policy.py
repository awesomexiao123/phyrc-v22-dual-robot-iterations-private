"""External official-runner adapter for the experimental V23 cooperative actor.

Only public observations enter the actor or optional diagnostic images.  No
simulator APIs, evaluation internals, seeds or scene state are read here.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

import numpy as np

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen_v22'
CHECKPOINT_SHA256 = '26fc0e330bb8e5e1be7b42e5831d98df7117d36383fb4716d3fedefc643e3dbf'
CAMERAS = ('overview', 'R0 wrist', 'R1 wrist', 'R0 head', 'R1 head')


def frozen_policy_class():
    """Load the isolated actor without replacing the runner's policy module."""
    name = '_phyrc_frozen_v22_actor'
    if name not in sys.modules:
        sys.path.insert(0, str(FROZEN))
        spec = importlib.util.spec_from_file_location(name, FROZEN / 'policy.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name].Policy


def verify_checkpoint(checkpoint):
    path = Path(checkpoint or FROZEN / 'weights/best.pt').resolve()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != CHECKPOINT_SHA256:
        raise ValueError(f'Frozen v22 checkpoint hash mismatch: {actual}')
    return path


def validate_spaces(observation_space, action_space):
    if tuple(action_space.shape) != (2, 9) or np.dtype(action_space.dtype) != np.dtype('float32'):
        raise ValueError('Requires float32 action space (2, 9)')
    if not np.all(np.asarray(action_space.low) == -1) or not np.all(np.asarray(action_space.high) == 1):
        raise ValueError('Requires normalized action bounds [-1, 1]')
    contract = json.loads((FROZEN / 'policy_interface_snapshot.json').read_text())
    dims = contract['default_dimensions']
    for name, entry in contract['observations'].items():
        expected = tuple(dims[v] if isinstance(v, str) else v for v in entry['shape'])
        space = observation_space.spaces.get(name)
        if space is None or tuple(space.shape) != expected or np.dtype(space.dtype) != np.dtype(entry['dtype']):
            raise ValueError(f'Requires public actor_rgbd observation {name}: {expected}/{entry["dtype"]}')


def validate_action(action):
    if not isinstance(action, np.ndarray) or action.shape != (2, 9) or action.dtype != np.float32:
        raise ValueError('Frozen actor must return an actual float32 array of shape (2, 9)')
    if not np.isfinite(action).all() or np.any(np.abs(action) > 1):
        raise ValueError('Frozen actor returned nonfinite or out-of-range actions')
    return action


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    return value


def atomic_json(path, value):
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(plain(value), ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


class Diagnostics:
    def __init__(self, root, episode):
        self.root = root
        self.path = root / f'episode_{episode:03d}'
        self.path.mkdir(parents=True, exist_ok=False)
        self.previous = None
        self.transition_images = 0

    def write(self, observation, action, debug):
        step = int(debug['step'])
        parent = debug.get('parent_debug') or {}
        signature = (debug.get('phase'), parent.get('phase'), debug.get('idle_mode'), debug.get('failure'))
        changed = signature != self.previous
        sim_time = float(np.asarray(observation['simulation_time_s']).item())
        record = dict(step=step, simulation_time_s=sim_time, phase=debug.get('phase'),
                      parent_phase=parent.get('phase'), idle_mode=debug.get('idle_mode'),
                      base_pose_world=observation['base_pose_world'], grasp_pose_base=observation['grasp_pose_base'],
                      gripper_close_command=observation['gripper_close_command'], fingertip_origin_distance=observation['fingertip_origin_distance'],
                      failure=debug.get('failure'), active_robot=debug.get('active_robot'),
                      checkpoint_sha256=CHECKPOINT_SHA256, action=action, debug=debug,
                      evidence='public observations and actor-owned diagnostics only; not training data')
        if step == 1 or step % 20 == 0 or changed:
            with (self.path / 'progress.jsonl').open('a') as stream:
                stream.write(json.dumps(plain(record), ensure_ascii=False, allow_nan=False) + '\n')
            atomic_json(self.path / 'latest.json', record)
            atomic_json(self.root / 'latest.json', dict(record, episode_directory=self.path.name))
        if step == 1 or step % 100 == 0 or (changed and debug.get('failure')):
            print(f'[v23] step={step} sim={sim_time:.2f}s phase={signature[0]} '
                  f'parent={signature[1]} idle={signature[2]} failure={signature[3]}', flush=True)
        save_transition = changed and self.transition_images < 10
        if step == 1 or step % 200 == 0 or save_transition:
            self.image(observation['rgb'], step, sim_time, signature)
            if save_transition:
                self.transition_images += 1
        self.previous = signature

    def image(self, rgb, step, sim_time, signature):
        import cv2
        # Five official camera frames, no free viewport or scene-derived labels.
        sheet = np.zeros((2 * 288, 3 * 256, 3), dtype=np.uint8)
        for i, label in enumerate(CAMERAS):
            y, x = (i // 3) * 288, (i % 3) * 256
            sheet[y + 24:y + 280, x:x + 256] = rgb[i]
            cv2.putText(sheet, label, (x + 6, y + 17), cv2.FONT_HERSHEY_SIMPLEX, .45, (255, 255, 255), 1)
        lines = [f'v23 step {step}', f'sim {sim_time:.2f}s', str(signature[0]), str(signature[2]),
                 'Public RGB evaluation evidence', 'No training/video recording']
        for i, line in enumerate(lines):
            cv2.putText(sheet, line, (518, 320 + i * 25), cv2.FONT_HERSHEY_SIMPLEX, .37, (255, 255, 255), 1)
        ok, encoded = cv2.imencode('.png', cv2.cvtColor(sheet, cv2.COLOR_RGB2BGR))
        if not ok:
            raise RuntimeError('Could not encode public camera contact sheet')
        data = encoded.tobytes()
        (self.path / f'public_rgb_step_{step:05d}.png').write_bytes(data)
        for destination in (self.path / 'latest.png', self.root / 'latest.png'):
            temporary = destination.with_name(destination.name + f'.{os.getpid()}.tmp')
            temporary.write_bytes(data)
            temporary.replace(destination)


class OfficialV22Adapter:
    def __init__(self, checkpoint, actor_class):
        self.checkpoint = checkpoint
        self.actor_class = actor_class
        self.device = os.environ.get('V22_DEVICE') or None
        self.actor = None  # The official runner calls reset after environment reset.
        self.episode = 0
        self.diagnostics = None
        self.diagnostic_root = None
        configured = os.environ.get('V22_DIAGNOSTICS_DIR')
        if configured:
            root = Path(configured).resolve()
            if not root.is_relative_to(Path('/output')) or root == Path('/output'):
                raise ValueError('V22_DIAGNOSTICS_DIR must be a separate directory beneath /output')
            self.diagnostic_root = root

    def reset(self):
        # Reconstruct the top actor: its own state has no complete reset method.
        # Delete first so resets do not temporarily retain two network copies.
        self.actor = None
        self.actor = self.actor_class(self.checkpoint, device=self.device)
        self.episode += 1
        self.diagnostics = Diagnostics(self.diagnostic_root, self.episode) if self.diagnostic_root else None

    def __call__(self, observation):
        if self.actor is None:
            self.reset()
        action = validate_action(self.actor(observation))
        if self.diagnostics:
            self.diagnostics.write(observation, action, self.actor.debug)
        return action


def load_policy(checkpoint, observation_space, action_space):
    validate_spaces(observation_space, action_space)
    checkpoint = verify_checkpoint(checkpoint)
    import torch
    torch.set_num_threads(1)
    import cv2
    cv2.setNumThreads(1)
    sys.path.insert(0, str(HERE))
    variant = os.environ.get('V23_VARIANT', 'hanging')
    if variant == 'tabletop':
        from tabletop_policy import Policy
    elif variant == 'sleeve_sides':
        from sleeve_pair_policy import Policy
    elif variant == 'hanging':
        from cooperative_policy import Policy
    else:
        raise ValueError('Unknown V23 variant: ' + variant)
    return OfficialV22Adapter(checkpoint, Policy)
