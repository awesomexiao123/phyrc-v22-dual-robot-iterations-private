"""Read-only RGB-D observability near two supplied world-frame grasps.

An image silhouette, yellow trim, or grasp point never establishes a sleeve.
A closed image region with observed background depth provides an unclassified
opening candidate only. Physical topology, identity and traversability remain
unknown. This module issues no robot actions and imports no simulator state.
"""
from copy import deepcopy

import cv2
import numpy as np

from human_targets import _validated, _camera_transform, _world_pixels, _FOCAL, _CAMERAS
from opening_candidates import detect_opening_candidates
from public_vision import _fabric_mask
from camera_geometry import project_optical


def _sample(points, cameras, pixels, limit=96):
    """Keep actual measured source pixels, rather than interpolated geometry."""
    selected = np.arange(0, len(points), max(1, int(np.ceil(len(points)/limit))))
    return dict(points_world=points[selected].tolist(), camera_indices=cameras[selected].tolist(),
                source_pixels_uv=pixels[selected].tolist())


def _image_boundary(mask):
    labels = np.zeros(mask.shape, np.uint8)
    contours, hierarchy = cv2.findContours(mask.astype(np.uint8), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    if hierarchy is not None:
        for index, contour in enumerate(contours):
            kind = 1 if hierarchy[0, index, 3] < 0 else 2
            cv2.drawContours(labels, [contour], -1, kind, 1)
    labels[~mask] = 0
    return labels


def _candidate_has_depth(candidate):
    support = candidate.get('observed_depth_support', {})
    return (candidate.get('kind') == 'unclassified_opening' and candidate.get('camera_index') in (1, 2, 3, 4)
            and support.get('ring_valid_fraction', 0) >= .8
            and support.get('interior_valid_fraction', 0) >= .7
            and support.get('background_fraction', 0) >= .85
            and support.get('median_background_gap_m', 0) >= .04
            and support.get('lower_quartile_background_gap_m', 0) >= .02)


def diagnose_sleeve_observability(obs, grasp_points_world, *, radius=.18, match_radius=.25):
    """Describe observed fabric/boundaries and nearby unclassified openings.

    ``grasp_points_world`` is a (2,3) array in robot order, computed from public
    own-robot poses by the caller. Point counts are source-pixel observations,
    not unique cloth particles. All returned point samples are valid-depth
    measurements. Overview camera 0 is never used.

    ``geometric_alignment_observable`` means a candidate center/plane can be
    estimated; it does not authorize aligning a supposed sleeve to a hand or
    entering it. Observational suggestions carry no direction or action command.
    """
    grasps = np.asarray(grasp_points_world, dtype=float)
    if grasps.shape != (2, 3) or not np.isfinite(grasps).all():
        raise ValueError('expected two finite public world-frame grasp points')
    if not np.isfinite([radius, match_radius]).all() or not .03 <= radius <= .5 or not radius <= match_radius <= .6:
        raise ValueError('invalid local observation or opening match radius')
    values = _validated(obs, wrists=True)
    rows, cols = np.indices((256, 256))
    regions = [dict(points=[], cameras=[], pixels=[], boundary=[], views=[]) for _ in (0, 1)]
    for camera in (1, 2, 3, 4):
        color = values['rgb'][camera]
        mask = _fabric_mask(color)
        boundaries = _image_boundary(mask)
        depth = values['depth'][camera, ..., 0]
        valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < (3. if camera < 3 else 5.))
        v, u = np.where(mask & valid)
        world = _world_pixels(values, camera, u, v, depth[v, u])
        rotation, origin = _camera_transform(values, camera)
        for index, grasp in enumerate(grasps):
            near = np.linalg.norm(world-grasp, axis=1) <= radius
            points = world[near]
            pixels = np.column_stack((u[near], v[near]))
            labels = boundaries[v[near], u[near]]
            optical_grasp = (grasp-origin) @ rotation
            projected = np.zeros(mask.shape, bool)
            if optical_grasp[2] > .03:
                uv = project_optical(optical_grasp, _FOCAL)
                pixel_radius = min(96., max(3., _FOCAL*radius/optical_grasp[2]))
                projected = (cols-uv[0])**2 + (rows-uv[1])**2 <= pixel_radius**2
            colored_pixels = int(np.count_nonzero(projected & mask))
            valid_color = int(np.count_nonzero(projected & mask & valid))
            view = dict(camera_index=camera, source_camera=_CAMERAS[camera][0],
                        measured_cloth_pixels=int(len(points)),
                        measured_boundary_pixels=int(np.count_nonzero(labels)),
                        projected_rgb_cloth_pixels=colored_pixels,
                        projected_cloth_depth_valid_fraction=valid_color/colored_pixels if colored_pixels else None,
                        view_plane_normal_world=None, view_normal_cosine=None,
                        local_plane_quality=None)
            if len(points) >= 24:
                sample = points[::max(1, int(np.ceil(len(points)/512)))]
                center = np.median(sample, axis=0)
                _, singular, axes = np.linalg.svd(sample-center, full_matrices=False)
                if singular[1] > .005:
                    planarity = float(singular[2]/singular[1])
                    view['local_plane_quality'] = planarity
                    toward_camera = origin-center
                    if planarity <= .3 and np.linalg.norm(toward_camera) > .03:
                        normal = axes[2]
                        cosine = float(abs(normal @ toward_camera)/np.linalg.norm(toward_camera))
                        if normal @ toward_camera < 0:
                            normal = -normal
                        view['view_plane_normal_world'] = normal.tolist()
                        view['view_normal_cosine'] = cosine
            regions[index]['points'].append(points)
            regions[index]['cameras'].append(np.full(len(points), camera, int))
            regions[index]['pixels'].append(pixels)
            regions[index]['boundary'].append(labels)
            regions[index]['views'].append(view)

    openings = detect_opening_candidates(obs)
    matches = [[], []]
    ambiguous = [[], []]
    unmatched = []
    for candidate_index, candidate in enumerate(openings['opening_candidates']):
        if not _candidate_has_depth(candidate):
            continue
        center = np.asarray(candidate['centroid_world'], dtype=float)
        ring = np.asarray(candidate['ring_points_world'], dtype=float)
        normal = np.asarray(candidate['normal_world'], dtype=float)
        if (center.shape != (3,) or normal.shape != (3,) or ring.ndim != 2 or ring.shape[1] != 3 or
                not len(ring) or not np.isfinite(np.r_[center, normal, ring.ravel()]).all() or
                np.linalg.norm(normal) < .5):
            continue
        distances = np.linalg.norm(grasps-center, axis=1)
        ring_distances = np.min(np.linalg.norm(grasps[:, None]-ring[None, :], axis=2), axis=1)
        eligible = (distances <= match_radius) & (ring_distances <= radius)
        choices = np.flatnonzero(eligible)
        if len(choices) == 0:
            unmatched.append(candidate_index)
            continue
        # A single opening observation must not become one sleeve per gripper.
        if len(choices) == 2 and abs(distances[0]-distances[1]) < .04:
            for index in (0, 1):
                ambiguous[index].append(candidate_index)
            continue
        index = int(choices[np.argmin(distances[choices])])
        matches[index].append(dict(candidate_index=candidate_index, kind='unclassified_opening',
            candidate_index_scope='frame_local_to_this_diagnostic_call; not persistent identity or cached detector index',
            observation_time_s=(float(np.asarray(obs['simulation_time_s']).item())
                                if 'simulation_time_s' in obs else None),
            opening_verified=False, sleeve_identity_verified=False,
            centroid_world=center.tolist(), normal_world=(normal/np.linalg.norm(normal)).tolist(),
            ring_points_world=ring.tolist(),
            inner_aperture=deepcopy(candidate['inner_aperture']),
            principal_axis_world=np.asarray(candidate['principal_axis_world'], dtype=float).tolist(),
            visible_ring_extent_m=np.asarray(candidate['visible_ring_extent_m'], dtype=float).tolist(),
            pixel_centroid=np.asarray(candidate['pixel_centroid'], dtype=float).tolist(),
            ring_point_scope='bounded measured cloth-band samples around this image hole; unordered, not an inner aperture polygon',
            extent_scope='extent of observed surrounding cloth band; not guaranteed free opening diameter',
            normal_convention='points_toward_observing_camera; not entry direction',
            source_camera=candidate['source_camera'], camera_index=candidate['camera_index'],
            distance_from_grasp_m=float(distances[index]), distance_from_visible_ring_m=float(ring_distances[index]),
            observed_depth_support=dict(candidate['observed_depth_support']),
            confidence=float(candidate['confidence']), planarity=float(candidate['planarity']),
            collar_like_hint=bool(candidate.get('collar_like', False))))

    reports = []
    for index, region in enumerate(regions):
        points = np.concatenate(region['points'])
        cameras = np.concatenate(region['cameras'])
        pixels = np.concatenate(region['pixels'])
        labels = np.concatenate(region['boundary'])
        local_matches = sorted(matches[index], key=lambda c: (c['distance_from_grasp_m'], -c['confidence']))
        visible = bool(local_matches)
        colored = sum(view['projected_rgb_cloth_pixels'] for view in region['views'])
        cosines = [view['view_normal_cosine'] for view in region['views'] if view['view_normal_cosine'] is not None]
        edge_on = bool(cosines and max(cosines) < .30)
        reasons = []
        if len(points) < 24:
            reasons.append('insufficient_measured_cloth_near_grasp')
        if not len(points) and colored:
            reasons.append('projected_cloth_color_has_no_supported_local_depth')
        if ambiguous[index]:
            reasons.append('opening_candidate_ambiguous_between_grasps')
        if not visible:
            reasons.append('no_nearby_depth_supported_closed_opening')
            if np.any(labels == 1):
                reasons.append('external_silhouette_is_not_an_entry')
        else:
            reasons.append('depth_supported_image_opening_visible_but_physical_entry_and_sleeve_identity_unknown')
        if edge_on:
            reasons.append('local_cloth_surface_is_viewed_near_edge_on')
        if visible:
            suggestion = ('resolve_collar_or_other_garment_identity' if any(c['collar_like_hint'] for c in local_matches)
                          else 'obtain_another_view_and_verify_opening_identity')
        elif not len(points):
            suggestion = 'obtain_valid_local_depth' if colored else 'reacquire_grasp_region_in_robot_camera'
        else:
            suggestion = 'change_camera_view_or_consider_guarded_wrist_reorientation_for_observation'
        sampled = _sample(points, cameras, pixels)
        boundary = labels > 0
        boundary_samples = _sample(points[boundary], cameras[boundary], pixels[boundary])
        reports.append(dict(grasp_index=index, grasp_world=grasps[index].tolist(),
            observed_cloth_point_count=int(len(points)), observed_boundary_point_count=int(boundary.sum()),
            external_image_boundary_point_count=int(np.count_nonzero(labels == 1)),
            internal_image_boundary_point_count=int(np.count_nonzero(labels == 2)),
            cloth_samples=sampled, boundary_samples=boundary_samples,
            boundary_kind='unclassified_image_boundary; silhouette and hole outlines are not sleeve labels',
            point_count_basis='valid source pixels, not unique cloth vertices or independent evidence',
            source_cameras=sorted({_CAMERAS[int(c)][0] for c in cameras}), views=region['views'],
            depth_supported_opening_candidates=local_matches,
            ambiguous_candidate_indices=ambiguous[index], opening_visible_in_rgbd=visible,
            geometric_alignment_observable=visible,
            alignment_scope='candidate center and normal only; no hand/sleeve alignment authorization',
            physical_entrance_verified=False, sleeve_identity_verified=False,
            safe_for_insertion=False, next_observation=suggestion,
            observation_suggestion_only=True, motion_requires_separate_guarded_controller=True,
            reasons=reasons))
    return dict(grasp_regions=reports,
        both_regions_have_depth_supported_opening=all(r['opening_visible_in_rgbd'] for r in reports),
        sleeve_pair_verified=False, physical_entries_verified=False, insertion_allowed=False,
        cross_view_identity_verified=False, unmatched_opening_candidate_indices=unmatched,
        candidate_indices_scope='frame_local_to_this_diagnostic_call; never join to separately cached opening detections',
        opening_candidate_rejections=dict(openings['rejected_candidate_counts']),
        opening_rejection_scope='all four robot cameras; rejection counts are not localized to a grasp',
        radius_m=float(radius), opening_match_radius_m=float(match_radius), cameras_used=[1, 2, 3, 4],
        read_only=True, limitations=('Blue/yellow appearance is a scene assumption. Closed image holes with '
            'background depth may be folds or another garment opening. Missing depth or side views cause '
            'abstention. No garment topology, cuff identity, clear insertion path, attachment or dressing claim.'))


def observe_sleeve_regions(obs, grasp_points_world, **kwargs):
    """Alias for callers treating this report as a read-only observation."""
    return diagnose_sleeve_observability(obs, grasp_points_world, **kwargs)
