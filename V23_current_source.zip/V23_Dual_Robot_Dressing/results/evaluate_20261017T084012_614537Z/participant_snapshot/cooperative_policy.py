"""Experimental V23: frozen V22 pickup followed by public RGB-D cooperation.

No task truth, scores, seed, or simulator API is an input to this controller.
Visual grasp checks are hypotheses, never official success labels.
"""
import importlib.util
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen_v22'
sys.path.insert(0, str(FROZEN))
from geometry import rotation, yaw_tilt
from frozen_pickup.execution import GripperExecution
from public_vision import cloth_cloud, helper_grasp_target, grasp_world, world_to_base
from human_targets import estimate_hands
from opening_candidates import detect_opening_candidates
from cloth_patch_tracker import ClothPatchTracker
from cooperative_transport import RigidPairTransport
from routed_pair_transport import RoutedPairTransport
from sleeve_observation import diagnose_sleeve_observability
from forearm_surface import estimate_forearm_surfaces
from grasp_pair_alignment import GraspPairAlignment
from active_view_planner import CandidateActiveViewPlanner
from distal_staging import plan_distal_staging, constrain_staging_to_lift_reach
from sleeve_probe import propose_sleeve_probe


def baseline_class():
    name = '_v23_unchanged_v22'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, FROZEN / 'policy.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name].Policy


def wrapped_angle(a):
    return float((a + np.pi) % (2 * np.pi) - np.pi)


def bounded(vector, maximum):
    v = np.asarray(vector, dtype=float)
    return v * min(1.0, maximum / max(float(np.linalg.norm(v)), 1e-9))


class Policy:
    VERSION = 'v23_07_hanging'
    SINGLE_HELPER_LIFT = True
    ALIGN_SLEEVE_SIDE_PAIR = False
    USE_DISTAL_SURFACE_STAGING = False
    HAND_CACHE_MAX_AGE_S = 90.
    METHOD = 'unchanged V22 pickup; anchored RGB-D helper grasp; fixed feature lift check; synchronized base transport'

    def __init__(self, checkpoint, device=None):
        self.baseline = baseline_class()(checkpoint, device=device)
        self.execution = GripperExecution(30)
        self.step = self.phase_steps = self.stable = self.lost = 0
        self.phase = 'v22_pickup'
        self.active = self.helper = None
        self.failure = None
        self.target = self.helper_base_goal = self.helper_yaw = None
        self.active_hold = None
        self.grasp_references = None
        self.helper_patch_before_lift = None
        self.patch_tracker = ClothPatchTracker()
        self.patch_tracking = {}
        self.dual_targets = None
        self.previous_action = np.zeros((2, 9), np.float32)
        self.target_info = {}
        self.hands = {}
        self.hand_observation_time = None
        self.forearm_surfaces = {}
        self.openings = {}
        self.sleeve_observability = {}
        self.visual_dual_grasp_candidate = False
        self.approach_waypoints = None
        self.transport = None
        self.transport_debug = {}
        self.pair_alignment = None
        self.pair_alignment_debug = {}
        self.active_view_planner = CandidateActiveViewPlanner()
        self.active_view_recommendation = {}
        self.staging_plan = {}
        self.sleeve_probe_proposal = {}
        self.debug = {}

    def change(self, phase):
        self.phase, self.phase_steps, self.stable, self.lost = phase, 0, 0, 0

    def fail(self, reason):
        self.failure = str(reason)
        self.change('stopped')

    def track_grasp(self, obs, action, robot, target, speed=.045, allow_base=True):
        """Own-pose servo in metres; yaw and all wrist angles remain held."""
        p = world_to_base(obs, robot, target)
        grasp = np.asarray(obs['grasp_pose_base'])[robot, :3]
        error = p - grasp
        action[robot, 3] = np.clip(1.8 * error[2], -speed, speed) / 1.54
        action[robot, 4] = np.clip(1.8 * error[0], -speed, speed) / 1.21
        if allow_base:
            action[robot, 1] = np.clip(1.2 * error[1], -min(speed, .035), min(speed, .035)) / .616
            if p[0] > .85 or p[0] < .48:
                action[robot, 0] = np.clip(1.0 * (p[0] - .66), -speed, speed) / .616
        return error

    def plan_helper_base(self, obs):
        base = np.asarray(obs['base_pose_world'])[self.helper, :3]
        delta = self.target[:2] - base[:2]
        self.helper_yaw = float(np.arctan2(delta[1], delta[0]))
        c, s = np.cos(self.helper_yaw), np.sin(self.helper_yaw)
        # Published gripper has a small lateral offset from the arm axis.
        lateral = float(np.asarray(obs['grasp_pose_base'])[self.helper, 1])
        offset = np.array([c * .66 - s * lateral, s * .66 + c * lateral])
        self.helper_base_goal = self.target[:2] - offset

    def update_target(self, obs):
        previous = self.target_info if self.target_info else None
        info = helper_grasp_target(obs, self.active, self.helper, previous=previous)
        self.target_info = info
        candidate = info.get('target_world')
        if candidate is None:
            self.lost += 1
            return False
        value = np.asarray(candidate, dtype=float)
        if value.shape != (3,) or not np.isfinite(value).all():
            raise ValueError('invalid public visual target')
        self.target = value
        self.lost = 0
        return True

    def cloth_distance(self, obs, point):
        cloud = cloth_cloud(obs)
        points = np.asarray(cloud['world_points'])
        if not len(points):
            return None
        return float(np.min(np.linalg.norm(points - point, axis=1)))

    def begin_hand_span_alignment(self, obs):
        """Match measured hand span at the current staging midpoint, not on skin.

        Sleeve-side fabric grasps are not cuff centres. This only prepares a
        bounded fabric shape hypothesis; it never inserts either hand.
        """
        now = float(np.asarray(obs['simulation_time_s']).item())
        if (not self.hands.get('detected') or self.hand_observation_time is None or
                not 0 <= now-self.hand_observation_time <= self.HAND_CACHE_MAX_AGE_S):
            raise ValueError('no recent measured hand pair for fabric-span alignment')
        hands = np.asarray(self.hands['hand_points_world'], dtype=float)
        current = np.stack([grasp_world(obs, r) for r in (0, 1)])
        if hands.shape != (2, 3) or not np.isfinite(hands).all():
            raise ValueError('invalid measured hand pair for fabric-span alignment')
        midpoint = current.mean(axis=0)
        difference = midpoint-hands.mean(axis=0)
        gap = float(np.linalg.norm(difference if self.staging_plan.get('selected') else difference[:2]))
        if not .25 <= gap <= .40:
            raise ValueError('fabric-span alignment requires hand staging gap .25..40m')
        relative = hands-hands.mean(axis=0)
        goals = min((midpoint+relative, midpoint+relative[::-1]),
                    key=lambda points: float(np.linalg.norm(points-current, axis=1).sum()))
        self.pair_alignment = GraspPairAlignment(obs, goals)
        if self.pair_alignment.failure:
            raise ValueError('fabric-span alignment: '+self.pair_alignment.failure)
        self.approach_waypoints = goals.copy()
        self.change('dual_align_hand_span')

    def __call__(self, obs):
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        parent_debug = self.baseline.debug
        distance = None
        visibility_hold = False
        pair_motion_hold = False
        constrained_motion = False
        try:
            if self.step % 20 == 0:
                observation = estimate_hands(obs)
                if observation.get('detected'):
                    # The mannequin is stationary in this task. Retain a measured
                    # hand pair when turning toward the cloth; never invent one.
                    points = np.asarray(observation['hand_points_world'])
                    agrees = True
                    if self.hands.get('detected'):
                        previous = np.asarray(self.hands['hand_points_world'])
                        agrees = min(np.max(np.linalg.norm(points - previous, axis=1)),
                                     np.max(np.linalg.norm(points[::-1] - previous, axis=1))) <= .12
                    if agrees:
                        self.hands = observation
                        self.hand_observation_time = float(np.asarray(obs['simulation_time_s']).item())
                        self.forearm_surfaces = estimate_forearm_surfaces(obs, points)
                        self.forearm_surfaces['observation_time_s'] = self.hand_observation_time
                if self.phase != 'v22_pickup':
                    self.openings = detect_opening_candidates(obs)
                if self.phase in ('dual_hold', 'dual_position_before_hands', 'dual_align_hand_span', 'await_sleeve_geometry'):
                    self.sleeve_observability = diagnose_sleeve_observability(
                        obs, np.stack([grasp_world(obs, r) for r in (0, 1)]))
            if self.phase == 'v22_pickup':
                action = self.baseline(obs)
                parent_debug = self.baseline.debug
                if self.baseline.failure:
                    self.fail('baseline: ' + self.baseline.failure)
                elif self.baseline.parent.stage == 'carry_hold':
                    self.active = int(self.baseline.active)
                    self.helper = 1 - self.active
                    self.active_hold = grasp_world(obs, self.active).copy()
                    self.change('helper_locate')
            elif self.phase != 'stopped':
                poses = np.asarray(obs['base_pose_world'])
                yaw, tilt = yaw_tilt(poses)
                if np.max(tilt) > .065:
                    raise ValueError('base tilt exceeds cooperative motion guard')
                if np.linalg.norm(poses[0, :2] - poses[1, :2]) < .48:
                    raise ValueError('robot bases too close')
                closed = np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
                if not closed[self.active]:
                    raise ValueError('original holder gripper opened')
                if self.phase in ('helper_test_lift', 'dual_hold', 'dual_position_before_hands', 'dual_align_hand_span', 'await_sleeve_geometry') and not closed[self.helper]:
                    raise ValueError('helper gripper opened after closing')
                self.track_grasp(obs, action, self.active, self.active_hold, .025, False)
                h = self.helper
                if self.phase == 'helper_locate':
                    action[h, 8] = -1
                    if self.update_target(obs):
                        self.stable += 1
                        if self.stable >= 5:
                            self.plan_helper_base(obs)
                            self.change('helper_travel')
                    else:
                        # Look toward the holder using public robot poses.
                        delta = self.active_hold[:2] - poses[h, :2]
                        error = wrapped_angle(np.arctan2(delta[1], delta[0]) - yaw[h])
                        action[h, 2] = np.clip(error, -.20, .20) / 2.86
                        self.stable = 0
                elif self.phase == 'helper_travel':
                    visible = self.update_target(obs)
                    visibility_hold = not visible
                    if self.lost > 60:
                        raise ValueError('lost visual free edge during helper travel')
                    action[h, 8] = -1
                    delta = self.helper_base_goal - poses[h, :2]
                    c, s = np.cos(yaw[h]), np.sin(yaw[h])
                    local = np.array([c * delta[0] + s * delta[1], -s * delta[0] + c * delta[1]])
                    yaw_error = wrapped_angle(self.helper_yaw - yaw[h])
                    action[h, 2] = np.clip(1.2 * yaw_error, -.25, .25) / 2.86
                    if abs(yaw_error) < .30:
                        action[h, :2] = bounded(1.1 * local, .10) / .616
                    desired_height = np.clip(self.target[2] + .10, .35, 1.34)
                    grip_z = grasp_world(obs, h)[2]
                    action[h, 3] = np.clip(1.8 * (desired_height - grip_z), -.09, .09) / 1.54
                    self.stable = self.stable + 1 if visible and np.linalg.norm(delta) < .025 and abs(yaw_error) < .035 else 0
                    if self.stable >= 10:
                        self.change('helper_pregrasp')
                elif self.phase in ('helper_pregrasp', 'helper_align'):
                    visible = self.update_target(obs)
                    visibility_hold = not visible
                    if self.lost > 60:
                        raise ValueError('lost visual free edge before grasp')
                    goal = self.target + np.array([0., 0., .09])
                    error = self.track_grasp(obs, action, h, goal, .045)
                    action[h, 8] = -1
                    self.stable = self.stable + 1 if visible and np.linalg.norm(error) < .012 else 0
                    if self.stable >= 12:
                        self.change('helper_touch')
                elif self.phase == 'helper_touch':
                    # Freeze the last measured surface target during final approach.
                    cloud = np.asarray(cloth_cloud(obs)['world_points'])
                    visible = bool(len(cloud) and np.min(np.linalg.norm(cloud - self.target, axis=1)) < .05)
                    visibility_hold = not visible
                    self.lost = 0 if visible else self.lost + 1
                    if self.lost > 60:
                        raise ValueError('free edge no longer visible during final approach')
                    goal = self.target + np.array([0., 0., .018])
                    error = self.track_grasp(obs, action, h, goal, .018)
                    action[h, 8] = -1
                    self.stable = self.stable + 1 if visible and np.linalg.norm(error) < .009 else 0
                    if self.stable >= 10:
                        distance = self.cloth_distance(obs, grasp_world(obs, h))
                        if distance is None or distance > .07:
                            raise ValueError('no visible cloth near helper gripper at close')
                        self.change('helper_close')
                elif self.phase == 'helper_close':
                    action[h, 8] = 1
                    if closed[h] and self.execution.stable[h] >= 30:
                        self.grasp_references = np.stack([grasp_world(obs, r) for r in range(2)])
                        cloud = np.asarray(cloth_cloud(obs)['world_points'])
                        patch = cloud[np.linalg.norm(cloud - self.grasp_references[h], axis=1) < .08]
                        if len(patch) < 12:
                            raise ValueError('insufficient visible cloth to verify helper test lift')
                        self.helper_patch_before_lift = np.median(patch, axis=0)
                        if self.SINGLE_HELPER_LIFT:
                            self.patch_tracking = self.patch_tracker.reset(obs, self.grasp_references[h], radius=.12)
                            if not self.patch_tracking['reliable']:
                                raise ValueError('insufficient fixed cloth features for helper lift verification')
                        self.change('helper_test_lift')
                elif self.phase == 'helper_test_lift':
                    goal = self.grasp_references[h] + np.array([0., 0., .04])
                    error = self.track_grasp(obs, action, h, goal, .012, False)
                    distance = self.cloth_distance(obs, grasp_world(obs, h))
                    near = distance is not None and distance < .055
                    # Same initial image features, not points reselected inside
                    # a translated sphere (which falsely passes static fabric).
                    self.patch_tracking = self.patch_tracker.update(obs)
                    moved = False
                    if self.patch_tracking['reliable']:
                        displacement = np.asarray(self.patch_tracking['median_displacement_world'])
                        moved = displacement[2] >= .018 and np.linalg.norm(displacement[:2]) < .045
                    self.lost = 0 if self.patch_tracking['reliable'] else self.lost + 1
                    if self.lost >= 40:
                        raise ValueError('lost original cloth features during helper lift verification')
                    self.stable = self.stable + 1 if np.linalg.norm(error) < .012 and closed[h] and near and moved else 0
                    if self.stable >= 20:
                        self.visual_dual_grasp_candidate = True
                        self.dual_targets = np.stack([grasp_world(obs, r) for r in range(2)])
                        self.change('dual_hold')
                elif self.phase == 'dual_hold':
                    for r in range(2):
                        self.track_grasp(obs, action, r, self.dual_targets[r], .018, False)
                    if self.phase_steps >= 60:
                        now = float(np.asarray(obs['simulation_time_s']).item())
                        recent = self.hand_observation_time is not None and now - self.hand_observation_time <= self.HAND_CACHE_MAX_AGE_S
                        if self.hands.get('detected') and recent:
                            hands = np.asarray(self.hands['hand_points_world'])
                            # Position held cloth in front of observed hands. This is
                            # staging only; no unobserved sleeve axes are invented.
                            mid = np.mean(hands, axis=0)
                            cloth_mid = np.mean(self.dual_targets, axis=0)
                            staging_mid = None
                            if self.USE_DISTAL_SURFACE_STAGING:
                                # Before contact with the mannequin, retain the
                                # actual earlier surface observations under the
                                # declared stationary-human assumption. Their
                                # original times and weak-view status remain in
                                # diagnostics. This is a waiting pose, not entry.
                                self.staging_plan = plan_distal_staging(obs, self.hands,
                                    self.forearm_surfaces,
                                    hand_observation_time_s=self.hand_observation_time,
                                    max_age_s=self.HAND_CACHE_MAX_AGE_S,
                                    stationary_human=True)
                                if self.staging_plan['available']:
                                    self.staging_plan = constrain_staging_to_lift_reach(
                                        obs, self.staging_plan, self.hands)
                                self.staging_plan['selected'] = bool(self.staging_plan['available'])
                                if self.staging_plan['selected']:
                                    staging_mid = np.asarray(self.staging_plan['target_grasp_midpoint_world'])
                                else:
                                    self.staging_plan['fallback'] = 'radial waiting pose; no inferred insertion direction'
                            if staging_mid is None:
                                direction = bounded((cloth_mid - mid) * np.array([1., 1., 0.]), 1.)
                                norm = np.linalg.norm(direction)
                                if norm < .05:
                                    raise ValueError('ambiguous approach to observed hands')
                                staging_mid = mid + .30 * direction / norm
                            shift = staging_mid - cloth_mid
                            self.transport = RoutedPairTransport(obs, shift, max_speed=.035)
                            self.approach_waypoints = self.transport.grasp0 + shift
                            self.change('dual_position_before_hands')
                        elif self.phase_steps > 200:
                            raise ValueError('cannot visually locate both mannequin hands')
                elif self.phase == 'dual_position_before_hands':
                    if self.transport is None:
                        raise ValueError('synchronous pair transport has not been initialized')
                    result = self.transport.step(obs)
                    self.transport_debug = result['debug']
                    if result['failure']:
                        raise ValueError(result['failure'])
                    action = result['action']
                    constrained_motion = True
                    pair_motion_hold = self.transport_debug.get('navigation_paused_pair', False)
                    if result['done']:
                        if self.ALIGN_SLEEVE_SIDE_PAIR:
                            self.begin_hand_span_alignment(obs)
                        else:
                            self.change('await_sleeve_geometry')
                elif self.phase == 'dual_align_hand_span':
                    if self.pair_alignment is None:
                        raise ValueError('fabric-span alignment was not initialized')
                    result = self.pair_alignment.step(obs)
                    self.pair_alignment_debug = result['debug']
                    if result['failure']:
                        raise ValueError(result['failure'])
                    action = result['action']
                    constrained_motion = True
                    pair_motion_hold = result['debug'].get('navigation_paused_pair', False)
                    if result['done']:
                        self.change('await_sleeve_geometry')
                elif self.phase == 'await_sleeve_geometry':
                    # Freeze both targets after staging; no unguarded base servo
                    # is allowed to resume while waiting for sleeve evidence.
                    action[:, :8] = 0
                    action[:, 8] = 1
                    constrained_motion = True
                    if self.phase_steps % 2 == 0:
                        grasp_points = np.stack([grasp_world(obs, r) for r in (0, 1)])
                        self.sleeve_observability = diagnose_sleeve_observability(obs, grasp_points)
                        self.active_view_recommendation = self.active_view_planner.recommend(
                            obs, grasp_points, self.sleeve_observability)
                        # Fresh geometry-only proposal. Execution and checking
                        # the actual fabric response are not implemented here;
                        # this revision still stops at this development stage.
                        fresh_hands = estimate_hands(obs)
                        if fresh_hands.get('detected'):
                            fresh_surfaces = estimate_forearm_surfaces(obs, fresh_hands['hand_points_world'])
                            fresh_surfaces['observation_time_s'] = float(obs['simulation_time_s'])
                            self.sleeve_probe_proposal = propose_sleeve_probe(obs, grasp_points,
                                self.sleeve_observability, fresh_hands, fresh_surfaces)
                        else:
                            self.sleeve_probe_proposal = dict(recommendation='hold',
                                reason='current_public_hand_pair_unavailable', motion_executor_included=False)
                else:
                    raise ValueError('unknown cooperative phase: ' + self.phase)
                phase_limit = 12000 if self.phase == 'dual_position_before_hands' else 1200
                if self.phase not in ('await_sleeve_geometry', 'stopped') and self.phase_steps > phase_limit:
                    raise ValueError('cooperative phase timed out: ' + self.phase)
                # Rate limit movement channels, never smear discrete gripper intents.
                if not constrained_motion:
                    action[:, :8] = self.previous_action[:, :8] + np.clip(action[:, :8] - self.previous_action[:, :8], -.012, .012)
                if visibility_hold:
                    action[self.helper, :8] = 0
                if pair_motion_hold:
                    action[:, :8] = 0
                action = self.execution.apply(obs, action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as exc:
            self.fail(str(exc))
        if self.failure:
            action[:] = 0
        action = np.clip(action, -1, 1).astype(np.float32)
        if action.shape != (2, 9) or not np.isfinite(action).all():
            self.fail('invalid action')
            action = np.zeros((2, 9), np.float32)
        self.previous_action = action.copy()
        self.debug = dict(version=self.VERSION, method=self.METHOD, step=self.step,
            phase=self.phase, phase_steps=self.phase_steps, failure=self.failure,
            active_robot=self.active, helper_robot=self.helper, idle_mode=self.phase,
            parent_debug=parent_debug, visual_target=self.target_info,
            helper_target_world=self.target, helper_base_goal=self.helper_base_goal,
            visual_cloth_distance_to_helper_m=distance,
            visual_dual_grasp_candidate=self.visual_dual_grasp_candidate,
            human_hand_estimate=self.hands, hand_observation_time_s=self.hand_observation_time,
            public_forearm_surface_candidates=self.forearm_surfaces,
            public_opening_candidates=self.openings, checkpoint_is_frozen=True,
            sleeve_observability=self.sleeve_observability,
            helper_fixed_feature_tracking=self.patch_tracking,
            synchronous_transport=self.transport_debug,
            fabric_span_alignment=self.pair_alignment_debug,
            active_view_recommendation=self.active_view_recommendation,
            staging_plan=self.staging_plan,
            sleeve_probe_proposal=self.sleeve_probe_proposal,
            new_network_training=False, complete_dressing_claimed=False)
        return action
