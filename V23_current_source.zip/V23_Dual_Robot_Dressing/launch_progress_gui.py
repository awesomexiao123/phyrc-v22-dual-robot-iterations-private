"""Open the frozen best verified dual carry demonstration in a visible window."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

from run_experiment import ROOT, IMAGE, verify


def main():
    lock = (ROOT / 'cache/runtime.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    verify()
    display = os.environ.get('DISPLAY')
    if not display:
        raise RuntimeError('No graphical desktop DISPLAY')
    previous = ROOT / 'results/evaluate_20261017T084012_614537Z'
    original = json.loads((previous / 'launch.json').read_text())
    snapshot = previous / 'participant_snapshot'
    for name, digest in original['source_sha256'].items():
        if hashlib.sha256((snapshot / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Verified demonstration source changed: ' + name)
    run_id = 'demo_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out = ROOT / 'results' / run_id
    out.mkdir(mode=0o770)
    out.chmod(0o770)
    # FamilyWild cookie permits the existing container UID to reach this desktop.
    # The temporary cookie remains group-readable only, never world-readable.
    auth = ROOT / 'cache' / 'gui.xauth'
    raw = subprocess.check_output(['xauth', 'nlist', display], text=True)
    if not raw.strip():
        raise RuntimeError('No X11 authentication record for desktop')
    auth.touch(mode=0o640, exist_ok=True)
    auth.chmod(0o640)
    entries = '\n'.join('ffff' + line[4:] for line in raw.splitlines()) + '\n'
    subprocess.run(['xauth', '-f', str(auth), 'nmerge', '-'], input=entries, text=True, check=True)
    # xauth replaces its output with mode 0600; restore container group access.
    auth.chmod(0o640)
    runner = out / 'show_dual_progress.py'
    shutil.copy2(ROOT / runner.name, runner)
    command = list(original['command'])
    image_at = command.index(IMAGE)
    command = command[:image_at]
    command[command.index('--name') + 1] = 'v23-dual-' + run_id.lower()
    command = [arg.replace('STRETCH4_HEADLESS=1', 'STRETCH4_HEADLESS=0')
               .replace('/output/' + previous.name + '/', '/output/' + run_id + '/')
               for arg in command]
    command += ['-e', 'DISPLAY=' + display, '-e', 'XAUTHORITY=/tmp/demo.xauth',
                '-e', 'STRETCH4_AUTO_EVALUATE=0',
                '-v', '/tmp/.X11-unix:/tmp/.X11-unix:ro',
                '-v', str(auth) + ':/tmp/demo.xauth:ro',
                '-v', str(runner) + ':/demo/runner.py:ro',
                IMAGE, '/demo/runner.py', '/output/' + run_id]
    manifest = dict(run_id=run_id, purpose='user_requested_visible_progress_demonstration',
                    based_on=previous.name, source_snapshot=str(snapshot),
                    policy_variant=original['variant'], seed=1401,
                    recording=False, full_dressing_success=False,
                    include_in_evaluation_statistics=False,
                    runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(), command=command)
    (out / 'launch.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with (out / 'console.log').open('w') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True, pass_fds=(lock.fileno(),))
    (out / 'pid.json').write_text(json.dumps(dict(docker_pid=process.pid)) + '\n')
    (ROOT / 'results/latest_demo.txt').write_text(str(out) + '\n')
    print(json.dumps(dict(status='loading', pid=process.pid, directory=str(out)), ensure_ascii=False))


if __name__ == '__main__':
    main()
