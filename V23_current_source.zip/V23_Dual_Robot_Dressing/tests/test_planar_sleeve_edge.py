"""Public saved-observation checks; no claim about physical cuff attachment."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import planar_sleeve_edge as edge
from human_targets import _validated, _world_pixels
from planar_shirt import estimate_planar_shirt


def observation():
    with np.load(ROOT/'participant/sample_observation.npz', allow_pickle=False) as archive:
        return {key: archive[key].copy() for key in archive.files}


class PlanarSleeveEdgeTests(unittest.TestCase):
    def test_sample_proposes_measured_8_to_25mm_inset_points(self):
        obs = observation()
        result = edge.estimate_planar_sleeve_edges(obs)
        self.assertTrue(result['detected'], result['edge_refinement_diagnostics'])
        self.assertEqual(len(result['candidates']), 2)
        self.assertEqual(result['proposal_version'], 'public_lateral_edge_inset_v1')
        for candidate in result['candidates']:
            self.assertGreaterEqual(candidate['actual_lateral_inset_m'], .008)
            self.assertLessEqual(candidate['actual_lateral_inset_m'], .025)
            self.assertGreaterEqual(candidate['nearest_supported_blue_boundary_distance_m'], .008)
            self.assertLessEqual(candidate['nearest_supported_blue_boundary_distance_m'], .025)
            self.assertGreaterEqual(candidate['support_pixel_count'], 6)
            self.assertGreaterEqual(candidate['support_unique_voxels'], 6)
            self.assertFalse(candidate['patch_recentered'])
            self.assertFalse(candidate['target_interpolated'])
            self.assertTrue(candidate['pixel_quantization_respected'])
            # Saved camera pixels support about20mm, rather than inventing15mm.
            self.assertAlmostEqual(candidate['actual_lateral_inset_m'], .020, delta=.001)

    def test_targets_and_original_edges_reconstruct_from_exact_public_pixels(self):
        obs = observation(); values = _validated(obs, wrists=True)
        result = edge.estimate_planar_sleeve_edges(obs)
        for candidate in result['candidates']:
            camera = candidate['camera_index']
            u, v = candidate['source_pixel_uv']
            z = obs['depth'][camera, v, u, 0]
            point = _world_pixels(values, camera, np.array([u]), np.array([v]), np.array([z]))[0]
            np.testing.assert_allclose(point, candidate['target_world'], atol=1e-10)
            boundary = candidate['boundary_evidence']
            u, v = boundary['source_pixel_uv']; z = obs['depth'][camera, v, u, 0]
            point = _world_pixels(values, camera, np.array([u]), np.array([v]), np.array([z]))[0]
            np.testing.assert_allclose(point, boundary['point_world'], atol=1e-10)
            self.assertEqual(boundary['measured_depth_z_m'], z)
            self.assertEqual(boundary['camera_index'], camera)
            self.assertEqual(boundary['observation_time_s'], float(obs['simulation_time_s']))
            self.assertTrue(boundary['exterior_depth_samples'])

    def test_report_and_observation_are_unmodified_and_original_candidates_preserved(self):
        obs = observation(); before = deepcopy(obs)
        original = estimate_planar_shirt(obs); original_before = deepcopy(original)
        result = edge.estimate_planar_sleeve_edges(obs, original)
        self.assertTrue(result['detected'])
        self.assertEqual(original, original_before)
        self.assertEqual(result['original_interior_candidates'], original['candidates'])
        self.assertEqual(result['plane'], original['plane'])
        self.assertEqual(result['hem_hypothesis'], original['hem_hypothesis'])
        self.assertEqual(result['collar_hypothesis'], original['collar_hypothesis'])
        for key in obs:
            np.testing.assert_array_equal(obs[key], before[key])

    def test_semantics_remain_unverified(self):
        result = edge.estimate_planar_sleeve_edges(observation())
        for key in ('cuff_edges_verified', 'physical_openings_verified', 'insertion_allowed', 'cross_time_identity_verified'):
            self.assertFalse(result[key])
        for candidate in result['candidates']:
            for key in ('opening_verified', 'cuff_edge_verified', 'grasp_success_verified', 'insertion_allowed'):
                self.assertFalse(candidate[key])
            self.assertTrue(candidate['heuristic'])
            self.assertIsNone(candidate['anatomical_side'])

    def test_same_pixels_are_deterministic_but_each_call_has_fresh_timestamp(self):
        obs = observation(); first = edge.estimate_planar_sleeve_edges(obs)
        obs['simulation_time_s'] += .05
        second = edge.estimate_planar_sleeve_edges(obs)
        for a, b in zip(first['candidates'], second['candidates']):
            self.assertEqual(a['source_pixel_uv'], b['source_pixel_uv'])
            self.assertEqual(a['boundary_evidence']['source_pixel_uv'], b['boundary_evidence']['source_pixel_uv'])
            self.assertEqual(a['camera_index'], b['camera_index'])
            self.assertNotEqual(a['boundary_evidence']['observation_time_s'], b['boundary_evidence']['observation_time_s'])

    def test_stale_supplied_geometry_cannot_authorize_a_target(self):
        obs = observation(); supplied = estimate_planar_shirt(obs)
        supplied['candidates'][0]['target_world'][0] += .01
        result = edge.estimate_planar_sleeve_edges(obs, supplied)
        self.assertFalse(result['detected'])
        self.assertEqual(result['candidates'], [])
        self.assertIn('does_not_match_current', result['reason'])

    def test_missing_depth_splits_reliable_arc_and_abstains(self):
        obs = observation()
        # Remove a middle distal-edge sample; do not close its missing gap.
        obs['depth_valid'][4, 121, 164, 0] = False
        result = edge.estimate_planar_sleeve_edges(obs)
        self.assertFalse(result['detected'], result)
        self.assertTrue(any('ambiguous_supported_distal' in d.get('reason', '')
                            for d in result['edge_refinement_diagnostics']))

    def test_foreground_outside_edge_cannot_masquerade_as_distal_silhouette(self):
        obs = observation()
        # Foreground obstacle outside the entire negative-side lateral rim.
        obs['depth'][4, 115:131, 164:170, 0] = .9
        result = edge.estimate_planar_sleeve_edges(obs)
        self.assertFalse(result['detected'], result)

    def test_invalid_outside_depth_cannot_be_gap_filled(self):
        obs = observation()
        obs['depth_valid'][4, 115:131, 164:170, 0] = False
        result = edge.estimate_planar_sleeve_edges(obs)
        self.assertFalse(result['detected'], result)

    def test_missing_depth_between_edge_and_target_is_not_bridged(self):
        obs = observation()
        obs['depth_valid'][4, 121, 163, 0] = False
        result = edge.estimate_planar_sleeve_edges(obs)
        for candidate in result['candidates']:
            camera = candidate['camera_index']
            strip = np.asarray(candidate['boundary_evidence']['inset_strip_source_pixels_uv'])
            self.assertTrue(np.all(obs['depth_valid'][camera, strip[:, 1], strip[:, 0], 0]))
            self.assertFalse(candidate['source_pixel_uv'] == [162, 121]
                             and candidate['boundary_evidence']['source_pixel_uv'] == [164, 121])

    def test_internal_blue_hole_is_counted_for_target_boundary_clearance(self):
        obs = observation()
        obs['rgb'][4, 121, 163] = 0
        result = edge.estimate_planar_sleeve_edges(obs)
        for candidate in result['candidates']:
            if candidate['camera_index'] == 4:
                self.assertNotEqual(candidate['source_pixel_uv'], [162, 121])
            strip = np.asarray(candidate['boundary_evidence']['inset_strip_source_pixels_uv'])
            color = obs['rgb'][candidate['camera_index'], strip[:, 1], strip[:, 0]].astype(float)
            self.assertTrue(np.all((color[:, 2] > 100) & (color[:, 2] > 1.25*color[:, 0])
                                   & (color[:, 2] > 1.25*color[:, 1])))

    def test_no_observed_pixel_in_requested_band_is_rejected_not_interpolated(self):
        with patch.object(edge, '_INSET', (.0149, .0151)):
            result = edge.estimate_planar_sleeve_edges(observation())
        self.assertFalse(result['detected'])
        self.assertEqual(result['candidates'], [])

    def test_unknown_original_planar_shape_never_refines(self):
        obs = observation(); obs['rgb'][:] = 0
        result = edge.estimate_planar_sleeve_edges(obs)
        self.assertFalse(result['detected'])
        self.assertEqual(result['candidates'], [])
        self.assertTrue(result['reason'].startswith('unknown_initial_planar_shirt'))

    def test_timestamp_and_overview_do_not_supply_geometry(self):
        obs = observation(); baseline = edge.estimate_planar_sleeve_edges(obs)
        obs['rgb'][0] = 255; obs['depth'][0] = .1; obs['depth_valid'][0] = True
        changed = edge.estimate_planar_sleeve_edges(obs)
        self.assertEqual([c['target_world'] for c in baseline['candidates']],
                         [c['target_world'] for c in changed['candidates']])
        obs['simulation_time_s'] = np.array(float('nan'))
        with self.assertRaises(ValueError):
            edge.estimate_planar_sleeve_edges(obs)

    def test_cyclic_arc_does_not_bridge_two_separate_supported_segments(self):
        runs = edge._cyclic_runs(np.array([True, True, False, True, True, False, False]))
        self.assertEqual([r.tolist() for r in runs], [[0, 1], [3, 4]])
        runs = edge._cyclic_runs(np.array([True, True, False, False, True, True]))
        self.assertEqual([r.tolist() for r in runs], [[4, 5, 0, 1]])


if __name__ == '__main__':
    unittest.main()
