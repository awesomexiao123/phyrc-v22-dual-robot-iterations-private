"""CPU boundary/guard tests with public observations; no learned model or GPU.

The feature and route stubs establish control-flow requirements, not physical
attachment, sleeve identity, navigation safety, or dressing success.
"""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import cooperative_policy as cooperative
import sleeve_pair_policy as sleeve
from contract_snapshot import load_contract, validate_observation
from public_vision import grasp_world


def observation():
    obs = dict(
        base_pose_world=np.array([[-1., 0, 0, 1, 0, 0, 0],
                                  [1., 0, 0, 1, 0, 0, 0]], np.float32),
        grasp_pose_base=np.array([[.6, -.1, 1., 1, 0, 0, 0],
                                   [.6, -.1, 1., 1, 0, 0, 0]], np.float32),
        gripper_close_command=np.zeros((2, 1), bool),
        fingertip_origin_distance=np.full((2, 1), .04, np.float32),
        joint_position=np.zeros((2, 13), np.float32),
        joint_velocity=np.zeros((2, 13), np.float32),
        base_twist_world=np.zeros((2, 6), np.float32),
        controller_target=np.zeros((2, 9), np.float32),
        previous_action=np.zeros((2, 9), np.float32),
        simulation_time_s=np.array(10., np.float64),
        rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.zeros((5, 256, 256, 1), np.float32),
        depth_valid=np.zeros((5, 256, 256, 1), bool))
    obs['fingertip_position_base'] = np.repeat(obs['grasp_pose_base'][:, None, :3], 2, axis=1)
    obs['fingertip_position_base'][:, 0, 1] += .02
    obs['fingertip_position_base'][:, 1, 1] -= .02
    return obs


class Baseline:
    """Mimic the frozen neural_approach -> refine_raise action boundary."""
    def __init__(self, *args, **kwargs):
        self.calls = self.observer_calls = 0
        self.failure = None
        self.debug = {}
        self.active, self.idle = 0, 1
        self.mode = 'search'
        self.transition = True
        self.executed_phase = 'neural_approach'
        self.parent = SimpleNamespace(stage='pickup', pickup=SimpleNamespace(
            phase='neural_approach', robot=0, debug={}))

    def __call__(self, obs):
        self.calls += 1
        self.parent.pickup.robot = self.active
        self.parent.pickup.debug['executed_phase'] = self.executed_phase
        action = np.zeros((2, 9), np.float32)
        action[self.idle, 2] = .07
        if self.transition:
            self.parent.pickup.phase = 'refine_raise'
        else:
            action[self.active, 0] = .03
        return action

    def _observe_idle(self, obs):
        self.observer_calls += 1
        return np.array([0., 0., .07])


def actor(obs, active=0, phase=None):
    with patch.object(cooperative, 'baseline_class', return_value=Baseline):
        policy = sleeve.Policy('unused-checkpoint')
    policy.baseline.active, policy.baseline.idle = active, 1-active
    if phase is not None:
        policy.handoff_done = True
        policy.active, policy.helper = active, 1-active
        policy.phase = phase
        policy.pair_targets = np.stack([grasp_world(obs, r) for r in (0, 1)]) - [0, 0, .12]
        policy.pair_base_goals = obs['base_pose_world'][:, :2] + [.15, 0]
        policy.pair_yaws = np.zeros(2)
        policy.execution.previous_closed[:] = obs['gripper_close_command'].reshape(2)
        policy.execution.stable[:] = 30
    return policy


def tracked(rise=.04, reliable=True):
    return dict(tracked_count=12 if reliable else 0, reliable=reliable,
                median_displacement_world=[0, 0, rise] if reliable else None,
                reason='synthetic fixed feature tracks', attachment_verified=False)


def transport_result(*, done=False, pause=False):
    action = np.zeros((2, 9), np.float32)
    action[:, 8] = 1.
    return dict(action=action, done=done, failure=None,
                debug={'navigation_paused_pair': pause})


def tick(obs):
    obs['simulation_time_s'][...] += .05


def integrate_public_action(obs, action, dt=.05):
    """Kinematic CPU feedback from the documented action units, not physics."""
    for robot in (0, 1):
        rotation = cooperative.rotation(obs['base_pose_world'][robot, 3:])
        world_velocity = rotation[:2, :2] @ (action[robot, :2]*.616)
        obs['base_pose_world'][robot, :2] += world_velocity*dt
        yaw = np.arctan2(rotation[1, 0], rotation[0, 0]) + action[robot, 2]*2.86*dt
        obs['base_pose_world'][robot, 3:] = [np.cos(yaw/2), 0., 0., np.sin(yaw/2)]
        obs['grasp_pose_base'][robot, 2] += action[robot, 3]*1.54*dt
        obs['grasp_pose_base'][robot, 0] += action[robot, 4]*1.21*dt
    obs['simulation_time_s'][...] += dt


class SleevePairTests(unittest.TestCase):
    def setUp(self):
        self.shirt = dict(detected=True, candidates=[
            {'target_world': [-.2, -.1, .8]}, {'target_world': [.2, -.1, .8]}])
        self.hands_patch = patch.object(cooperative, 'estimate_hands', return_value={'detected': False})
        self.shirt_patch = patch.object(sleeve, 'estimate_planar_shirt', return_value=self.shirt)
        self.hands_patch.start(); self.shirt_patch.start()
        self.addCleanup(self.hands_patch.stop); self.addCleanup(self.shirt_patch.stop)

    def test_fixture_matches_public_contract(self):
        validate_observation(observation(), load_contract(cooperative.FROZEN / 'policy_interface_snapshot.json'),
                             robots=2, joints=13, profile='actor_rgbd')

    def test_exact_preclose_handoff_clears_both_rows_and_never_calls_baseline_again(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(); policy = actor(obs, active)
                policy.previous_action[:, :8] = .2
                action = policy(obs)
                self.assertIsNone(policy.failure)
                self.assertTrue(policy.handoff_done)
                self.assertEqual((policy.active, policy.helper), (active, 1-active))
                self.assertEqual(policy.phase, 'pair_clear_raise')
                np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                np.testing.assert_array_equal(action[:, 8], -np.ones(2))
                self.assertFalse(obs['gripper_close_command'].any())
                for _ in range(4):
                    tick(obs); policy(obs)
                self.assertEqual(policy.baseline.calls, 1)
                self.assertEqual(policy.baseline.observer_calls, 4)

    def test_baseline_is_preserved_before_refinement_boundary(self):
        obs = observation(); policy = actor(obs)
        policy.baseline.transition = False
        action = policy(obs)
        self.assertFalse(policy.handoff_done)
        self.assertEqual(policy.phase, 'v22_pickup')
        self.assertAlmostEqual(action[0, 0], .03)
        self.assertAlmostEqual(action[1, 2], .07)

    def test_unloaded_helper_copies_measured_trained_pitch_with_grasp_height_compensation(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(); policy = actor(obs, active, 'pair_clear_raise')
                obs['joint_position'][active, 9] = .715
                origins = np.stack([grasp_world(obs, r) for r in (0, 1)])
                policy.pair_targets = origins-[0., 0., .25]
                first = policy(obs)
                self.assertEqual(policy.phase, 'pair_set_wrist')
                np.testing.assert_array_equal(first[:, :8], np.zeros((2, 8)))
                for _ in range(240):
                    action = policy(obs)
                    self.assertIsNone(policy.failure)
                    np.testing.assert_array_equal(action[:, [0, 1, 2, 5, 7]], np.zeros((2, 5)))
                    np.testing.assert_array_equal(action[:, 8], -np.ones(2))
                    self.assertLessEqual(np.max(np.abs(action[:, 6]*5.5)), .15000001)
                    if policy.phase == 'pair_clear_retract':
                        break
                    # Public-pose integration includes the real geometric
                    # coupling: pitching a forward 30cm wrist-to-grasp lever lowers
                    # its grasp center unless the lift compensates it.
                    old = obs['joint_position'][:, 9].copy()
                    new = old+action[:, 6]*5.5*.05
                    obs['joint_position'][:, 9] = new
                    obs['grasp_pose_base'][:, 0] += .30*(np.cos(new)-np.cos(old))
                    obs['grasp_pose_base'][:, 2] -= .30*(np.sin(new)-np.sin(old))
                    integrate_public_action(obs, action)
                self.assertEqual(policy.phase, 'pair_clear_retract')
                np.testing.assert_allclose(obs['joint_position'][:, 9], .715, atol=.005)
                final = np.stack([grasp_world(obs, r) for r in (0, 1)])
                np.testing.assert_allclose(final[:, [0, 2]], origins[:, [0, 2]], atol=.008)
                self.assertEqual(policy.wrist_pitch_goal, float(obs['joint_position'][active, 9]))

    def test_wrist_alignment_cannot_rotate_a_closed_gripper(self):
        obs = observation(); policy = actor(obs, phase='pair_set_wrist')
        policy.wrist_pitch_goal = .715
        policy.wrist_hold_centers = np.stack([grasp_world(obs, r) for r in (0, 1)])
        obs['gripper_close_command'][1] = True
        action = policy(obs)
        self.assertIn('both grippers open', policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_forward_deflection_near_cloth_stops_before_pushing_further(self):
        obs = observation(); policy = actor(obs, phase='pair_touch')
        policy.pair_targets = np.stack([grasp_world(obs, r) for r in (0, 1)])-[0, 0, .024]
        policy.pair_targets[0, 0] += .016
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': policy.pair_targets.copy()}):
            action = policy(obs)
        self.assertIn('forward alignment displaced', policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_missed_first_refine_raise_boundary_is_rejected(self):
        obs = observation(); policy = actor(obs)
        policy.baseline.executed_phase = 'refine_raise'
        action = policy(obs)
        self.assertIsNotNone(policy.failure)
        self.assertEqual(policy.phase, 'stopped')
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_handoff_rejects_either_already_closed_gripper(self):
        for closed_robot in (0, 1):
            with self.subTest(closed_robot=closed_robot):
                obs = observation(); obs['gripper_close_command'][closed_robot] = True
                policy = actor(obs)
                np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
                self.assertIn('before either gripper closes', policy.failure)

    def test_survey_only_routes_observer_to_helper_for_both_roles(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(); policy = actor(obs, active, 'pair_survey')
                action = policy(obs)
                self.assertIsNone(policy.failure)
                np.testing.assert_array_equal(action[active, :8], np.zeros(8))
                np.testing.assert_array_equal(action[1-active, [0, 1, 3, 4, 5, 6, 7]], np.zeros(7))
                self.assertGreater(action[1-active, 2], 0)
                np.testing.assert_array_equal(action[:, 8], -np.ones(2))
                self.assertEqual(policy.baseline.calls, 0)

    def test_observer_exception_stops_pair(self):
        obs = observation(); policy = actor(obs, phase='pair_survey')
        policy.previous_action[:, :8] = .08
        with patch.object(policy.baseline, '_observe_idle', side_effect=ValueError('idle_public_base_drift')):
            action = policy(obs)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))
        self.assertIn('idle_public_base_drift', policy.failure)

    def prepare_survey_exit(self, obs, policy):
        policy.hands = {'detected': True, 'hand_points_world': [[0, 0, 1.3], [0, .36, 1.3]]}
        policy.hand_observation_time = float(obs['simulation_time_s'])
        policy.baseline.mode = 'view_hold'

    def test_unreachable_table_side_route_stops_both_and_stays_stopped(self):
        for unreachable_robot in (0, 1):
            with self.subTest(unreachable_robot=unreachable_robot):
                obs = observation(); policy = actor(obs, phase='pair_survey')
                self.prepare_survey_exit(obs, policy)
                policy.previous_action[:, :8] = .08
                def route(observation, robot, goal, **kwargs):
                    return dict(feasible=robot != unreachable_robot, reason='enclosed table side',
                                waypoints_world_xy=[observation['base_pose_world'][robot, :2], goal])
                with patch.object(sleeve, 'plan_base_route', side_effect=route):
                    action = policy(obs)
                np.testing.assert_array_equal(action, np.zeros((2, 9)))
                self.assertIn('no public-depth route', policy.failure)
                np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
                self.assertEqual(policy.baseline.calls, 0)

    def test_survey_route_transition_drops_old_observer_motion(self):
        obs = observation(); policy = actor(obs, phase='pair_survey')
        self.prepare_survey_exit(obs, policy)
        policy.previous_action[policy.helper, 2] = .07
        def route(observation, robot, goal, **kwargs):
            return dict(feasible=True, reason='stub unobserved route',
                        waypoints_world_xy=[observation['base_pose_world'][robot, :2], goal])
        with patch.object(sleeve, 'plan_base_route', side_effect=route):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'pair_navigate')
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_loss_of_either_original_patch_stops_both_without_smoothing_leak(self):
        for phase in ('pair_pregrasp', 'pair_touch'):
            for missing in (0, 1):
                with self.subTest(phase=phase, missing=missing):
                    obs = observation(); policy = actor(obs, phase=phase)
                    policy.previous_action[:, :8] = .08
                    cloud = policy.pair_targets[[1-missing]].copy()
                    with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': cloud}):
                        action = policy(obs)
                    self.assertIsNone(policy.failure)
                    self.assertEqual(policy.lost, 1)
                    np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                    np.testing.assert_array_equal(action[:, 8], -np.ones(2))

    def test_pregrasp_fifteen_mm_lateral_errors_require_measured_base_convergence(self):
        for active in (0, 1):
            for yaws in ((0., np.pi/2), (np.pi, -np.pi/2)):
                for sign in (-1, 1):
                    with self.subTest(active=active, yaws=yaws, sign=sign):
                        obs = observation()
                        for robot, yaw in enumerate(yaws):
                            obs['base_pose_world'][robot, 3:] = [np.cos(yaw/2), 0, 0, np.sin(yaw/2)]
                        policy = actor(obs, active, 'pair_pregrasp')
                        initial_bases = obs['base_pose_world'].copy()
                        rotations = [cooperative.rotation(p[3:]) for p in initial_bases]
                        lateral = np.array([sign*.015, -sign*.015])
                        for robot in (0, 1):
                            policy.pair_targets[robot] += rotations[robot] @ [0., lateral[robot], 0.]
                        fixed_cloth = policy.pair_targets.copy()
                        def free_guard(observation, robot, body, **kwargs):
                            self.assertLessEqual(np.linalg.norm(body), .01000001)
                            self.assertEqual(kwargs['max_speed'], .01)
                            return {'body_velocity_xy': np.asarray(body).tolist()}
                        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': fixed_cloth}), \
                                patch.object(sleeve, 'guard_base_velocity', side_effect=free_guard):
                            # Repeating outputs without moving the public pose
                            # must never make an uncorrected 15 mm error pass.
                            for _ in range(12):
                                action = policy(obs); tick(obs)
                                self.assertEqual(policy.phase, 'pair_pregrasp')
                            for _ in range(120):
                                errors = [cooperative.world_to_base(obs, r, policy.pair_targets[r]+[0, 0, .12])
                                          - obs['grasp_pose_base'][r, :3] for r in (0, 1)]
                                action = policy(obs)
                                self.assertIsNone(policy.failure)
                                self.assertTrue(np.all(np.linalg.norm(action[:, :2]*.616, axis=1) <= .01000001))
                                np.testing.assert_allclose(action[:, 3], np.zeros(2), atol=1e-7)
                                np.testing.assert_array_equal(action[:, [0, 2, 5, 6, 7]], np.zeros((2, 5)))
                                if policy.phase == 'pair_touch':
                                    self.assertLess(max(abs(error[1]) for error in errors), .003)
                                    self.assertLess(max(np.linalg.norm(error) for error in errors), .008)
                                    break
                                integrate_public_action(obs, action)
                        self.assertEqual(policy.phase, 'pair_touch')
                        for robot in (0, 1):
                            moved = obs['base_pose_world'][robot, :2]-initial_bases[robot, :2]
                            lateral_move = float(rotations[robot][:2, 1] @ moved)
                            self.assertGreater(lateral_move*np.sign(lateral[robot]), .012)
                            self.assertLess(abs(lateral_move), .0151)
                        self.assertEqual(policy.baseline.calls, 0)

    def test_pregrasp_small_lateral_error_still_requires_eight_mm_3d_alignment(self):
        obs = observation(); policy = actor(obs, phase='pair_pregrasp')
        policy.pair_targets[:, 0] += .012
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': policy.pair_targets.copy()}), \
                patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, body, **kw:
                             {'body_velocity_xy': np.asarray(body).tolist()}):
            for _ in range(12):
                policy(obs); tick(obs)
                self.assertEqual(policy.phase, 'pair_pregrasp')
                self.assertEqual(policy.stable, 0)
            for _ in range(60):
                errors = [cooperative.world_to_base(obs, r, policy.pair_targets[r]+[0, 0, .12])
                          - obs['grasp_pose_base'][r, :3] for r in (0, 1)]
                action = policy(obs)
                if policy.phase == 'pair_touch':
                    self.assertLess(max(np.linalg.norm(error) for error in errors), .008)
                    break
                integrate_public_action(obs, action)
        self.assertEqual(policy.phase, 'pair_touch')
        self.assertTrue(np.all(obs['grasp_pose_base'][:, 0] > .604))

    def test_pregrasp_blocked_side_step_cannot_leak_previous_motion(self):
        for blocked_robot in (0, 1):
            with self.subTest(blocked_robot=blocked_robot):
                obs = observation(); policy = actor(obs, active=1-blocked_robot, phase='pair_pregrasp')
                policy.pair_targets[:, 1] += .015
                policy.previous_action[:, :8] = .08
                def guard(observation, robot, body, **kwargs):
                    return {'body_velocity_xy': [0., 0.] if robot == blocked_robot else np.asarray(body).tolist()}
                with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': policy.pair_targets.copy()}), \
                        patch.object(sleeve, 'guard_base_velocity', side_effect=guard):
                    action = policy(obs)
                self.assertIsNone(policy.failure)
                self.assertEqual(policy.phase, 'pair_pregrasp')
                np.testing.assert_array_equal(action[blocked_robot, :8], np.zeros(8))
                self.assertGreater(action[1-blocked_robot, 1], 0)
                self.assertLessEqual(np.linalg.norm(action[1-blocked_robot, :2]*.616), .01000001)

    def test_touch_uses_bounded_fresh_side_hold_and_over_one_cm_drift_stops_both(self):
        for robot in (0, 1):
            for drift in (-.011, -.005, 0., .005, .011):
                with self.subTest(robot=robot, drift=drift):
                    obs = observation(); policy = actor(obs, active=robot, phase='pair_touch')
                    policy.pair_targets = np.stack([grasp_world(obs, r) for r in (0, 1)]) - [0., 0., sleeve.Policy.CONTACT_OFFSET_M]
                    policy.pair_targets[robot, 1] += drift
                    # The former faster pregrasp command must not leak into
                    # the slower measured descent hold.
                    policy.previous_action[:, 1] = .01/.616
                    with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': policy.pair_targets.copy()}):
                        action = policy(obs)
                    if abs(drift) > .01:
                        self.assertIn('drifted during contact descent', policy.failure)
                        np.testing.assert_array_equal(action, np.zeros((2, 9)))
                    else:
                        self.assertIsNone(policy.failure)
                        np.testing.assert_array_equal(action[:, [0, 2]], np.zeros((2, 2)))
                        self.assertLessEqual(np.max(np.abs(action[:, 1]))*.616, .005000001)
                        if drift:
                            self.assertGreater(action[robot, 1]*drift, 0.)
                            np.testing.assert_array_equal(action[:, 3:5], np.zeros((2, 2)))
                        else:
                            np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_descent_rejects_real_v08_base_drift_using_measured_side_feedback(self):
        for yaws in ((0., np.pi), (np.pi/2, -np.pi/2)):
            with self.subTest(yaws=yaws):
                obs = observation()
                for r, yaw in enumerate(yaws):
                    obs['base_pose_world'][r, 3:] = [np.cos(yaw/2), 0., 0., np.sin(yaw/2)]
                policy = actor(obs, phase='pair_touch')
                rotations = [cooperative.rotation(p[3:]) for p in obs['base_pose_world']]
                for r in (0, 1):
                    policy.pair_targets[r] += rotations[r] @ [0., (.002376, .001466)[r], 0.]
                fixed_targets = policy.pair_targets.copy()
                with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': fixed_targets}), \
                        patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                                     dict(body_velocity_xy=np.asarray(b).tolist())):
                    for _ in range(320):
                        action = policy(obs)
                        self.assertIsNone(policy.failure, policy.debug)
                        self.assertLessEqual(np.max(np.abs(action[:, 1]))*.616, .005000001)
                        if policy.phase == 'pair_close':
                            break
                        integrate_public_action(obs, action)
                        # Bias measured in v08: commands zero still translated
                        # R0 about -2.28mm/s and R1 -1.42mm/s in own lateral axes.
                        for r in (0, 1):
                            obs['base_pose_world'][r, :2] += rotations[r][:2, :2] @ np.array([.0008 if r else 0., -(.00228, .00142)[r]])*.05
                self.assertEqual(policy.phase, 'pair_close')
                for r in (0, 1):
                    error = cooperative.world_to_base(obs, r, fixed_targets[r]+[0., 0., sleeve.Policy.CONTACT_OFFSET_M])-obs['grasp_pose_base'][r, :3]
                    self.assertLess(abs(error[1]), .003)
                    self.assertLess(np.linalg.norm(error), .010)

    def test_descent_guard_block_holds_both_arms_without_smoothing(self):
        obs = observation(); policy = actor(obs, phase='pair_touch')
        policy.pair_targets[:, 1] += .003
        policy.previous_action[:, :8] = .08
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': policy.pair_targets.copy()}), \
                patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                             dict(body_velocity_xy=[0., 0.] if r == 1 else np.asarray(b).tolist())):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_descent_waits_for_five_good_alignment_observations_after_pause(self):
        obs = observation(); policy = actor(obs, phase='pair_touch')
        policy.pair_targets[:, 1] += .005
        fixed_targets = policy.pair_targets.copy()
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': fixed_targets}), \
                patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                             dict(body_velocity_xy=np.asarray(b).tolist())):
            action = policy(obs)
            self.assertTrue(policy.descent_alignment_paused)
            np.testing.assert_array_equal(action[:, 3:5], np.zeros((2, 2)))
            obs['base_pose_world'][:, 1] += .0025
            for _ in range(4):
                tick(obs); action = policy(obs)
                self.assertTrue(policy.descent_alignment_paused)
                np.testing.assert_array_equal(action[:, 3:5], np.zeros((2, 2)))
            tick(obs); action = policy(obs)
            self.assertFalse(policy.descent_alignment_paused)
            self.assertTrue(np.all(action[:, 3] < 0.))

    def test_face_old_twenty_five_milliradian_tolerance_cannot_pass_before_actual_rotation(self):
        obs = observation(); policy = actor(obs, phase='pair_face_cloth')
        policy.pair_yaws = np.array([.015, -.015])
        for _ in range(15):
            policy(obs); tick(obs)
            self.assertEqual(policy.phase, 'pair_face_cloth')
            self.assertEqual(policy.stable, 0)
        for _ in range(80):
            yaws, _ = cooperative.yaw_tilt(obs['base_pose_world'])
            errors = [cooperative.wrapped_angle(goal-current) for goal, current in zip(policy.pair_yaws, yaws)]
            action = policy(obs)
            self.assertIsNone(policy.failure)
            if policy.phase == 'pair_pregrasp':
                self.assertLess(max(abs(error) for error in errors), .008)
                break
            integrate_public_action(obs, action)
        self.assertEqual(policy.phase, 'pair_pregrasp')

    def test_persistent_patch_loss_stops_instead_of_closing(self):
        obs = observation(); policy = actor(obs, phase='pair_touch')
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': np.empty((0, 3))}):
            for _ in range(40):
                tick(obs); action = policy(obs)
        self.assertEqual(policy.phase, 'stopped')
        self.assertIn('no longer visibly supported', policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_pair_close_waits_thirty_quiet_observations_then_starts_only_paired_lift(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(); policy = actor(obs, active, 'pair_close')
                policy.execution.stable[:] = 0
                policy.previous_action[:, :8] = .08
                policy.pair_trackers = [Mock(reset=Mock(return_value=tracked())) for _ in (0, 1)]
                with patch.object(cooperative, 'RigidPairTransport') as transport:
                    action = policy(obs)
                    np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                    np.testing.assert_array_equal(action[:, 8], np.ones(2))
                    obs['gripper_close_command'][:] = True
                    for _ in range(30):
                        tick(obs); action = policy(obs)
                        self.assertEqual(policy.phase, 'pair_close')
                        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                        transport.assert_not_called()
                    tick(obs); action = policy(obs)
                    self.assertEqual(policy.phase, 'pair_test_lift')
                    self.assertFalse(policy.SINGLE_HELPER_LIFT)
                    self.assertEqual(transport.call_count, 1)
                    self.assertEqual(transport.call_args.args[1], [0, 0, .04])
                    transport.return_value.step.assert_not_called()
                    np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                    self.assertEqual(policy.baseline.calls, 0)
                    for tracker in policy.pair_trackers:
                        tracker.reset.assert_called_once()

    def test_unsettled_second_gripper_prevents_lift(self):
        obs = observation(); policy = actor(obs, phase='pair_close')
        policy.execution.stable[:] = 0
        policy(obs)
        obs['gripper_close_command'][:] = True
        obs['joint_velocity'][1, 11] = .06
        with patch.object(cooperative, 'RigidPairTransport') as transport:
            for _ in range(35):
                tick(obs); action = policy(obs)
            transport.assert_not_called()
        self.assertEqual(policy.phase, 'pair_close')
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_either_missing_or_static_patch_blocks_pair_raise_and_transport(self):
        for rejected_robot in (0, 1):
            for result in (tracked(reliable=False), tracked(rise=0.), tracked(rise=-.04)):
                with self.subTest(rejected_robot=rejected_robot, evidence=result):
                    obs = observation(); obs['gripper_close_command'][:] = True
                    policy = actor(obs, phase='pair_test_lift')
                    policy.previous_action[:, :8] = .08
                    tracks = [tracked(), tracked()]; tracks[rejected_robot] = result
                    policy.pair_trackers = [Mock(update=Mock(return_value=t)) for t in tracks]
                    policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
                    with patch.object(cooperative, 'RigidPairTransport') as transport:
                        for index in range(20 if not result['reliable'] else 1):
                            action = policy(obs)
                            if not result['reliable'] and index < 19:
                                self.assertIsNone(policy.failure)
                                np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                                policy.pair_lift.step.assert_not_called()
                            tick(obs)
                        transport.assert_not_called()
                    self.assertIn('fixed-feature evidence', policy.failure)
                    self.assertFalse(policy.visual_dual_grasp_candidate)
                    self.assertEqual(policy.phase, 'stopped')
                    np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_unobservable_initial_grasp_stops_before_any_test_lift(self):
        for active in (0, 1):
            for missing_robot in (0, 1):
                with self.subTest(active=active, missing_robot=missing_robot):
                    obs = observation(); obs['gripper_close_command'][:] = True
                    policy = actor(obs, active, 'pair_close')
                    policy.previous_action[:, :8] = .08
                    reports = [tracked(rise=0.), tracked(rise=0.)]
                    reports[missing_robot] = tracked(reliable=False)
                    policy.pair_trackers = [Mock(reset=Mock(return_value=t)) for t in reports]
                    with patch.object(cooperative, 'RigidPairTransport') as transport:
                        action = policy(obs)
                        transport.assert_not_called()
                    self.assertEqual(policy.phase, 'stopped')
                    self.assertIn('visual verification unavailable before test lift', policy.failure)
                    self.assertIn('actual grasp status unknown', policy.failure)
                    np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_transient_test_lift_visibility_loss_freezes_reference_and_recovers_without_reseeding(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_test_lift')
        policy.previous_action[:, :8] = .08
        policy.pair_trackers = [Mock(update=Mock(return_value=tracked())),
                                Mock(update=Mock(side_effect=[tracked(reliable=False)]*4+[tracked()]))]
        moving = transport_result(); moving['action'][:, 3] = .012/1.54
        policy.pair_lift = Mock(step=Mock(return_value=moving))
        for _ in range(4):
            action = policy(obs); tick(obs)
            np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
            np.testing.assert_array_equal(action[:, 8], np.ones(2))
            self.assertIsNone(policy.failure)
            self.assertTrue(policy.transport_debug['visual_verification_paused_pair'])
            policy.pair_lift.step.assert_not_called()
        action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.test_lift_visibility_lost, 0)
        self.assertFalse(policy.transport_debug['visual_verification_paused_pair'])
        policy.pair_lift.step.assert_called_once()
        np.testing.assert_allclose(action, moving['action'])
        for tracker in policy.pair_trackers:
            tracker.reset.assert_not_called()

    def test_raise_rejects_stale_future_invalid_and_unreachable_public_geometry_before_motion(self):
        for fault in ('stale', 'future', 'missing_time', 'invalid_hands', 'invalid_joints', 'unreachable_r0', 'unreachable_r1', 'over_bounded_raise'):
            with self.subTest(fault=fault):
                obs = observation(); obs['gripper_close_command'][:] = True
                policy = actor(obs, phase='pair_test_lift')
                self.prepare_survey_exit(obs, policy)
                if fault == 'stale': policy.hand_observation_time -= policy.HAND_CACHE_MAX_AGE_S+.01
                elif fault == 'future': policy.hand_observation_time += .01
                elif fault == 'missing_time': policy.hand_observation_time = None
                elif fault == 'invalid_hands': policy.hands['hand_points_world'][0][2] = np.nan
                elif fault == 'invalid_joints': obs['joint_position'][0, 3] = np.nan
                elif fault.startswith('unreachable'): obs['joint_position'][int(fault[-1]), 3] = 1.0
                elif fault == 'over_bounded_raise':
                    policy.hands['hand_points_world'] = [[0., 0., 1.7], [0., .36, 1.7]]
                policy.previous_action[:, :8] = .08
                policy.pair_trackers = [Mock(update=Mock(return_value=tracked())) for _ in (0, 1)]
                policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
                with patch.object(cooperative, 'RigidPairTransport') as transport:
                    action = policy(obs)
                    transport.assert_not_called()
                self.assertEqual(policy.phase, 'stopped')
                self.assertIsNotNone(policy.failure)
                np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_pitched_lift_reach_uses_measured_grasps_and_preserves_requested_valid_height(self):
        for active in (0, 1):
            for hand_z in (1.146, 1.293):
                with self.subTest(active=active, hand_z=hand_z):
                    obs = observation(); obs['gripper_close_command'][:] = True
                    obs['joint_position'][:, 3] = [.90, .92]
                    obs['joint_position'][:, 9] = .715
                    obs['grasp_pose_base'][:, 2] = .1782204955816269+obs['joint_position'][:, 3]-.29535798728466034*np.sin(.715)
                    policy = actor(obs, active, 'pair_test_lift')
                    self.prepare_survey_exit(obs, policy)
                    policy.hands['hand_points_world'] = [[0., 0., hand_z], [0., .36, hand_z]]
                    policy.pair_trackers = [Mock(update=Mock(return_value=tracked())) for _ in (0, 1)]
                    policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
                    with patch.object(cooperative, 'RigidPairTransport') as transport:
                        action = policy(obs)
                        if hand_z > 1.2:
                            transport.assert_not_called()
                            self.assertIn('common own lift reach', policy.failure)
                        else:
                            transport.assert_called_once()
                            expected = hand_z-obs['grasp_pose_base'][:, 2].mean()
                            self.assertAlmostEqual(transport.call_args.args[1][2], expected, places=6)
                            self.assertLessEqual(max(policy.pair_raise_precondition['predicted_lift_joint_positions_m']), 1.185)
                            self.assertFalse(policy.pair_raise_precondition['requested_height_clamped'])
                            self.assertIsNone(policy.failure)
                    np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_raise_joint_margin_uses_world_vertical_projection_of_tilted_base(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        obs['joint_position'][:, 3] = 1.
        obs['base_pose_world'][:, 3:] = [np.cos(.02), np.sin(.02), 0., 0.]
        policy = actor(obs, phase='pair_test_lift')
        self.prepare_survey_exit(obs, policy)
        midpoint_z = np.mean([grasp_world(obs, r)[2] for r in (0, 1)])
        # .18493 m is below the naive .185 joint remainder but ABOVE its
        # actual world-Z projection for a .04 rad base tilt.
        height = midpoint_z+.18493
        policy.hands['hand_points_world'] = [[0., 0., height], [0., .36, height]]
        policy.pair_trackers = [Mock(update=Mock(return_value=tracked())) for _ in (0, 1)]
        policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
        with patch.object(cooperative, 'RigidPairTransport') as transport:
            action = policy(obs)
            transport.assert_not_called()
        self.assertIn('common own lift reach', policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_paired_transport_pause_cannot_reintroduce_smoothed_motion(self):
        for phase in ('pair_test_lift', 'pair_raise'):
            with self.subTest(phase=phase):
                obs = observation(); obs['gripper_close_command'][:] = True
                policy = actor(obs, phase=phase)
                policy.previous_action[:, :8] = .08
                policy.pair_lift = Mock(step=Mock(return_value=transport_result(pause=True)))
                policy.pair_trackers = [Mock(update=Mock(return_value=tracked())) for _ in (0, 1)]
                action = policy(obs)
                self.assertIsNone(policy.failure)
                np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_transport_lag_correction_is_not_changed_by_outer_smoothing(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_raise')
        policy.previous_action[:, 3] = .025 / 1.54
        result = transport_result()
        result['action'][1, 3] = .012 / 1.54
        result['debug']['pause_for_lag'] = True
        requested_motion = result['action'][:, :8].copy()
        policy.pair_lift = Mock(step=Mock(return_value=result))
        action = policy(obs)
        self.assertIsNone(policy.failure)
        # The leading robot must hold while the lagging robot catches up.
        np.testing.assert_allclose(action[:, :8], requested_motion, atol=1e-9)

    def prepare_navigation(self, obs, policy):
        policy.routes = [dict(feasible=True, reason='synthetic route',
                              waypoints_world_xy=[obs['base_pose_world'][r, :2], policy.pair_base_goals[r]])
                         for r in (0, 1)]
        policy.navigation_progress_position = obs['base_pose_world'][:, :2].copy()
        policy.navigation_progress_time = np.full(2, float(obs['simulation_time_s']))

    def test_depth_guard_reduction_is_not_increased_by_outer_smoothing(self):
        obs = observation(); policy = actor(obs, phase='pair_navigate')
        self.prepare_navigation(obs, policy)
        policy.previous_action[:, 0] = .05
        with patch.object(sleeve, 'guard_base_velocity', return_value={
                'body_velocity_xy': [.001, 0.], 'reason': 'reduced for observed obstacle'}):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertTrue(np.all(np.linalg.norm(action[:, :2] * .616, axis=1) <= .00100001))

    def test_navigation_requires_actual_progress_and_rejects_new_blocked_route(self):
        for mode in ('no_progress', 'blocked_replan'):
            with self.subTest(mode=mode):
                obs = observation(); policy = actor(obs, phase='pair_navigate')
                self.prepare_navigation(obs, policy)
                if mode == 'no_progress':
                    obs['simulation_time_s'][...] += 12.1
                else:
                    policy.navigation_blocked_steps[:] = [29, 29]
                with patch.object(sleeve, 'guard_base_velocity', return_value={
                        'body_velocity_xy': [0., 0.], 'reason': 'observed obstacle'}), \
                        patch.object(sleeve, 'plan_base_route', return_value={
                            'feasible': False, 'reason': 'new blocked corridor'}):
                    action = policy(obs)
                self.assertIsNotNone(policy.failure)
                self.assertEqual(policy.phase, 'stopped')
                np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_sustained_nonzero_slowdown_replans_from_new_depth_before_stalling(self):
        obs = observation(); policy = actor(obs, phase='pair_navigate')
        self.prepare_navigation(obs, policy)
        policy.navigation_slow_steps[1] = 29
        def guarded(observation, robot, body, **kwargs):
            return dict(body_velocity_xy=(np.asarray(body)*(.2 if robot == 1 else 1.)).tolist())
        replacement = dict(feasible=True, reason='new route around observed table edge',
                           waypoints_world_xy=[[1., 0.], [1., .2], [1.15, 0.]])
        with patch.object(sleeve, 'guard_base_velocity', side_effect=guarded), \
                patch.object(sleeve, 'plan_base_route', return_value=replacement) as planner, \
                patch.object(sleeve, 'validate_base_route_segment', return_value=dict(feasible=False, reason='new table edge')):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.route_replans, [0, 1])
        self.assertEqual(planner.call_args.kwargs['execution_clearance_m'], .12)
        np.testing.assert_array_equal(action[1, :8], np.zeros(8))
        self.assertGreater(np.linalg.norm(action[0, :2]), 0.)
        self.assertEqual(policy.navigation_slow_steps[1], 0)

    def test_valid_half_speed_tangent_route_is_not_repeatedly_replanned(self):
        obs = observation(); policy = actor(obs, phase='pair_navigate')
        self.prepare_navigation(obs, policy)
        policy.navigation_slow_steps = [19, 19]
        with patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                          dict(body_velocity_xy=(np.asarray(b)*.5).tolist())), \
                patch.object(sleeve, 'validate_base_route_segment', return_value=dict(feasible=True)) as check, \
                patch.object(sleeve, 'plan_base_route') as planner:
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(check.call_count, 2)
        planner.assert_not_called()
        self.assertTrue(np.all(np.linalg.norm(action[:, :2], axis=1) > 0.))
        self.assertEqual(policy.route_replans, [0, 0])

    def test_waypoint_bend_is_not_cut_at_old_thirty_five_mm_tolerance(self):
        obs = observation(); policy = actor(obs, phase='pair_navigate')
        self.prepare_navigation(obs, policy)
        policy.routes[0]['waypoints_world_xy'] = [[-1.1, 0.], [-.98, 0.], [-.98, .3]]
        with patch.object(sleeve, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                          dict(body_velocity_xy=np.asarray(b).tolist())):
            action = policy(obs)
        self.assertEqual(policy.route_indices[0], 1)
        self.assertGreater(action[0, 0], 0)
        self.assertAlmostEqual(action[0, 1], 0.)

    def test_successful_pair_test_uses_observed_hand_height_then_hands_off_once(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(); obs['gripper_close_command'][:] = True
                policy = actor(obs, active, 'pair_test_lift')
                policy.ENABLE_FAR_CLOTH_PITCH_PILOT = False
                self.prepare_survey_exit(obs, policy)
                policy.pair_trackers = [Mock(update=Mock(return_value=tracked())) for _ in (0, 1)]
                policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
                with patch.object(cooperative, 'RigidPairTransport') as transport, \
                        patch.object(sleeve, 'LoadedRollObservation') as roll, \
                        patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
                    transport.return_value.step.return_value = transport_result(done=True)
                    roll.return_value.step.return_value = dict(transport_result(done=True), skipped=True)
                    action = policy(obs)
                    self.assertIsNone(policy.failure)
                    self.assertEqual(policy.phase, 'pair_raise')
                    self.assertTrue(policy.visual_dual_grasp_candidate)
                    self.assertAlmostEqual(transport.call_args.args[1][2], .3, places=6)
                    tick(obs); policy(obs)
                    self.assertEqual(policy.phase, 'pair_observe_roll')
                    roll.assert_not_called()
                    tick(obs); policy(obs)
                    roll.assert_called_once()
                    self.assertTrue(roll.call_args.kwargs['stationary_human'])
                    self.assertEqual(roll.call_args.args[2], policy.hand_observation_time)
                    self.assertEqual(policy.phase, 'dual_hold')
                    np.testing.assert_allclose(policy.dual_targets,
                                               np.stack([grasp_world(obs, r) for r in (0, 1)]))
                    tick(obs); policy(obs)
                    self.assertEqual(policy.phase, 'dual_hold')
                    self.assertEqual(transport.call_count, 1)
                self.assertEqual(policy.baseline.calls, 0)

    def test_roll_pending_abort_passes_only_bounded_cancellation_without_smoothing(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_roll')
        policy.previous_action[:, :8] = .08
        result = transport_result()
        result.update(cancellation_only=True, pending_failure='lost current cloth')
        result['action'][0, 7] = -.001
        policy.loaded_roll = Mock(step=Mock(return_value=result))
        with patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'pair_observe_roll')
        np.testing.assert_array_equal(action, result['action'])
        self.assertTrue(policy.debug['loaded_roll_observation']['cancellation_only'])
        self.assertEqual(policy.loaded_roll_debug['pending_failure'], 'lost current cloth')
        # Only the child's later settled/final failure ends the controller.
        result['failure'] = 'lost current cloth'; tick(obs)
        np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
        self.assertEqual(policy.phase, 'stopped')

    def test_roll_initial_snapshot_follows_zero_base_handoff_action(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_raise')
        self.prepare_survey_exit(obs, policy)
        policy.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
        obs['controller_target'][:, 6:8] = [.0001, -.001]
        captured = []
        def create(frame, *args, **kwargs):
            captured.append(frame['controller_target'][:, 6:9].copy())
            return Mock(step=Mock(return_value=transport_result()))
        with patch.object(sleeve, 'LoadedRollObservation', side_effect=create) as factory:
            action = policy(obs)
            self.assertEqual(policy.phase, 'pair_observe_roll')
            factory.assert_not_called()
            np.testing.assert_array_equal(action[:, :8], 0.)
            # The simulator applies the just-returned hold before observing the
            # next frame. Constructing on the old frame caused the real v12 skip.
            obs['controller_target'][:, 6:9] = 0
            tick(obs); policy(obs)
            factory.assert_called_once()
            np.testing.assert_array_equal(captured[0], 0.)
            self.assertIsNone(policy.failure)

    def test_roll_opening_stop_request_requires_current_diagnostic_not_stale_cache(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_roll')
        policy.loaded_roll = Mock(step=Mock(return_value=transport_result()))
        policy.sleeve_observability = {'both_regions_have_depth_supported_opening': True}
        with patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}) as diagnose:
            policy(obs)
            self.assertFalse(policy.loaded_roll.step.call_args.kwargs['stop_for_openings'])
            diagnose.return_value = {'both_regions_have_depth_supported_opening': True}
            for _ in range(3):
                tick(obs); policy(obs)
            self.assertTrue(policy.loaded_roll.step.call_args.kwargs['stop_for_openings'])
            self.assertEqual(diagnose.call_count, 2)
        self.assertEqual(policy.loaded_roll.step.call_count, 4)

    def test_completed_roll_preserves_new_measured_hold_centers_and_diagnostics(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_roll')
        policy.ENABLE_FAR_CLOTH_PITCH_PILOT = False
        policy.previous_action[:, :8] = .08
        result = dict(transport_result(done=True), experiment_completed=True)
        result['debug']['measured_total_absolute_roll_degrees'] = 9.
        policy.loaded_roll = Mock(step=Mock(return_value=result))
        with patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
            action = policy(obs)
        self.assertEqual(policy.phase, 'dual_hold')
        np.testing.assert_allclose(policy.dual_targets, [grasp_world(obs, r) for r in (0, 1)])
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
        self.assertTrue(policy.debug['loaded_roll_observation']['experiment_completed'])
        tick(obs); policy(obs)
        self.assertEqual(policy.debug['loaded_roll_observation']['measured_total_absolute_roll_degrees'], 9.)

    def test_roll_to_pitch_pilot_preserves_original_hand_timestamp_and_single_instance(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_roll')
        self.prepare_survey_exit(obs, policy)
        original_time = policy.hand_observation_time
        policy.loaded_roll = Mock(step=Mock(return_value=transport_result(done=True)))
        with patch.object(sleeve, 'LoadedPitchObservation') as pilot, \
                patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
            pilot.return_value.step.return_value = transport_result()
            action = policy(obs)
            self.assertEqual(policy.phase, 'pair_observe_pitch')
            pilot.assert_not_called()
            np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
            for _ in range(3):
                tick(obs); policy(obs)
            pilot.assert_called_once()
            self.assertEqual(pilot.call_args.args[2], original_time)
            self.assertTrue(pilot.call_args.kwargs['stationary_human'])
            self.assertEqual(pilot.return_value.step.call_count, 3)
            self.assertEqual(policy.phase, 'pair_observe_pitch')

    def test_pitch_pending_abort_preserves_coupled_target_cancellation(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_pitch')
        policy.previous_action[:, :8] = .08
        result = dict(transport_result(), cancellation_only=True, pending_failure='center drift')
        result['action'][1, [3, 4, 6]] = [.0002, .0003, .001]
        policy.loaded_pitch = Mock(step=Mock(return_value=result))
        with patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
            action = policy(obs)
        np.testing.assert_array_equal(action, result['action'])
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'pair_observe_pitch')
        self.assertTrue(policy.debug['loaded_pitch_observation']['cancellation_only'])
        result['failure'] = 'center drift'; tick(obs)
        np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
        self.assertEqual(policy.phase, 'stopped')

    def test_completed_pitch_enters_dual_hold_with_current_measured_grasps(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='pair_observe_pitch')
        result = dict(transport_result(done=True), experiment_completed=True)
        result['debug']['measured_total_absolute_pitch_degrees'] = 4.
        policy.loaded_pitch = Mock(step=Mock(return_value=result))
        with patch.object(cooperative, 'diagnose_sleeve_observability', return_value={}):
            action = policy(obs)
        self.assertEqual(policy.phase, 'dual_hold')
        np.testing.assert_allclose(policy.dual_targets, [grasp_world(obs, r) for r in (0, 1)])
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
        np.testing.assert_array_equal(action[:, 8], np.ones(2))
        tick(obs); policy(obs)
        self.assertEqual(policy.debug['loaded_pitch_observation']['measured_total_absolute_pitch_degrees'], 4.)

    def test_old_helper_only_lift_phase_is_not_executed(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='helper_test_lift')
        policy.previous_action[1, 3] = .08
        np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
        self.assertEqual(policy.phase, 'stopped')
        self.assertIn('unknown sleeve-side phase', policy.failure)
        self.assertEqual(policy.baseline.calls, 0)


if __name__ == '__main__':
    unittest.main()
