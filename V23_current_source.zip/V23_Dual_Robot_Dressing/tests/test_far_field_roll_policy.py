"""Small CPU regressions for the separate far-field trial; no physics claims."""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
import equilibrium_wrist_experiments as wrapper
import far_field_roll_policy as trial
import loaded_equilibrium_calibration as calibration
import loaded_roll_observation as roll
from test_equilibrium_wrist_experiments import fixture, integrate
from test_loaded_equilibrium_calibration import observation
from test_loaded_roll_observation import hands, visible
from test_sleeve_pair_policy import Baseline, observation as policy_observation, tick


class FarFieldRollTests(unittest.TestCase):
    def test_default_pose_limit_unchanged_and_only_new_two_second_window_accepts_slow_pose_creep(self):
        self.assertEqual(calibration.LoadedEquilibriumCalibration.POSE_RANGE, .00025)
        self.assertEqual(calibration.LongLoadedEquilibriumCalibration.POSE_RANGE, .00025)
        self.assertEqual(trial.FarFieldEquilibriumCalibration.LINEAR_RANGE, .00025)
        outcomes = []
        with patch.object(calibration, '_cloth_evidence', side_effect=visible):
            for kind in (calibration.LongLoadedEquilibriumCalibration, trial.FarFieldEquilibriumCalibration):
                obs = observation(); initial = obs['base_pose_world'].copy()
                controller = kind(obs, hands(), 0.)
                for frame in range(41):
                    obs['simulation_time_s'][...] = frame*.05
                    obs['base_pose_world'][:, 1] = initial[:, 1]+frame*.05*.0003
                    result = controller.step(obs)
                    if frame < 40:
                        self.assertFalse(result['done'])
                    self.assertIsNone(result['failure'], result)
                outcomes.append(result)
        self.assertFalse(outcomes[0]['done'])
        self.assertTrue(outcomes[1]['done'], outcomes[1])
        self.assertEqual(outcomes[1]['calibration']['frame_count'], 41)
        self.assertAlmostEqual(outcomes[1]['debug']['grasp_window_diameter_m'], .0006)
        self.assertIn('1mm', outcomes[1]['calibration']['method'])
        self.assertFalse(outcomes[1]['debug']['continuous_time_stationary_verified'])

    def test_original_joint_range_drift_and_time_budgets_remain(self):
        with patch.object(calibration, '_cloth_evidence', side_effect=visible):
            obs = observation(); controller = trial.FarFieldEquilibriumCalibration(obs, hands(), 0.)
            q0 = obs['joint_position'].copy()
            for frame in range(41):
                obs['simulation_time_s'][...] = frame*.05
                delta = min(frame*.05*.0002, .0003)
                obs['joint_position'][0, 4:6] = q0[0, 4:6]+[delta, -delta]
                result = controller.step(obs)
            self.assertFalse(result['done']); self.assertGreater(result['debug']['window_reset_count'], 0)
            obs = observation(); controller = trial.FarFieldEquilibriumCalibration(obs, hands(), 0.)
            controller.step(obs)
            obs['simulation_time_s'][...] += .05
            obs['base_pose_world'][0, 0] += .0031
            self.assertIn('3mm_budget', controller.step(obs)['failure'])
            obs = observation(); controller = trial.FarFieldEquilibriumCalibration(obs, hands(), 0.)
            for frame in range(122):
                obs['simulation_time_s'][...] = frame*.05
                obs['controller_target'][0, 0] += 2e-6
                result = controller.step(obs)
                if result['failure']: break
            self.assertIn('timed_out', result['failure'])
            self.assertEqual(controller.time0, 0.)
            self.assertEqual(controller.MAX_SECONDS, 6.)

    def test_real_calibrated_core_completes_one_degree_with_small_persistent_budget(self):
        with ExitStack() as stack:
            for module in (roll, wrapper):
                stack.enter_context(patch.object(module, '_cloth_evidence', side_effect=visible))
            obs, baseline = fixture()
            controller = trial.CalibratedOneDegreeLoadedRoll(obs, hands(), 0., calibration=baseline)
            initial = obs['joint_position'][:, 10].copy()
            for _ in range(250):
                result = controller.step(obs)
                self.assertIsNone(result['failure'], result)
                if result['done']: break
                integrate(obs, result['action'], baseline)
            self.assertTrue(result['experiment_completed'], result)
            np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:, 10]-initial), 1., atol=.01)
            self.assertLessEqual(np.rad2deg(controller.absolute_angle).sum(), 2.5)
            self.assertEqual(result['debug']['nominal_positive_roll_degrees_per_robot'], 1.)
            self.assertEqual(result['debug']['per_robot_absolute_ceiling_degrees'], 1.25)
            self.assertEqual(result['debug']['total_absolute_roll_budget_degrees'], 2.5)

    def test_roll_completion_stops_without_pitch_contact_or_repeated_frame_dispatch(self):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = trial.Policy('unused.pt')
        obs = policy_observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.phase = 'pair_observe_roll'; actor.step = 2; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor._cache_scene = Mock(); actor.observe_sleeves = Mock(return_value={})
        hold = np.zeros((2, 9), np.float32); hold[:, 8] = 1.
        actor.loaded_roll = Mock(step=Mock(return_value=dict(action=hold, done=False,
            failure=None, experiment_completed=False, debug={})))
        actor._create_loaded_pitch = Mock(side_effect=AssertionError('pitch must not start'))
        actor(obs); actor(obs)
        self.assertEqual(actor.loaded_roll.step.call_count, 1)
        actor.loaded_roll.step.return_value.update(done=True, experiment_completed=True)
        tick(obs); np.testing.assert_array_equal(actor(obs), hold)
        self.assertEqual(actor.phase, 'far_roll_trial_complete')
        for _ in range(3):
            actor(obs); tick(obs); np.testing.assert_array_equal(actor(obs), hold)
        self.assertEqual(actor.loaded_roll.step.call_count, 2)
        actor._create_loaded_pitch.assert_not_called()
        self.assertIsNone(actor.contact_experiment)
        self.assertFalse(actor.debug['pitch_or_contact_started'])


if __name__ == '__main__':
    unittest.main()
