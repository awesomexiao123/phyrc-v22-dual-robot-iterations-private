"""Calibrated wrapper contract, with public-state fixtures and CPU-only mocks."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import calibrated_hypothesis_contact as calibrated
import hypothesis_contact_experiment as experiment
from public_vision import _rotation
from test_calibrated_contact_governor import fixture
from test_hypothesis_contact_experiment import FakeGovernor, FakeObserver, FakeMotion, FakeTracker, hold


class CalibratedHypothesisContactTests(unittest.TestCase):
    def setUp(self):
        FakeTracker.instances = []; FakeMotion.instances = []
        self.obs, self.calibration = fixture()
        self.obs['cloth_motion'] = np.zeros((2, 3))
        self.obs['cloth_reliable'] = np.ones(2, bool)
        self.calibration.update(variant='staging_passive_prior_compatible',
            prior_calibration_original_observed_at_s=.1)
        self.anchor = np.array([[1., 2., 3.], [2., 3., 4.]])
        self.anchor_stamp = .5

    def make(self, **overrides):
        kwargs = dict(calibration=self.calibration, skin_anchor=self.anchor,
                      skin_anchor_observed_at=self.anchor_stamp)
        kwargs.update(overrides)
        return calibrated.CalibratedHypothesisContactExperiment(self.obs, {'detected': True},
            [0, 1], {'detected': True}, .1, **kwargs)

    @staticmethod
    def observe_plan(obj, obs, now):
        _, grasps, _, _, _ = experiment._snapshot(obs)
        obj.hand_assignment = [0, 1]
        return grasps+[.02, 0., 0.], np.array([[1., 0., 0.], [1., 0., 0.]]), grasps+[.04, 0., 0.]

    def test_missing_wrong_and_stale_calibration_never_emits_motion(self):
        for value in (None, {}, dict(self.calibration, variant='unrelated')):
            with self.subTest(calibration=value):
                with self.assertRaises((ValueError, TypeError, AttributeError)):
                    self.make(calibration=value)
        self.obs['simulation_time_s'][...] += .1
        with patch.object(experiment, 'OpeningApproachCoordinator', FakeObserver), \
                patch.object(experiment.HypothesisContactExperiment, '_observe_plan', self.observe_plan), \
                patch.object(experiment.HypothesisContactExperiment, '_refresh_skin'), \
                patch.object(experiment, 'ClothPatchTracker', FakeTracker), \
                patch.object(calibrated, 'check_calibrated_contact_clearance', return_value=dict(valid=True, checks=[])):
            obj = self.make()
            self.assertIn('fresh_calibration', obj.governor.failure)
            output = obj.step(self.obs)
        self.assertIn('fresh_calibration', output['failure'])
        np.testing.assert_array_equal(output['action'][:, :8], 0.)
        self.assertIsNone(obj.motion)

    def test_original_skin_anchor_survives_fresh_detection_and_clearance_receives_raw_state(self):
        obj = self.make(); _, grasps, _, _, _ = experiment._snapshot(self.obs)
        obj.hands = grasps.copy()
        points = np.concatenate([np.repeat(h[None], 6, axis=0) for h in obj.hands])
        images = dict(depth=np.ones((5, 2, 6, 1)), depth_valid=np.ones((5, 2, 6, 1), bool),
                      rgb=np.zeros((5, 2, 6, 3), np.uint8))
        with patch.object(experiment, '_validated', return_value=images), \
                patch.object(experiment, '_skin', return_value=np.ones((2, 6), bool)), \
                patch.object(experiment, '_fabric_mask', return_value=np.zeros((2, 6), bool)), \
                patch.object(experiment, '_world_pixels', return_value=points):
            obj._refresh_skin(self.obs, 1.)
            obj._refresh_skin(self.obs, 2.)
        self.assertEqual(obj.skin_stamp, 2.)
        self.assertEqual(obj.skin_anchor_stamp, .5)
        np.testing.assert_array_equal(obj.skin_anchor, self.anchor)
        self.anchor[:] = -999
        self.assertFalse(np.any(obj.skin_anchor == -999))
        marker = {'current_evidence': True}; obj.governor.motion_evidence = marker
        action = hold()
        with patch.object(calibrated, 'check_calibrated_contact_clearance',
                return_value=dict(valid=True, checks=[{'checked_segment': 'raw_pending'}])) as check:
            obj._check_clearance(self.obs, action, 2.)
            self.assertIs(check.call_args.args[0], self.obs)
            self.assertIs(check.call_args.args[1], marker)
            self.assertIs(check.call_args.args[2], action)
            self.assertEqual(check.call_args.kwargs['skin_observed_at'], 2.)
            self.assertEqual(check.call_args.kwargs['skin_anchor_observed_at'], .5)
            self.assertEqual(obj.clearance, [{'checked_segment': 'raw_pending'}])
            check.return_value = dict(valid=False, reason='expired_original_anchor', checks=[])
            with self.assertRaisesRegex(ValueError, 'expired_original_anchor'):
                obj._check_clearance(self.obs, action, 2.)

    def test_two_pulses_keep_governor_fixed_tracks_calibration_and_total_budget(self):
        governor = FakeGovernor(self.obs); governor.motion_evidence = {}; governor.settled = True
        with patch.object(calibrated, 'CalibratedContactGovernor', return_value=governor) as factory, \
                patch.object(experiment.HypothesisContactExperiment, '_observe_plan', self.observe_plan), \
                patch.object(experiment.HypothesisContactExperiment, '_refresh_skin'), \
                patch.object(experiment.HypothesisContactExperiment, '_coverage', return_value=[10, 10]), \
                patch.object(experiment, 'ClothPatchTracker', FakeTracker), \
                patch.object(experiment, 'GraspPairAlignment', FakeMotion), \
                patch.object(experiment, 'ContactPulseAlignment', FakeMotion), \
                patch.object(calibrated, 'check_calibrated_contact_clearance', return_value=dict(valid=True, checks=[])):
            obj = self.make(); original_calibration = deepcopy(obj.calibration)
            obj.step(self.obs)
            original_trackers = list(obj.trackers); original_time = obj.time0
            for _ in range(2):
                _, grasps, _, _, _ = experiment._snapshot(self.obs)
                obj._start_motion(self.obs, 'contact_pulse', grasps)
                obj.motion.done = True
                self.obs['simulation_time_s'][...] += .05
                for robot in (0, 1):
                    rotation = _rotation(self.obs['base_pose_world'][robot, 3:])
                    self.obs['grasp_pose_base'][robot, :3] += rotation.T @ np.array([.005, 0., 0.])
                self.obs['cloth_motion'][:, 0] += .005
                output = obj.step(self.obs)
                self.assertIsNone(output['failure'], output)
                self.assertIs(obj.governor, governor)
                self.assertEqual(obj.trackers, original_trackers)
            factory.assert_called_once()
            self.assertEqual([t.reset_calls for t in obj.trackers], [1, 1])
            self.assertEqual(len(obj.pulse_results), 2)
            self.assertAlmostEqual(obj.pulse_travel, .01)
            self.assertEqual(obj.time0, original_time)
            self.assertEqual(obj.calibration, original_calibration)
            self.assertEqual(obj.skin_anchor_stamp, .5)
            self.assertFalse(output['debug']['calibration_refreshed_during_contact'])
            self.assertFalse(output['debug']['physical_simulation_validation_completed'])
            calls = len(governor.calls)
            obj.step(self.obs)
            self.assertEqual(len(governor.calls), calls)
            self.assertEqual(len(obj.pulse_results), 2)


if __name__ == '__main__':
    unittest.main()
