"""Stage boundaries preserve the sampled calibration and global drift budget."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
import equilibrium_contact_policy as equilibrium
from test_sleeve_pair_policy import Baseline, observation, tick


class EquilibriumPolicyTests(unittest.TestCase):
    def actor(self, phase):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = equilibrium.Policy('unused.pt')
        obs = observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.step = 2; actor.phase = phase; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor._cache_scene = Mock(); actor.observe_sleeves = Mock(return_value={})
        return actor, obs

    def test_roll_completion_requires_fresh_pitch_calibration(self):
        actor, obs = self.actor('pair_observe_roll')
        hold = np.zeros((2, 9), np.float32); hold[:, 8] = 1
        actor.loaded_roll = Mock(step=Mock(return_value=dict(action=hold, done=True,
            failure=None, experiment_completed=True, debug={})))
        actor.wrist_calibration = {'observed_at_s': 1.}
        with patch.object(equilibrium.Policy, 'CALIBRATION_CLASS') as calibration, \
                patch.object(equilibrium, 'CalibratedLoadedContactPitch') as pitch:
            actor(obs)
            self.assertEqual(actor.phase, 'pair_settle_before_pitch')
            self.assertIsNone(actor.wrist_calibration)
            calibration.assert_not_called(); pitch.assert_not_called()
            measured = {'observed_at_s': 10.05}
            calibration.return_value.step.return_value = dict(action=hold, done=True,
                failure=None, calibration=measured, debug={})
            tick(obs); actor(obs)
            calibration.assert_called_once(); pitch.assert_not_called()
            self.assertEqual(actor.phase, 'pair_observe_pitch')
            self.assertIs(actor.wrist_calibration, measured)
            pitch.return_value.step.return_value = dict(action=hold, done=False, failure=None, debug={})
            tick(obs); actor(obs)
            self.assertIs(pitch.call_args.kwargs['calibration'], measured)

    def test_pitch_calibration_never_resets_original_global_drift_reference(self):
        actor, obs = self.actor('pair_settle_before_roll')
        with patch.object(equilibrium.Policy, 'CALIBRATION_CLASS'):
            actor._create_wrist_handoff(obs)
            first = actor.wrist_global_reference
            obs['grasp_pose_base'][:, 2] += .002
            actor._create_wrist_handoff(obs)
            self.assertIs(actor.wrist_global_reference, first)
        actor.phase = 'pair_settle_before_pitch'
        obs['grasp_pose_base'][:, 2] += .0012
        with patch.object(equilibrium.Policy, 'CALIBRATION_CLASS') as calibration:
            action = actor(obs)
            calibration.assert_not_called()
        self.assertEqual(actor.phase, 'stopped')
        self.assertIn('global wrist trial', actor.failure)
        np.testing.assert_array_equal(action[:, :8], 0.)


if __name__ == '__main__':
    unittest.main()
