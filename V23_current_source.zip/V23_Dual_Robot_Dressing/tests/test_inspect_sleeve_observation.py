"""Saved public-report comparisons; no simulator, actor, or truth fixtures."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


path = Path(__file__).resolve().parents[1]/'inspect_sleeve_observation.py'
spec = importlib.util.spec_from_file_location('inspect_sleeve_observation', path)
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


def report(stamp, cameras=()):
    regions = []
    for robot in (0, 1):
        candidates = [dict(kind='unclassified_opening', camera_index=camera,
            candidate_index=robot*10+camera, observation_time_s=stamp,
            observed_depth_support=dict(ring_valid_fraction=.95, interior_valid_fraction=.9,
                background_fraction=.9, median_background_gap_m=.1,
                lower_quartile_background_gap_m=.05)) for camera in cameras]
        regions.append(dict(grasp_index=robot, observed_cloth_point_count=40+robot,
            observed_boundary_point_count=12, internal_image_boundary_point_count=4,
            external_image_boundary_point_count=8, depth_supported_opening_candidates=candidates,
            views=[dict(camera_index=3, measured_cloth_pixels=40+robot,
                measured_boundary_pixels=12, projected_rgb_cloth_pixels=50,
                projected_cloth_depth_valid_fraction=.8)],
            ambiguous_candidate_indices=[], reasons=['unclassified_observation']))
    return dict(observation_time_s=stamp, grasp_regions=regions,
        opening_candidate_rejections={'foreground_occlusion_or_no_background_gap': 2},
        both_regions_have_depth_supported_opening=bool(cameras))


def row(step, now, phase, observation, roll=None, pitch=None):
    return dict(step=step, simulation_time_s=now, phase=phase,
        debug=dict(sleeve_observability=copy.deepcopy(observation), loaded_roll_observation=roll or {},
                   loaded_pitch_observation=pitch or {}))


def measured_roll(now, total=4.5):
    return dict(report_observed_at_s=now, phase='roll',
        measured_absolute_roll_degrees=[total, 0.],
        measured_total_absolute_roll_degrees=total, total_absolute_roll_budget_degrees=10.)


def cavity_report(stamp, cameras=()):
    candidates = [dict(kind='unclassified_depth_cavity', camera_index=camera,
        source_camera='head_'+str(camera), observation_time_s=stamp, eligible_grasp_indices=[0, 1],
        depth_evidence=dict(interior_pixel_count=40, interior_valid_fraction=1.,
            adjacent_rim_valid_fraction=1., adjacent_rim_cloth_fraction=1., deeper_cloth_fraction=.8,
            minimum_required_recession_z_m=.025, optical_z_recession_m=dict(min=.03, median=.055),
            first_surface_plane_normal_recession_m=dict(min=.02, median=.04),
            first_surface_distance_behind_plane_along_camera_ray_m=dict(median=.06),
            first_surface_depth_z_m=dict(median=1.2), sampled_source_pixels_uv=[[12, 30]],
            free_advance_verified=False, permitted_advance_m=None),
        fitted_rim_plane=dict(planarity_ratio=.02, maximum_measured_residual_m=.003,
            measured_rim_pixel_count=25, normal_world=[0., 1., 0.],
            normal_convention='towards observing camera; not entry direction')) for camera in cameras]
    return dict(observation_time_s=stamp, depth_cavity_candidates=candidates,
        status='unclassified_observed_depth_cavities' if candidates else 'unknown',
        rejected_candidate_counts={'foreground_surface': 3, 'bad_plane': 2},
        diagnostics=[dict(camera_index=camera, nearby_valid_cloth_pixels=120, plane_hypotheses=4,
            depth_regions_examined=3, accepted_candidates=1) for camera in cameras])


def with_cavities(stamp, nested):
    return dict(report(stamp), depth_cavity_observations=nested)


class InspectSleeveObservationTests(unittest.TestCase):
    def test_fresh_roll_sequence_reports_actual_candidate_change_and_budget(self):
        rows = [row(1, 10., 'pair_raise', report(10.)),
                row(2, 10.1, 'pair_observe_roll', report(10.1), measured_roll(10.1, 0.)),
                row(3, 11., 'pair_observe_roll', report(11., (3,)), measured_roll(11.)),
                row(4, 11.1, 'dual_hold', report(11.1, (3,)), measured_roll(11.))]
        result = review.review_records(rows); window = result['roll_windows'][0]
        self.assertEqual(window['comparison_after']['candidate_count_delta_by_camera']['3'], 2)
        self.assertEqual(window['comparison_after']['per_grasp_pixel_count_deltas'][0]['observed_cloth_point_count'], 0)
        self.assertIsNone(window['comparison_after']['per_grasp_pixel_count_deltas'][0]['cameras'][0]['measured_internal_boundary_pixels'])
        self.assertEqual(window['during_peak']['step'], 3)
        self.assertEqual(window['last_roll_measurement']['measured_total_absolute_roll_degrees'], 4.5)
        metric = window['after']['metrics']['grasp_regions'][0]
        self.assertEqual(metric['internal_image_boundary_point_count'], 4)
        self.assertIsNone(metric['views'][0]['measured_internal_boundary_pixels'])
        self.assertEqual(metric['views'][0]['measured_cloth_pixels'], 40)
        text = review.render_chinese({'runs': [dict(run='test', episodes=[dict(result, episode='episode_001')], warnings=[])]})
        self.assertIn('未检测到开口不等于没有袖口', text)
        self.assertIn('合计4.5° / 预算10.0°', text)

    def test_retained_postrun_report_is_not_after_roll_evidence(self):
        original = report(10., (3,))
        rows = [row(1, 9.9, 'pair_raise', report(9.9)),
                row(2, 10., 'pair_observe_roll', original, measured_roll(10.)),
                row(3, 10.1, 'dual_hold', original, measured_roll(10.)),
                row(4, 90., 'stopped', original, measured_roll(10.))]
        result = review.review_records(rows)
        self.assertIsNone(result['roll_windows'][0]['after'])
        self.assertEqual(result['latest_snapshot']['freshness']['status'], 'retained_stale')
        self.assertEqual(result['latest_snapshot']['freshness']['age_s'], 80.)
        self.assertEqual(result['latest_snapshot']['roll']['freshness']['age_s'], 80.)
        self.assertFalse(result['latest_snapshot']['new_report'])
        self.assertEqual(result['roll_windows'][0]['comparison_after']['status'],
                         'insufficient_fresh_timestamped_reports')

    def test_legacy_no_timestamp_including_candidate_timestamps_remains_unknown(self):
        old = report(10., (3,)); old.pop('observation_time_s')
        changed = copy.deepcopy(old); changed['grasp_regions'][0]['observed_cloth_point_count'] += 1
        result = review.review_records([row(1, 10., 'pair_raise', old),
            row(2, 11., 'pair_observe_roll', changed), row(3, 12., 'dual_hold', old)])
        self.assertTrue(all(not item['usable_for_comparison'] for item in result['snapshots']))
        self.assertEqual(result['snapshots'][1]['freshness']['status'], 'unknown_timestamp')
        self.assertEqual(result['snapshots'][1]['metrics']['candidate_observation_times_s'], [10.])
        self.assertEqual(result['roll_windows'][0]['comparison_during']['status'],
                         'insufficient_fresh_timestamped_reports')

    def test_future_and_stale_reports_are_not_fresh_even_if_payload_changed(self):
        result = review.review_records([row(1, 10., 'pair_raise', report(11.)),
            row(2, 12., 'pair_observe_roll', report(9., (3,))),
            row(3, 12.1, 'pair_observe_roll', report(12.))])
        self.assertEqual(result['snapshots'][0]['freshness']['status'], 'future_timestamp_invalid')
        self.assertEqual(result['snapshots'][1]['freshness']['status'], 'retained_stale')
        self.assertTrue(result['snapshots'][2]['usable_for_comparison'])
        self.assertAlmostEqual(result['snapshots'][2]['freshness']['age_s'], .1)

    def test_candidate_counts_deduplicate_only_inside_same_camera_and_frame(self):
        saved = report(1., (3, 4))
        saved['grasp_regions'][1]['depth_supported_opening_candidates'] = copy.deepcopy(
            saved['grasp_regions'][0]['depth_supported_opening_candidates'])
        saved['grasp_regions'][0]['depth_supported_opening_candidates'].append(
            dict(kind='unclassified_opening', camera_index=1, observed_depth_support={}))
        values = review.summarize_report(saved)
        self.assertEqual(values['supported_candidate_count'], 2)
        self.assertEqual(values['supported_candidate_counts_by_camera'], {'1': 0, '2': 0, '3': 1, '4': 1})
        self.assertEqual(values['invalid_saved_supported_candidates'], 1)
        result = review.review_records([row(1, 1., 'pair_observe_roll', saved),
                                       row(2, 2., 'pair_observe_roll', report(2., (3, 4)))])
        self.assertEqual(result['phases'][0]['usable_timestamped_observations'], 2)

    def test_camera_boundary_split_preserved_when_available_not_inferred(self):
        saved = report(1.)
        saved['grasp_regions'][0]['views'][0].update(measured_internal_boundary_pixels=3,
                                                  measured_external_boundary_pixels=9)
        result = review.summarize_report(saved)
        self.assertTrue(result['per_camera_boundary_split_available'])
        self.assertEqual(result['grasp_regions'][0]['views'][0]['measured_external_boundary_pixels'], 9)
        self.assertIsNone(result['grasp_regions'][1]['views'][0]['measured_external_boundary_pixels'])

    def test_fresh_report_cannot_relabel_old_candidate_geometry_as_current(self):
        saved = report(1., (3,))
        saved['observation_time_s'] = 2.
        result = review.summarize_report(saved)
        self.assertEqual(result['supported_candidate_count'], 0)
        self.assertEqual(result['invalid_saved_supported_candidates'], 2)

    def test_cavity_metrics_keep_unclassified_first_surface_not_opening_or_free_path(self):
        source = with_cavities(20., cavity_report(20., (3, 4)))
        source['depth_cavity_observations']['depth_cavity_candidates'][1]['depth_evidence']['interior_blue_fraction'] = .7
        result = review.review_records([row(1, 20., 'pair_observe_pitch', source)])
        snapshot = result['snapshots'][0]; cavity = snapshot['cavity']
        self.assertEqual(snapshot['metrics']['supported_candidate_count'], 0)
        self.assertEqual(cavity['candidate_counts_by_camera'], {'1': 0, '2': 0, '3': 1, '4': 1})
        self.assertEqual(cavity['rejected_candidate_count'], 5)
        self.assertEqual(cavity['diagnostics_by_camera'][0]['nearby_valid_cloth_pixels'], 120)
        first = cavity['candidates'][0]
        self.assertEqual(first['depth_evidence']['deeper_cloth_fraction'], .8)
        self.assertIsNone(first['depth_evidence']['interior_blue_fraction'])
        self.assertEqual(cavity['candidates'][1]['depth_evidence']['interior_blue_fraction'], .7)
        self.assertEqual(first['fitted_rim_plane']['maximum_measured_residual_m'], .003)
        self.assertEqual(first['depth_evidence']['first_surface_plane_normal_recession_m']['median'], .04)
        self.assertNotIn('sampled_source_pixels_uv', first['depth_evidence'])
        self.assertFalse(first['sleeve_identity_verified'])
        self.assertFalse(first['free_advance_verified'])
        self.assertIsNone(first['permitted_advance_m'])
        self.assertFalse(cavity['insertion_allowed'])
        text = review.render_chinese({'runs': [dict(run='v13', episodes=[dict(result, episode='episode_001')], warnings=[])]})
        self.assertIn('深处布料比例（蓝/黄）0.8，单独蓝色比例None', text)
        self.assertIn('单独蓝色比例0.7', text)
        self.assertIn('平面残差上限0.003米', text)
        self.assertIn('这些深度不是可自由前进距离', text)

    def test_nested_clock_never_borrows_fresh_parent_and_repeated_nested_is_not_new(self):
        nested = cavity_report(10., (3,))
        rows = [row(1, 10.8, 'pair_observe_roll', with_cavities(10.8, nested)),
                row(2, 10.9, 'pair_observe_roll', with_cavities(10.9, nested)),
                row(3, 20., 'dual_hold', with_cavities(20., nested))]
        snapshots = review.review_records(rows)['snapshots']
        self.assertTrue(snapshots[0]['cavity_usable_for_comparison'])
        self.assertAlmostEqual(snapshots[0]['cavity']['freshness']['age_s'], .8)
        self.assertTrue(snapshots[1]['usable_for_comparison'])
        self.assertFalse(snapshots[1]['new_cavity_report'])
        self.assertFalse(snapshots[1]['cavity_usable_for_comparison'])
        self.assertEqual(snapshots[2]['freshness']['status'], 'same_frame')
        self.assertEqual(snapshots[2]['cavity']['freshness']['status'], 'retained_stale')
        self.assertEqual(snapshots[2]['cavity']['freshness']['age_s'], 10.)
        self.assertEqual(snapshots[2]['cavity']['candidates'][0]['observation_time_s'], 10.)
        self.assertFalse(snapshots[2]['cavity_usable_for_comparison'])
        # Refreshing only the nested payload cannot refresh the parent opening evidence.
        result = review.review_records([
            row(1, 1., 'pair_observe_pitch', with_cavities(1., cavity_report(1.))),
            row(2, 1.1, 'pair_observe_pitch', with_cavities(1., cavity_report(1.1, (3,))))])
        self.assertFalse(result['snapshots'][1]['new_report'])
        self.assertTrue(result['snapshots'][1]['new_cavity_report'])

    def test_roll_and_pitch_windows_do_not_attribute_pitch_to_post_roll(self):
        pitch = dict(report_observed_at_s=14., phase='pitch', measured_absolute_pitch_degrees=[2., 2.],
                     measured_total_absolute_pitch_degrees=4., total_absolute_pitch_budget_degrees=5.)
        rows = [row(1, 10., 'pair_raise', with_cavities(10., cavity_report(10.))),
                row(2, 11., 'pair_observe_roll', with_cavities(11., cavity_report(11., (3,))), measured_roll(11., 0.)),
                row(3, 12., 'pair_observe_roll', with_cavities(12., cavity_report(12., (3,))), measured_roll(12.)),
                row(4, 13., 'pair_observe_pitch', with_cavities(13., cavity_report(13., (3, 4)))),
                row(5, 14., 'pair_observe_pitch', with_cavities(14., cavity_report(14., (3, 4))), pitch=pitch),
                row(6, 15., 'dual_hold', with_cavities(15., cavity_report(15., (3, 4))), pitch=pitch)]
        result = review.review_records(rows)
        roll, pitch_window = result['roll_windows'][0], result['pitch_windows'][0]
        self.assertIsNone(roll['after'])
        self.assertIsNone(roll['cavity_after'])
        self.assertEqual(roll['next_orientation_phase_excluded'], 'pair_observe_pitch')
        self.assertEqual(roll['cavity_during_peak']['step'], 3)
        self.assertEqual(pitch_window['cavity_before']['step'], 3)
        self.assertEqual(pitch_window['cavity_during_observation_steps'], [4, 5])
        self.assertEqual(pitch_window['cavity_after']['step'], 6)
        self.assertEqual(pitch_window['cavity_comparison_after']['candidate_count_delta_by_camera']['4'], 1)
        self.assertEqual(pitch_window['comparison_after']['candidate_count_delta_by_camera']['4'], 0)
        self.assertEqual(pitch_window['last_pitch_measurement']['measured_total_absolute_pitch_degrees'], 4.)
        text = review.render_chinese({'runs': [dict(run='v13', episodes=[dict(result, episode='episode_001')], warnings=[])]})
        self.assertIn('滚转记录步骤 2–3', text)
        self.assertIn('俯仰记录步骤 4–5', text)
        self.assertIn('合计4.0° / 预算5.0°', text)

    def test_unknown_future_stale_error_and_invalid_cavities_never_become_fresh_evidence(self):
        unknown = cavity_report(None, (3,)); unknown.pop('observation_time_s')
        error = dict(observation_time_s=5., depth_cavity_candidates=[], available=False, error='depth unavailable')
        result = review.review_records([
            row(1, 1., 'pair_observe_pitch', with_cavities(1., unknown)),
            row(2, 2., 'pair_observe_pitch', with_cavities(2., cavity_report(3., (3,)))),
            row(3, 4., 'pair_observe_pitch', with_cavities(4., cavity_report(2., (4,)))),
            row(4, 5., 'pair_observe_pitch', with_cavities(5., error))])
        self.assertTrue(all(not s['cavity_usable_for_comparison'] for s in result['snapshots']))
        self.assertEqual([s['cavity']['freshness']['status'] for s in result['snapshots']],
                         ['unknown_timestamp', 'future_timestamp_invalid', 'retained_stale', 'same_frame'])
        malformed = cavity_report(10., (3, 4, 1))
        malformed['depth_cavity_candidates'][0]['observation_time_s'] = 9.
        malformed['depth_cavity_candidates'][1]['kind'] = 'verified_sleeve'
        malformed['depth_cavity_candidates'][2]['camera_index'] = 0
        summary = review.summarize_cavities(malformed, 10.)
        self.assertEqual(summary['saved_candidate_count'], 3)
        self.assertEqual(summary['candidate_count'], 0)
        self.assertEqual(summary['invalid_saved_candidates'], 3)

    def test_nested_report_can_exist_without_parent_and_old_reports_remain_compatible(self):
        result = review.review_records([
            row(1, 1., 'pair_raise', report(1.)),
            row(2, 2., 'pair_observe_pitch', dict(depth_cavity_observations=cavity_report(2., (3,)))),
            row(3, 50., 'stopped', dict(depth_cavity_observations=cavity_report(2., (3,))))])
        self.assertIsNone(result['snapshots'][0]['cavity'])
        self.assertIsNone(result['snapshots'][1]['metrics'])
        self.assertTrue(result['snapshots'][1]['cavity_usable_for_comparison'])
        self.assertEqual(result['snapshots'][2]['cavity']['freshness']['age_s'], 48.)
        self.assertIsNone(result['pitch_windows'][0]['cavity_after'])
        self.assertEqual(result['pitch_windows'][0]['cavity_during_peak']['step'], 2)

    def test_partial_live_file_and_newer_latest_are_read_once_without_duplicate(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory)/'run'; episode = run/'diagnostics'/'episode_001'
            episode.mkdir(parents=True)
            first, second = row(1, 1., 'pair_raise', report(1.)), row(2, 2., 'pair_observe_roll', report(2.))
            (episode/'progress.jsonl').write_text(json.dumps(first)+'\n'+json.dumps(second)+'\n'+ '{"step":')
            (episode/'latest.json').write_text(json.dumps(second))
            result = review.review_run(run)
            self.assertEqual(result['episodes'][0]['record_count'], 2)
            self.assertEqual(len(result['episodes'][0]['warnings']), 1)
            (episode/'latest.json').write_text(json.dumps(row(3, 3., 'dual_hold', report(3.))))
            self.assertEqual(review.review_run(run)['episodes'][0]['record_count'], 3)

    def test_cli_latest_fallback_outputs_only_review_files_and_rejects_path_escape(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(review, 'ROOT', Path(directory)):
            run = Path(directory)/'results'/'example'; diag = run/'diagnostics'; diag.mkdir(parents=True)
            source = json.dumps(row(1, 1., 'stopped', report(None)))
            (diag/'latest.json').write_text(source)
            self.assertEqual(review.main(['--run', 'example']), 0)
            output = json.loads((run/'sleeve_observation_review.json').read_text())
            self.assertTrue(output['public_diagnostics_only'])
            self.assertFalse(output['controller_feedback'])
            self.assertTrue((run/'sleeve_observation_review.txt').exists())
            self.assertEqual((diag/'latest.json').read_text(), source)
            with self.assertRaises(SystemExit):
                review.main(['--run', '../example'])


if __name__ == '__main__':
    unittest.main()
