"""Synthetic public RGB-D provenance/abstention checks, not cuff proof."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import held_edge_hypotheses as edge
from human_targets import _validated, _world_pixels


def observation():
    pose = np.zeros((2, 7), dtype=np.float64)
    pose[:, 3] = 1
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.zeros((5, 256, 256, 1), np.float64),
        depth_valid=np.zeros((5, 256, 256, 1), bool),
        base_pose_world=pose.copy(), grasp_pose_base=pose.copy(),
        simulation_time_s=np.array(2.5))
    for camera in (3, 4):
        obs['depth'][camera, ..., 0] = 1.5
        obs['depth_valid'][camera, ..., 0] = True
        obs['rgb'][camera, 80:177, 80:177] = [10, 20, 230]
        obs['depth'][camera, 80:177, 80:177, 0] = 1.
    values = _validated(obs, wrists=True)
    obs['grasp_pose_base'][:, :3] = _world_pixels(values, 3,
        np.array([82, 174]), np.array([128, 128]), np.ones(2))
    candidates = []
    for u in (80, 176):
        v = np.arange(110, 147)
        points = _world_pixels(values, 3, np.full(len(v), u), v, np.ones(len(v)))
        candidates.append(dict(boundary_evidence=dict(observation_time_s=0.,
            camera_index=3, source_camera='robot_0_head',
            full_arc_source_pixels_uv=np.column_stack((np.full(len(v), u), v)).tolist(),
            full_arc_measured_points_world=points.tolist())))
    return obs, dict(detected=True, candidates=candidates)


class HeldEdgeHypothesisTests(unittest.TestCase):
    def detect(self, obs, initial, assignment=(0, 1)):
        return edge.estimate_held_edge_hypotheses(obs, initial, assignment)

    def test_two_actual_current_edges_with_measured_arc_and_multiview_agreement(self):
        obs, initial = observation(); result = self.detect(obs, initial)
        self.assertTrue(result['detected'], result)
        self.assertTrue(result['distinct_current_regions'])
        values = _validated(obs, wrists=True)
        for robot, item in enumerate(result['hypotheses']):
            self.assertEqual(item['robot_index'], robot)
            self.assertEqual(item['agreeing_camera_indices'], [3, 4])
            self.assertTrue(item['multi_view_agreement_checked'])
            self.assertEqual(item['observation_time_s'], float(obs['simulation_time_s']))
            camera = item['camera_index']; u, v = item['edge_source_pixel_uv']
            self.assertEqual(item['measured_edge_depth_z_m'], obs['depth'][camera, v, u, 0])
            point = _world_pixels(values, camera, u, v, obs['depth'][camera, v, u, 0])
            np.testing.assert_allclose(point, item['edge_point_world'], atol=1e-12)
            np.testing.assert_allclose(point-np.asarray(item['current_grasp_world']),
                                       item['edge_from_current_grasp_world'], atol=1e-12)
            prior = result['robots'][robot]['initial_size_prior']
            self.assertEqual(prior['initial_boundary_camera_index'], 3)
            self.assertEqual(prior['initial_boundary_observation_time_s'], 0.)
            self.assertTrue(prior['width_is_observed_arc_span_not_cuff_circumference'])
            uv = np.asarray(item['arc_source_pixels_uv'])
            points = _world_pixels(values, camera, uv[:, 0], uv[:, 1], obs['depth'][camera, uv[:, 1], uv[:, 0], 0])
            np.testing.assert_allclose(points, item['arc_measured_points_world'], atol=1e-12)
            self.assertLessEqual(np.linalg.norm(points-np.asarray(result['robots'][robot]['current_grasp_world']), axis=1).max(), .08)
            self.assertGreaterEqual(item['support_pixel_count'], 4)
            self.assertTrue(item['selected_edge_exterior_depth'])
            for key in ('mouth_point_inferred', 'physical_opening_verified', 'cuff_identity_verified',
                        'attachment_verified', 'rigid_cloth_transform_used', 'contact_authorized', 'insertion_allowed'):
                self.assertFalse(item[key])

    def test_initial_geometry_is_only_width_prior_and_explicit_assignment_preserved(self):
        obs, initial = observation(); first = self.detect(obs, initial)
        changed = deepcopy(initial)
        for candidate in changed['candidates']:
            points = np.asarray(candidate['boundary_evidence']['full_arc_measured_points_world'])
            candidate['boundary_evidence']['full_arc_measured_points_world'] = (points+[8, -4, 3]).tolist()
        second = self.detect(obs, changed, (1, 0))
        self.assertTrue(second['detected'])
        for robot in (0, 1):
            self.assertEqual(second['hypotheses'][robot]['edge_point_world'], first['hypotheses'][robot]['edge_point_world'])
            self.assertEqual(second['hypotheses'][robot]['initial_candidate_index'], 1-robot)

    def test_current_wrist_camera_extrinsics_follow_each_own_grasp(self):
        obs, initial = observation()
        obs['rgb'][3:5] = 0
        obs['depth_valid'][3:5] = False
        for camera in (1, 2):
            obs['depth'][camera] = .6
            obs['depth_valid'][camera] = True
            obs['rgb'][camera, 30:225, 128:230] = [10, 20, 230]
            obs['depth'][camera, 30:225, 128:230, 0] = .24
        result = self.detect(obs, initial)
        self.assertTrue(result['detected'], result)
        for robot, item in enumerate(result['hypotheses']):
            self.assertEqual(item['camera_index'], robot+1)
            self.assertEqual(item['agreeing_camera_indices'], [robot+1])
            self.assertFalse(item['multi_view_agreement_checked'])
            self.assertLess(item['distance_from_current_grasp_m'], .01)

    def test_current_depth_and_timestamp_recomputed_without_cached_geometry(self):
        obs, initial = observation(); first = self.detect(obs, initial)
        obs['simulation_time_s'] = np.array(3.)
        obs['depth'][3:5, 80:177, 80:177, 0] = 1.015
        second = self.detect(obs, initial)
        self.assertTrue(second['detected'], second)
        for robot in (0, 1):
            self.assertEqual(second['hypotheses'][robot]['observation_time_s'], 3.)
            self.assertEqual(second['hypotheses'][robot]['measured_edge_depth_z_m'], 1.015)
            self.assertGreater(np.linalg.norm(np.asarray(first['hypotheses'][robot]['edge_point_world'])-
                                              second['hypotheses'][robot]['edge_point_world']), .01)
        obs['depth'][3:5, 80:177, 80:177, 0] = 1.2
        self.assertFalse(self.detect(obs, initial)['detected'])

    def test_current_boundary_missing_depth_does_not_use_initial_edge(self):
        obs, initial = observation()
        obs['depth_valid'][3:5, 105:152, 80, 0] = False
        result = self.detect(obs, initial)
        self.assertFalse(result['detected'])
        self.assertIsNone(result['hypotheses'][0])
        self.assertIsNotNone(result['hypotheses'][1])

    def test_missing_middle_depth_is_not_joined_into_continuous_arc(self):
        obs, initial = observation()
        obs['depth_valid'][3:5, 128, 80, 0] = False
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(result['robots'][0]['ambiguous'])
        self.assertEqual(result['robots'][0]['reason'], 'multiple_current_edges_near_grasp')

    def test_foreground_noncloth_occlusion_edges_rejected(self):
        obs, initial = observation()
        obs['depth'][3:5, 100:157, 79, 0] = .7
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(any(d['rejected_counts'].get('foreground_noncloth_occludes_edge')
                            for d in result['per_camera_diagnostics']))

    def test_exterior_missing_depth_rejected(self):
        obs, initial = observation()
        obs['depth_valid'][3:5, 100:157, 79, 0] = False
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(any(d['rejected_counts'].get('exterior_depth_missing')
                            for d in result['per_camera_diagnostics']))

    def test_internal_yellow_hole_is_not_held_external_edge(self):
        obs, initial = observation()
        obs['rgb'][3:5, 115:142, 115:142] = [230, 220, 10]
        obs['depth'][3:5, 115:142, 115:142, 0] = 1.2
        values = _validated(obs, wrists=True)
        obs['grasp_pose_base'][0, :3] = _world_pixels(values, 3, 115, 128, 1.)
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(any(d['rejected_counts'].get('internal_colour_hole_excluded')
                            for d in result['per_camera_diagnostics']))

    def test_two_disconnected_nearby_edges_are_ambiguous(self):
        obs, initial = observation()
        obs['rgb'][3:5, 100:157, 70:75] = [10, 20, 230]
        obs['depth'][3:5, 100:157, 70:75, 0] = 1.
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(result['robots'][0]['ambiguous'])

    def test_image_border_component_not_accepted(self):
        obs, initial = observation()
        obs['rgb'][3:5, 0:177, 80:177] = [10, 20, 230]
        obs['depth'][3:5, 0:177, 80:177, 0] = 1.
        result = self.detect(obs, initial)
        self.assertEqual(result['hypotheses'], [None, None])
        self.assertTrue(any(d['rejected_counts'].get('image_border_contour_excluded')
                            for d in result['per_camera_diagnostics']))

    def test_cross_camera_disagreement_abstains_instead_of_averaging(self):
        obs, initial = observation()
        obs['rgb'][4, 80:177, 80:85] = 0
        obs['depth'][4, 80:177, 80:85, 0] = 1.5
        result = self.detect(obs, initial)
        self.assertIsNone(result['hypotheses'][0])
        self.assertTrue(result['robots'][0]['ambiguous'])
        self.assertEqual(result['robots'][0]['reason'], 'current_camera_edges_disagree_over_2cm_or_tangent')

    def test_same_region_for_two_grasps_rejected(self):
        obs, initial = observation()
        obs['grasp_pose_base'][1] = obs['grasp_pose_base'][0]
        result = self.detect(obs, initial)
        self.assertFalse(result['distinct_current_regions'])
        self.assertEqual(result['hypotheses'], [None, None])
        self.assertTrue(all(row['ambiguous'] for row in result['robots']))

    def test_overview_ignored_and_inputs_unchanged(self):
        obs, initial = observation()
        obs['rgb'][0] = 255
        obs['depth'][0] = np.nan
        before = deepcopy(obs); original = deepcopy(initial)
        result = self.detect(obs, initial)
        self.assertTrue(result['detected'])
        self.assertEqual(initial, original)
        for key in obs:
            np.testing.assert_array_equal(obs[key], before[key])
        self.assertNotIn(0, result['cameras_used'])

    def test_invalid_assignment_radius_timestamp_and_future_prior(self):
        obs, initial = observation()
        for assignment in ((0, 0), (1, 1), (True, False), (.0, 1.), None):
            with self.assertRaises(ValueError):
                self.detect(obs, initial, assignment)
        for radius in (.02, .081, np.nan):
            with self.assertRaises(ValueError):
                edge.estimate_held_edge_hypotheses(obs, initial, [0, 1], radius_m=radius)
        initial['candidates'][0]['boundary_evidence']['observation_time_s'] = 3.
        result = self.detect(obs, initial)
        self.assertFalse(result['detected'])
        self.assertIn('future', result['reason'])
        obs['simulation_time_s'] = np.array(np.nan)
        with self.assertRaises(ValueError):
            self.detect(obs, initial)


if __name__ == '__main__':
    unittest.main()
