"""Synthetic public-cloud tests for bounded observed-obstacle route planning."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import planar_navigation as navigation


def observation(start=(-1.5, 0), other=(3., 3.), robot=0):
    bases = np.zeros((2, 7)); bases[:, 3] = 1
    bases[robot, :2] = start; bases[1-robot, :2] = other
    return {'base_pose_world': bases, 'grasp_pose_base': np.array([[.5, -.08, 1., 1, 0, 0, 0]]*2)}


def cloud(points):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    return {'points': np.column_stack((points, np.full(len(points), .4))),
            'sampled_valid_count': len(points), 'filtered_self_count': 0}


def plan(obs, goal, points, robot=0, **kwargs):
    with patch.object(navigation, '_depth_obstacle_points', return_value=cloud(points)):
        return navigation.plan_base_route(obs, robot, goal, **kwargs)


def plan_pair(obs, shift, points, **kwargs):
    with patch.object(navigation, '_depth_obstacle_points', return_value=cloud(points)):
        return navigation.plan_pair_route(obs, shift, **kwargs)


def corridor(center_y=0.):
    """Finite 84 cm gap: fits the default base margin but requires slowdown."""
    x = np.linspace(-.5, .5, 21)
    return np.vstack((np.column_stack((x, np.full(len(x), center_y-.42))),
                      np.column_stack((x, np.full(len(x), center_y+.42)))))


class PlanarNavigationTests(unittest.TestCase):
    def test_clear_exact_endpoints_can_attach_without_clearing_occupied_cells(self):
        obs = observation(start=(-1., 0))
        points = np.array([[-1., .425], [1., .425]])
        result = plan(obs, [1., 0], points, execution_clearance_m=.12)
        self.assertTrue(result['feasible'], result)
        origin = np.asarray(result['region_origin_world_xy'])
        centers = np.vstack((points, obs['base_pose_world'][1, :2]))
        radii = np.r_[np.full(2, .42), .72]
        occupied = navigation._inflate(origin, tuple(result['grid_shape']), centers, radii)
        for name, endpoint in [('start', [-1., 0]), ('goal', [1., 0])]:
            connection = result['grid_endpoint_connections'][name]
            self.assertTrue(connection['rounded_cell_occupied'])
            self.assertTrue(occupied[tuple(connection['rounded_grid_node_yx'])])
            self.assertFalse(occupied[tuple(connection['grid_node_yx'])])
            self.assertLessEqual(connection['connection_length_m'], .10)
            self.assertTrue(navigation._segment_clear(np.array(endpoint),
                np.array(connection['grid_node_world_xy']), centers, radii))
        path = np.asarray(result['waypoints_world_xy'])
        np.testing.assert_allclose(path[[0, -1]], [[-1., 0], [1., 0]])
        for start, end in zip(path, path[1:]):
            self.assertTrue(navigation._segment_clear(start, end, centers, radii))

    def test_grid_connection_cannot_cross_obstacle_to_reach_free_node(self):
        # A free node across a blocking disk is not an allowed attachment,
        # even though both endpoints themselves are outside that disk.
        occupied = np.ones((3, 3), bool); occupied[1, 2] = False
        original = occupied.copy()
        node, detail = navigation._endpoint_grid_connection(np.array([-.05, 0]),
            np.array([-.05, -.05]), occupied, np.array([[0., 0.]]), np.array([.04]))
        self.assertIsNone(node)
        self.assertFalse(detail['connected'])
        self.assertEqual(detail['free_candidate_segments_checked'], 1)
        np.testing.assert_array_equal(occupied, original)

    def test_endpoint_connections_are_bounded_and_do_not_escape_narrow_corridor(self):
        x = np.linspace(-.6, .6, 25)
        walls = np.vstack((np.column_stack((x, np.full(len(x), -.43))),
                           np.column_stack((x, np.full(len(x), .43)))))
        result = plan(observation(start=(0, 0)), [1.5, 0], walls, execution_clearance_m=.12)
        # Exact center has 13 cm clearance, but no fully clear 5 cm cell is
        # available within the connector's 10 cm bound. Do not tunnel out.
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'start_endpoint_has_no_clear_grid_connection')
        self.assertEqual(result['waypoints_world_xy'], [])
        self.assertFalse(result['grid_endpoint_connections']['start']['connected'])

    def test_wider_execution_margin_routes_around_narrow_slowdown_corridor(self):
        points = corridor()
        default = plan(observation(), [1.5, 0], points)
        explicit_default = plan(observation(), [1.5, 0], points, execution_clearance_m=.04)
        wider = plan(observation(), [1.5, 0], points, execution_clearance_m=.16)
        self.assertTrue(default['feasible'], default)
        self.assertTrue(wider['feasible'], wider)
        np.testing.assert_allclose(default['waypoints_world_xy'], explicit_default['waypoints_world_xy'])
        self.assertEqual(default['execution_clearance_m'], .04)
        # The straight center route has only 12 cm outside the 30 cm footprint:
        # it enters the live guard's 20 cm braking region. A 16 cm planning
        # margin must avoid that corridor, rather than smooth back through it.
        self.assertEqual(len(default['waypoints_world_xy']), 2)
        path = np.asarray(wider['waypoints_world_xy'])
        self.assertGreater(len(path), 2)
        self.assertGreater(wider['path_length_m'], default['path_length_m'])
        for start, end in zip(path, path[1:]):
            self.assertTrue(navigation._segment_clear(start, end, points, np.full(len(points), .46)))
        self.assertEqual(wider['execution_clearance_m'], .16)
        self.assertEqual(wider['obstacle_clearance_m'], .16)

    def test_wider_margin_rejects_start_and_goal_without_clearing_obstacles(self):
        for point, reason in [([-1.5, .42], 'start_in_observed_collision_rejected'),
                              ([1.5, .42], 'goal_in_observed_collision_rejected')]:
            with self.subTest(point=point):
                default = plan(observation(), [1.5, 0], [point])
                wider = plan(observation(), [1.5, 0], [point], execution_clearance_m=.16)
                self.assertTrue(default['feasible'], default)
                self.assertFalse(wider['feasible'])
                self.assertEqual(wider['reason'], reason)
                self.assertEqual(wider['waypoints_world_xy'], [])
                self.assertEqual(wider['execution_clearance_m'], .16)

    def test_wider_margin_applies_to_other_robot_disk(self):
        obs = observation(other=(2.2, 0))
        self.assertTrue(plan(obs, [1.5, 0], [])['feasible'])
        result = plan(obs, [1.5, 0], [], execution_clearance_m=.16)
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'goal_in_observed_collision_rejected')

    def test_invalid_clearance_fails_before_depth_for_both_planners(self):
        for margin in (float('nan'), float('inf'), -float('inf'), .0399, .2001,
                       20., None, 'bad', [.16], 10**400):
            with self.subTest(margin=margin), patch.object(navigation, '_depth_obstacle_points') as read:
                single = navigation.plan_base_route(observation(), 0, [1.5, 0], execution_clearance_m=margin)
                pair = navigation.plan_pair_route(observation(), [.5, 0], execution_clearance_m=margin)
                for result in (single, pair):
                    self.assertFalse(result['feasible'])
                    self.assertIn('finite scalar in [0.04, 0.20]', result['reason'])
                    self.assertIsNone(result['execution_clearance_m'])
                read.assert_not_called()
        for margin in (.04, .20):
            self.assertTrue(plan(observation(), [1.5, 0], [], execution_clearance_m=margin)['feasible'])

    def test_segment_validation_rejects_35mm_early_waypoint_corner_cut(self):
        obs = observation(start=(.31, .345))
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud([[0, 0]])):
            original_approach = navigation.validate_base_route_segment(obs, 0, [-.3, .345], [.345, .345])
            original_departure = navigation.validate_base_route_segment(obs, 0, [.345, .345], [.345, -.3])
            shortcut = navigation.validate_base_route_segment(obs, 0, [.31, .345], [.345, -.3])
        self.assertTrue(original_approach['feasible'])
        self.assertTrue(original_departure['feasible'])
        self.assertFalse(shortcut['feasible'])
        self.assertEqual(shortcut['reason'], 'segment_in_observed_collision_rejected')

    def test_segment_validation_keeps_unknown_margin_and_companion_constraints(self):
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud([])):
            result = navigation.validate_base_route_segment(observation(), 0, [-1, 0], [1, 0], .16)
            blocked = navigation.validate_base_route_segment(observation(other=(0, .7)), 0, [-1, 0], [1, 0], .16)
            invalid = navigation.validate_base_route_segment(observation(), 0, [-1, 0], [1, 0], float('nan'))
        self.assertTrue(result['feasible'])
        self.assertTrue(result['unknown_space'])
        self.assertFalse(result['space_is_certified_free'])
        self.assertTrue(result['execution_requires_depth_guard'])
        self.assertEqual(result['execution_clearance_m'], .16)
        self.assertFalse(blocked['feasible'])
        self.assertFalse(invalid['feasible'])

    def test_rectangle_table_detour_and_simplified_segments_remain_clear(self):
        x, y = np.meshgrid(np.linspace(-.4, .4, 9), np.linspace(-.5, .5, 11))
        table = np.column_stack((x.ravel(), y.ravel()))
        result = plan(observation(), (1.5, 0), table)
        self.assertTrue(result['feasible'], result)
        waypoints = np.asarray(result['waypoints_world_xy'])
        self.assertGreaterEqual(len(waypoints), 3)
        self.assertGreater(np.max(np.abs(waypoints[:, 1])), .84)
        for a, b in zip(waypoints, waypoints[1:]):
            self.assertTrue(navigation._segment_clear(a, b, table, np.full(len(table), .34)))
        self.assertLessEqual(result['expanded_nodes'], navigation.MAX_EXPANSIONS)
        self.assertLessEqual(result['region_side_m'], 8.)

    def test_enclosed_goal_is_unreachable_without_clearing_wall(self):
        line = np.linspace(-.8, .8, 33)
        walls = np.vstack((np.column_stack((line, np.full(len(line), -.8))),
                           np.column_stack((line, np.full(len(line), .8))),
                           np.column_stack((np.full(len(line), -.8), line)),
                           np.column_stack((np.full(len(line), .8), line))))
        result = plan(observation(start=(-2., 0)), (0, 0), walls)
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'no_route_in_bounded_region')

    def test_eight_neighbor_search_cannot_cut_diagonal_corner(self):
        occupied = np.array([[False, True], [True, False]])
        route, _, reason = navigation._astar(occupied, (0, 0), (1, 1))
        self.assertIsNone(route)
        self.assertEqual(reason, 'no_route_in_bounded_region')

    def test_robot_role_symmetry(self):
        points = np.array([[0., y] for y in np.linspace(-.4, .4, 9)])
        first = plan(observation(robot=0), (1.5, 0), points, robot=0)
        second = plan(observation(robot=1), (1.5, 0), points, robot=1)
        self.assertTrue(first['feasible']); self.assertTrue(second['feasible'])
        np.testing.assert_allclose(first['waypoints_world_xy'], second['waypoints_world_xy'])

    def test_far_goal_rejected_before_any_depth_query(self):
        with patch.object(navigation, '_depth_obstacle_points') as read:
            result = navigation.plan_base_route(observation(), 0, [8., 0.])
        self.assertFalse(result['feasible'])
        self.assertIn('outside_bounded', result['reason'])
        read.assert_not_called()

    def test_actual_endpoint_obstacles_are_never_cleared(self):
        for point, reason in [([-1.5, 0], 'start_in_observed_collision_rejected'),
                              ([1.5, 0], 'goal_in_observed_collision_rejected')]:
            result = plan(observation(), [1.5, 0], [point])
            self.assertFalse(result['feasible'])
            self.assertEqual(result['reason'], reason)
            self.assertEqual(result['waypoints_world_xy'], [])

    def test_other_base_is_an_extra_inflated_obstacle(self):
        result = plan(observation(other=(0., 0.)), [1.5, 0], [])
        self.assertTrue(result['feasible'], result)
        path = np.asarray(result['waypoints_world_xy'])
        self.assertGreater(np.max(np.abs(path[:, 1])), .64)
        for a, b in zip(path, path[1:]):
            self.assertTrue(navigation._segment_clear(a, b, np.array([[0., 0.]]), np.array([.64])))

    def test_no_depth_stays_explicitly_unknown(self):
        result = plan(observation(), [1.5, 0], [])
        self.assertTrue(result['feasible'])
        self.assertTrue(result['unknown_space'])
        self.assertFalse(result['space_is_certified_free'])
        self.assertTrue(result['execution_requires_depth_guard'])
        self.assertEqual(result['route_observation_status'], 'unobserved_route')


class PairNavigationTests(unittest.TestCase):
    def test_pair_segment_retains_clear_tangent_but_rejects_new_obstacle(self):
        obs = observation(start=(-1., -.6), other=(-1., .6))
        # Lower base passes a surface at 12.5 cm outside its footprint: this
        # is valid at .12 despite the guard applying ordinary slowdown.
        points = [[0., -1.025]]
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud(points)):
            clear = navigation.validate_pair_route_segment(obs, [-1., 0], [1., 0])
        self.assertTrue(clear['feasible'], clear)
        self.assertEqual(clear['base_sweeps_clear'], [True, True])
        self.assertEqual(clear['execution_clearance_m'], .12)
        # The pair center remains clear, but a newly visible object intersects
        # only the upper base's path. Both sweeps must be checked separately.
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud(points+[[0., .6]])):
            blocked = navigation.validate_pair_route_segment(obs, [-1., 0], [1., 0])
        self.assertFalse(blocked['feasible'])
        self.assertEqual(blocked['base_sweeps_clear'], [True, False])
        self.assertEqual(blocked['reason'], 'pair_segment_in_observed_collision_rejected')
        self.assertEqual(blocked['swept_base_segments_checked'], 2)

    def test_pair_segment_filters_both_own_models_but_not_adjacent_obstacle(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        masts = obs['base_pose_world'][:, :3]+[-.093, -.10, .6]
        with patch.object(navigation, '_depth_obstacle_points', return_value={'points': masts}):
            clear = navigation.validate_pair_route_segment(obs, [0, 0], [0, 1])
        self.assertTrue(clear['feasible'], clear)
        self.assertEqual(clear['planning_self_body_excluded_count_by_robot'], [2, 2])
        self.assertEqual(clear['retained_obstacle_point_count_by_robot'], [0, 0])
        with patch.object(navigation, '_depth_obstacle_points', return_value={
                'points': np.vstack((masts, [-.68, 0, .6]))}):
            blocked = navigation.validate_pair_route_segment(obs, [0, 0], [0, 1])
        self.assertFalse(blocked['feasible'])
        self.assertEqual(blocked['base_sweeps_clear'], [False, True])
        self.assertEqual(blocked['retained_obstacle_point_count_by_robot'], [1, 1])

    def test_pair_segment_current_offsets_and_role_swap_match(self):
        obs = observation(start=(-1., -.6), other=(-1., .6))
        swapped = {key: value[::-1].copy() for key, value in obs.items()}
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud([[0., .6]])):
            first = navigation.validate_pair_route_segment(obs, [-1, 0], [1, 0])
            second = navigation.validate_pair_route_segment(swapped, [-1, 0], [1, 0])
        self.assertFalse(first['feasible']); self.assertFalse(second['feasible'])
        self.assertEqual(first['base_sweeps_clear'], second['base_sweeps_clear'][::-1])
        np.testing.assert_allclose(first['base_offsets_from_pair_center_world_xy'],
                                   second['base_offsets_from_pair_center_world_xy'][::-1])

    def test_pair_segment_rejects_spacing_and_invalid_input_before_depth(self):
        cases = [(observation(start=(0, 0), other=(.7, 0)), [0, 0], [1, 0], .12,
                  'initial_pair_footprints_overlap_or_lack_clearance'),
                 (observation(), [0, 0], [float('nan'), 0], .12, 'invalid_planning_input'),
                 (observation(), [0, 0], [1, 0], float('nan'), 'invalid_planning_input')]
        for obs, start, end, margin, reason in cases:
            with self.subTest(reason=reason), patch.object(navigation, '_depth_obstacle_points') as read:
                result = navigation.validate_pair_route_segment(obs, start, end, margin)
                self.assertFalse(result['feasible']); self.assertIn(reason, result['reason'])
                read.assert_not_called()

    def test_pair_segment_unknown_stays_unknown_and_zero_length_checks_both_bases(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud([])):
            clear = navigation.validate_pair_route_segment(obs, [0, 0], [0, 0])
        self.assertTrue(clear['feasible'])
        self.assertTrue(clear['unknown_space'])
        self.assertFalse(clear['space_is_certified_free'])
        self.assertTrue(clear['execution_requires_fixed_pair_offsets'])
        self.assertTrue(clear['execution_requires_depth_guard'])
        self.assertFalse(clear['other_robot_is_fixed_obstacle'])
        with patch.object(navigation, '_depth_obstacle_points', return_value=cloud([[1.32, 0]])):
            blocked = navigation.validate_pair_route_segment(obs, [0, 0], [0, 0])
        self.assertFalse(blocked['feasible'])
        self.assertEqual(blocked['base_sweeps_clear'], [True, False])

    def assert_pair_sweeps_clear(self, obs, result, points, margin=.04):
        self.assertTrue(result['feasible'], result)
        centers = np.asarray(result['pair_center_waypoints_world_xy'])
        offsets = obs['base_pose_world'][:, :2] - obs['base_pose_world'][:, :2].mean(axis=0)
        obstacles = np.asarray(points).reshape(-1, 2)
        for robot in (0, 1):
            path = centers + offsets[robot]
            for start, end in zip(path, path[1:]):
                self.assertTrue(navigation._segment_clear(start, end, obstacles,
                                                         np.full(len(obstacles), .30+margin)))
        np.testing.assert_allclose(centers[0], obs['base_pose_world'][:, :2].mean(axis=0))
        self.assertEqual(result['swept_base_segments_checked'], 2*(len(centers)-1))

    def test_wider_shared_route_avoids_one_bases_slowdown_corridor(self):
        obs = observation(start=(-1.5, -.6), other=(-1.5, .6))
        points = corridor(center_y=-.6)
        default = plan_pair(obs, [3., 0], points)
        explicit_default = plan_pair(obs, [3., 0], points, execution_clearance_m=.04)
        wider = plan_pair(obs, [3., 0], points, execution_clearance_m=.16)
        self.assert_pair_sweeps_clear(obs, default, points)
        self.assert_pair_sweeps_clear(obs, wider, points, margin=.16)
        np.testing.assert_allclose(default['pair_center_waypoints_world_xy'],
                                   explicit_default['pair_center_waypoints_world_xy'])
        self.assertEqual(len(default['pair_center_waypoints_world_xy']), 2)
        self.assertGreater(len(wider['pair_center_waypoints_world_xy']), 2)
        self.assertGreater(wider['path_length_m'], default['path_length_m'])
        self.assertEqual(wider['obstacle_clearance_m'], .16)
        self.assertEqual(wider['execution_clearance_m'], .16)

    def test_shared_configuration_endpoint_connectors_keep_both_base_sweeps_clear(self):
        obs = observation(start=(-1., -.6), other=(-1., .6))
        points = np.array([[-1., -1.025], [1., -1.025]])
        result = plan_pair(obs, [2., 0], points, execution_clearance_m=.12)
        self.assert_pair_sweeps_clear(obs, result, points, margin=.12)
        for name in ('start', 'goal'):
            attachment = result['grid_endpoint_connections'][name]
            self.assertTrue(attachment['rounded_cell_occupied'])
            self.assertTrue(attachment['connected'])
            self.assertLessEqual(attachment['connection_length_m'], .10)
        np.testing.assert_allclose(result['pair_center_waypoints_world_xy'][0], [-1., 0.])
        np.testing.assert_allclose(result['pair_center_waypoints_world_xy'][-1], [1., 0.])

    def test_wider_pair_margin_rejects_one_base_endpoint(self):
        obs = observation(start=(-1.5, -.6), other=(-1.5, .6))
        for point, reason in [([-1.5, -1.02], 'start_in_observed_collision_rejected'),
                              ([1.5, -1.02], 'goal_in_observed_collision_rejected')]:
            with self.subTest(point=point):
                self.assertTrue(plan_pair(obs, [3., 0], [point])['feasible'])
                wider = plan_pair(obs, [3., 0], [point], execution_clearance_m=.16)
                self.assertFalse(wider['feasible'])
                self.assertEqual(wider['reason'], reason)
                self.assertEqual(wider['pair_center_waypoints_world_xy'], [])

    def test_wider_margin_requires_initial_pair_separation(self):
        obs = observation(start=(0, 0), other=(.7, 0))
        self.assertTrue(plan_pair(obs, [1., 0], [])['feasible'])
        with patch.object(navigation, '_depth_obstacle_points') as read:
            result = navigation.plan_pair_route(obs, [1., 0], execution_clearance_m=.16)
            read.assert_not_called()
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'initial_pair_footprints_overlap_or_lack_clearance')

    def test_opposite_table_sides_require_shared_retreat_before_sideways_transport(self):
        # Synthetic table, not environment truth: a direct diagonal translation
        # catches the left base on a table corner despite a clear pair center.
        obs = observation(start=(-.9, 0), other=(.9, 0))
        x, y = np.meshgrid(np.linspace(-.45, .45, 10), np.linspace(-.5, .5, 11))
        table = np.column_stack((x.ravel(), y.ravel()))
        shift = np.array([1., 1.6])
        self.assertFalse(navigation._segment_clear(obs['base_pose_world'][0, :2],
            obs['base_pose_world'][0, :2]+shift, table, np.full(len(table), .34)))
        result = plan_pair(obs, shift, table)
        self.assert_pair_sweeps_clear(obs, result, table)
        path = np.asarray(result['pair_center_waypoints_world_xy'])
        self.assertGreaterEqual(len(path), 3)
        np.testing.assert_allclose(path[-1], shift)
        self.assertLessEqual(result['expanded_nodes'], navigation.MAX_EXPANSIONS)
        self.assertLessEqual(result['region_side_m'], navigation.MAX_SIDE)

    def test_obstacle_on_only_one_base_path_still_requires_pair_detour(self):
        obs = observation(start=(-1.5, -.6), other=(-1.5, .6))
        points = np.array([[0., .6]])
        result = plan_pair(obs, [3., 0], points)
        self.assert_pair_sweeps_clear(obs, result, points)
        self.assertGreaterEqual(len(result['pair_center_waypoints_world_xy']), 3)

    def test_individually_feasible_routes_cannot_be_combined_through_narrow_gap(self):
        obs = observation(start=(-1.5, -.6), other=(-1.5, .6))
        y = np.r_[np.arange(-5., -.449, .05), np.arange(.45, 5.001, .05)]
        wall = np.column_stack((np.zeros(len(y)), y))
        for robot in (0, 1):
            individual = plan(obs, obs['base_pose_world'][robot, :2]+[3., 0], wall, robot=robot)
            self.assertTrue(individual['feasible'], individual)
        paired = plan_pair(obs, [3., 0], wall)
        self.assertFalse(paired['feasible'])
        self.assertEqual(paired['reason'], 'no_route_in_bounded_region')

    def test_role_swap_preserves_shared_route(self):
        obs = observation(start=(-1.5, -.6), other=(-1.5, .6))
        swapped = {key: value[::-1].copy() for key, value in obs.items()}
        points = [[0., .6]]
        first, second = plan_pair(obs, [3., 0], points), plan_pair(swapped, [3., 0], points)
        self.assertTrue(first['feasible'], first); self.assertTrue(second['feasible'], second)
        np.testing.assert_allclose(first['pair_center_waypoints_world_xy'], second['pair_center_waypoints_world_xy'])
        np.testing.assert_allclose(first['base_offsets_from_pair_center_world_xy'],
                                   second['base_offsets_from_pair_center_world_xy'][::-1])

    def test_companion_initial_position_is_not_a_stationary_obstacle(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        result = plan_pair(obs, [2., 0], [[-1., .05], [1., .05]])
        self.assertTrue(result['feasible'], result)
        self.assertEqual(result['planning_self_body_excluded_count_by_robot'], [2, 2])
        self.assertFalse(result['other_robot_is_fixed_obstacle'])
        self.assertTrue(result['unknown_space'])
        self.assertFalse(result['space_is_certified_free'])
        self.assertTrue(result['execution_requires_fixed_pair_offsets'])
        self.assertTrue(result['execution_requires_depth_guard'])
        self.assertIn('contacting environment', result['limitation'])

    def test_real_start_or_goal_collision_is_not_cleared(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        cases = [([-.75, 0], 'start_in_observed_collision_rejected'),
                 ([3., 0], 'goal_in_observed_collision_rejected')]
        for point, expected in cases:
            with self.subTest(point=point):
                result = plan_pair(obs, [2., 0], [point])
                self.assertFalse(result['feasible'])
                self.assertEqual(result['reason'], expected)
                self.assertEqual(result['pair_center_waypoints_world_xy'], [])
        # Near a base at height 0.6 is not in the narrow low-body exclusion.
        with patch.object(navigation, '_depth_obstacle_points', return_value={
                'points': np.array([[-1., 0, .6]]), 'sampled_valid_count': 1}):
            result = navigation.plan_pair_route(obs, [2., 0])
        self.assertEqual(result['reason'], 'start_in_observed_collision_rejected')

    def test_pair_masts_move_with_formation_but_adjacent_surface_remains_obstacle(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        masts = obs['base_pose_world'][:, :3]+[-.093, -.10, .6]
        with patch.object(navigation, '_depth_obstacle_points', return_value={
                'points': masts, 'sampled_valid_count': 2}):
            result = navigation.plan_pair_route(obs, [2., 0])
        self.assertTrue(result['feasible'], result)
        self.assertEqual(result['planning_self_body_excluded_count_by_robot'], [2, 2])
        with patch.object(navigation, '_depth_obstacle_points', return_value={
                'points': np.vstack((masts, [-.75, 0, .6])), 'sampled_valid_count': 3}):
            result = navigation.plan_pair_route(obs, [2., 0])
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'start_in_observed_collision_rejected')

    def test_far_shift_and_initial_pair_collision_are_rejected_without_depth_query(self):
        cases = [(observation(start=(-1., 0), other=(1., 0)), [8., 0], 'outside_bounded'),
                 (observation(start=(0, 0), other=(.5, 0)), [1., 0], 'footprints_overlap')]
        for obs, shift, reason in cases:
            with self.subTest(reason=reason), patch.object(navigation, '_depth_obstacle_points') as read:
                result = navigation.plan_pair_route(obs, shift)
                self.assertFalse(result['feasible']); self.assertIn(reason, result['reason'])
                read.assert_not_called()

    def test_zero_shift_still_checks_both_base_collisions(self):
        obs = observation(start=(-1., 0), other=(1., 0))
        result = plan_pair(obs, [0., 0], [])
        self.assertTrue(result['feasible'], result)
        self.assertEqual(result['pair_center_waypoints_world_xy'], [[0., 0.]])
        self.assertEqual(result['path_length_m'], 0.)
        result = plan_pair(obs, [0., 0], [[1.25, 0]])
        self.assertFalse(result['feasible'])
        self.assertEqual(result['reason'], 'start_in_observed_collision_rejected')


if __name__ == '__main__':
    unittest.main()
