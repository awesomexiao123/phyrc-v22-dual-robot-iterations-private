from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch, Mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
import sleeve_contact_policy as contact
from test_sleeve_pair_policy import Baseline, observation
from test_sleeve_edge_policy import proposal


class ContactPolicyTests(unittest.TestCase):
    def actor(self):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = contact.Policy('unused.pt')
        actor.shirt = proposal(9.)
        actor.shirt_observed_at = 9.
        return actor

    def test_local_current_handoff_retains_original_width_prior_unchanged(self):
        actor = self.actor(); original = deepcopy(actor.shirt)
        current = proposal(10.)
        current['candidates'][0]['target_world'][0] += .008
        with patch.object(contact, 'reacquire_planar_sleeve_edges', return_value=current) as reacquire, \
                patch.object(contact.SleeveSidePolicy, '_prepare_pair') as prepare:
            actor._prepare_pair(observation())
        self.assertEqual(actor.initial_edge_report, original)
        self.assertEqual(actor.shirt, current)
        self.assertEqual(actor.shirt_observed_at, 10.)
        reacquire.assert_called_once()
        prepare.assert_called_once()
        self.assertIsNot(actor.initial_edge_report, original)

    def test_unknown_local_edges_do_not_fall_back_or_start_contact(self):
        actor = self.actor()
        with patch.object(contact, 'reacquire_planar_sleeve_edges', return_value={'detected':False, 'reason':'occluded'}):
            with self.assertRaisesRegex(ValueError, 'occluded'):
                actor._prepare_pair(observation())
        self.assertIsNone(actor.initial_edge_report)
        self.assertIsNone(actor.contact_experiment)

    def test_staging_transition_defers_contact_until_next_observation(self):
        actor = self.actor()
        actor.phase = 'dual_position_before_hands'
        def parent(obs):
            actor.phase = 'await_sleeve_geometry'
            return np.zeros((2,9), np.float32)
        with patch.object(contact.EdgePolicy, '__call__', side_effect=parent), \
                patch.object(contact, 'HypothesisContactExperiment') as experiment:
            actor(observation())
        self.assertEqual(actor.phase, 'hypothesis_contact')
        experiment.assert_not_called()

    def test_finished_trial_holds_on_future_calls(self):
        actor = self.actor(); actor.phase = 'contact_trial_complete'
        for _ in range(3):
            action = actor(observation())
            np.testing.assert_array_equal(action[:,:8],0)
            np.testing.assert_array_equal(action[:,8],1)
            self.assertIsNone(actor.failure)


if __name__ == '__main__':
    unittest.main()
