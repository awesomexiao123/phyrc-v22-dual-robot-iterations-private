"""Synthetic public RGB-D rim tracking; no physical opening or sleeve claim."""
import copy
from pathlib import Path
import sys
import unittest

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
from opening_candidates import detect_opening_candidates, _PUBLIC, _cloth_masks
from opening_rim_tracker import OpeningRimTracker


def scene(camera=3):
    pose = np.zeros((2, 7)); pose[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.full((5, 256, 256, 1), 1.5, np.float32),
        depth_valid=np.ones((5, 256, 256, 1), bool),
        base_pose_world=pose.copy(), grasp_pose_base=pose.copy(), simulation_time_s=1.)
    outer = np.zeros((256, 256), np.uint8)
    cv2.circle(outer, (128, 128), 48, 1, -1)
    interior = np.zeros_like(outer)
    cv2.circle(interior, (128, 128), 24, 1, -1)
    cloth = (outer > 0) & (interior == 0)
    rng = np.random.default_rng(29)
    texture = cv2.resize(rng.integers(120, 250, (128, 128), dtype=np.uint8),
                         (256, 256), interpolation=cv2.INTER_NEAREST)
    obs['rgb'][camera][cloth] = np.column_stack((np.full(cloth.sum(), 8),
                                               np.full(cloth.sum(), 14), texture[cloth]))
    obs['depth'][camera, ..., 0][cloth] = .7
    candidate = detect_opening_candidates(obs)['opening_candidates'][0]
    return obs, candidate, cloth, interior.astype(bool)


def shifted(obs, camera, dx, time):
    moved = copy.deepcopy(obs)
    affine = np.array([[1, 0, dx], [0, 1, 0]], np.float32)
    moved['rgb'][camera] = cv2.warpAffine(obs['rgb'][camera], affine, (256, 256))
    moved['depth'][camera, ..., 0] = cv2.warpAffine(obs['depth'][camera, ..., 0], affine,
        (256, 256), flags=cv2.INTER_NEAREST, borderValue=1.5)
    moved['depth_valid'][camera, ..., 0] = cv2.warpAffine(obs['depth_valid'][camera, ..., 0].astype(np.uint8),
        affine, (256, 256), flags=cv2.INTER_NEAREST).astype(bool)
    moved['simulation_time_s'] = time
    return moved


class OpeningRimTrackerTests(unittest.TestCase):
    def test_hand_10mm_behind_contour_preserves_fresh_rim_not_empty_space_claim(self):
        for camera in (1, 2, 3, 4):
            with self.subTest(camera=camera):
                obs, candidate, cloth, interior = scene(camera)
                tracker = OpeningRimTracker()
                start = tracker.reset(obs, candidate)
                self.assertTrue(start['reliable'], start['reason'])
                moved = copy.deepcopy(obs); moved['simulation_time_s'] = 1.05
                moved['rgb'][camera][interior] = [180, 110, 80]
                moved['depth'][camera, ..., 0][interior] = .710
                self.assertFalse(detect_opening_candidates(moved)['detected'])
                result = tracker.update(moved)
                self.assertTrue(result['reliable'], result['reason'])
                self.assertEqual(result['identity'], start['identity'])
                self.assertTrue(set(result['feature_ids']).issubset(start['feature_ids']))
                np.testing.assert_allclose(result['median_displacement_world'], 0, atol=.0003)
                self.assertEqual(result['rim_geometry']['observation_time_s'], 1.05)
                self.assertEqual(result['inner_aperture']['observation_time_s'], 1.05)
                self.assertEqual(result['rim_geometry']['current_rim_depth_valid_fraction'], 1.)
                self.assertNotIn('observed_depth_support', result['rim_geometry'])
                self.assertIn('unknown', result['current_interior_free_space'])
                self.assertFalse(result['insertion_allowed'])
                self.assertFalse(result['physical_opening_verified'])
                self.assertNotIn('action', result)

    def test_real_cloth_motion_and_fixed_camera_identity_accumulate_without_reseeding(self):
        obs, candidate, _, _ = scene()
        tracker = OpeningRimTracker(); initial = tracker.reset(obs, candidate)
        self.assertTrue(initial['reliable'])
        rotation, _ = _PUBLIC._camera_transform(obs, 3)
        previous_ids = set(initial['feature_ids'])
        for index, dx in enumerate((2, 4, 6), 1):
            moved = shifted(obs, 3, dx, 1.+index*.05)
            result = tracker.update(moved)
            self.assertTrue(result['reliable'], result['reason'])
            expected = rotation @ np.array([dx*.7/_PUBLIC._FOCAL, 0., 0.])
            np.testing.assert_allclose(result['median_displacement_world'], expected, atol=.0005)
            np.testing.assert_allclose(np.asarray(result['centroid_world'])-initial['centroid_world'], expected, atol=1e-7)
            self.assertTrue(set(result['feature_ids']).issubset(previous_ids))
            previous_ids = set(result['feature_ids'])
            self.assertFalse(result['features_reseeded'])

    def test_moving_head_or_wrist_does_not_report_static_cloth_motion(self):
        for camera in (1, 2, 3, 4):
            with self.subTest(camera=camera):
                obs, candidate, _, _ = scene(camera)
                tracker = OpeningRimTracker(); start = tracker.reset(obs, candidate)
                self.assertTrue(start['reliable'])
                rotation, _ = _PUBLIC._camera_transform(obs, camera)
                moved = shifted(obs, camera, -3, 1.05)
                translation = rotation @ np.array([3*.7/_PUBLIC._FOCAL, 0., 0.])
                robot, key = (camera-3, 'base_pose_world') if camera >= 3 else (camera-1, 'grasp_pose_base')
                moved[key][robot, :3] += translation
                result = tracker.update(moved)
                self.assertTrue(result['reliable'], result['reason'])
                np.testing.assert_allclose(result['median_displacement_world'], 0., atol=.0005)
                np.testing.assert_allclose(result['centroid_world'], start['centroid_world'], atol=1e-7)

    def test_missing_or_unrelated_rim_and_new_depth_discontinuity_latch_unknown(self):
        for fault in ('occlusion', 'partial_rim_occlusion', 'unrelated_texture', 'missing_depth', 'depth_jump', 'fill_hole', 'open_edge'):
            with self.subTest(fault=fault):
                obs, candidate, cloth, interior = scene()
                tracker = OpeningRimTracker(); self.assertTrue(tracker.reset(obs, candidate)['reliable'])
                bad = copy.deepcopy(obs); bad['simulation_time_s'] = 1.05
                if fault == 'occlusion': bad['rgb'][3][cloth] = [160, 160, 160]
                elif fault == 'partial_rim_occlusion':
                    cv2.circle(bad['rgb'][3], (151, 128), 10, (180, 110, 80), -1)
                    cv2.circle(bad['depth'][3, ..., 0], (151, 128), 10, .69, -1)
                elif fault == 'unrelated_texture':
                    rng = np.random.default_rng(704)
                    texture = cv2.resize(rng.integers(120, 250, (128, 128), dtype=np.uint8),
                        (256, 256), interpolation=cv2.INTER_NEAREST)
                    bad['rgb'][3, ..., 2][cloth] = texture[cloth]
                elif fault == 'missing_depth': bad['depth_valid'][3, ..., 0][cloth] = False
                elif fault == 'depth_jump': bad['depth'][3, ..., 0][cloth] = .61
                elif fault == 'fill_hole': bad['rgb'][3][interior] = [8, 14, 220]
                elif fault == 'open_edge': bad['rgb'][3, 125:132, 128:181] = 0
                result = tracker.update(bad)
                self.assertFalse(result['reliable'])
                self.assertIsNone(result['centroid_world'])
                self.assertIsNone(result['inner_aperture'])
                self.assertIsNone(result['median_displacement_world'])
                recovered = copy.deepcopy(obs); recovered['simulation_time_s'] = 1.10
                self.assertFalse(tracker.update(recovered)['reliable'])

    def test_split_aperture_rejects_multiple_matching_contours(self):
        obs, candidate, _, interior = scene()
        tracker = OpeningRimTracker(); self.assertTrue(tracker.reset(obs, candidate)['reliable'])
        moved = copy.deepcopy(obs); moved['simulation_time_s'] = 1.05
        cut = interior & (np.abs(np.indices((256, 256))[1]-128) <= 2)
        moved['rgb'][3][cut] = [8, 14, 220]
        moved['depth'][3, ..., 0][cut] = .7
        result = tracker.update(moved)
        self.assertFalse(result['reliable'])
        self.assertIn('multiple_matching', result['reason'])

    def test_current_depth_is_rebuilt_and_original_interior_evidence_cannot_seed_near_hand(self):
        obs, candidate, cloth, interior = scene()
        tracker = OpeningRimTracker(); start = tracker.reset(obs, candidate)
        moved = copy.deepcopy(obs); moved['simulation_time_s'] = 1.05
        moved['depth'][3, ..., 0][cloth] = .707
        result = tracker.update(moved)
        self.assertTrue(result['reliable'], result['reason'])
        rotation, _ = _PUBLIC._camera_transform(obs, 3)
        # The ray is at the actual pixel center, not exactly optical origin.
        self.assertAlmostEqual(np.dot(np.asarray(result['centroid_world'])-start['centroid_world'], rotation[:, 2]), .007, places=6)
        self.assertGreater(np.linalg.norm(np.asarray(result['centroid_world'])-start['centroid_world']), .0069)
        stale = copy.deepcopy(obs)
        stale['depth'][3, ..., 0][interior] = .710
        self.assertFalse(OpeningRimTracker().reset(stale, candidate)['reliable'])
        stale = copy.deepcopy(obs); stale['simulation_time_s'] = 2.
        self.assertFalse(OpeningRimTracker().reset(stale, candidate)['reliable'])

    def test_freshness_camera_jump_and_global_path_bounds(self):
        for fault in ('same_time', 'gap', 'age', 'camera_jump', 'path'):
            with self.subTest(fault=fault):
                obs, candidate, _, _ = scene()
                tracker = OpeningRimTracker(max_age_s=.06 if fault == 'age' else 120., max_path_m=.005 if fault == 'path' else .40)
                self.assertTrue(tracker.reset(obs, candidate)['reliable'])
                moved = copy.deepcopy(obs); moved['simulation_time_s'] = 1.05
                if fault == 'same_time': moved['simulation_time_s'] = 1.
                elif fault == 'gap': moved['simulation_time_s'] = 1.3
                elif fault == 'age': moved['simulation_time_s'] = 1.1
                elif fault == 'camera_jump': moved['base_pose_world'][0, 0] += .1
                elif fault == 'path': moved = shifted(obs, 3, 3, 1.05)
                result = tracker.update(moved)
                self.assertFalse(result['reliable'], result)


if __name__ == '__main__':
    unittest.main()
