"""Synthetic public RGB-D observability checks; no physical sleeve claims."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import sleeve_observation as diagnostic


def scene(camera=3, gap=.5, hole=True, centers=((128, 128),), outer=40, inner=20):
    pose = np.zeros((2, 7), np.float32); pose[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.full((5, 256, 256, 1), 2., np.float32),
               depth_valid=np.ones((5, 256, 256, 1), bool),
               base_pose_world=pose.copy(), grasp_pose_base=pose.copy())
    cloth = np.zeros((256, 256), np.uint8)
    interiors = np.zeros_like(cloth)
    for center in centers:
        cv2.circle(cloth, center, outer, 1, cv2.FILLED)
        if hole:
            cv2.circle(cloth, center, inner, 0, cv2.FILLED)
            cv2.circle(interiors, center, inner, 1, cv2.FILLED)
    obs['rgb'][camera][cloth.astype(bool)] = [10, 20, 230]
    obs['depth'][camera, ..., 0][cloth.astype(bool)] = 1.
    obs['depth'][camera, ..., 0][interiors.astype(bool)] = 1.+gap
    return obs


def point(obs, camera, u, v=128, depth=1.):
    values = diagnostic._validated(obs, wrists=True)
    return diagnostic._world_pixels(values, camera, np.array([u]), np.array([v]), np.array([depth]))[0]


def grasp_pair(obs, camera=3):
    first = point(obs, camera, 152)
    return np.stack([first, first+[1., 0., 0.]])


class SleeveObservationTests(unittest.TestCase):
    def test_measured_opening_remains_unclassified_and_observation_is_read_only(self):
        obs = scene(); grasps = grasp_pair(obs)
        original = {key: value.copy() for key, value in obs.items()}
        original_grasps = grasps.copy()
        report = diagnostic.diagnose_sleeve_observability(obs, grasps)
        first, second = report['grasp_regions']
        self.assertTrue(first['opening_visible_in_rgbd'])
        self.assertTrue(first['geometric_alignment_observable'])
        self.assertFalse(second['opening_visible_in_rgbd'])
        candidate = first['depth_supported_opening_candidates'][0]
        self.assertEqual(candidate['kind'], 'unclassified_opening')
        self.assertFalse(candidate['opening_verified'])
        self.assertFalse(first['physical_entrance_verified'])
        self.assertFalse(first['sleeve_identity_verified'])
        self.assertFalse(first['safe_for_insertion'])
        self.assertFalse(report['insertion_allowed'])
        self.assertFalse(report['sleeve_pair_verified'])
        self.assertIn('another_view', first['next_observation'])
        for key in obs:
            np.testing.assert_array_equal(obs[key], original[key])
        np.testing.assert_array_equal(grasps, original_grasps)

    def test_external_silhouette_and_yellow_outer_trim_never_become_an_entry(self):
        for yellow in (False, True):
            with self.subTest(yellow=yellow):
                obs = scene(hole=False)
                if yellow:
                    trim = np.zeros((256, 256), np.uint8)
                    cv2.circle(trim, (128, 128), 40, 1, 2)
                    obs['rgb'][3][trim.astype(bool)] = [230, 220, 10]
                    obs['depth'][3, ..., 0][trim.astype(bool)] = 1.
                report = diagnostic.observe_sleeve_regions(obs, grasp_pair(obs))
                first = report['grasp_regions'][0]
                self.assertGreater(first['observed_cloth_point_count'], 24)
                self.assertGreater(first['external_image_boundary_point_count'], 0)
                self.assertFalse(first['opening_visible_in_rgbd'])
                self.assertFalse(first['geometric_alignment_observable'])
                self.assertIn('external_silhouette_is_not_an_entry', first['reasons'])
                self.assertIn('change_camera_view', first['next_observation'])

    def test_foreground_same_depth_missing_depth_and_open_side_abstain(self):
        for mode in ('foreground', 'same_depth', 'missing_depth', 'open_side'):
            with self.subTest(mode=mode):
                obs = scene(gap=-.2 if mode == 'foreground' else 0. if mode == 'same_depth' else .5)
                if mode == 'missing_depth':
                    obs['depth_valid'][:] = False
                if mode == 'open_side':
                    obs['rgb'][3, 126:131, 128:175] = 0
                report = diagnostic.diagnose_sleeve_observability(obs, grasp_pair(obs))
                first = report['grasp_regions'][0]
                self.assertFalse(first['opening_visible_in_rgbd'])
                self.assertFalse(report['insertion_allowed'])
                if mode == 'missing_depth':
                    self.assertEqual(first['observed_cloth_point_count'], 0)
                    self.assertEqual(first['next_observation'], 'obtain_valid_local_depth')
                if mode in ('foreground', 'same_depth'):
                    self.assertIn('foreground_occlusion_or_no_background_gap', report['opening_candidate_rejections'])

    def test_one_ambiguous_opening_is_not_assigned_as_two_sleeves(self):
        obs = scene()
        grasps = np.stack([point(obs, 3, 104), point(obs, 3, 152)])
        report = diagnostic.diagnose_sleeve_observability(obs, grasps)
        self.assertFalse(report['both_regions_have_depth_supported_opening'])
        for region in report['grasp_regions']:
            self.assertFalse(region['opening_visible_in_rgbd'])
            self.assertEqual(region['ambiguous_candidate_indices'], [0])
            self.assertIn('opening_candidate_ambiguous_between_grasps', region['reasons'])

    def test_two_separated_depth_candidates_supply_geometry_but_not_sleeve_identity(self):
        obs = scene(centers=((80, 128), (176, 128)), outer=30, inner=12)
        grasps = np.stack([point(obs, 3, 96), point(obs, 3, 192)])
        report = diagnostic.diagnose_sleeve_observability(obs, grasps)
        self.assertTrue(report['both_regions_have_depth_supported_opening'])
        self.assertFalse(report['sleeve_pair_verified'])
        candidates = [r['depth_supported_opening_candidates'][0] for r in report['grasp_regions']]
        self.assertNotEqual(candidates[0]['candidate_index'], candidates[1]['candidate_index'])
        for region in report['grasp_regions']:
            self.assertTrue(region['geometric_alignment_observable'])
            self.assertFalse(region['safe_for_insertion'])

    def test_yellow_inner_ring_is_only_a_collar_hint(self):
        obs = scene()
        trim = np.zeros((256, 256), np.uint8)
        cv2.circle(trim, (128, 128), 22, 1, cv2.FILLED)
        cv2.circle(trim, (128, 128), 20, 0, cv2.FILLED)
        obs['rgb'][3][trim.astype(bool)] = [230, 220, 10]
        report = diagnostic.diagnose_sleeve_observability(obs, grasp_pair(obs))
        region = report['grasp_regions'][0]
        self.assertTrue(region['depth_supported_opening_candidates'][0]['collar_like_hint'])
        self.assertEqual(region['next_observation'], 'resolve_collar_or_other_garment_identity')
        self.assertFalse(region['sleeve_identity_verified'])

    def test_returned_samples_are_actual_valid_depth_pixels(self):
        obs = scene(); obs['depth_valid'][3, 100:110, 120:160] = False
        report = diagnostic.diagnose_sleeve_observability(obs, grasp_pair(obs))
        values = diagnostic._validated(obs, wrists=True)
        for region in report['grasp_regions']:
            for key in ('cloth_samples', 'boundary_samples'):
                sample = region[key]
                self.assertLessEqual(len(sample['points_world']), 96)
                for world, camera, (u, v) in zip(sample['points_world'], sample['camera_indices'], sample['source_pixels_uv']):
                    self.assertIn(camera, (1, 2, 3, 4))
                    self.assertTrue(obs['depth_valid'][camera, v, u, 0])
                    measured = diagnostic._world_pixels(values, camera, np.array([u]), np.array([v]),
                                                       np.array([obs['depth'][camera, v, u, 0]]))[0]
                    np.testing.assert_allclose(world, measured, atol=1e-7)

    def test_camera_roles_and_public_pose_translation_equivariance(self):
        for camera in (1, 2, 3, 4):
            with self.subTest(camera=camera):
                obs = scene(camera=camera); grasps = grasp_pair(obs, camera)
                first = diagnostic.diagnose_sleeve_observability(obs, grasps)['grasp_regions'][0]
                delta = np.array([.4, -.2, .3])
                obs['base_pose_world'][:, :3] += delta
                second = diagnostic.diagnose_sleeve_observability(obs, grasps+delta)['grasp_regions'][0]
                self.assertTrue(first['opening_visible_in_rgbd'])
                self.assertTrue(second['opening_visible_in_rgbd'])
                a, b = first['depth_supported_opening_candidates'][0], second['depth_supported_opening_candidates'][0]
                self.assertEqual(a['camera_index'], camera)
                np.testing.assert_allclose(np.asarray(b['centroid_world'])-a['centroid_world'], delta, atol=1e-6)
                np.testing.assert_allclose(b['normal_world'], a['normal_world'], atol=1e-6)

    def test_matched_candidates_keep_same_frame_ring_geometry_without_persistent_identity_claim(self):
        for camera in (1, 2, 3, 4):
            with self.subTest(camera=camera):
                obs = scene(camera=camera); obs['simulation_time_s'] = 12.35
                source = diagnostic.detect_opening_candidates(obs)
                with patch.object(diagnostic, 'detect_opening_candidates', return_value=source):
                    report = diagnostic.diagnose_sleeve_observability(obs, grasp_pair(obs, camera))
                candidate = report['grasp_regions'][0]['depth_supported_opening_candidates'][0]
                original = source['opening_candidates'][candidate['candidate_index']]
                for field in ('ring_points_world', 'principal_axis_world', 'visible_ring_extent_m', 'pixel_centroid'):
                    np.testing.assert_array_equal(candidate[field], original[field])
                self.assertEqual(candidate['source_camera'], original['source_camera'])
                self.assertEqual(candidate['camera_index'], camera)
                self.assertEqual(candidate['observation_time_s'], 12.35)
                self.assertEqual(candidate['inner_aperture'], original['inner_aperture'])
                self.assertTrue(candidate['inner_aperture']['available'])
                self.assertLessEqual(len(candidate['ring_points_world']), 64)
                self.assertIn('frame_local', candidate['candidate_index_scope'])
                self.assertIn('separately cached', report['candidate_indices_scope'])
                self.assertIn('not an inner aperture polygon', candidate['ring_point_scope'])
                self.assertIn('not guaranteed free opening diameter', candidate['extent_scope'])
                self.assertFalse(candidate['opening_verified'])
                self.assertFalse(candidate['sleeve_identity_verified'])
                before = original['ring_points_world'][0][0]
                candidate['ring_points_world'][0][0] += 1.
                self.assertEqual(original['ring_points_world'][0][0], before)
                before_uv = original['inner_aperture']['contour_pixels_uv'][0][0]
                candidate['inner_aperture']['contour_pixels_uv'][0][0] += 1
                self.assertEqual(original['inner_aperture']['contour_pixels_uv'][0][0], before_uv)

    def test_overview_only_data_cannot_create_local_fabric_or_opening(self):
        obs = scene(camera=0)
        report = diagnostic.diagnose_sleeve_observability(obs, np.array([[0, 0, 1.], [0, .4, 1.]]))
        self.assertEqual(report['cameras_used'], [1, 2, 3, 4])
        self.assertFalse(report['both_regions_have_depth_supported_opening'])
        for region in report['grasp_regions']:
            self.assertEqual(region['observed_cloth_point_count'], 0)
            self.assertFalse(region['opening_visible_in_rgbd'])


if __name__ == '__main__':
    unittest.main()
