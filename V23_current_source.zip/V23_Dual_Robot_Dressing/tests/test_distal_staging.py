"""Public report geometry checks for waiting position inference, no simulator."""
import copy
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
from distal_staging import plan_distal_staging, constrain_staging_to_lift_reach


def reports(weak_first=False, axes=None):
    hands = np.array([[-.20, 0., 1.], [.20, 0., 1.]])
    if axes is None:
        axes = np.array([[.18, .85, -.49], [.18, .85, -.49]])
    axes = np.asarray(axes, float)
    axes /= np.linalg.norm(axes, axis=1)[:, None]
    hand_report = dict(detected=True, hand_points_world=hands.tolist(), observation_time_s=8.)
    rows = []
    for index, (hand, axis) in enumerate(zip(hands, axes)):
        weak = weak_first and index == 0
        views = [dict(camera_index=camera, hand_index=index, axis_world=axis.tolist(),
            axis_sign='measured_hand_toward_one_sided_visible_proximal_surface',
            proximal_observed_surface_point_world=(hand+.17*axis).tolist())
            for camera in ((3,) if weak else (3, 4))]
        rows.append(dict(hand_index=index, hand_surface_world=hand.tolist(),
            status='single_view_candidate' if weak else 'multi_view_consistent_candidate',
            axis_world=None if weak else axis.tolist(), candidate_views=views,
            axis_sign='hand_surface_toward_visible_proximal_surface', conflicting_pairs=[],
            supporting_parallax_pairs=[] if weak else [dict(camera_indices=[3, 4])]))
    return dict(simulation_time_s=9.), hand_report, dict(observation_time_s=8., hand_surfaces=rows), axes


def lift_case(target_z=1.2932061550479401, q=(.90, .90), yaw=(0., np.pi)):
    """Synthetic own poses from the audited zero-lift offset and .715 rad wrist pitch."""
    obs, hands, surfaces, _ = reports(weak_first=True)
    initial = plan_distal_staging(obs, hands, surfaces)
    z_shift = target_z-initial['target_grasp_midpoint_world'][2]
    for hand, surface in zip(hands['hand_points_world'], surfaces['hand_surfaces']):
        hand[2] += z_shift
        surface['hand_surface_world'][2] += z_shift
        for view in surface['candidate_views']:
            view['proximal_observed_surface_point_world'][2] += z_shift
    proposal = plan_distal_staging(obs, hands, surfaces)
    bases = np.zeros((2, 7))
    bases[:, 0] = [-.6, .6]
    bases[:, 3] = np.cos(np.array(yaw)/2)
    bases[:, 6] = np.sin(np.array(yaw)/2)
    grasps = np.zeros((2, 7))
    grasps[:, 3] = 1.
    grasps[:, :2] = [.70, -.0874191597]
    grasps[:, 2] = .1782204955816269+np.asarray(q)-.29535798728466034*np.sin(.715)
    joints = np.zeros((2, 13))
    joints[:, 3], joints[:, 9] = q, .715
    obs.update(base_pose_world=bases, grasp_pose_base=grasps, joint_position=joints)
    return obs, hands, proposal


class DistalStagingTests(unittest.TestCase):
    def test_three_dimensional_distal_sign_raises_target_for_downward_proximal_surface(self):
        obs, hands, surface, axes = reports()
        original = copy.deepcopy((obs, hands, surface))
        result = plan_distal_staging(obs, hands, surface)
        self.assertTrue(result['available'])
        expected = np.array([0., 0., 1.])-.30*axes.mean(axis=0)
        np.testing.assert_allclose(result['target_grasp_midpoint_world'], expected)
        self.assertGreater(result['target_grasp_midpoint_world'][2], 1.14)
        self.assertLess(result['distal_offset_world'][1], -.25)
        self.assertAlmostEqual(np.linalg.norm(result['distal_offset_world']), .30)
        self.assertGreaterEqual(min(result['target_midpoint_distances_to_observed_hands_m']), .30)
        self.assertFalse(result['insertion_allowed'])
        self.assertFalse(result['full_body_or_garment_swept_clearance_verified'])
        self.assertNotIn('action', result)
        self.assertEqual((obs, hands, surface), original)

    def test_unique_single_view_axis_used_honestly_without_inventing_multiview_support(self):
        obs, hands, surface, _ = reports(weak_first=True)
        result = plan_distal_staging(obs, hands, surface)
        self.assertTrue(result['available'])
        self.assertTrue(result['contains_weak_single_view_evidence'])
        self.assertIn('single_view_hypothesis', result['reason'])
        self.assertEqual(result['per_hand_axis_evidence'][0]['camera_indices'], [3])
        self.assertEqual(result['per_hand_axis_evidence'][0]['status'], 'single_view_candidate')
        self.assertIsNone(surface['hand_surfaces'][0]['axis_world'])
        # The existing actor keeps a separate hand timestamp; this is supported.
        del hands['observation_time_s']
        self.assertTrue(plan_distal_staging(obs, hands, surface, hand_observation_time_s=8.)['available'])

    def test_conflicting_views_opposite_signs_or_nonunique_weak_axes_abstain(self):
        for fault in ('view_conflict', 'opposite', 'disagree', 'weak_multiple', 'bad_sign', 'support_behind'):
            with self.subTest(fault=fault):
                axes = [[0, 1, 0], [0, -1, 0]] if fault == 'opposite' else [[0, 1, 0], [0, .7, -.7]] if fault == 'disagree' else None
                obs, hands, surface, _ = reports(weak_first=True, axes=axes)
                first = surface['hand_surfaces'][0]
                if fault == 'view_conflict':
                    first['conflicting_pairs'] = [dict(camera_indices=[3, 4])]
                elif fault == 'weak_multiple':
                    first['candidate_views'].append(copy.deepcopy(first['candidate_views'][0]))
                elif fault == 'bad_sign':
                    first['axis_sign'] = 'toward_camera'
                elif fault == 'support_behind':
                    first['candidate_views'][0]['proximal_observed_surface_point_world'] = hands['hand_points_world'][0]
                result = plan_distal_staging(obs, hands, surface)
                self.assertFalse(result['available'])
                self.assertIsNone(result['target_grasp_midpoint_world'])

    def test_stale_future_mismatched_hand_identity_and_timestamp_are_rejected(self):
        for fault in ('stale', 'future', 'mismatched_time', 'missing_time', 'mismatched_hand', 'swapped_indices'):
            with self.subTest(fault=fault):
                obs, hands, surface, _ = reports()
                if fault == 'stale':
                    obs['simulation_time_s'] = 14.
                elif fault == 'future':
                    obs['simulation_time_s'] = 7.9
                elif fault == 'mismatched_time':
                    surface['observation_time_s'] = 8.2
                elif fault == 'missing_time':
                    del hands['observation_time_s']
                elif fault == 'mismatched_hand':
                    surface['hand_surfaces'][1]['hand_surface_world'][0] += .03
                else:
                    surface['hand_surfaces'].reverse()
                result = plan_distal_staging(obs, hands, surface)
                self.assertFalse(result['available'])
                self.assertIsNone(result['target_grasp_midpoint_world'])

    def test_midpoint_clearance_not_assumed_when_hand_span_runs_along_surface_axis(self):
        obs, hands, surface, _ = reports(axes=[[1, 0, 0], [1, 0, 0]])
        result = plan_distal_staging(obs, hands, surface)
        self.assertFalse(result['available'])
        self.assertIn('reduce_observed_hand_clearance', result['reason'])
        self.assertAlmostEqual(min(result['target_midpoint_distances_to_observed_hands_m']), .10)

    def test_old_observation_requires_explicit_stationary_mode_and_retains_actual_timestamps(self):
        obs, hands, surface, _ = reports(weak_first=True)
        obs['simulation_time_s'] = 268.
        self.assertFalse(plan_distal_staging(obs, hands, surface)['available'])
        default_limit = plan_distal_staging(obs, hands, surface, max_age_s=300.)
        self.assertFalse(default_limit['available'])
        self.assertIn('explicit_stationary', default_limit['reason'])
        result = plan_distal_staging(obs, hands, surface, stationary_human=True, max_age_s=300.)
        self.assertTrue(result['available'])
        self.assertTrue(result['stationary_human_assumption_declared'])
        self.assertTrue(result['stationary_human_cache_used'])
        self.assertIn('not verified', result['stationary_human_assumption'])
        self.assertEqual(result['observation_age_s'], dict(hands=260., surfaces=260.))
        self.assertEqual(result['source_observation_time_s'], dict(hands=8., surfaces=8.))
        self.assertEqual(hands['observation_time_s'], 8.)
        self.assertEqual(surface['observation_time_s'], 8.)
        # Enabling the assumption alone does not silently enlarge the 5 s limit.
        self.assertFalse(plan_distal_staging(obs, hands, surface, stationary_human=True)['available'])

    def test_stationary_mode_still_rejects_age_301_future_and_more_than_300_requested(self):
        obs, hands, surface, _ = reports()
        for now in (309., 7.9):
            with self.subTest(now=now):
                obs['simulation_time_s'] = now
                result = plan_distal_staging(obs, hands, surface, stationary_human=True, max_age_s=300.)
                self.assertFalse(result['available'])
                self.assertIn('stale_or_from_future', result['reason'])
                self.assertAlmostEqual(result['observation_age_s']['hands'], now-8.)
        obs['simulation_time_s'] = 108.
        self.assertFalse(plan_distal_staging(obs, hands, surface, stationary_human=True, max_age_s=301.)['available'])
        self.assertFalse(plan_distal_staging(obs, hands, surface, stationary_human='yes', max_age_s=180.)['available'])

    def test_robot_camera_frame_does_not_choose_sign_and_world_rigid_transform_is_equivariant(self):
        obs, hands, surface, _ = reports(weak_first=True)
        before = plan_distal_staging(obs, hands, surface)
        angle = .7
        rotation = np.array([[np.cos(angle), -np.sin(angle), 0], [np.sin(angle), np.cos(angle), 0], [0, 0, 1]])
        translation = np.array([.5, -.7, .2])
        hands['hand_points_world'] = (np.asarray(hands['hand_points_world']) @ rotation.T+translation).tolist()
        for row in surface['hand_surfaces']:
            row['hand_surface_world'] = (rotation @ row['hand_surface_world']+translation).tolist()
            if row['axis_world'] is not None:
                row['axis_world'] = (rotation @ row['axis_world']).tolist()
            for view in row['candidate_views']:
                view['axis_world'] = (rotation @ view['axis_world']).tolist()
                view['proximal_observed_surface_point_world'] = (rotation @ view['proximal_observed_surface_point_world']+translation).tolist()
        after = plan_distal_staging(obs, hands, surface)
        self.assertTrue(after['available'])
        np.testing.assert_allclose(after['target_grasp_midpoint_world'], rotation @ before['target_grasp_midpoint_world']+translation)


class LiftReachStagingTests(unittest.TestCase):
    def test_measured_pitched_grasp_clamps_1293_to_1169_with_joint_margin(self):
        obs, hands, proposal = lift_case()
        before_obs, before_proposal = copy.deepcopy(obs), copy.deepcopy(proposal)
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertTrue(result['available'], result['reason'])
        self.assertTrue(result['reach_adjusted'])
        expected = .1782204955816269+1.185-.29535798728466034*np.sin(.715)
        target = np.asarray(result['target_grasp_midpoint_world'])
        self.assertAlmostEqual(target[2], expected, places=10)
        self.assertTrue(1.16 < target[2] < 1.18)
        np.testing.assert_allclose(result['predicted_lift_joint_positions_m'], [1.185, 1.185])
        self.assertAlmostEqual(np.linalg.norm(result['distal_offset_world']), .30)
        old_offset = np.asarray(proposal['distal_offset_world'])
        new_offset = np.asarray(result['distal_offset_world'])
        self.assertGreater(np.linalg.norm(new_offset[:2]), np.linalg.norm(old_offset[:2]))
        np.testing.assert_allclose(new_offset[:2]/np.linalg.norm(new_offset[:2]), old_offset[:2]/np.linalg.norm(old_offset[:2]))
        self.assertGreater(result['inferred_axis_deviation_degrees'], 20.)
        self.assertGreaterEqual(min(result['target_midpoint_distances_to_observed_hands_m']), .30)
        self.assertFalse(result['insertion_aligned'])
        self.assertNotIn('action', result)
        self.assertEqual(proposal, before_proposal)
        for key in obs:
            np.testing.assert_array_equal(obs[key], before_obs[key])

    def test_same_vertical_shift_preserves_asymmetric_grasp_heights_and_is_role_symmetric(self):
        obs, hands, proposal = lift_case(q=(.72, 1.02), yaw=(.6, -1.3))
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertTrue(result['available'], result['reason'])
        # The higher robot has only .165 m remaining. The midpoint bound is
        # therefore below BOTH robots' identical individual maximum grasp Z.
        self.assertAlmostEqual(result['selected_common_world_z_shift_m'], .165)
        expected_mid_z = obs['grasp_pose_base'][:, 2].mean()+.165
        self.assertAlmostEqual(result['target_grasp_midpoint_world'][2], expected_mid_z)
        np.testing.assert_allclose(result['predicted_lift_joint_positions_m'], [.885, 1.185])
        shifted = obs['grasp_pose_base'][:, 2]+result['selected_common_world_z_shift_m']
        self.assertAlmostEqual(shifted[1]-shifted[0], .30)
        for key in ('base_pose_world', 'grasp_pose_base', 'joint_position'):
            obs[key] = obs[key][::-1].copy()
        swapped = constrain_staging_to_lift_reach(obs, proposal, hands['hand_points_world'])
        np.testing.assert_allclose(swapped['target_grasp_midpoint_world'], result['target_grasp_midpoint_world'])
        np.testing.assert_allclose(swapped['predicted_lift_joint_positions_m'], result['predicted_lift_joint_positions_m'][::-1])

    def test_base_rotation_zz_and_world_base_height_set_bounds_not_wrist_pitch_recalculation(self):
        obs, hands, proposal = lift_case()
        obs['base_pose_world'][:, 2] = [.015, .030]
        obs['base_pose_world'][0, 3:] = [np.cos(.02), np.sin(.02), 0., 0.]
        # Current public grasp already contains the wrist-dependent height.
        # Changing q9 alone must not be treated as new measured grasp geometry.
        obs['joint_position'][:, 9] = .10
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertTrue(result['available'], result['reason'])
        from public_vision import grasp_world
        current_mid = np.asarray([grasp_world(obs, r) for r in (0, 1)]).mean(axis=0)
        expected_shift = np.cos(.04)*.285
        self.assertAlmostEqual(result['selected_common_world_z_shift_m'], expected_shift)
        self.assertAlmostEqual(result['target_grasp_midpoint_world'][2], current_mid[2]+expected_shift)
        self.assertAlmostEqual(result['predicted_lift_joint_positions_m'][0], 1.185)
        self.assertLess(result['predicted_lift_joint_positions_m'][1], 1.185)

    def test_already_reachable_target_is_unchanged_and_lower_limit_also_applies(self):
        obs, hands, proposal = lift_case(target_z=1.10)
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertTrue(result['available'])
        self.assertFalse(result['reach_adjusted'])
        np.testing.assert_array_equal(result['target_grasp_midpoint_world'], proposal['target_grasp_midpoint_world'])
        # Lift geometry is arbitrary but fully measured; common lower shift is
        # determined by q3 and is protected by the same 15 mm margin.
        obs, hands, proposal = lift_case(target_z=.03, q=(.1, .1))
        obs['grasp_pose_base'][:, 2] = .14
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertTrue(result['available'], result['reason'])
        self.assertAlmostEqual(result['target_grasp_midpoint_world'][2], .055)
        np.testing.assert_allclose(result['predicted_lift_joint_positions_m'], [.015, .015])

    def test_invalid_unknown_and_degenerate_geometry_abstains(self):
        for fault in ('unknown', 'missing_joints', 'bad_joint', 'bad_pose', 'tilt', 'no_bearing', 'no_z_sphere', 'mismatched_hands', 'no_common_interval', 'bad_margin'):
            with self.subTest(fault=fault):
                obs, hands, proposal = lift_case()
                margin = .015
                if fault == 'unknown': proposal['available'] = False
                elif fault == 'missing_joints': del obs['joint_position']
                elif fault == 'bad_joint': obs['joint_position'][0, 3] = 1.21
                elif fault == 'bad_pose': obs['grasp_pose_base'][0, 2] = np.nan
                elif fault == 'tilt': obs['base_pose_world'][0, 3:] = [np.cos(.1), np.sin(.1), 0., 0.]
                elif fault == 'no_bearing':
                    proposal['target_grasp_midpoint_world'] = (np.asarray(proposal['hand_midpoint_world'])+[0, 0, .30]).tolist()
                elif fault == 'no_z_sphere': obs['grasp_pose_base'][:, 2] -= 1.
                elif fault == 'mismatched_hands': hands['hand_points_world'][0][1] += .01
                elif fault == 'no_common_interval': obs['joint_position'][:, 3] = [0., 1.2]
                elif fault == 'bad_margin': margin = -.01
                result = constrain_staging_to_lift_reach(obs, proposal, hands, margin_m=margin)
                self.assertFalse(result['available'])
                self.assertIsNone(result['target_grasp_midpoint_world'])

    def test_extending_horizontal_bearing_must_not_move_within_30cm_of_one_hand(self):
        obs, hands, proposal = lift_case()
        # Initially mostly vertical offset is .30 m from the midpoint and over
        # .30 m from each hand. Lowering while increasing X would approach one
        # hand too closely; do not silently shorten clearance or invent a Y path.
        midpoint = np.asarray(proposal['hand_midpoint_world'])
        original_offset = np.array([.02, 0., np.sqrt(.30**2-.02**2)])
        proposal['target_grasp_midpoint_world'] = (midpoint+original_offset).tolist()
        self.assertGreater(min(np.linalg.norm(np.asarray(hands['hand_points_world'])-proposal['target_grasp_midpoint_world'], axis=1)), .30)
        result = constrain_staging_to_lift_reach(obs, proposal, hands)
        self.assertFalse(result['available'])
        self.assertIn('less_than_30cm', result['reason'])


if __name__ == '__main__':
    unittest.main()
