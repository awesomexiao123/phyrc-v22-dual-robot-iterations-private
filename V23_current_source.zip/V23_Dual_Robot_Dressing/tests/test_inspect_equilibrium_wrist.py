"""Small offline fixtures: no simulator, actor imports, or live-run writes."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

spec=importlib.util.spec_from_file_location('equilibrium_review',Path(__file__).resolve().parents[1]/'inspect_equilibrium_wrist.py')
review=importlib.util.module_from_spec(spec);spec.loader.exec_module(review)


def row(step=1, time=1., angle=0., shift=0.):
    q=np.zeros((2,13));q[:,10]=np.deg2rad(angle)
    base=np.array([[shift,0,0,2**-.5,0,0,2**-.5],[2+shift,0,0,1,0,0,0]])
    grasp=np.array([[1,0,1,1,0,0,0],[1,0,1,1,0,0,0]])
    return dict(step=step,simulation_time_s=time,phase='pair_observe_roll',joint_position=q.tolist(),
        base_pose_world=base.tolist(),grasp_pose_base=grasp.tolist(),_episode='episode_001',
        action=np.ones((2,9)).tolist(),debug=dict(loaded_roll_observation=dict(phase='roll_0',
            report_observed_at_s=time,experiment_completed=False,wrapper_actual_absolute_angle_degrees=[9.,8.])))


def handoff():
    q=np.zeros((2,13));q[:,3]=1.;q[:,4:8]=.1
    t=np.zeros((2,9));t[:,0]=1.0026;t[:,1]=.4
    b=np.zeros((2,5));b[:,0]=.0026
    return dict(stage='pair_settle_before_roll',calibration=dict(observed_at_s=1.,window_start_s=.5,
        frame_count=11,controller_bias=b.tolist(),arm_position_offsets=np.zeros((2,4)).tolist(),
        last_joint_position=q.tolist(),controller_target_reference=t.tolist(),method='synthetic',
        raw_joint_velocity_median=np.full((2,13),.01).tolist(),raw_joint_velocity_peak_deviation=np.full((2,13),.001).tolist()),
        report=dict(original_target_observed_at_s=.5,window_reset_count=2))


class InspectEquilibriumWristTests(unittest.TestCase):
    def test_handoff_dedup_preserves_original_time_and_subtracts_bias_once(self):
        a,b=row(),row(2,2.)
        for r in (a,b):r['debug']['equilibrium_handoffs']=[handoff()]
        result=review.summarize_episode([a,b])
        self.assertEqual(result['handoff_count'],1)
        h=result['equilibrium_handoffs'][0]
        self.assertEqual(h['observed_at_s'],1.)
        self.assertEqual(h['window_duration_s'],.5)
        np.testing.assert_allclose(h['final_effective_target_residual'],0.,atol=1e-15)
        self.assertEqual(result['roll']['latest']['actor_reported_absolute_degrees'],[9.,8.])

    def test_actual_net_and_sparse_absolute_differ_and_commands_are_ignored(self):
        rows=[row(),row(2,1.05,2.),row(3,1.10,1.)]
        result=review.summarize_episode(rows)
        motion=result['roll']['sampled_actual_motion']
        np.testing.assert_allclose(motion['net_degrees'],[1.,1.])
        np.testing.assert_allclose(motion['sampled_absolute_degrees_lower_bound'],[3.,3.])
        self.assertEqual(result['roll']['status'],'not_completed_in_snapshot')
        rows[-1]['debug']['loaded_roll_observation']['experiment_completed']=True
        self.assertEqual(review.summarize_episode(rows)['roll']['status'],'completed')

    def test_pose_quaternion_drift_and_missing_reference_remain_explicit(self):
        a,b=row(),row(2,2.,shift=.002)
        result=review.summarize_episode([a,b])['drift_after_wrist_start']
        np.testing.assert_allclose(result['observed_max_grasp_drift_m'],[.002,.002],atol=1e-14)
        self.assertFalse(result['exact_controller_reference_available'])
        self.assertIsNone(result['maximum_continuous_drift_m'])
        a.pop('grasp_pose_base')
        result=review.summarize_episode([a,b])['drift_after_wrist_start']
        self.assertIsNone(result['observed_max_grasp_drift_m'])

    def test_latest_alias_deduplicates_and_partial_line_is_warning(self):
        with tempfile.TemporaryDirectory() as tmp:
            run=Path(tmp);episode=run/'diagnostics/episode_001';episode.mkdir(parents=True)
            a,b=row(),row(2,2.)
            (episode/'progress.jsonl').write_text(json.dumps(a)+'\n'+json.dumps(b)+'\n{"partial":')
            (run/'diagnostics/latest.json').write_text(json.dumps(b))
            records,warnings=review.read_records(run)
            self.assertEqual(len(records),2);self.assertEqual(len(warnings),1)
            result=review.inspect_run(run)
            self.assertIn('no_completion',result['run_state'])
            json.dumps(result,allow_nan=False)
            self.assertFalse((run/'STOP').exists())

    def test_original_reference_can_be_saved_inside_a_later_diagnostic_frame(self):
        original = row(time=.5)
        a, b = row(time=1., shift=.001), row(2, 2., shift=.002)
        _, grasp = review.own_poses(original)
        a['debug']['wrist_global_reference'] = dict(time=.5,
            base=original['base_pose_world'], grasp=grasp.tolist())
        result = review.summarize_episode([a, b])['drift_after_wrist_start']
        self.assertTrue(result['exact_controller_reference_available'])
        self.assertEqual(result['original_controller_start_time_s'], .5)
        np.testing.assert_allclose(result['observed_max_grasp_drift_m'], [.002, .002], atol=1e-14)

    def test_base_native_twist_and_pose_difference_are_separate_evidence(self):
        poses = np.array([row()['base_pose_world'] for _ in range(11)])
        window = dict(public_times_s=(np.arange(11)*.05).tolist(),
            base_pose_world=poses.tolist(), raw_base_twist_world=np.full((11, 2, 6), .003).tolist())
        result = review.summarize_base_window(dict(base_diagnostic_window=window))
        np.testing.assert_allclose(result['pose_difference']['longest_consecutive_base_rest_candidate_s'], [.5]*3)
        np.testing.assert_allclose(result['raw_instantaneous_twist']['longest_consecutive_base_rest_candidate_s'], [0.]*3)
        window['raw_base_twist_world'] = [None]*11
        self.assertIsNone(review.summarize_base_window(dict(base_diagnostic_window=window))['raw_instantaneous_twist'])
        window['public_times_s'][5] += .02
        self.assertIn('unknown', review.summarize_base_window(dict(base_diagnostic_window=window))['status'])

    def test_missing_joint_motion_and_retained_debug_do_not_invent_later_rotation(self):
        a=row();a.pop('joint_position')
        b=row(2,10.,angle=40.);b['phase']='dual_hold'
        b['debug']['loaded_roll_observation']['report_observed_at_s']=1.
        b['debug']['loaded_roll_observation']['skipped']=True
        result=review.summarize_episode([a,b])
        self.assertIsNone(result['roll']['sampled_actual_motion'])
        self.assertEqual(result['roll']['status'],'skipped')
        self.assertEqual(result['roll']['latest']['report_age_s'],9.)

    def test_first_anomaly_keeps_its_own_time_and_raw_value_after_recovery(self):
        a = row()
        anomaly = dict(observation_time_s=.95, raw_joint_velocity=[[.04]],
                       offending=[dict(robot=0, joint_index=3, raw_velocity=.04)])
        a['debug']['loaded_roll_observation']['first_raw_velocity_anomaly'] = anomaly
        b = row(2, 2.)
        b['debug']['loaded_roll_observation']['equilibrium_wrapper'] = dict(
            raw_joint_velocity=np.zeros((2, 13)).tolist())
        result = review.summarize_axis([a, b], 'roll')
        saved = result['first_raw_velocity_anomaly']
        self.assertEqual(saved['observation_time_s'], .95)
        self.assertEqual(saved['offending'][0]['raw_velocity'], .04)
        saved['offending'][0]['raw_velocity'] = 9.
        self.assertEqual(anomaly['offending'][0]['raw_velocity'], .04)


if __name__=='__main__':unittest.main()
