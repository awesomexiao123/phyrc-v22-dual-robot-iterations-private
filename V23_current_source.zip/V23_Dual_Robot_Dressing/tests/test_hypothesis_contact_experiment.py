"""CPU-isolated orchestration tests; mocks establish no physical safety claim."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import hypothesis_contact_experiment as experiment


def observation(now=0.):
    base = np.zeros((2, 7)); base[:, 3] = 1.; base[1, 1] = 1.
    grasp = base.copy(); grasp[:, :3] = [.5, 0., .5]
    q = np.zeros((2, 13)); q[:, 3] = .5; q[:, 4:8] = .05
    targets = np.zeros((2, 9)); targets[:, :2] = [.5, .2]
    return dict(base_pose_world=base, grasp_pose_base=grasp,
        simulation_time_s=np.array(now), joint_position=q, joint_velocity=np.zeros((2, 13)),
        controller_target=targets, base_twist_world=np.zeros((2, 6)),
        gripper_close_command=np.ones(2, bool), fingertip_origin_distance=np.full(2, .02),
        cloth_motion=np.zeros((2, 3)), cloth_reliable=np.ones(2, bool))


def hold():
    a = np.zeros((2, 9), np.float32); a[:, 8] = 1.
    return a


class FakeGovernor:
    def __init__(self, obs):
        self.calls = []; self.settled = False; self.failure = None
        self.pending_failure = None; self.scale = 1.; self.cancel = hold()
        self.debug = {}; self.suppress_duplicate = False

    def step(self, obs, action, *, halt=False, max_speed_mps=.01):
        now = float(obs['simulation_time_s'])
        duplicate = bool(self.calls and self.calls[-1]['time'] == now)
        self.calls.append(dict(time=now, halt=halt, action=np.asarray(action).copy(), speed=max_speed_mps))
        outgoing = self.cancel.copy() if halt or self.pending_failure else np.asarray(action).copy()
        if not halt and not self.pending_failure:
            outgoing[:, :8] *= self.scale
        if duplicate and self.suppress_duplicate:
            outgoing = hold()
        return dict(action=outgoing, failure=self.failure, pending_failure=self.pending_failure,
            cancellation_only=bool(halt or self.pending_failure), settled=self.settled,
            debug=dict(common_scale=self.scale, common_command_scale=self.scale,
                       unresolved_target_lag=bool(self.failure)))


class FakeObserver:
    def __init__(self, **kwargs):
        self.calls = []; self.fresh_hands = {}; self.fresh_forearms = {}

    def _observe_hands(self, obs, now):
        self.calls.append(now)
        self.fresh_hands = dict(observation_time_s=now, detected=True)
        self.fresh_forearms = dict(observation_time_s=now)


class FakeTracker:
    instances = []

    def __init__(self):
        self.robot = len(self.instances); self.instances.append(self)
        self.reset_calls = self.update_calls = 0

    def reset(self, obs, center, radius):
        self.reset_calls += 1
        return dict(reliable=bool(obs['cloth_reliable'][self.robot]), median_displacement_world=[0., 0., 0.],
                    feature_ids=[self.robot*100+index for index in range(6)], features_reseeded=False)

    def update(self, obs):
        self.update_calls += 1
        return dict(reliable=bool(obs['cloth_reliable'][self.robot]),
            median_displacement_world=obs['cloth_motion'][self.robot].tolist(),
            feature_ids=[self.robot*100+index for index in range(6)], features_reseeded=False)


class FakeMotion:
    instances = []

    def __init__(self, obs, goal, max_speed):
        self.instances.append(self); self.goal = np.asarray(goal).copy()
        self.max_speed = max_speed; self.time0 = float(obs['simulation_time_s'])
        self.failure = None; self.done = False; self.calls = 0; self.reference_fraction = .2
        self.action = hold(); self.action[:, 4] = .001
        self.segment = None

    def step(self, obs):
        self.calls += 1; self.reference_fraction += .1
        return dict(action=self.action.copy(), failure=self.failure, done=self.done, debug={})


class HypothesisContactExperimentTests(unittest.TestCase):
    def setUp(self):
        FakeTracker.instances = []; FakeMotion.instances = []
        self.real_coverage = experiment.HypothesisContactExperiment._coverage
        self.real_refresh_skin = experiment.HypothesisContactExperiment._refresh_skin
        self.patchers = [patch.object(experiment, 'ContactMotionGovernor', FakeGovernor),
            patch.object(experiment, 'OpeningApproachCoordinator', FakeObserver),
            patch.object(experiment, 'ClothPatchTracker', FakeTracker),
            patch.object(experiment, 'GraspPairAlignment', FakeMotion),
            patch.object(experiment, 'ContactPulseAlignment', FakeMotion),
            patch.object(experiment, 'RoutedPairTransport', FakeMotion),
            patch.object(experiment, 'estimate_held_edge_hypotheses', side_effect=self.edges),
            patch.object(experiment, 'plan_hypothesis_contact', side_effect=self.plan),
            patch.object(experiment.HypothesisContactExperiment, '_refresh_skin'),
            patch.object(experiment.HypothesisContactExperiment, '_check_clearance'),
            patch.object(experiment.HypothesisContactExperiment, '_coverage', return_value=[10, 10])]
        self.mocks = [p.start() for p in self.patchers]
        self.addCleanup(lambda: [p.stop() for p in reversed(self.patchers)])
        self.obs = observation()
        self.plan_available = True; self.feasibility_changes = {}
        self.plan_axes = np.array([[1., 0., 0.], [1., 0., 0.]])
        self.plan_hand_shift = np.zeros(3)
        self.plan_assignment = [0, 1]

    def edges(self, obs, initial, assignment):
        return dict(detected=True, observation_time_s=float(obs['simulation_time_s']))

    def plan(self, obs, edges, hands, forearms):
        now = float(obs['simulation_time_s'])
        self.assertEqual(edges['observation_time_s'], now)
        self.assertEqual(hands['observation_time_s'], now)
        self.assertEqual(forearms['observation_time_s'], now)
        _, grasps, _, _, _ = experiment._snapshot(obs)
        feasibility = dict(lift_reachable_at_current_wrist=True,
            alignment_then_common_translation_arm_feasible=True,
            endpoint_travel_within_30cm=True, span_does_not_exceed_initial_plus_2cm=True,
            modeled_visible_footprint_fits_nominal_radius=True,
            observed_housing_screen=[dict(observed_housing_conflict=False) for _ in (0, 1)])
        feasibility.update(self.feasibility_changes)
        return dict(available=self.plan_available, reason='mock_geometry', observation_time_s=now,
            target_grasps_world=(grasps+[.02, 0., 0.]).tolist(),
            robot_ordered_axis_world=self.plan_axes.tolist(), robot_to_hand_assignment=self.plan_assignment,
            robot_ordered_hand_points_world=(grasps+[.04, 0., 0.]+self.plan_hand_shift).tolist(), feasibility=feasibility)

    def make(self):
        return experiment.HypothesisContactExperiment(self.obs, {'detected': True}, [0, 1], {}, 0.)

    def tick(self, obj, seconds=.05):
        self.obs['simulation_time_s'] += seconds
        return obj.step(self.obs)

    def assert_hold(self, result):
        np.testing.assert_array_equal(result['action'], hold())

    def start_span(self):
        obj = self.make(); self.assert_hold(obj.step(self.obs))
        obj.governor.settled = True
        self.assert_hold(self.tick(obj))
        self.assertEqual(obj.phase, 'span')
        self.assertIsNotNone(obj.motion)
        return obj

    def test_unknown_current_geometry_never_starts_motion(self):
        self.plan_available = False
        obj = self.make(); obj.governor.settled = True
        result = obj.step(self.obs)
        self.assert_hold(result)
        self.assertIsNotNone(result['failure'])
        self.assertEqual(FakeMotion.instances, [])
        self.assertEqual(FakeTracker.instances, [])

    def test_initial_and_each_motion_stage_require_measured_settle(self):
        obj = self.make()
        self.assert_hold(obj.step(self.obs))
        self.assertIsNone(obj.motion)
        self.assert_hold(self.tick(obj)); self.assertIsNone(obj.motion)
        obj.governor.settled = True
        self.assert_hold(self.tick(obj)); first = obj.motion
        self.assertEqual(obj.phase, 'span'); self.assertEqual(first.calls, 0)
        first.done = True; obj.governor.settled = False
        self.assert_hold(self.tick(obj))
        self.assertIs(obj.motion, first); self.assertIsNone(obj.pending_stage)
        obj.governor.settled = True
        self.assert_hold(self.tick(obj))
        self.assertIsNone(obj.motion); self.assertEqual(obj.pending_stage, 'translate')
        self.assert_hold(self.tick(obj))
        self.assertEqual(obj.phase, 'translate'); self.assertEqual(obj.motion.calls, 0)

    def test_fixed_feature_loss_stops_without_reseed(self):
        obj = self.start_span()
        self.obs['cloth_reliable'][0] = False
        result = self.tick(obj)
        self.assert_hold(result); self.assertIsNotNone(result['failure'])
        self.assertEqual(len(FakeTracker.instances), 2)
        self.assertEqual([t.reset_calls for t in FakeTracker.instances], [1, 1])
        self.obs['cloth_reliable'][:] = True
        self.assert_hold(self.tick(obj))
        self.assertEqual([t.reset_calls for t in FakeTracker.instances], [1, 1])

    def test_fixed_feature_motion_inconsistent_with_grasp_stops(self):
        obj = self.start_span()
        self.obs['cloth_motion'][0, 0] = .031
        result = self.tick(obj)
        self.assert_hold(result)
        self.assertIn('differ from grasp motion', result['failure'])

    def test_same_frame_repeat_does_not_advance_motion_track_or_governor(self):
        obj = self.start_span(); self.tick(obj)
        state = (obj.motion.calls, obj.motion.reference_fraction, len(obj.governor.calls),
                 [t.update_calls for t in FakeTracker.instances], obj.travel.copy())
        self.assert_hold(obj.step(self.obs))
        self.assertEqual(obj.motion.calls, state[0]); self.assertEqual(obj.motion.reference_fraction, state[1])
        self.assertEqual(len(obj.governor.calls), state[2])
        self.assertEqual([t.update_calls for t in FakeTracker.instances], state[3])
        np.testing.assert_array_equal(obj.travel, state[4])

    def test_reference_advance_uses_governor_common_scale_and_keeps_fixed_origin(self):
        obj = self.start_span(); motion = obj.motion
        origin_time = motion.time0; goal = motion.goal.copy()
        motion.reference_fraction = .2; obj.governor.scale = .25
        self.tick(obj)
        self.assertAlmostEqual(motion.reference_fraction, .225)
        self.assertEqual(motion.time0, origin_time)
        np.testing.assert_array_equal(motion.goal, goal)
        obj.governor.scale = 0.
        self.tick(obj)
        self.assertAlmostEqual(motion.reference_fraction, .225)

    def test_nested_segment_reference_advance_is_scaled_without_reseeding(self):
        obj = self.start_span(); motion = obj.motion
        motion.segment = type('Segment', (), {'reference': .03})()
        refs = obj._reference_snapshot(motion)
        motion.reference_fraction += .1; motion.segment.reference += .01
        obj._scale_reference_advance(refs, .25)
        self.assertAlmostEqual(motion.reference_fraction, .225)
        self.assertAlmostEqual(motion.segment.reference, .0325)

    def test_first_cancellation_action_not_erased_by_second_same_frame_governor_call(self):
        obj = self.start_span(); obj.governor.settled = False
        obj.governor.pending_failure = 'mock_pending_stop'
        obj.governor.cancel[:, 3] = -.0001
        obj.governor.suppress_duplicate = True
        before = len(obj.governor.calls)
        result = self.tick(obj)
        self.assertEqual(len(obj.governor.calls)-before, 1)
        np.testing.assert_array_equal(result['action'], obj.governor.cancel)
        self.assertIsNone(result['failure'])
        self.assertIn('mock_pending_stop', result['debug']['pending_failure'])

    def test_pending_failure_cancellation_is_checked_against_observed_clearance(self):
        obj = self.start_span(); obj.governor.settled = False
        obj.pending_failure = 'mock_visual_evidence_lost'
        obj.governor.cancel[:, 3] = -.0001
        clearance = self.mocks[9]; clearance.reset_mock()
        result = self.tick(obj)
        np.testing.assert_array_equal(result['action'], obj.governor.cancel)
        self.assertTrue(clearance.called)
        np.testing.assert_array_equal(clearance.call_args.args[1], obj.governor.cancel)

    def test_geometric_availability_does_not_override_known_reach_infeasibility(self):
        self.feasibility_changes = {'lift_reachable_at_current_wrist': False}
        obj = self.make(); obj.governor.settled = True
        result = obj.step(self.obs)
        self.assert_hold(result); self.assertIsNotNone(result['failure'])
        self.assertEqual(FakeMotion.instances, [])

    def prepare_pulse(self):
        obj = self.start_span()
        _, grasps, _, _, _ = experiment._snapshot(self.obs)
        obj.phase = 'contact_pulse'; obj.contact_start = grasps.copy()
        obj.track_baseline = np.zeros((2, 3)); obj.coverage_baseline = [10, 10]
        obj.axes = np.array([[1., 0., 0.], [1., 0., 0.]])
        return obj, grasps

    def test_contact_pulse_records_actual_grasp_and_original_cloth_motion(self):
        obj, grasps = self.prepare_pulse()
        shift = .005*obj.axes
        obj._completed_motion(self.obs, grasps+shift, shift)
        self.assertAlmostEqual(obj.pulse_travel, .005)
        self.assertEqual(obj.contact_travel, 0.)
        self.assertEqual(obj.pending_stage, 'contact_pulse')
        response = obj.pulse_results[0]
        np.testing.assert_allclose(response['measured_grasp_shift_world'], shift)
        np.testing.assert_allclose(response['fixed_cloth_shift_world'], shift)
        self.assertFalse(response['sleeve_entry_verified'])

    def test_pulse_cannot_count_command_only_without_measured_motion(self):
        obj, grasps = self.prepare_pulse()
        with self.assertRaisesRegex(ValueError, 'did not produce consistent'):
            obj._completed_motion(self.obs, grasps, np.zeros((2, 3)))
        self.assertEqual(obj.contact_travel, 0.)

    def test_pulse_needs_both_original_cloth_sides_to_respond(self):
        obj, grasps = self.prepare_pulse()
        actual = .005*obj.axes; cloth = actual.copy(); cloth[1] = 0.
        with self.assertRaisesRegex(ValueError, 'did not produce consistent'):
            obj._completed_motion(self.obs, grasps+actual, cloth)
        self.assertEqual(obj.contact_travel, 0.)

    def test_public_cloth_cloud_dictionary_counts_unique_observed_proximal_voxels(self):
        obj, _ = self.prepare_pulse()
        points = np.array([obj.hands[0]+[.02, 0., 0.], obj.hands[0]+[.02, 0., 0.],
            obj.hands[0]+[.02, .08, 0.], obj.hands[0]+[-.02, 0., 0.],
            obj.hands[1]+[.03, 0., 0.]])
        with patch.object(experiment, 'cloth_cloud', return_value=dict(world_points=points,
                camera_indices=np.full(len(points), 4), source_pixels_uv=np.zeros((len(points), 2)))):
            counts = self.real_coverage(obj, self.obs)
        self.assertEqual(counts, [1, 1])

    def test_contact_trial_stops_at_40mm_total_with_20mm_nominal_beyond_surface(self):
        obj, grasps = self.prepare_pulse(); obj.pulse_travel = .035; obj.contact_travel = .015
        self.mocks[10].return_value = [100, 100]
        obj._completed_motion(self.obs, grasps+.005*obj.axes, .005*obj.axes)
        self.assertTrue(obj.done)
        self.assertAlmostEqual(obj.pulse_travel, .040)
        self.assertAlmostEqual(obj.contact_travel, .020)
        self.assertEqual(obj.phase, 'bounded_contact_trial_finished')

    def test_trial_stops_at_30mm_total_without_extra_proximal_coverage(self):
        obj, grasps = self.prepare_pulse(); obj.pulse_travel = .025; obj.contact_travel = .005
        obj._completed_motion(self.obs, grasps+.005*obj.axes, .005*obj.axes)
        self.assertTrue(obj.done)
        self.assertAlmostEqual(obj.pulse_travel, .030)
        self.assertAlmostEqual(obj.contact_travel, .010)
        self.assertEqual(obj.phase, 'initial_contact_trial_finished_without_support_for_extension')

    def test_first_20mm_approach_has_no_contact_growth_requirement(self):
        obj, grasps = self.prepare_pulse(); obj.pulse_travel = .015
        self.mocks[10].return_value = [0, 0]
        obj._completed_motion(self.obs, grasps+.005*obj.axes, .005*obj.axes)
        self.assertFalse(obj.done)
        self.assertAlmostEqual(obj.pulse_travel, .020)
        self.assertEqual(obj.contact_travel, 0.)
        self.assertEqual(obj.pending_stage, 'contact_pulse')

    def test_first_5mm_nominal_contact_can_explore_before_extension_coverage_gate(self):
        obj, grasps = self.prepare_pulse(); obj.pulse_travel = .020
        self.mocks[10].return_value = [0, 0]
        obj._completed_motion(self.obs, grasps+.005*obj.axes, .005*obj.axes)
        self.assertFalse(obj.done)
        self.assertAlmostEqual(obj.pulse_travel, .025)
        self.assertAlmostEqual(obj.contact_travel, .005)

    def test_accepted_fine_plan_refreshes_axes_and_hands_without_changing_assignment(self):
        obj = self.start_span()
        _, grasps, _, _, _ = experiment._snapshot(self.obs)
        old_hands = obj.hands.copy()
        angle = .03
        self.plan_axes[:] = [np.cos(angle), np.sin(angle), 0.]
        self.plan_hand_shift[:] = [0., 0., .005]
        obj._start_motion(self.obs, 'fine', grasps)
        np.testing.assert_allclose(obj.axes, self.plan_axes)
        np.testing.assert_allclose(obj.hands, old_hands+self.plan_hand_shift)
        self.assertEqual(obj.hand_assignment, [0, 1])
        self.plan_assignment = [1, 0]
        with self.assertRaisesRegex(ValueError, 'hand assignment changed'):
            obj._start_motion(self.obs, 'fine', grasps)

    def test_stationary_skin_anchor_keeps_original_points_and_timestamp(self):
        obj = self.start_span()
        self.obs['rgb'] = np.zeros((5, 256, 256, 3), np.uint8)
        self.obs['depth'] = np.full((5, 256, 256, 1), .5)
        self.obs['depth_valid'] = np.zeros((5, 256, 256, 1), bool)
        self.obs['depth_valid'][1:3, 100, 100:112, 0] = True
        shift = np.zeros(3)

        def points(values, camera, u, v, depth):
            return np.repeat((obj.hands[(camera-1) % 2]+shift)[None], len(u), axis=0)

        with patch.object(experiment, '_skin', return_value=np.ones((256, 256), bool)), \
                patch.object(experiment, '_fabric_mask', return_value=np.zeros((256, 256), bool)), \
                patch.object(experiment, '_world_pixels', side_effect=points):
            self.real_refresh_skin(obj, self.obs, 1.)
            anchor = obj.skin_anchor.copy()
            self.assertEqual(obj.skin_anchor_stamp, 1.)
            shift[:] = [.001, 0., 0.]
            self.real_refresh_skin(obj, self.obs, 2.)
            self.assertEqual(obj.skin_stamp, 2.)
            self.assertEqual(obj.skin_anchor_stamp, 1.)
            np.testing.assert_array_equal(obj.skin_anchor, anchor)
            self.assertFalse(np.array_equal(obj.skin, anchor))
            self.obs['depth_valid'][:] = False
            self.real_refresh_skin(obj, self.obs, 3.)
            self.assertEqual(obj.skin_stamp, 2.)
            self.assertEqual(obj.skin_anchor_stamp, 1.)

    def test_total_clock_budget_stops_instead_of_restarting(self):
        obj = self.start_span()
        result = self.tick(obj, 181.)
        self.assert_hold(result); self.assertIn('budget', result['failure'])
        self.assertEqual(len(FakeMotion.instances), 1)


if __name__ == '__main__':
    unittest.main()
