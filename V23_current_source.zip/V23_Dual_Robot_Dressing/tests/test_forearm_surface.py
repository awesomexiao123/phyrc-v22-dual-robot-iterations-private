"""Synthetic RGB-D geometry tests, never mannequin or anatomical truth."""
import sys
from pathlib import Path
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import forearm_surface as surface


def scene(*, cameras=(3, 4), baseline=.18, kind='arm', slanted=True, blue=False):
    """Ray-cast finite planar visible strips into the public camera model."""
    pose = np.zeros((2, 7), float); pose[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.zeros((5, 256, 256, 1), np.float32),
               depth_valid=np.zeros((5, 256, 256, 1), bool),
               base_pose_world=pose.copy(), grasp_pose_base=pose.copy())
    rotation, origin = surface._camera_transform(surface._validated(obs, wrists=True), 3)
    obs['base_pose_world'][1, :3] = rotation @ [baseline, 0., 0.]
    hand = origin + rotation @ [-.18, -.12, 1.]
    other = origin + rotation @ [.25, .24, 1.]
    optical_axis = np.array([.70, .52, .49] if slanted else [1., 0., 0.])
    optical_axis /= np.linalg.norm(optical_axis)
    axis = rotation @ optical_axis
    width = rotation @ np.cross([0., 0., 1.], optical_axis)
    width /= np.linalg.norm(width)
    strips = [(hand, axis, width, -.025, .27, .018)]
    if kind == 'isolated_hand':
        strips = [(hand, axis, width, -.025, .025, .020)]
    elif kind == 'broad_background':
        strips = [(hand, axis, width, -.025, .27, .20)]
    elif kind == 'mixed_branches':
        second_axis = rotation @ np.array([-.70, .52, .49])/np.linalg.norm([-.70, .52, .49])
        second_width = np.cross(rotation[:, 2], second_axis); second_width /= np.linalg.norm(second_width)
        strips.append((hand, second_axis, second_width, -.025, .27, .018))
    elif kind == 'discontinuous_background':
        strips = [(hand, axis, width, -.025, .025, .020),
                  (hand+rotation@[0., 0., .15], axis, width, .04, .27, .018)]
    rows, cols = np.indices((256, 256))
    optical_rays = np.stack(((cols+.5-128)/surface._FOCAL, (rows+.5-128)/surface._FOCAL, np.ones((256, 256))), axis=-1)
    for camera in cameras:
        camera_rotation, camera_origin = surface._camera_transform(surface._validated(obs, wrists=True), camera)
        rays = optical_rays @ camera_rotation.T
        zbuffer = np.full((256, 256), np.inf)
        for center, direction, sideways, low, high, halfwidth in strips:
            normal = np.cross(direction, sideways)
            denominator = rays @ normal
            depth = np.full_like(denominator, np.nan)
            usable = np.abs(denominator) > .01
            depth[usable] = ((center-camera_origin) @ normal)/denominator[usable]
            points = camera_origin + rays*depth[..., None]
            local = points-center
            along, across = local @ direction, local @ sideways
            hit = usable & (depth > .03) & (depth < zbuffer) & (along >= low) & (along <= high) & (np.abs(across) <= halfwidth)
            zbuffer[hit] = depth[hit]
        visible = np.isfinite(zbuffer)
        obs['depth'][camera, ..., 0][visible] = zbuffer[visible]
        obs['depth_valid'][camera, ..., 0] = visible
        obs['rgb'][camera][visible] = [10, 20, 230] if blue else [200, 150, 150]
    return obs, np.stack([hand, other]), axis


class ForearmSurfaceTests(unittest.TestCase):
    def test_slanted_surface_keeps_full_3d_axis_and_requires_parallax_views(self):
        obs, hands, expected = scene()
        original = {key: value.copy() for key, value in obs.items()}
        result = surface.estimate_forearm_surfaces(obs, hands)
        first = result['hand_surfaces'][0]
        self.assertEqual(first['status'], 'multi_view_consistent_candidate', first)
        axis = np.asarray(first['axis_world'])
        self.assertGreater(axis @ expected, np.cos(np.deg2rad(5)))
        self.assertGreater(abs(axis[2]), .2)
        self.assertFalse(first['anatomical_axis_verified'])
        self.assertFalse(first['internal_skeleton_estimated'])
        self.assertFalse(first['insertion_allowed'])
        self.assertFalse(result['insertion_allowed'])
        self.assertTrue(first['supporting_parallax_pairs'])
        for key in obs:
            np.testing.assert_array_equal(obs[key], original[key])

    def test_world_rigid_transform_of_cameras_and_surface_preserves_world_axis(self):
        obs, hands, expected = scene()
        angle = .65
        rotation = np.array([[np.cos(angle), -np.sin(angle), 0],
                             [np.sin(angle), np.cos(angle), 0], [0, 0, 1.]])
        translation = np.array([.7, -.4, .2])
        obs['base_pose_world'][:, :3] = obs['base_pose_world'][:, :3] @ rotation.T + translation
        obs['base_pose_world'][:, 3:] = [np.cos(angle/2), 0, 0, np.sin(angle/2)]
        hands = hands @ rotation.T + translation
        result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
        self.assertEqual(result['status'], 'multi_view_consistent_candidate', result)
        self.assertGreater(np.dot(result['axis_world'], rotation@expected), np.cos(np.deg2rad(5)))

    def test_moving_camera_while_world_surface_stays_fixed_does_not_rotate_axis(self):
        axes = []
        for baseline in (.18, .28):
            obs, hands, expected = scene(baseline=baseline)
            result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
            self.assertEqual(result['status'], 'multi_view_consistent_candidate', result)
            self.assertGreater(np.dot(result['axis_world'], expected), np.cos(np.deg2rad(5)))
            axes.append(result['axis_world'])
        self.assertGreater(np.dot(*axes), np.cos(np.deg2rad(3)))

    def test_disagreeing_individually_elongated_camera_surfaces_are_not_fused(self):
        obs, hands, _ = scene()
        inconsistent, _, _ = scene(slanted=False)
        for key in ('rgb', 'depth', 'depth_valid'):
            obs[key][4] = inconsistent[key][4]
        result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
        self.assertEqual(len(result['candidate_views']), 2)
        self.assertEqual(result['status'], 'unknown')
        self.assertIsNone(result['axis_world'])
        self.assertEqual(result['reason'], 'camera_surface_axes_conflict')
        self.assertTrue(result['conflicting_pairs'])

    def test_single_camera_and_duplicate_optical_pose_cannot_make_strong_claim(self):
        for cameras, baseline, expected_status in (((3,), .18, 'single_view_candidate'), ((3, 4), 0., 'unknown')):
            with self.subTest(cameras=cameras, baseline=baseline):
                obs, hands, _ = scene(cameras=cameras, baseline=baseline)
                result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
                self.assertEqual(result['status'], expected_status, result)
                self.assertIsNone(result['axis_world'])
                self.assertEqual(result['supporting_parallax_pairs'], [])
                self.assertFalse(result['insertion_allowed'])

    def test_isolated_hand_mixed_arms_and_background_are_unknown(self):
        for kind in ('isolated_hand', 'mixed_branches', 'broad_background', 'discontinuous_background'):
            with self.subTest(kind=kind):
                obs, hands, _ = scene(kind=kind)
                result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
                self.assertEqual(result['status'], 'unknown', result)
                self.assertIsNone(result['axis_world'])
                self.assertFalse(result['insertion_allowed'])

    def test_blue_cloth_and_missing_depth_never_supply_forearm_axis(self):
        for mode in ('cloth', 'missing_depth'):
            with self.subTest(mode=mode):
                obs, hands, _ = scene(blue=mode == 'cloth')
                if mode == 'missing_depth':
                    obs['depth_valid'][:] = False
                result = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
                self.assertEqual(result['status'], 'unknown')
                self.assertEqual(result['candidate_views'], [])

    def test_input_hand_order_does_not_change_surface_identity(self):
        obs, hands, _ = scene()
        first = surface.estimate_forearm_surfaces(obs, hands)['hand_surfaces'][0]
        swapped = surface.estimate_forearm_surfaces(obs, hands[::-1])['hand_surfaces'][1]
        self.assertEqual(first['status'], 'multi_view_consistent_candidate', first)
        self.assertEqual(swapped['status'], first['status'])
        np.testing.assert_allclose(first['axis_world'], swapped['axis_world'], atol=1e-7)
        self.assertFalse(swapped['anatomical_axis_verified'])

    def test_nearby_other_hand_prevents_ambiguous_hand_assignment(self):
        obs, hands, axis = scene()
        hands[1] = hands[0] + axis*.045
        result = surface.estimate_forearm_surfaces(obs, hands)
        for hand in result['hand_surfaces']:
            self.assertEqual(hand['status'], 'unknown', hand)
            self.assertIsNone(hand['axis_world'])

    def test_overview_does_not_contribute_surface_evidence(self):
        obs, hands, _ = scene(cameras=(3,))
        for key in ('rgb', 'depth', 'depth_valid'):
            obs[key][0] = obs[key][3]
            obs[key][3] = 0
        result = surface.estimate_forearm_surfaces(obs, hands)
        self.assertEqual(result['cameras_used'], [1, 2, 3, 4])
        self.assertTrue(all(hand['status'] == 'unknown' for hand in result['hand_surfaces']))


if __name__ == '__main__':
    unittest.main()
