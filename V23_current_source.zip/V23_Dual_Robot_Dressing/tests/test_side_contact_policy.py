"""CPU variant wiring/provenance checks; no model load or simulator."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import cooperative_policy as cooperative
import side_contact_policy as side
import sleeve_contact_policy as contact
from planar_shirt import estimate_planar_shirt
from test_sleeve_pair_policy import Baseline, observation


def planar():
    return dict(detected=True, candidates=[
        dict(target_world=[-.3, 0., .6], geometric_side='negative_lateral'),
        dict(target_world=[.3, 0., .6], geometric_side='positive_lateral')])


def edge_prior(stamp=9.):
    original = planar()
    edges = deepcopy(original['candidates'])
    for index, candidate in enumerate(edges):
        candidate['target_world'][0] += -.03 if index == 0 else .03
        candidate.update(observation_time_s=stamp,
            boundary_evidence=dict(observation_time_s=stamp, camera_index=4,
                full_arc_measured_points_world=[[0., 0., 0.], [0., .03, 0.], [0., .06, 0.]]))
    return dict(detected=True, observation_time_s=stamp, candidates=edges,
                original_interior_candidates=original['candidates'])


class SideContactPolicyTests(unittest.TestCase):
    def actor(self):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = side.Policy('unused.pt')
        actor.shirt = planar(); actor.shirt_observed_at = 9.
        actor.cached_edge_prior = edge_prior()
        return actor

    def test_detector_returns_original_interior_targets_and_caches_same_frame_size_prior(self):
        actor = self.actor(); obs = observation(); original = planar(); edges = edge_prior(10.)
        with patch.object(side, 'estimate_planar_shirt', return_value=original), \
                patch.object(side, 'estimate_planar_sleeve_edges', return_value=edges) as detect:
            result = actor._estimate_shirt(obs)
        self.assertIs(result, original)
        detect.assert_called_once_with(obs, original)
        self.assertEqual(actor.cached_edge_prior, edges)
        self.assertIsNot(actor.cached_edge_prior, edges)
        edges['candidates'][0]['target_world'][0] = 8.
        self.assertNotEqual(actor.cached_edge_prior, edges)

    def test_missing_new_edge_views_keep_old_prior_timestamp_without_restamping(self):
        actor = self.actor(); previous = deepcopy(actor.cached_edge_prior)
        with patch.object(side, 'estimate_planar_shirt', return_value=planar()), \
                patch.object(side, 'estimate_planar_sleeve_edges', return_value=dict(detected=False)):
            actor._estimate_shirt(observation())
        self.assertEqual(actor.cached_edge_prior, previous)
        self.assertEqual(actor.cached_edge_prior['observation_time_s'], 9.)

    def test_missing_planar_view_does_not_relabel_cached_geometry_as_current(self):
        actor = self.actor(); previous = deepcopy(actor.cached_edge_prior)
        with patch.object(side, 'estimate_planar_shirt', return_value=dict(detected=False)), \
                patch.object(side, 'estimate_planar_sleeve_edges') as detect:
            result = actor._estimate_shirt(observation())
        self.assertFalse(result['detected']); detect.assert_not_called()
        self.assertEqual(actor.cached_edge_prior, previous)

    def test_old_timestamp_from_claimed_current_edge_detector_is_rejected(self):
        actor = self.actor()
        with patch.object(side, 'estimate_planar_shirt', return_value=planar()), \
                patch.object(side, 'estimate_planar_sleeve_edges', return_value=edge_prior(9.95)):
            with self.assertRaisesRegex(ValueError, 'current planar observation'):
                actor._estimate_shirt(observation())

    def test_handoff_calls_original_side_logic_and_never_edge_reacquisition(self):
        actor = self.actor(); original = deepcopy(actor.shirt)
        with patch.object(contact, 'reacquire_planar_sleeve_edges', side_effect=AssertionError('edge pickup path forbidden')):
            actor._prepare_pair(observation())
        self.assertEqual(actor.shirt, original)
        self.assertEqual(actor.shirt_observed_at, 9.)
        self.assertEqual(actor.initial_edge_report, actor.cached_edge_prior)
        self.assertIsNot(actor.initial_edge_report, actor.cached_edge_prior)
        self.assertTrue(actor.handoff_done)
        expected = np.asarray([c['target_world'] for c in original['candidates']])[actor.pair_candidate_indices]
        np.testing.assert_array_equal(actor.pair_targets, expected)
        edge_targets = np.asarray([c['target_world'] for c in actor.initial_edge_report['candidates']])[actor.pair_candidate_indices]
        self.assertGreater(np.linalg.norm(edge_targets-actor.pair_targets, axis=1).min(), .02)
        actor.cached_edge_prior['observation_time_s'] = 10.
        self.assertEqual(actor.initial_edge_report['observation_time_s'], 9.)

    def test_stale_future_missing_mixed_swapped_or_displaced_prior_blocks_handoff(self):
        for fault in ('missing', 'stale', 'future', 'mixed', 'swapped', 'displaced', 'malformed'):
            actor = self.actor()
            if fault == 'missing':
                actor.cached_edge_prior = None
            elif fault == 'stale':
                actor.cached_edge_prior['observation_time_s'] = -21.
            elif fault == 'future':
                actor.cached_edge_prior['observation_time_s'] = 11.
            elif fault == 'mixed':
                actor.cached_edge_prior['candidates'][0]['boundary_evidence']['observation_time_s'] = 9.5
            elif fault == 'swapped':
                actor.cached_edge_prior['original_interior_candidates'].reverse()
            elif fault == 'displaced':
                actor.cached_edge_prior['original_interior_candidates'][1]['target_world'][0] += .031
            else:
                actor.cached_edge_prior['original_interior_candidates'][0]['target_world'] = [float('nan'), 0., .6]
            with self.subTest(fault=fault), patch.object(side.SleeveSidePolicy, '_prepare_pair') as prepare:
                with self.assertRaises(ValueError):
                    actor._prepare_pair(observation())
                prepare.assert_not_called()
                self.assertIsNone(actor.initial_edge_report)

    def test_bounded_interior_shift_is_accepted_without_moving_target_to_old_edge(self):
        actor = self.actor(); actor.shirt['candidates'][0]['target_world'][0] += .029
        wanted = deepcopy(actor.shirt)
        actor._prepare_pair(observation())
        self.assertEqual(actor.shirt, wanted)
        self.assertEqual(actor.initial_edge_report['original_interior_candidates'][0]['target_world'], [-.3, 0., .6])

    def test_current_side_prior_must_also_have_nonfuture_recent_timestamp(self):
        for stamp in (-21., 11., float('nan')):
            actor = self.actor(); actor.shirt_observed_at = stamp
            with self.subTest(stamp=stamp), self.assertRaises(ValueError):
                actor._prepare_pair(observation())

    def test_same_sample_uses_original_planar_points_and_separate_observed_edge_prior(self):
        actor = self.actor()
        with np.load(ROOT/'participant/sample_observation.npz', allow_pickle=False) as archive:
            obs = {key: archive[key].copy() for key in archive.files}
        expected = estimate_planar_shirt(obs)
        result = actor._estimate_shirt(obs)
        self.assertEqual(result['candidates'], expected['candidates'])
        self.assertTrue(actor.cached_edge_prior['detected'])
        self.assertEqual(actor.cached_edge_prior['original_interior_candidates'], expected['candidates'])
        self.assertEqual(actor.cached_edge_prior['observation_time_s'], float(obs['simulation_time_s']))
        original = np.asarray([c['target_world'] for c in result['candidates']])
        edge = np.asarray([c['target_world'] for c in actor.cached_edge_prior['candidates']])
        self.assertGreater(np.linalg.norm(original-edge, axis=1).min(), .025)

    def test_contact_pitch_and_contact_executor_are_inherited_unmodified(self):
        self.assertEqual(side.Policy.VERSION, 'v23_18_contact_sleeve_sides')
        self.assertIn('interior sleeve-side pickups', side.Policy.METHOD)
        self.assertIn('edge size prior only', side.Policy.METHOD)
        self.assertIs(side.Policy._create_loaded_pitch, contact.Policy._create_loaded_pitch)
        self.assertIs(side.Policy.__call__, contact.Policy.__call__)
        self.assertIs(side.Policy._validate_common_lift, side.SleeveSidePolicy._validate_common_lift)
        self.assertIs(side.Policy._track_has_evidence, side.SleeveSidePolicy._track_has_evidence)
        self.assertFalse(side.Policy.ALIGN_SLEEVE_SIDE_PAIR)
        self.assertFalse(side.Policy.ENABLE_OBSERVED_OPENING_APPROACH)


if __name__ == '__main__':
    unittest.main()
