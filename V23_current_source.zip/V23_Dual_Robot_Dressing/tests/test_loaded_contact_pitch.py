"""Longer posture experiment retains original cumulative and lag guards."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_pitch_observation as pitch
from loaded_contact_pitch import LoadedContactPitch
from test_loaded_pitch_observation import observation, integrate, hands, visible
from public_vision import grasp_world


class ContactPitchTests(unittest.TestCase):
    def test_ten_degree_pair_with_lag_keeps_original_grasps_and_absolute_budget(self):
        obs = observation(base_tilt=.025)
        with patch.object(pitch, '_cloth_evidence', side_effect=visible):
            controller = LoadedContactPitch(obs, hands(), 0., stationary_human=True)
            original = controller.grasp0.copy(); worst_drift = 0.
            for _ in range(950):
                result = controller.step(obs)
                self.assertIsNone(result['failure'], result)
                self.assertIsNone(result['pending_failure'], result)
                self.assertLessEqual(np.count_nonzero(result['action'][:, 6]), 1)
                np.testing.assert_array_equal(result['action'][:, [0, 1, 2, 5, 7]], 0.)
                worst_drift = max(worst_drift, float(np.max(np.linalg.norm(
                    np.stack([grasp_world(obs,r) for r in (0,1)])-original, axis=1))))
                if result['done']: break
                integrate(obs, result['action'], follow=(.3, .65, .5))
        self.assertTrue(result['experiment_completed'], result)
        self.assertLess(worst_drift, .001)
        self.assertLess(float(obs['simulation_time_s']), 45.)
        np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:, 9]), 31., atol=.01)
        self.assertLess(result['debug']['measured_total_absolute_pitch_degrees'], 20.01)
        self.assertAlmostEqual(result['debug']['total_absolute_pitch_budget_degrees'], 21.)
        self.assertEqual(result['debug']['cached_hand_observed_at_s'], 0.)
        np.testing.assert_array_equal(controller.grasp0, original)

    def test_larger_angle_does_not_reuse_small_pilot_yaw_allowance(self):
        obs = observation(yaw=np.deg2rad(5.))
        controller = LoadedContactPitch(obs, hands(), 0., stationary_human=True)
        result = controller.step(obs)
        self.assertTrue(result['skipped'])
        self.assertIn('lateral_residual', result['debug']['ineligible_reason'])
        np.testing.assert_array_equal(result['action'][:, :8], 0.)


if __name__ == '__main__':
    unittest.main()
