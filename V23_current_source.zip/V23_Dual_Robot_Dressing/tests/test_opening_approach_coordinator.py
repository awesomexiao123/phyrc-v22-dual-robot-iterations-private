"""Public-observation coordinator boundaries; controller stubs do not prove physics."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import opening_approach_coordinator as coordinator
from test_sleeve_probe import scene


class Tracker:
    def __init__(self, reliable=True):
        self.reliable = reliable
        self.reset_count = self.update_count = 0
        self.identity = None
        self.candidate = None

    def reset(self, obs, candidate):
        self.reset_count += 1
        self.candidate = copy.deepcopy(candidate)
        self.identity = dict(initial_camera_index=candidate['camera_index'],
            initial_source_camera=candidate['source_camera'], initial_observation_time_s=float(obs['simulation_time_s']),
            initial_contour_pixels_uv=candidate['inner_aperture']['contour_pixels_uv'],
            initial_background_depth_supported=True)
        return self.report(obs)

    def update(self, obs):
        self.update_count += 1
        return self.report(obs)

    def report(self, obs):
        candidate = copy.deepcopy(self.candidate)
        candidate['observation_time_s'] = float(obs['simulation_time_s'])
        candidate['inner_aperture']['observation_time_s'] = float(obs['simulation_time_s'])
        return dict(reliable=self.reliable, reason='synthetic reliable rim' if self.reliable else 'synthetic rim occlusion',
            kind='tracked_unclassified_rim', identity=copy.deepcopy(self.identity), features_reseeded=False,
            tracked_count=12, median_displacement_world=[0., 0., 0.], rim_geometry=candidate)


class Approach:
    def __init__(self, obs):
        self.calls = []
        self.spent = 0.
        self.lost_since = None
        self.done = False
        self.failure = None

    def step(self, obs, rims, hands, forearms):
        self.calls.append((copy.deepcopy(rims), copy.deepcopy(hands), copy.deepcopy(forearms)))
        now = float(obs['simulation_time_s'])
        action = coordinator.OpeningApproachCoordinator._hold()
        lost = not all(rim['reliable'] for rim in rims) or not hands.get('detected') or not forearms.get('hand_surfaces')
        if lost:
            self.lost_since = now if self.lost_since is None else self.lost_since
            if now-self.lost_since > 2.:
                self.failure = 'geometry_reacquisition_timed_out: synthetic lost rim'
        elif len(self.calls) > 1:
            self.spent += .004
            action[:, 1] = .001
        return dict(action=action, done=self.done, failure=self.failure,
            debug=dict(requested_path_m=self.spent, hold_reason='lost rim' if lost else None,
                       custom_response_evidence='preserve this child diagnostic'))


def refresh_report(report, now):
    report = copy.deepcopy(report)
    for row in report['grasp_regions']:
        for candidate in row['depth_supported_opening_candidates']:
            candidate['observation_time_s'] = now
            candidate['inner_aperture']['observation_time_s'] = now
    return report


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.obs, _, self.sleeves, self.hands, self.surfaces, _ = scene(hand_depth=1.04)
        self.hand_mock = patch.object(coordinator, 'estimate_hands', return_value=self.hands).start()
        self.surface_mock = patch.object(coordinator, 'estimate_forearm_surfaces', return_value=self.surfaces).start()
        self.addCleanup(patch.stopall)

    def test_lost_rim_does_not_suppress_bounded_integrated_target_cancellation(self):
        trackers = [Tracker(), Tracker()]
        with patch.object(coordinator, 'OpeningRimTracker', side_effect=trackers), \
                patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach):
            owner = coordinator.OpeningApproachCoordinator()
            owner.step(self.obs, self.sleeves)
            trackers[0].reliable = False
            action = owner._hold(); action[:, 3] = -.001/1.54
            owner.approach.step = Mock(return_value=dict(action=action, done=False,
                failure=None, pending_failure='bounded abort pending', cancellation_only=True,
                debug={'cancellation_only': True}))
            self.obs['simulation_time_s'] = 1.05
            result = owner.step(self.obs)
        np.testing.assert_array_equal(result['action'], action)
        self.assertIsNone(result['failure'])
        self.assertEqual(result['pending_failure'], 'bounded abort pending')
        self.assertTrue(result['cancellation_only'])
        self.assertTrue(result['debug']['fixed_track_identity_lost'])

    def test_cancellation_label_cannot_authorize_base_motion_or_excess_lift_rate(self):
        for fault in ('base', 'lift'):
            with self.subTest(fault=fault), \
                    patch.object(coordinator, 'OpeningRimTracker', side_effect=[Tracker(), Tracker()]), \
                    patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach):
                self.obs['simulation_time_s'] = 1.
                owner = coordinator.OpeningApproachCoordinator(); owner.step(self.obs, self.sleeves)
                action = owner._hold()
                action[:, 0 if fault == 'base' else 3] = .01
                owner.approach.step = Mock(return_value=dict(action=action, done=False,
                    failure=None, cancellation_only=True, debug={}))
                self.obs['simulation_time_s'] = 1.05
                result = owner.step(self.obs)
                self.assertIn('invalid_lift_only', result['failure'])
                np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_all_or_nothing_initialization_retries_only_before_started(self):
        attempts = [Tracker(), Tracker(False), Tracker(), Tracker()]
        with patch.object(coordinator, 'OpeningRimTracker', side_effect=attempts) as factory, \
             patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach) as control_factory:
            owner = coordinator.OpeningApproachCoordinator()
            result = owner.step(self.obs, self.sleeves)
            self.assertFalse(owner.started)
            self.assertIsNone(owner.trackers)
            self.assertIsNone(owner.approach)
            control_factory.assert_not_called()
            np.testing.assert_array_equal(result['action'][:, :8], 0.)
            self.assertIn('both_initial', result['debug']['initialization_reason'])
            owner.step(self.obs, self.sleeves)
            self.assertEqual(factory.call_count, 2)
            self.obs['simulation_time_s'] = 1.05
            result = owner.step(self.obs, refresh_report(self.sleeves, 1.05))
            self.assertTrue(owner.started)
            self.assertEqual(factory.call_count, 4)
            control_factory.assert_called_once()
            self.assertEqual([t.reset_count for t in attempts], [1, 1, 1, 1])
            self.assertEqual([t.update_count for t in attempts], [0, 0, 0, 0])
            self.assertIs(owner.trackers[0], attempts[2])
            self.assertEqual(len(owner.approach.calls), 1)

    def test_first_frame_uses_reset_reports_duplicate_holds_and_one_budget_instance_persists(self):
        trackers = [Tracker(), Tracker()]
        with patch.object(coordinator, 'OpeningRimTracker', side_effect=trackers), \
             patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach) as factory:
            owner = coordinator.OpeningApproachCoordinator()
            first = owner.step(self.obs, self.sleeves)
            instance = owner.approach
            self.assertTrue(owner.started)
            self.assertEqual([t.update_count for t in trackers], [0, 0])
            self.assertEqual(len(instance.calls), 1)
            self.assertEqual(instance.calls[0][0][0]['rim_geometry']['observation_time_s'], 1.)
            for now in (1.05, 1.10, 1.15):
                self.obs['simulation_time_s'] = now
                result = owner.step(self.obs, None)
                self.assertIs(owner.approach, instance)
                np.testing.assert_array_equal(result['action'][:, 1], np.full(2, .001, np.float32))
                count = len(instance.calls)
                duplicate = owner.step(self.obs, None)
                self.assertEqual(len(instance.calls), count)
                np.testing.assert_array_equal(duplicate['action'][:, :8], 0.)
                self.assertIn('no_duplicate', duplicate['debug']['hold_reason'])
            factory.assert_called_once()
            self.assertEqual([t.reset_count for t in trackers], [1, 1])
            self.assertEqual([t.update_count for t in trackers], [3, 3])
            self.assertAlmostEqual(result['debug']['approach']['requested_path_m'], .012)
            self.assertEqual(self.hand_mock.call_count, 4)
            self.assertEqual(self.surface_mock.call_count, 4)
            self.assertEqual(instance.calls[-1][1]['observation_time_s'], 1.15)
            self.assertEqual(instance.calls[-1][2]['observation_time_s'], 1.15)
            self.assertEqual(self.hands['observation_time_s'], 1.)
            self.assertEqual(self.surfaces['observation_time_s'], 1.)

    def test_missing_initial_geometry_holds_and_times_out_after_twenty_seconds(self):
        owner = coordinator.OpeningApproachCoordinator()
        with patch.object(coordinator, 'ObservedPairApproach') as factory:
            for now in (1., 10., 20.99):
                self.obs['simulation_time_s'] = now
                result = owner.step(self.obs, None)
                self.assertIsNone(result['failure'])
                self.assertFalse(owner.started)
                np.testing.assert_array_equal(result['action'][:, :8], 0.)
                np.testing.assert_array_equal(result['action'][:, 8], 1.)
            self.obs['simulation_time_s'] = 21.
            result = owner.step(self.obs, self.sleeves)
            self.assertIn('wait_timed_out', result['failure'])
            self.assertFalse(result['debug']['actual_grasp_failure_claimed'])
            factory.assert_not_called()

    def test_stale_misbound_ambiguous_unobserved_or_duplicate_initial_candidates_cannot_seed(self):
        for fault in ('stale', 'grasp_index', 'grasp_pose', 'ambiguous', 'no_depth', 'same_ring', 'far_ring'):
            with self.subTest(fault=fault):
                report = copy.deepcopy(self.sleeves)
                row = report['grasp_regions'][0]
                candidate = row['depth_supported_opening_candidates'][0]
                if fault == 'stale': candidate['observation_time_s'] = .9
                elif fault == 'grasp_index': row['grasp_index'] = 1
                elif fault == 'grasp_pose': row['grasp_world'][0] += .006
                elif fault == 'ambiguous': row['ambiguous_candidate_indices'] = [1]
                elif fault == 'no_depth': candidate['observed_depth_support']['ring_valid_fraction'] = .1
                elif fault == 'same_ring': report['grasp_regions'][1]['depth_supported_opening_candidates'] = copy.deepcopy(row['depth_supported_opening_candidates'])
                elif fault == 'far_ring': candidate['centroid_world'][0] += 1.
                with patch.object(coordinator, 'OpeningRimTracker') as factory:
                    owner = coordinator.OpeningApproachCoordinator()
                    result = owner.step(self.obs, report)
                    self.assertFalse(owner.started)
                    self.assertIsNone(result['failure'])
                    factory.assert_not_called()
                    np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_lost_rim_keeps_same_controller_uses_its_timeout_and_never_reseeds(self):
        trackers = [Tracker(), Tracker()]
        with patch.object(coordinator, 'OpeningRimTracker', side_effect=trackers) as tracker_factory, \
             patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach) as factory:
            owner = coordinator.OpeningApproachCoordinator(); owner.step(self.obs, self.sleeves)
            trackers[1].reliable = False
            instance = owner.approach
            for index in range(1, 12):
                self.obs['simulation_time_s'] = 1.+.21*index
                result = owner.step(self.obs, self.sleeves)
                self.assertIs(owner.approach, instance)
                np.testing.assert_array_equal(result['action'][:, :8], 0.)
                self.assertTrue(result['debug']['fixed_track_identity_lost'])
                self.assertTrue(result['debug']['regrasp_or_new_view_diagnostic_required'])
                if result['failure']:
                    break
            self.assertIn('geometry_reacquisition_timed_out', result['failure'])
            self.assertEqual([t.reset_count for t in trackers], [1, 1])
            self.assertEqual(tracker_factory.call_count, 2)
            factory.assert_called_once()
            self.obs['simulation_time_s'] += .05
            owner.step(self.obs, self.sleeves)
            factory.assert_called_once()

    def test_child_results_forward_without_smoothing_and_done_failure_latch(self):
        for terminal in ('done', 'failure'):
            with self.subTest(terminal=terminal):
                trackers = [Tracker(), Tracker()]
                with patch.object(coordinator, 'OpeningRimTracker', side_effect=trackers), \
                     patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach):
                    owner = coordinator.OpeningApproachCoordinator(); owner.step(self.obs, self.sleeves)
                    self.obs['simulation_time_s'] += .05
                    moving = owner.step(self.obs, None)
                    np.testing.assert_array_equal(moving['action'][:, 1], np.full(2, .001, np.float32))
                    self.assertEqual(moving['debug']['approach']['custom_response_evidence'], 'preserve this child diagnostic')
                    if terminal == 'done': owner.approach.done = True
                    else: owner.approach.failure = 'synthetic measured response rejected'
                    self.obs['simulation_time_s'] += .05
                    result = owner.step(self.obs, None)
                    self.assertEqual(result['done'], terminal == 'done')
                    self.assertEqual(result['failure'], None if terminal == 'done' else 'synthetic measured response rejected')
                    np.testing.assert_array_equal(result['action'][:, :8], 0.)
                    calls = len(owner.approach.calls)
                    owner.step(self.obs, None)
                    self.assertEqual(len(owner.approach.calls), calls)
                self.obs['simulation_time_s'] = 1.

    def test_real_rim_initialization_and_current_update_are_bound_to_public_contours(self):
        cloth = self.obs['rgb'][3, :, :, 2] > 100
        texture = cv2.resize(np.random.default_rng(29).integers(120, 250, (128, 128), dtype=np.uint8),
                             (256, 256), interpolation=cv2.INTER_NEAREST)
        self.obs['rgb'][3, :, :, 2][cloth] = texture[cloth]
        with patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach):
            owner = coordinator.OpeningApproachCoordinator()
            first = owner.step(self.obs, self.sleeves)
            self.assertTrue(owner.started, first['debug']['initialization_reason'])
            self.assertTrue(all(report['reliable'] for report in first['debug']['tracker_reports']))
            self.assertEqual([report['update_count'] for report in first['debug']['tracker_reports']], [0, 0])
            self.obs['simulation_time_s'] = 1.05
            result = owner.step(self.obs, None)
            self.assertTrue(all(report['reliable'] for report in result['debug']['tracker_reports']))
            self.assertEqual([report['update_count'] for report in result['debug']['tracker_reports']], [1, 1])
            for report in result['debug']['tracker_reports']:
                self.assertEqual(report['rim_geometry']['observation_time_s'], 1.05)

    def test_hand_perception_error_supplies_missing_current_reports_not_old_success(self):
        trackers = [Tracker(), Tracker()]
        with patch.object(coordinator, 'OpeningRimTracker', side_effect=trackers), \
             patch.object(coordinator, 'ObservedPairApproach', side_effect=Approach):
            owner = coordinator.OpeningApproachCoordinator(); owner.step(self.obs, self.sleeves)
            self.hand_mock.side_effect = ValueError('synthetic hand depth unavailable')
            self.obs['simulation_time_s'] = 1.05
            result = owner.step(self.obs, None)
            self.assertIsNone(result['failure'])
            self.assertIn('hand depth unavailable', result['debug']['perception_error'])
            np.testing.assert_array_equal(result['action'][:, :8], 0.)
            _, hands, surfaces = owner.approach.calls[-1]
            self.assertFalse(hands['detected'])
            self.assertEqual(hands['hand_points_world'], [])
            self.assertEqual(surfaces['hand_surfaces'], [])
            self.assertEqual(hands['observation_time_s'], 1.05)
            self.assertEqual(surfaces['observation_time_s'], 1.05)
            self.assertEqual([tracker.reset_count for tracker in trackers], [1, 1])

    def test_surface_fallback_only_when_primary_pair_missing_and_priors_never_refresh(self):
        original = copy.deepcopy(self.hands)
        owner = coordinator.OpeningApproachCoordinator(original_hand_report=original,
            original_observed_at=1., stationary_human=True, max_prior_age_s=90.)
        original['hand_points_world'][0][0] += 1.
        with patch.object(coordinator, 'reacquire_observed_hand_pair') as reacquire:
            owner._observe_hands(self.obs, 1.)
            reacquire.assert_not_called()
            self.hand_mock.return_value = {'detected': False}
            for now in (1.05, 1.10):
                self.obs['simulation_time_s'] = now
                replacement = copy.deepcopy(self.hands)
                replacement['observation_time_s'] = now
                replacement['hand_points_world'][0][0] += .001
                reacquire.return_value = replacement
                owner._observe_hands(self.obs, now)
                self.assertTrue(owner.fresh_hands['detected'])
                self.assertEqual(owner.fresh_hands['observation_time_s'], now)
                self.assertEqual(owner.fresh_forearms['observation_time_s'], now)
                self.assertEqual(reacquire.call_args.args[2], 1.)
                self.assertEqual(reacquire.call_args.kwargs['max_prior_age_s'], 90.)
                np.testing.assert_array_equal(reacquire.call_args.args[1]['hand_points_world'],
                                              self.hands['hand_points_world'])
                self.surface_mock.assert_called_with(self.obs, replacement['hand_points_world'])
            self.assertEqual(owner.original_hand_observed_at, 1.)
            self.assertEqual(owner.hand_perception_source, 'current_surface_reacquisition_from_fixed_identity_priors')

    def test_missing_or_stale_surface_fallback_never_becomes_fresh_success(self):
        self.hand_mock.return_value = {'detected': False}
        for stale in (False, True):
            with self.subTest(stale=stale):
                owner = coordinator.OpeningApproachCoordinator(original_hand_report=self.hands,
                    original_observed_at=1., stationary_human=True)
                replacement = dict(detected=stale, hand_points_world=self.hands['hand_points_world'] if stale else [],
                                   observation_time_s=.9 if stale else 1.)
                self.surface_mock.reset_mock()
                with patch.object(coordinator, 'reacquire_observed_hand_pair', return_value=replacement):
                    owner._observe_hands(self.obs, 1.)
                self.assertFalse(owner.fresh_hands['detected'])
                self.assertEqual(owner.fresh_hands['hand_points_world'], [])
                self.assertEqual(owner.fresh_forearms['hand_surfaces'], [])
                self.surface_mock.assert_not_called()
                if stale:
                    self.assertIn('did_not_return_current_frame', owner.perception_error)

    def test_surface_fallback_requires_explicit_stationary_assumption_and_original_pair(self):
        self.hand_mock.return_value = {'detected': False}
        for kwargs in ({}, {'original_hand_report': self.hands, 'original_observed_at': 1.},
                       {'stationary_human': True}):
            with patch.object(coordinator, 'reacquire_observed_hand_pair') as reacquire:
                owner = coordinator.OpeningApproachCoordinator(**kwargs)
                owner._observe_hands(self.obs, 1.)
                reacquire.assert_not_called()
                self.assertFalse(owner.fresh_hands['detected'])


if __name__ == '__main__':
    unittest.main()
