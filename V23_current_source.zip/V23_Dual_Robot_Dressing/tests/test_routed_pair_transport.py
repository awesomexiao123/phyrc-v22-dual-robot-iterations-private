"""CPU kinematic and fault tests; not cloth attachment or physics validation."""
import sys
from pathlib import Path
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import cooperative_transport as straight
import routed_pair_transport as routed


def observation(yaws=(0., np.pi/2)):
    bases = np.array([[-1., 0, 0, 1, 0, 0, 0], [1., 0, 0, 1, 0, 0, 0]], float)
    for robot, yaw in enumerate(yaws):
        bases[robot, 3:] = [np.cos(yaw/2), 0, 0, np.sin(yaw/2)]
    return dict(base_pose_world=bases, grasp_pose_base=np.array([[.5, -.08, 1., 1, 0, 0, 0]]*2, float),
        gripper_close_command=np.ones((2, 1), bool), simulation_time_s=np.array(0.),
        depth=np.zeros((5, 256, 256, 1), np.float32), depth_valid=np.zeros((5, 256, 256, 1), bool))


def free_guard(obs, robot, body_velocity_xy, **kwargs):
    return {'body_velocity_xy': np.asarray(body_velocity_xy).tolist()}


def integrate(obs, action):
    for robot in (0, 1):
        rotation = straight._rotation(obs['base_pose_world'][robot, 3:])
        obs['base_pose_world'][robot, :2] += rotation[:2, :2] @ (action[robot, :2]*.616*.05)
        obs['grasp_pose_base'][robot, 2] += action[robot, 3]*1.54*.05
    obs['simulation_time_s'][...] += .05


def direct_route(obs, shift, **kwargs):
    center = obs['base_pose_world'][:, :2].mean(axis=0)
    return dict(feasible=True, reason='synthetic geometry', unknown_space=True,
                pair_center_waypoints_world_xy=[center.tolist(), (center+shift).tolist()])


def segment_result(done=False, blocked=False, action=None):
    if action is None:
        action = np.zeros((2, 9), np.float32)
    return dict(action=action, done=done, failure=None, debug={'navigation_paused_pair': blocked})


class RoutedTransportTests(unittest.TestCase):
    def test_height_then_multiple_xy_segments_for_both_yaw_assignments(self):
        for yaws in ((0., np.pi/2), (np.pi/2, 0.)):
            with self.subTest(yaws=yaws):
                obs = observation(yaws)
                controller = routed.RoutedPairTransport(obs, [.03, .04, .02])
                initial = controller.grasp0.copy()
                seen_phases = set()
                def corner_route(o, shift, **kwargs):
                    np.testing.assert_allclose(o['grasp_pose_base'][:, 2], 1.02, atol=.008)
                    center = o['base_pose_world'][:, :2].mean(axis=0)
                    return dict(feasible=True, reason='synthetic corner', unknown_space=True,
                        pair_center_waypoints_world_xy=[center, center+[shift[0], 0], center+shift])
                with patch.object(routed, 'plan_pair_route', side_effect=corner_route) as planner, \
                        patch.object(straight, 'guard_base_velocity', side_effect=free_guard):
                    for _ in range(300):
                        phase_before = controller.phase
                        result = controller.step(obs)
                        seen_phases.add(phase_before)
                        self.assertIsNone(result['failure'], result)
                        action = result['action']
                        np.testing.assert_array_equal(action[:, [2, 4, 5, 6, 7]], np.zeros((2, 5)))
                        np.testing.assert_array_equal(action[:, 8], np.ones(2))
                        if phase_before == 'height':
                            np.testing.assert_array_equal(action[:, :2], np.zeros((2, 2)))
                        if result['debug']['segment_transition_hold']:
                            np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
                        if result['done']:
                            break
                        integrate(obs, action)
                self.assertTrue(result['done'], result)
                self.assertEqual(controller.completed_segments, 3)
                planner.assert_called_once()
                self.assertTrue({'height', 'translate', 'verify_goal'}.issubset(seen_phases))
                _, final, _, _, _ = straight._snapshot(obs)
                np.testing.assert_allclose(final, initial+controller.shift, atol=.008)
                np.testing.assert_array_equal(controller.step(obs)['action'][:, :8], np.zeros((2, 8)))

    def test_static_observations_do_not_advance_to_route_or_complete(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.03, 0, .02])
        with patch.object(routed, 'plan_pair_route') as planner, \
                patch.object(straight, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(50):
                result = controller.step(obs)
            self.assertEqual(controller.segment.reference, 0.)
            self.assertFalse(result['done'])
            planner.assert_not_called()
            for _ in range(320):
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
                if result['failure']:
                    break
            self.assertIn('no measured pair progress', result['failure'])
            self.assertFalse(result['done'])
            planner.assert_not_called()

    def test_long_obstacle_stop_replans_from_current_public_pose_and_rejects_failure(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.10, 0, 0])
        requests = []
        def planner(o, shift, **kwargs):
            requests.append(np.asarray(shift).copy())
            return direct_route(o, shift) if len(requests) == 1 else {'feasible': False, 'reason': 'blocked corridor'}
        blocked = False
        def guard(o, robot, body, **kwargs):
            return {'body_velocity_xy': [0., 0.] if blocked and robot == 1 else np.asarray(body).tolist()}
        with patch.object(routed, 'plan_pair_route', side_effect=planner), \
                patch.object(straight, 'guard_base_velocity', side_effect=guard):
            for _ in range(20):
                result = controller.step(obs); integrate(obs, result['action'])
            measured_before_block = obs['base_pose_world'][:, :2].mean(axis=0).copy()
            blocked = True
            for _ in range(40):
                result = controller.step(obs)
                np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                if result['failure']:
                    break
                integrate(obs, result['action'])
        self.assertEqual(controller.replans, 1)
        self.assertIn('blocked corridor', result['failure'])
        self.assertEqual(len(requests), 2)
        np.testing.assert_allclose(requests[1], [.1, 0]-measured_before_block)
        self.assertLess(requests[1][0], requests[0][0])
        self.assertGreater(result['debug']['calls'], 30)

    def test_repeated_obstacles_exhaust_two_replans_with_no_motion_leak(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.10, 0, 0])
        with patch.object(routed, 'plan_pair_route', side_effect=direct_route) as planner, \
                patch.object(straight, 'guard_base_velocity', return_value={'body_velocity_xy': [0., 0.]}):
            for _ in range(130):
                result = controller.step(obs)
                np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                if result['failure']:
                    break
                integrate(obs, result['action'])
        self.assertEqual(controller.replans, 2)
        self.assertEqual(planner.call_count, 3)
        self.assertIn('exhausted two', result['failure'])

    def test_persistent_nonzero_obstacle_slowdown_replans_without_forgetting_goal(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.20, 0, 0])
        original_goal = controller.goal_grasps.copy()
        def slow_guard(o, robot, body, **kwargs):
            return dict(body_velocity_xy=(np.asarray(body)*.2).tolist())
        with patch.object(routed, 'plan_pair_route', side_effect=direct_route) as planner, \
                patch.object(straight, 'guard_base_velocity', side_effect=slow_guard), \
                patch.object(routed, 'validate_pair_route_segment', return_value=dict(feasible=False)):
            for _ in range(80):
                result = controller.step(obs)
                self.assertIsNone(result['failure'], result)
                if controller.replans:
                    break
                integrate(obs, result['action'])
        self.assertEqual(controller.replans, 1)
        self.assertEqual(planner.call_count, 2)
        self.assertEqual(planner.call_args.kwargs['execution_clearance_m'], .12)
        np.testing.assert_array_equal(controller.goal_grasps, original_goal)
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
        self.assertTrue(result['debug']['segment_transition_hold'])

    def test_pair_keeps_valid_half_speed_path_without_replan_loop(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.20, 0, 0])
        with patch.object(routed, 'plan_pair_route', side_effect=direct_route) as planner, \
                patch.object(straight, 'guard_base_velocity', side_effect=lambda o, r, b, **k:
                          dict(body_velocity_xy=(np.asarray(b)*.5).tolist())), \
                patch.object(routed, 'validate_pair_route_segment', return_value=dict(feasible=True)) as check:
            for _ in range(80):
                result = controller.step(obs)
                self.assertIsNone(result['failure'], result)
                integrate(obs, result['action'])
        self.assertGreater(check.call_count, 0)
        self.assertEqual(controller.replans, 0)
        planner.assert_called_once()
        self.assertGreater(np.linalg.norm(result['action'][:, :2]), 0.)
        self.assertLess(float(obs['simulation_time_s']), 6.)

    def test_cumulative_relative_grasp_error_survives_segment_resets(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.08, 0, 0])
        points = np.column_stack((np.arange(9)*.01, np.zeros(9)))
        with patch.object(routed, 'plan_pair_route', return_value={
                'feasible': True, 'pair_center_waypoints_world_xy': points}), \
                patch.object(routed, 'RigidPairTransport', return_value=Mock(
                    step=Mock(return_value=segment_result(done=True)))):
            controller.step(obs)
            for step in range(6):
                obs['base_pose_world'][:, 0] += .01
                obs['grasp_pose_base'][1, 2] += .007
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
                if step < 5:
                    self.assertIsNone(result['failure'])
            self.assertIn('cumulative relative grasp', result['failure'])
            self.assertGreater(result['debug']['relative_grasp_error_m'], .04)
            self.assertFalse(result['done'])
            np.testing.assert_array_equal(result['action'], np.zeros((2, 9)))

    def test_false_segment_done_without_measured_progress_is_rejected(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.03, 0, 0])
        with patch.object(routed, 'plan_pair_route', side_effect=direct_route), \
                patch.object(routed, 'RigidPairTransport', return_value=Mock(
                    step=Mock(return_value=segment_result(done=True)))):
            controller.step(obs)
            result = controller.step(obs)
        self.assertIn('without measured target poses', result['failure'])
        self.assertEqual(controller.completed_segments, 0)
        self.assertFalse(result['done'])

    def test_final_global_target_is_checked_even_if_local_segments_finish(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.03, 0, 0])
        points = np.column_stack((np.arange(4)*.01, np.zeros(4)))
        with patch.object(routed, 'plan_pair_route', return_value={
                'feasible': True, 'pair_center_waypoints_world_xy': points}), \
                patch.object(routed, 'RigidPairTransport', return_value=Mock(
                    step=Mock(return_value=segment_result(done=True)))):
            controller.step(obs)
            for _ in range(3):
                obs['base_pose_world'][:, 0] += .01
                obs['grasp_pose_base'][:, 2] += .005
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
                self.assertIsNone(result['failure'])
            self.assertEqual(controller.phase, 'verify_goal')
            result = controller.step(obs)
        self.assertIn('original desired shift', result['failure'])
        self.assertFalse(result['done'])

    def test_guarded_zero_action_is_forwarded_without_outer_smoothing(self):
        obs = observation(); controller = routed.RoutedPairTransport(obs, [.03, 0, 0])
        moving = np.zeros((2, 9), np.float32); moving[:, 0] = .04
        zero = segment_result(); zero['debug']['pause_for_lag'] = True
        segment = Mock(step=Mock(side_effect=[segment_result(action=moving), zero]))
        with patch.object(routed, 'plan_pair_route', side_effect=direct_route), \
                patch.object(routed, 'RigidPairTransport', return_value=segment):
            controller.step(obs)
            self.assertTrue(np.any(controller.step(obs)['action'][:, :8]))
            result = controller.step(obs)
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
        np.testing.assert_array_equal(result['action'][:, 8], np.ones(2))

    def test_open_gripper_and_total_timeout_failures_latch_across_stage_handoffs(self):
        for mode in ('open0', 'open1', 'timeout', 'backwards_clock'):
            with self.subTest(mode=mode):
                obs = observation(); controller = routed.RoutedPairTransport(obs, [.03, 0, 0])
                if mode.startswith('open'):
                    obs['gripper_close_command'][int(mode[-1])] = False
                elif mode == 'timeout':
                    obs['simulation_time_s'][...] = controller.timeout_s+.1
                else:
                    obs['simulation_time_s'][...] = -.1
                result = controller.step(obs)
                self.assertIsNotNone(result['failure'])
                np.testing.assert_array_equal(result['action'], np.zeros((2, 9)))
                self.assertEqual(controller.step(observation())['failure'], result['failure'])


if __name__ == '__main__':
    unittest.main()
