"""New phases hand off only on fresh frames and preserve governed actions."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
import equilibrium_translation_policy as translation
from test_sleeve_pair_policy import Baseline, observation, tick


class TranslationPolicyTests(unittest.TestCase):
    def actor(self, phase):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = translation.Policy('unused.pt')
        obs = observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.step = 2; actor.phase = phase; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor._cache_scene = Mock(); actor.observe_sleeves = Mock(return_value={})
        return actor, obs

    def test_pitch_completion_needs_new_calibration_and_a_new_trial_frame(self):
        actor, obs = self.actor('pair_observe_pitch')
        hold = np.zeros((2, 9), np.float32); hold[:, 8] = 1.
        actor.loaded_pitch = Mock(step=Mock(return_value=dict(action=hold, done=True,
            failure=None, experiment_completed=True, debug={})))
        with patch.object(translation.Policy, 'CALIBRATION_CLASS') as calibration, \
                patch.object(translation, 'LoadedTranslationTrial') as trial:
            actor(obs)
            self.assertEqual(actor.phase, 'translation_settle')
            calibration.assert_not_called(); trial.assert_not_called()
            measured = {'observed_at_s': 10.05}
            calibration.return_value.step.return_value = dict(action=hold, done=True,
                failure=None, calibration=measured, debug={})
            tick(obs); actor(obs)
            self.assertEqual(actor.phase, 'translation_trial')
            calibration.assert_called_once(); trial.assert_not_called()
            trial.return_value.step.return_value = dict(action=hold, done=True, failure=None, debug={})
            tick(obs); actor(obs)
            self.assertIs(trial.call_args.kwargs['calibration'], measured)
            self.assertEqual(actor.phase, 'translation_trial_complete')
            tick(obs); action = actor(obs)
            trial.assert_called_once()
            np.testing.assert_array_equal(action[:, :8], 0.)

    def test_execution_cannot_silently_change_governor_prediction(self):
        actor, obs = self.actor('translation_trial')
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.; action[:, 3] = .0005
        actor.translation_trial = Mock(step=Mock(return_value=dict(action=action,
            done=False, failure=None, debug={})))
        actor.execution.apply = Mock(return_value=np.zeros((2, 9), np.float32))
        output = actor(obs)
        self.assertEqual(actor.phase, 'stopped')
        self.assertIn('execution modified', actor.failure)
        np.testing.assert_array_equal(output, 0.)


if __name__ == '__main__':
    unittest.main()
