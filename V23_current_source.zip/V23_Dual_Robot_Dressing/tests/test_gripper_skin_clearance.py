"""Own USD geometry/public-pose tests, with no human/cloth truth or simulator."""
from pathlib import Path
import hashlib
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import gripper_skin_clearance as skin


def _matrix_quat(m):
    # Test poses use modest rotations, so the positive-trace branch suffices.
    w = np.sqrt(1+np.trace(m))/2
    return np.array([w, (m[2, 1]-m[1, 2])/(4*w),
                     (m[0, 2]-m[2, 0])/(4*w), (m[1, 0]-m[0, 1])/(4*w)])


def observation(pitch=np.deg2rad(31), roll=0., yaw=0., jaw=.103):
    obs = dict(base_pose_world=np.array([[0., 0., 0., 1., 0., 0., 0.],
                                          [0., 2., 0., 1., 0., 0., 0.]]),
               grasp_pose_base=np.zeros((2, 7)), joint_position=np.zeros((2, 13)),
               fingertip_position_base=np.zeros((2, 2, 3)), simulation_time_s=np.array(10.))
    obs['joint_position'][:, 8:11] = [yaw, pitch, roll]
    obs['joint_position'][:, 11:13] = jaw
    for robot in (0, 1):
        rel = skin._relative_link_poses(obs['joint_position'][robot])
        base_wrist = skin._pose([.3, 0., 1.], [1., 0., 0., 0.])
        grasp = base_wrist @ rel['grasp_center_link']
        obs['grasp_pose_base'][robot] = np.r_[grasp[:3, 3], _matrix_quat(grasp[:3, :3])]
        for i, side in enumerate(('left', 'right')):
            obs['fingertip_position_base'][robot, i] = (base_wrist @ rel['gripper_fingertip_'+side+'_link'])[:3, 3]
    return obs


def evaluate(obs, points, robot=0, **kwargs):
    if 'skin_observed_at' not in kwargs:
        kwargs['skin_observed_at'] = float(obs['simulation_time_s'])
    return skin.observed_gripper_skin_clearance(obs, robot, points, **kwargs)


class GripperSkinClearanceTests(unittest.TestCase):
    def test_pitched_grasp_54mm_above_point_does_not_use_giant_grasp_ball(self):
        obs = observation()
        point = obs['grasp_pose_base'][0, :3]-[0., 0., .054]
        result = evaluate(obs, [point])
        self.assertTrue(result['valid'], result)
        self.assertGreater(result['observed_minimum_clearance_m'], .020)
        self.assertLess(result['observed_minimum_clearance_m'], .054)
        self.assertIn('finger', result['closest_primitive'])
        self.assertFalse(result['fullbody_clearance'])
        self.assertFalse(result['collision_free'])
        self.assertFalse(result['unobserved_skin_clearance_known'])
        self.assertFalse(result['insertion_allowed'])
        self.assertEqual(len(result['model_bounds']), 13)

    def test_point_inside_housing_box_is_potential_obstacle_not_contact_claim(self):
        obs = observation()
        models, _, _ = skin._public_geometry(obs, 0)
        model, t = next(p for p in models if p[0]['link']=='quick_connect_interface_link')
        centre = (np.asarray(model['lower_m'])+model['upper_m'])/2
        point = centre @ t[:3, :3].T+t[:3, 3]
        result = evaluate(obs, [point])
        self.assertTrue(result['valid'])
        self.assertEqual(result['observed_minimum_clearance_m'], 0.)
        self.assertFalse(result['collision_free'])

    def test_independent_upstream_wrist_shells_do_not_rotate_with_distal_roll_or_pitch(self):
        reports = []
        for pitch, roll in ((0., 0.), (.54, 0.), (.54, .36)):
            models, _, _ = skin._public_geometry(observation(pitch=pitch, roll=roll), 0)
            reports.append({m['link']: t for m, t in models})
        for report in reports[1:]:
            np.testing.assert_allclose(report['wrist_link'], reports[0]['wrist_link'], atol=1e-12)
            np.testing.assert_allclose(report['wrist_yaw_link'], reports[0]['wrist_yaw_link'], atol=1e-12)
        np.testing.assert_allclose(reports[1]['wrist_pitch_link'], reports[2]['wrist_pitch_link'], atol=1e-12)
        self.assertGreater(np.linalg.norm(reports[1]['quick_connect_interface_link']-reports[2]['quick_connect_interface_link']), .1)

    def test_jaw_geometry_uses_measured_joint_not_close_intent(self):
        closed, opened = observation(jaw=.103), observation(jaw=.5)
        closed['gripper_close_command'] = opened['gripper_close_command'] = np.ones((2, 1), dtype=bool)
        c, _, _ = skin._public_geometry(closed, 0)
        o, _, _ = skin._public_geometry(opened, 0)
        ct = {m['link']: t for m, t in c}; ot = {m['link']: t for m, t in o}
        np.testing.assert_allclose(ct['quick_connect_interface_link'], ot['quick_connect_interface_link'])
        self.assertGreater(np.linalg.norm(ct['gripper_fingertip_left_link'][:3, 3]-ot['gripper_fingertip_left_link'][:3, 3]), .05)
        self.assertGreater(np.linalg.norm(ct['gripper_fingertip_right_link'][:3, 3]-ot['gripper_fingertip_right_link'][:3, 3]), .05)

    def test_world_base_rotation_and_robot_indices_preserve_distance(self):
        obs = observation(pitch=.48, roll=.2, yaw=-.3)
        point = obs['grasp_pose_base'][0, :3]-[0., 0., .054]
        baseline = evaluate(obs, [point])
        q = np.array([np.cos(.38), np.sin(.38)/np.sqrt(2), 0., np.sin(.38)/np.sqrt(2)])
        translation = np.array([2., -3., .4])
        for robot in (0, 1):
            with self.subTest(robot=robot):
                obs['base_pose_world'][robot] = np.r_[translation, q]
                world = point @ skin._rotation(q).T+translation
                report = evaluate(obs, [world], robot=robot)
                self.assertTrue(report['valid'], report)
                self.assertAlmostEqual(report['observed_minimum_clearance_m'], baseline['observed_minimum_clearance_m'], places=11)

    def test_fingertip_fk_disagreement_rejects_and_small_error_expands_model(self):
        obs = observation()
        point = obs['grasp_pose_base'][0, :3]-[0., 0., .054]
        before = evaluate(obs, [point])
        obs['fingertip_position_base'][0, 0, 0] += .001
        after = evaluate(obs, [point])
        self.assertTrue(after['valid'])
        self.assertAlmostEqual(before['observed_minimum_clearance_m']-after['observed_minimum_clearance_m'], .001, places=10)
        obs['fingertip_position_base'][0, 0, 0] += .003
        bad = evaluate(obs, [point])
        self.assertFalse(bad['valid'])
        self.assertIn('disagree', bad['reason'])

    def test_proposed_translation_is_bounded_sampled_and_never_a_robot_command(self):
        obs = observation()
        point = obs['grasp_pose_base'][0, :3]-[0., 0., .054]
        base = evaluate(obs, [point])
        toward = evaluate(obs, [point], proposed_translation_world=[0., 0., -.005])
        away = evaluate(obs, [point], proposed_translation_world=[0., 0., .005])
        self.assertTrue(toward['valid'])
        self.assertEqual(toward['translation_sample_count'], 6)
        self.assertLess(toward['observed_minimum_clearance_m'], base['observed_minimum_clearance_m']-.002)
        self.assertAlmostEqual(away['observed_minimum_clearance_m'], base['observed_minimum_clearance_m'])
        self.assertFalse(toward['entire_continuous_sweep_checked'])
        self.assertNotIn('action', toward)
        self.assertFalse(evaluate(obs, [point], proposed_translation_world=[0., 0., -.00501])['valid'])

    def test_static_cache_requires_original_timestamp_and_explicit_age_bound(self):
        obs = observation()
        point = obs['grasp_pose_base'][0, :3]-[0., 0., .054]
        self.assertFalse(evaluate(obs, [point], skin_observed_at=9., max_skin_age_s=300.)['valid'])
        self.assertFalse(evaluate(obs, [point], skin_observed_at=9., stationary_skin=True)['valid'])
        report = evaluate(obs, [point], skin_observed_at=9., stationary_skin=True, max_skin_age_s=300.)
        self.assertTrue(report['valid'])
        self.assertEqual(report['skin_observed_at'], 9.)
        self.assertEqual(report['skin_age_s'], 1.)
        self.assertFalse(evaluate(obs, [point], skin_observed_at=-300., stationary_skin=True, max_skin_age_s=300.)['valid'])
        self.assertFalse(evaluate(obs, [point], skin_observed_at=10.1)['valid'])

    def test_missing_invalid_and_out_of_limit_public_state_are_unknown(self):
        for key in ('base_pose_world', 'grasp_pose_base', 'joint_position', 'fingertip_position_base', 'simulation_time_s'):
            obs = observation(); del obs[key]
            self.assertFalse(evaluate(obs, [[0., 0., 0.]], skin_observed_at=10.)['valid'])
        for fault in ('quat', 'joint', 'nan', 'tip_shape'):
            obs = observation()
            if fault=='quat': obs['grasp_pose_base'][0, 3:]=0.
            if fault=='joint': obs['joint_position'][0, 11]=.6
            if fault=='nan': obs['joint_position'][1, 8]=np.nan
            if fault=='tip_shape': obs['fingertip_position_base']=np.zeros((2, 3))
            result=evaluate(obs, [[0., 0., 0.]])
            self.assertFalse(result['valid'], result)
            self.assertIsNone(result['observed_minimum_clearance_m'])
        for points in ([], [[np.nan, 0., 0.]], [1., 2., 3.]):
            self.assertFalse(evaluate(observation(), points)['valid'])

    def test_recorded_public_sample_matches_fingertip_observation(self):
        path=ROOT/'participant/sample_observation.npz'
        if not path.exists(): self.skipTest('Optional public sample not installed')
        obs=dict(np.load(path))
        for robot in (0, 1):
            _, errors, _=skin._public_geometry(obs, robot)
            self.assertLess(max(errors), .00001)

    def test_all_box_bounds_and_zero_fk_agree_with_hashed_own_usd(self):
        try:
            from pxr import Usd, UsdGeom
        except ImportError:
            self.skipTest('Optional CPU USD geometry verification needs pxr')
        path=ROOT/skin.ASSET_RELATIVE_PATH
        if not path.exists(): self.skipTest('Optional own robot asset not installed')
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), skin.ASSET_SHA256)
        stage=Usd.Stage.Open(str(path)); cache=UsdGeom.XformCache()
        self.assertEqual(UsdGeom.GetStageMetersPerUnit(stage), 1.)
        for item in skin._OWN_GEOMETRY_DATA['colliders']:
            prim=stage.GetPrimAtPath(item['source_prim'])
            link=stage.GetPrimAtPath('/stretch/'+item['link'])
            transform=cache.GetLocalToWorldTransform(prim)*cache.GetLocalToWorldTransform(link).GetInverse()
            vertices=np.array([transform.Transform(v) for v in UsdGeom.Mesh(prim).GetPointsAttr().Get()])
            self.assertEqual(len(vertices), item['vertex_count'])
            self.assertTrue(np.all(vertices>=np.asarray(item['lower_m'])-1e-12))
            self.assertTrue(np.all(vertices<=np.asarray(item['upper_m'])+1e-12))
            self.assertTrue(np.all(vertices.min(0)-item['lower_m']<.00000101))
            self.assertTrue(np.all(np.asarray(item['upper_m'])-vertices.max(0)<.00000101))
        anchor=np.asarray(cache.GetLocalToWorldTransform(stage.GetPrimAtPath('/stretch/wrist_link'))).T
        for link, transform in skin._relative_link_poses(np.zeros(13)).items():
            expected=np.asarray(cache.GetLocalToWorldTransform(stage.GetPrimAtPath('/stretch/'+link))).T
            np.testing.assert_allclose(anchor@transform, expected, atol=3e-7)


if __name__ == '__main__':
    unittest.main()
