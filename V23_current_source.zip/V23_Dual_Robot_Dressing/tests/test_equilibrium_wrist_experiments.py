"""Synthetic CPU equilibrium+kinematic tests; not physical motion evidence."""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import equilibrium_wrist_experiments as wrapper
import loaded_roll_observation as roll
import loaded_pitch_observation as pitch
from test_loaded_pitch_observation import observation, update_pose
from test_loaded_roll_observation import hands, visible


BIAS = np.tile([.0026, .001, .0001, -.004, .00008], (2, 1))
OFFSETS = np.tile([.00015, -.0001, .00005, -.0001], (2, 1))


def fixture():
    obs = observation(); obs['simulation_time_s'][...] = 1.
    obs['joint_position'][:, 4:8] += OFFSETS
    obs['controller_target'][:, :5] += BIAS
    obs['joint_velocity'][:, 3] = .0105
    obs['joint_velocity'][:, 9] = -.022
    obs['base_twist_world'] = np.zeros((2, 6))
    c = dict(observed_at_s=1., window_start_s=.5, frame_count=11, method='synthetic supported loaded zero-input window',
        controller_bias=BIAS.tolist(), arm_position_offsets=OFFSETS.tolist(),
        raw_joint_velocity_median=obs['joint_velocity'].tolist(),
        raw_joint_velocity_peak_deviation=np.full((2, 13), .0001).tolist(),
        last_joint_position=obs['joint_position'].tolist(), last_base_pose=obs['base_pose_world'].tolist(),
        controller_target_reference=obs['controller_target'].tolist())
    return obs, c


def integrate(obs, action, c, follow=.5):
    previous = obs['joint_position'].copy()
    obs['controller_target'][:, :5] += action[:, 3:8]*np.array([1.54, 1.21, 5.5, 5.5, 5.5])*.05
    effective = obs['controller_target'][:, :5]-np.asarray(c['controller_bias'])
    q = obs['joint_position']
    q[:, 3] += follow*(effective[:, 0]-q[:, 3])
    q[:, 4:8] += follow*(effective[:, 1, None]/4+np.asarray(c['arm_position_offsets'])-q[:, 4:8])
    q[:, 8:11] += follow*(effective[:, 2:5]-q[:, 8:11])
    obs['joint_velocity'] = np.asarray(c['raw_joint_velocity_median'])+(q-previous)/.05
    update_pose(obs); obs['simulation_time_s'][...] += .05


class EquilibriumWristTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        for module in (roll, pitch, wrapper):
            self.stack.enter_context(patch.object(module, '_cloth_evidence', side_effect=visible))
        self.addCleanup(self.stack.close)

    def construct(self, kind=wrapper.CalibratedLoadedRoll):
        obs, c = fixture()
        ctl = kind(obs, hands(), 0., calibration=c)
        self.assertIsNone(ctl.failure)
        self.assertTrue(ctl.core.eligible, ctl.core._result())
        return obs, c, ctl

    def test_frozen_derived_targets_offsets_and_finite_difference_velocity_no_raw_mutation(self):
        obs, c, ctl = self.construct()
        original = deepcopy(obs); baseline = deepcopy(c)
        r = ctl.step(obs)
        for key, value in original.items(): np.testing.assert_array_equal(obs[key], value)
        np.testing.assert_allclose(ctl.core.targets0[:, :5], obs['controller_target'][:, :5]-BIAS)
        np.testing.assert_allclose(ctl.core.q0[:, 4:8], obs['joint_position'][:, 4:8]-OFFSETS)
        self.assertEqual(c, baseline)
        self.assertTrue(r['debug']['derived_effective_targets_used'])
        np.testing.assert_array_equal(r['debug']['equilibrium_wrapper']['position_difference_velocity'], 0.)
        # Caller mutation must not refresh the owned baseline.
        c['controller_bias'][0][0] = 0.
        np.testing.assert_array_equal(ctl.calibration['controller_bias'], BIAS)

    def test_biased_roll_completes_actual_angles_with_raw_targets_including_bias(self):
        obs, c, ctl = self.construct()
        for _ in range(450):
            r = ctl.step(obs)
            self.assertIsNone(r['failure'], r)
            self.assertIsNone(r['pending_failure'], r)
            if r['done']: break
            integrate(obs, r['action'], c)
        self.assertTrue(r['experiment_completed'], r)
        np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:, 10]), 4.5, atol=.01)
        np.testing.assert_allclose(obs['controller_target'][:, 4], ctl.core.goals+BIAS[:, 4], atol=1e-7)
        self.assertTrue(r['debug']['equilibrium_wrapper']['actual_position_window_stable'])

    def test_contact_pitch_preserves_coupled_compensation_and_original_ten_degree_budget(self):
        obs, c, ctl = self.construct(wrapper.CalibratedLoadedContactPitch)
        for _ in range(950):
            r = ctl.step(obs)
            self.assertIsNone(r['failure'], r)
            self.assertIsNone(r['pending_failure'], r)
            if r['done']: break
            integrate(obs, r['action'], c)
        self.assertTrue(r['experiment_completed'], r)
        np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:, 9]), 31., atol=.02)
        np.testing.assert_allclose(obs['controller_target'][:, 3], ctl.core.goals+BIAS[:, 3], atol=1e-7)
        self.assertLess(np.rad2deg(ctl.absolute_angle).sum(), 20.02)
        self.assertLess(float(obs['simulation_time_s'])-1., 45.)

    def test_cancel_only_removes_new_lead_preserving_baseline_for_both_kernels(self):
        for kind in (wrapper.CalibratedLoadedRoll, wrapper.CalibratedLoadedContactPitch):
            with self.subTest(kind=kind.__name__):
                obs, c, ctl = self.construct(kind)
                for _ in range(80):
                    r = ctl.step(obs); self.assertIsNone(r['failure'], r)
                    integrate(obs, r['action'], c, follow=.25)
                    if np.any(np.abs(r['action'][:, 3:8]) > 0): break
                for _ in range(50):
                    r = ctl.step(obs, stop_for_openings=True)
                    self.assertIsNone(r['failure'], r)
                    if r['done']: break
                    integrate(obs, r['action'], c)
                self.assertTrue(r['early_stopped'], r)
                self.assertFalse(r['experiment_completed'])
                measured = wrapper._CalibratedWrist._coordinates(obs['joint_position'])
                np.testing.assert_allclose(obs['controller_target'][:, :5]-measured, BIAS, atol=1e-5)
                self.assertTrue(r['debug']['equilibrium_wrapper']['actual_position_window_stable'])

    def test_actual_raw_limits_and_predicted_next_target_cannot_be_hidden_by_bias(self):
        obs, c = fixture(); obs['controller_target'][0, 0] = 1.196
        c['controller_target_reference'] = obs['controller_target'].tolist()
        ctl = wrapper.CalibratedLoadedRoll(obs, hands(), 0., calibration=c)
        self.assertIn('raw_controller_target', ctl.step(obs)['failure'])
        obs, c, ctl = self.construct()
        original = ctl.core.step
        def excessive(*args, **kwargs):
            r = original(*args, **kwargs); r['action'][0, 3] = 1.
            return r
        with patch.object(ctl.core, 'step', side_effect=excessive):
            r = ctl.step(obs)
        self.assertIn('raw_controller_target', r['failure'])
        np.testing.assert_array_equal(r['action'][:, :8], 0.)

    def test_single_arm_segment_drift_is_not_recentered(self):
        for kind in (wrapper.CalibratedLoadedRoll, wrapper.CalibratedLoadedContactPitch):
            obs, c, ctl = self.construct(kind); ctl.step(obs)
            obs['simulation_time_s'][...] += .05
            obs['joint_position'][0, 4] += .004; obs['joint_position'][0, 5] -= .004
            r = ctl.step(obs)
            self.assertTrue(r['skipped'] or r['failure'] or r['pending_failure'], r)
            np.testing.assert_array_equal(ctl.calibration['arm_position_offsets'], OFFSETS)
            np.testing.assert_array_equal(r['action'][:, :8], 0.)

    def test_new_raw_velocity_anomaly_aborts_without_discarding_position_checks(self):
        obs, c, ctl = self.construct(); ctl.step(obs)
        obs['simulation_time_s'][...] += .05; obs['joint_velocity'][0, 3] += .02
        r = ctl.step(obs)
        self.assertEqual(ctl.pending_failure, 'new_raw_joint_velocity_anomaly_outside_frozen_window')
        np.testing.assert_array_equal(r['action'][:, :8], 0.)
        for _ in range(6):
            obs['simulation_time_s'][...] += .05; r = ctl.step(obs)
            if r['failure']: break
        self.assertIn('raw_joint_velocity_anomaly', r['failure'])

    def test_first_raw_anomaly_evidence_and_pending_failure_survive_recovery(self):
        for kind in (wrapper.CalibratedLoadedRoll, wrapper.CalibratedLoadedContactPitch):
            with self.subTest(kind=kind.__name__):
                obs, c, ctl = self.construct(kind); ctl.step(obs)
                obs['simulation_time_s'][...] += .05
                obs['joint_velocity'][1, 3] += .05
                trigger_qd = obs['joint_velocity'].copy()
                first = ctl.step(obs)
                self.assertIn('raw_joint_velocity_anomaly', first['pending_failure'])
                evidence = deepcopy(first['debug']['first_raw_velocity_anomaly'])
                self.assertEqual(evidence['observation_time_s'], 1.05)
                self.assertEqual(evidence['offending'][0]['robot'], 1)
                self.assertEqual(evidence['offending'][0]['joint_index'], 3)
                np.testing.assert_array_equal(evidence['raw_joint_velocity'], trigger_qd)
                np.testing.assert_array_equal(evidence['raw_controller_target'], obs['controller_target'])
                self.assertGreater(evidence['offending'][0]['absolute_departure'], evidence['offending'][0]['limit'])
                # Mutation of a returned report cannot alter the owned snapshot.
                first['debug']['first_raw_velocity_anomaly']['raw_joint_velocity'][1][3] = 999.
                obs['joint_velocity'] = np.asarray(c['raw_joint_velocity_median']).copy()
                for _ in range(8):
                    obs['simulation_time_s'][...] += .05
                    result = ctl.step(obs)
                    self.assertEqual(result['debug']['first_raw_velocity_anomaly'], evidence)
                    self.assertIn('raw_joint_velocity_anomaly', result['pending_failure'])
                    np.testing.assert_array_equal(result['action'][:, :8], 0.)
                    if result['failure']: break
                self.assertIn('raw_joint_velocity_anomaly', result['failure'])
                self.assertFalse(result['experiment_completed'])
                self.assertEqual(ctl.step(obs)['debug']['first_raw_velocity_anomaly'], evidence)

    def test_later_guard_failure_does_not_replace_first_raw_anomaly(self):
        obs, c, ctl = self.construct(); ctl.step(obs)
        obs['simulation_time_s'][...] += .05; obs['joint_velocity'][0, 3] += .02
        first = ctl.step(obs)
        obs['simulation_time_s'][...] += .05
        obs['grasp_pose_base'][0, 0] += .004
        later = ctl.step(obs)
        self.assertEqual(later['failure'], first['pending_failure'])
        self.assertIn('3mm', later['debug']['equilibrium_wrapper']['terminal_guard_failure'])
        self.assertEqual(later['debug']['first_raw_velocity_anomaly'], first['debug']['first_raw_velocity_anomaly'])

    def test_repeat_frames_emit_no_action_or_budget_and_stale_calibration_rejected(self):
        obs, c, ctl = self.construct()
        for _ in range(20):
            r = ctl.step(obs)
            if np.any(r['action'][:, :8]): break
            integrate(obs, r['action'], c)
        before = ctl.absolute_angle.copy(); calls = ctl.core.calls
        for _ in range(5):
            repeat = ctl.step(obs)
            np.testing.assert_array_equal(repeat['action'][:, :8], 0.)
        np.testing.assert_array_equal(ctl.absolute_angle, before); self.assertEqual(ctl.core.calls, calls)
        obs, c = fixture(); obs['simulation_time_s'][...] += .1
        self.assertIn('75ms', wrapper.CalibratedLoadedRoll(obs, hands(), 0., calibration=c).step(obs)['failure'])

    def test_clock_gap_or_changed_same_time_is_failure(self):
        for fault in ('gap', 'backwards', 'same_time_changed', 'same_time_qd_changed'):
            obs, c, ctl = self.construct(); ctl.step(obs)
            if fault == 'gap': obs['simulation_time_s'][...] += .1
            if fault == 'backwards': obs['simulation_time_s'][...] -= .01
            if fault == 'same_time_changed': obs['joint_position'][0, 3] += .0001
            if fault == 'same_time_qd_changed': obs['joint_velocity'][0, 3] += .01
            self.assertIsNotNone(ctl.step(obs)['failure'])

    def test_completed_kernel_does_not_bypass_quarter_second_actual_position_window(self):
        obs, c, ctl = self.construct()
        ctl.core.done = True; ctl.core.early_stopped = True
        result = ctl.step(obs)
        self.assertFalse(result['done'])
        for frame in range(5):
            integrate(obs, result['action'], c)
            result = ctl.step(obs)
            self.assertEqual(result['done'], frame == 4)
            np.testing.assert_array_equal(result['action'][:, :8], 0.)
        self.assertTrue(result['debug']['equilibrium_wrapper']['actual_position_window_stable'])

    def test_original_angle_time_and_grasp_budgets_remain_enforced(self):
        for fault in ('angle', 'time', 'grasp'):
            obs, c, ctl = self.construct(); ctl.step(obs)
            obs['simulation_time_s'][...] += .05
            if fault == 'angle': ctl.absolute_angle[0] = ctl.core.PER_WRIST_RAD+.01
            if fault == 'time': ctl.time0 = float(obs['simulation_time_s'])-ctl.core.MAX_SECONDS-.01
            if fault == 'grasp': obs['grasp_pose_base'][0, 0] += .0031
            r = ctl.step(obs)
            self.assertIn('budget', r['failure']); np.testing.assert_array_equal(r['action'][:, :8], 0.)


if __name__ == '__main__':
    unittest.main()
