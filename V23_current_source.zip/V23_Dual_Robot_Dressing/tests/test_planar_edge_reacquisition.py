"""Current local RGB-D remeasurement; these tests do not verify material identity."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import planar_edge_reacquisition as edge
from human_targets import _validated, _world_pixels
from planar_sleeve_edge import estimate_planar_sleeve_edges
from planar_shirt import estimate_planar_shirt


def observation():
    with np.load(ROOT/'participant/sample_observation.npz', allow_pickle=False) as archive:
        obs = {key: archive[key].copy() for key in archive.files}
    initial = estimate_planar_sleeve_edges(obs)
    obs['simulation_time_s'] += .5
    return obs, initial


class PlanarEdgeReacquisitionTests(unittest.TestCase):
    def test_sample_locally_remeasured_exact_targets_and_current_plane(self):
        obs, initial = observation()
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertTrue(result['detected'], result['per_camera_diagnostics'])
        self.assertFalse(result['full_shirt_redetected'])
        self.assertFalse(result['original_geometry_relabelled_as_current'])
        self.assertNotIn('plane', result)
        values = _validated(obs, wrists=True)
        for old, current in zip(initial['candidates'], result['candidates']):
            self.assertEqual(current['target_world'], old['target_world'])
            self.assertEqual(current['target_shift_from_initial_m'], 0.)
            self.assertAlmostEqual(current['actual_lateral_inset_m'], .020, delta=.001)
            self.assertEqual(current['observation_time_s'], float(obs['simulation_time_s']))
            self.assertEqual(current['initial_observation_time_s'], initial['observation_time_s'])
            camera = current['camera_index']; u, v = current['source_pixel_uv']
            world = _world_pixels(values, camera, u, v, obs['depth'][camera, v, u, 0])
            np.testing.assert_allclose(world, current['target_world'], atol=1e-12)
            plane = current['current_local_plane']
            self.assertEqual(plane['observation_time_s'], float(obs['simulation_time_s']))
            uv = np.asarray(plane['support_source_pixels_uv'])
            world = _world_pixels(values, camera, uv[:, 0], uv[:, 1], obs['depth'][camera, uv[:, 1], uv[:, 0], 0])
            np.testing.assert_allclose(world, plane['support_measured_points_world'], atol=1e-12)
            self.assertEqual(plane['support_pixel_count'], len(uv))

    def test_missing_current_collar_and_hem_does_not_require_full_shirt_redetection(self):
        obs, initial = observation()
        color = obs['rgb'].astype(float)
        yellow = ((color[..., 0] > 110) & (color[..., 1] > 90)
                  & (color[..., 2] < .7*np.minimum(color[..., 0], color[..., 1])))
        obs['rgb'][yellow] = 0
        self.assertFalse(estimate_planar_shirt(obs)['detected'])
        with patch('planar_shirt.estimate_planar_shirt', side_effect=AssertionError('full shirt rerun forbidden')):
            result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertTrue(result['detected'], result['per_camera_diagnostics'])

    def test_historical_report_and_inputs_are_preserved_without_restamping(self):
        obs, initial = observation(); saved = deepcopy(initial); before = deepcopy(obs)
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertEqual(result['initial_edge_report'], saved)
        self.assertEqual(initial, saved)
        self.assertNotEqual(result['observation_time_s'], result['initial_edge_report']['observation_time_s'])
        for key in obs:
            np.testing.assert_array_equal(obs[key], before[key])
        self.assertEqual(result['initial_edge_report']['candidates'][0]['boundary_evidence']['observation_time_s'],
                         saved['observation_time_s'])
        result['initial_edge_report']['candidates'][0]['target_world'][0] += 10
        self.assertEqual(initial, saved)

    def test_current_depth_changes_target_and_plane_instead_of_reusing_cached_geometry(self):
        obs, initial = observation()
        rgb = obs['rgb'][4].astype(float)
        blue = (rgb[..., 2] > 100) & (rgb[..., 2] > 1.25*rgb[..., 0]) & (rgb[..., 2] > 1.25*rgb[..., 1])
        obs['depth'][4, ..., 0][blue] += .01
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertTrue(result['detected'], result['per_camera_diagnostics'])
        for old, current in zip(initial['candidates'], result['candidates']):
            self.assertGreater(current['target_shift_from_initial_m'], .005)
            self.assertLessEqual(current['target_shift_from_initial_m'], .03)
            self.assertNotEqual(current['target_world'], old['target_world'])
            camera = current['camera_index']; u, v = current['source_pixel_uv']
            self.assertEqual(current['measured_target_depth_z_m'], obs['depth'][camera, v, u, 0])
        obs['depth'][4, ..., 0][blue] += .1
        self.assertFalse(edge.reacquire_planar_sleeve_edges(obs, initial)['detected'])

    def test_foreground_arm_occlusion_of_local_target_returns_unknown(self):
        obs, initial = observation()
        obs['rgb'][4, 112:134, 153:173] = [50, 50, 50]
        obs['depth'][4, 112:134, 153:173, 0] = .6
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'])
        self.assertEqual(result['candidates'], [])

    def test_foreground_outside_edge_cannot_supply_cloth_boundary(self):
        obs, initial = observation()
        obs['depth'][4, 110:135, 164:174, 0] = .9
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'], result['per_camera_diagnostics'])

    def test_missing_edge_depth_returns_unknown(self):
        obs, initial = observation()
        obs['depth_valid'][4, 110:135, 163:174, 0] = False
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'])

    def test_split_local_boundary_arc_does_not_pick_an_arbitrary_half(self):
        obs, initial = observation()
        obs['depth_valid'][4, 121, 164, 0] = False
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'])
        self.assertTrue(any('ambiguous_current_local_external_edge_arc' in entry.get('reason', '')
                            for entry in result['per_camera_diagnostics']))

    def test_missing_inset_strip_is_never_filled(self):
        obs, initial = observation()
        obs['depth_valid'][4, 121, 163, 0] = False
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        for current in result['candidates']:
            camera = current['camera_index']; boundary = current['boundary_evidence']
            strip = np.asarray(boundary['inset_strip_source_pixels_uv'])
            self.assertTrue(np.all(obs['depth_valid'][camera, strip[:, 1], strip[:, 0], 0]))
            self.assertFalse(current['source_pixel_uv'] == [162, 121] and boundary['source_pixel_uv'] == [164, 121])

    def test_current_two_camera_agreement_or_disagreement_is_checked(self):
        obs, initial = observation()
        obs['base_pose_world'][0] = obs['base_pose_world'][1]
        for key in ('rgb', 'depth', 'depth_valid'):
            obs[key][3] = obs[key][4]
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertTrue(result['detected'])
        self.assertEqual(result['candidates'][0]['agreeing_camera_indices'], [3, 4])
        obs['base_pose_world'][0, 2] += .025
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'current_local_edge_views_disagree_over_2cm')

    def test_initial_geometry_future_or_mixed_timestamps_rejected(self):
        obs, initial = observation()
        altered = deepcopy(initial); altered['observation_time_s'] = float(obs['simulation_time_s'])+1
        self.assertFalse(edge.reacquire_planar_sleeve_edges(obs, altered)['detected'])
        altered = deepcopy(initial); altered['candidates'][0]['boundary_evidence']['observation_time_s'] += .2
        self.assertFalse(edge.reacquire_planar_sleeve_edges(obs, altered)['detected'])
        obs['simulation_time_s'] = np.array(np.nan)
        with self.assertRaises(ValueError):
            edge.reacquire_planar_sleeve_edges(obs, initial)

    def test_prior_spatial_region_cannot_be_arbitrarily_reassigned(self):
        obs, initial = observation()
        initial['candidates'][0]['target_world'][0] += .2
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        self.assertFalse(result['detected'])
        self.assertEqual(result['candidates'], [])

    def test_semantic_and_control_authority_stay_unverified(self):
        obs, initial = observation()
        result = edge.reacquire_planar_sleeve_edges(obs, initial)
        for key in ('cross_time_identity_verified', 'physical_openings_verified', 'insertion_allowed', 'policy_modified'):
            self.assertFalse(result[key])
        self.assertTrue(result['read_only'])
        for current in result['candidates']:
            for key in ('opening_verified', 'cuff_edge_verified', 'grasp_success_verified',
                        'insertion_allowed', 'cross_time_identity_verified', 'target_interpolated'):
                self.assertFalse(current[key])


if __name__ == '__main__':
    unittest.main()
