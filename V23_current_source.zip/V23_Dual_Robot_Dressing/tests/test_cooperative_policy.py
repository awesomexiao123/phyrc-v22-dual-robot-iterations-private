"""CPU action routing and motion guards; no model loading or simulator."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "participant"))
import cooperative_policy as cooperative
from public_vision import grasp_world
from contract_snapshot import load_contract, validate_observation


class BaselineStub:
    def __init__(self, *args, **kwargs):
        self.debug = {}
        self.failure = None
        self.active = 0
        self.parent = SimpleNamespace(stage="carry_hold")

    def __call__(self, obs):
        return np.zeros((2, 9), np.float32)


def observation(active=0):
    obs = dict(base_pose_world=np.array([[-1., 0, 0, 1, 0, 0, 0],
                                         [1., 0, 0, 1, 0, 0, 0]], np.float32),
               grasp_pose_base=np.array([[.6, -.1, 1., 1, 0, 0, 0],
                                         [.6, -.1, 1., 1, 0, 0, 0]], np.float32),
               gripper_close_command=np.zeros((2, 1), bool),
               fingertip_origin_distance=np.full((2, 1), .04, np.float32),
               joint_position=np.zeros((2, 13), np.float32),
               joint_velocity=np.zeros((2, 13), np.float32),
               base_twist_world=np.zeros((2, 6), np.float32),
               controller_target=np.zeros((2, 9), np.float32),
               previous_action=np.zeros((2, 9), np.float32),
               simulation_time_s=np.array(10., np.float64),
               rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.zeros((5, 256, 256, 1), np.float32),
               depth_valid=np.zeros((5, 256, 256, 1), bool))
    obs['fingertip_position_base'] = np.repeat(obs['grasp_pose_base'][:, None, :3], 2, axis=1)
    obs['joint_position'][:, 3] = 1.-.1782204955816269
    obs['joint_position'][:, 4:8] = (.6-.4662579894065857)/4
    obs['fingertip_position_base'][:, 0, 1] += .02
    obs['fingertip_position_base'][:, 1, 1] -= .02
    obs["gripper_close_command"][active] = True
    return obs


def paint_synthetic_hands(obs, camera=3, depth=1.2):
    """Visible face and two hand components; exercises the real RGB-D detector."""
    obs['rgb'][camera, 100:130, 70:90] = [200, 150, 150]
    obs['rgb'][camera, 100:108, 120:130] = [200, 150, 150]
    obs['rgb'][camera, 90:98, 145:155] = [200, 150, 150]
    obs['depth'][camera] = depth
    obs['depth_valid'][camera] = True


def dual_hold_actor(obs):
    obs['gripper_close_command'][:] = True
    policy = actor(obs, phase='dual_hold')
    policy.dual_targets = np.stack([grasp_world(obs, robot) for robot in (0, 1)])
    policy.execution.previous_closed[:] = True
    return policy


def actor(obs, active=0, phase="helper_travel"):
    with patch.object(cooperative, "baseline_class", return_value=BaselineStub):
        policy = cooperative.Policy("not-loaded.pt")
    policy.active, policy.helper = active, 1-active
    policy.active_hold = grasp_world(obs, active)
    policy.phase = phase
    policy.target = grasp_world(obs, 1-active) + [0, 0, .05]
    policy.helper_base_goal = obs["base_pose_world"][1-active, :2] + [.25, .15]
    policy.helper_yaw = 0.
    return policy


class CooperativeSafetyTest(unittest.TestCase):
    def test_depth_cavity_cache_preserves_time_and_cannot_create_verified_opening(self):
        obs = observation()
        policy = actor(obs)
        policy.ENABLE_DEPTH_CAVITY_DIAGNOSTICS = True
        points = np.stack([grasp_world(obs, r) for r in (0, 1)])
        def detect(frame, _):
            return dict(observation_time_s=float(frame['simulation_time_s']),
                depth_cavity_candidates=[{'kind': 'unclassified_depth_cavity'}],
                both_regions_have_depth_supported_opening=True)
        module = SimpleNamespace(detect_depth_cavity_candidates=detect)
        with patch.dict(sys.modules, depth_cavity_candidates=module), \
                patch.object(cooperative, 'diagnose_sleeve_observability',
                    return_value={'both_regions_have_depth_supported_opening': False}):
            first = policy.observe_sleeves(obs, points)
            obs['simulation_time_s'] = np.array(10.8)
            cached = policy.observe_sleeves(obs, points)
            self.assertIs(first['depth_cavity_observations'], cached['depth_cavity_observations'])
            self.assertEqual(cached['depth_cavity_observations']['observation_time_s'], 10.)
            obs['simulation_time_s'] = np.array(11.)
            updated = policy.observe_sleeves(obs, points)
        self.assertEqual(updated['depth_cavity_observations']['observation_time_s'], 11.)
        self.assertEqual(first['depth_cavity_observations']['observation_time_s'], 10.)
        self.assertFalse(updated['both_regions_have_depth_supported_opening'])
        self.assertFalse(updated['depth_cavity_motion_integration'])

    def test_depth_diagnostic_failure_preserves_closed_motion_hold(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='await_sleeve_geometry')
        policy.ENABLE_DEPTH_CAVITY_DIAGNOSTICS = True
        policy.execution.previous_closed[:] = True
        policy.phase_steps = 1
        def broken(*_):
            raise ValueError('invalid diagnostic depth')
        module = SimpleNamespace(detect_depth_cavity_candidates=broken)
        with patch.dict(sys.modules, depth_cavity_candidates=module):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(action[:, :8], 0.)
        np.testing.assert_array_equal(action[:, 8], 1.)
        self.assertFalse(policy.depth_cavity_observation['available'])
        self.assertEqual(policy.depth_cavity_observation['observation_time_s'], 10.)

    def test_fixture_matches_complete_public_contract(self):
        contract = load_contract(cooperative.FROZEN/'policy_interface_snapshot.json')
        validate_observation(observation(), contract, robots=2, joints=13, profile='actor_rgbd')

    def test_helper_travel_routes_both_possible_roles(self):
        for active in (0, 1):
            with self.subTest(active=active):
                obs = observation(active)
                policy = actor(obs, active)
                with patch.object(cooperative, "helper_grasp_target",
                                  return_value={"target_world": policy.target.tolist()}):
                    action = policy(obs)
                self.assertIsNone(policy.failure)
                np.testing.assert_array_equal(action[active], np.zeros(9))
                self.assertGreater(np.linalg.norm(action[1-active, :8]), 0)
                self.assertEqual(action[1-active, 8], -1.)
                self.assertEqual(action.dtype, np.float32)

    def test_close_wait_cannot_leak_previous_smoothed_movement(self):
        obs = observation()
        policy = actor(obs, phase="helper_close")
        policy.previous_action[1, :8] = .08
        action = policy(obs)
        np.testing.assert_array_equal(action[1, :8], np.zeros(8))
        self.assertEqual(action[1, 8], 1.)
        self.assertTrue(policy.execution.pending[1])

    def test_target_loss_stops_helper_immediately(self):
        obs = observation()
        policy = actor(obs, phase="helper_pregrasp")
        policy.target += [.10, .10, .10]
        policy.previous_action[1, :8] = .04
        with patch.object(cooperative, "helper_grasp_target",
                          return_value={"target_world": None, "reason": "occluded"}):
            action = policy(obs)
        np.testing.assert_array_equal(action[1, :8], np.zeros(8))
        self.assertEqual(policy.lost, 1)
        self.assertEqual(action[1, 8], -1.)

    def test_helper_opening_after_dual_grasp_stops_pair(self):
        for phase in ("dual_hold", "dual_position_before_hands", "dual_align_hand_span", "await_sleeve_geometry", "observed_sleeve_approach", "await_sleeve_entry"):
            with self.subTest(phase=phase):
                obs = observation()
                policy = actor(obs, phase=phase)
                policy.visual_dual_grasp_candidate = True
                policy.dual_targets = np.stack([grasp_world(obs, r) for r in range(2)])
                policy.approach_waypoints = policy.dual_targets + [0, 0, .10]
                action = policy(obs)
                self.assertIsNotNone(policy.failure)
                np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_base_separation_failure_remains_stopped(self):
        obs = observation()
        policy = actor(obs)
        obs["base_pose_world"][1, :2] = [-.8, 0]
        first = policy(obs)
        self.assertEqual(policy.phase, "stopped")
        np.testing.assert_array_equal(first, np.zeros((2, 9)))
        obs["base_pose_world"][1, :2] = [1., 0]
        second = policy(obs)
        np.testing.assert_array_equal(second, np.zeros((2, 9)))
        self.assertIsNotNone(policy.failure)

    def test_holder_opening_stops_all_movement(self):
        obs = observation()
        policy = actor(obs)
        obs["gripper_close_command"][0] = False
        policy.previous_action[:, :8] = .08
        action = policy(obs)
        self.assertIsNotNone(policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_lift_requires_fixed_features_even_with_a_tall_nearby_cloth_surface(self):
        for cloth_rise, should_pass in ((0., False), (.04, True)):
            with self.subTest(cloth_rise=cloth_rise):
                obs = observation()
                obs["gripper_close_command"][:] = True
                policy = actor(obs, phase="helper_test_lift")
                policy.grasp_references = np.stack([grasp_world(obs, r) for r in range(2)])
                policy.helper_patch_before_lift = policy.grasp_references[1].copy()
                policy.execution.previous_closed[:] = True
                obs["grasp_pose_base"][1, 2] += .04
                x, z = np.meshgrid(np.linspace(-.01, .01, 5), np.linspace(-.12, .16, 50))
                cloud = policy.helper_patch_before_lift + np.column_stack(
                    (x.ravel(), np.zeros(x.size), z.ravel()))
                tracked = {'reliable': True, 'median_displacement_world': [0, 0, cloth_rise]}
                with patch.object(cooperative, "cloth_cloud", return_value={"world_points": cloud}), \
                        patch.object(policy.patch_tracker, 'update', return_value=tracked):
                    for _ in range(20):
                        policy(obs)
                self.assertIsNone(policy.failure)
                self.assertEqual(policy.visual_dual_grasp_candidate, should_pass)
                self.assertEqual(policy.phase, "dual_hold" if should_pass else "helper_test_lift")

    def test_missing_feature_tracks_stop_instead_of_claiming_dual_grasp(self):
        obs = observation()
        obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='helper_test_lift')
        policy.grasp_references = np.stack([grasp_world(obs, r) for r in range(2)])
        policy.execution.previous_closed[:] = True
        with patch.object(cooperative, 'cloth_cloud', return_value={'world_points': np.empty((0, 3))}):
            for _ in range(40):
                action = policy(obs)
        self.assertEqual(policy.phase, 'stopped')
        self.assertFalse(policy.visual_dual_grasp_candidate)
        self.assertIn('original cloth features', policy.failure)
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_pair_obstacle_stop_cannot_leak_smoothed_base_motion(self):
        obs = observation()
        obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='dual_position_before_hands')
        policy.execution.previous_closed[:] = True
        policy.previous_action[:, :2] = .05
        policy.transport = SimpleNamespace(step=lambda observation: dict(
            action=np.zeros((2, 9), np.float32), done=False, failure=None,
            debug={'navigation_paused_pair': True}))
        action = policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_no_visible_hands_does_not_invent_cached_target(self):
        obs = observation()
        policy = dual_hold_actor(obs)
        policy.step, policy.phase_steps = 19, 59
        action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertFalse(policy.hands.get('detected', False))
        self.assertIsNone(policy.hand_observation_time)
        self.assertIsNone(policy.approach_waypoints)
        self.assertEqual(policy.phase, 'dual_hold')
        np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_occlusion_keeps_measured_hands_without_refreshing_timestamp(self):
        obs = observation()
        paint_synthetic_hands(obs)
        policy = dual_hold_actor(obs)
        policy.step = 19
        policy(obs)
        self.assertIsNone(policy.failure)
        self.assertTrue(policy.hands.get('detected'))
        measured_points = np.array(policy.hands['hand_points_world'])
        measured_time = policy.hand_observation_time
        obs['rgb'][:] = 0
        obs['depth_valid'][:] = False
        obs['simulation_time_s'][...] = 30.
        policy.step = 39
        policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(policy.hands['hand_points_world'], measured_points)
        self.assertEqual(policy.hand_observation_time, measured_time)
        self.assertIsNone(policy.approach_waypoints)

    def test_expired_hand_cache_cannot_start_human_positioning(self):
        for age, should_approach in ((89.9, True), (90.1, False)):
            with self.subTest(cache_age=age):
                obs = observation()
                paint_synthetic_hands(obs)
                policy = dual_hold_actor(obs)
                policy.step = 19
                policy(obs)
                self.assertTrue(policy.hands.get('detected'))
                measured_time = policy.hand_observation_time
                obs['rgb'][:] = 0
                obs['depth_valid'][:] = False
                obs['simulation_time_s'][...] = measured_time + age
                policy.step, policy.phase_steps = 39, 59
                policy(obs)
                self.assertIsNone(policy.failure)
                self.assertEqual(policy.hand_observation_time, measured_time)
                self.assertEqual(policy.phase,
                                 'dual_position_before_hands' if should_approach else 'dual_hold')
                self.assertEqual(policy.approach_waypoints is not None, should_approach)
                if not should_approach:
                    policy.phase_steps = 200
                    action = policy(obs)
                    self.assertEqual(policy.phase, 'stopped')
                    self.assertIn('cannot visually locate', policy.failure)
                    np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_inconsistent_hand_detection_does_not_replace_cache(self):
        obs = observation()
        paint_synthetic_hands(obs)
        policy = dual_hold_actor(obs)
        policy.step = 19
        policy(obs)
        old_points = np.array(policy.hands['hand_points_world'])
        old_time = policy.hand_observation_time
        # Same colored components at a substantially different measured depth
        # must not move a stationary person's cached target or renew its age.
        paint_synthetic_hands(obs, depth=1.6)
        obs['simulation_time_s'][...] += 1.
        policy.step = 39
        policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(policy.hands['hand_points_world'], old_points)
        self.assertEqual(policy.hand_observation_time, old_time)

    def test_transport_completion_aligns_hand_span_without_removing_staging_gap(self):
        for reverse in (False, True):
            with self.subTest(reverse=reverse):
                obs = observation()
                obs['gripper_close_command'][:] = True
                obs['base_pose_world'][:, :3] = [[-1., -.3, 0.], [1., -.3, 0.]]
                obs['base_pose_world'][1, 3:] = [0., 0., 0., 1.]
                obs['grasp_pose_base'][:, :3] = [.7, 0., 1.]
                policy = actor(obs, phase='dual_position_before_hands')
                policy.ALIGN_SLEEVE_SIDE_PAIR = True
                policy.execution.previous_closed[:] = True
                hands = np.array([[-.19, 0., 1.], [.19, 0., 1.]])
                policy.hands = dict(detected=True, hand_points_world=hands[::-1] if reverse else hands)
                policy.hand_observation_time = float(obs['simulation_time_s'])
                policy.transport = SimpleNamespace(step=lambda observation: dict(
                    action=np.zeros((2, 9), np.float32), done=True, failure=None, debug={}))
                policy(obs)
                self.assertIsNone(policy.failure)
                self.assertEqual(policy.phase, 'dual_align_hand_span')
                np.testing.assert_allclose(policy.pair_alignment.goal,
                    [[-.19, -.3, 1.], [.19, -.3, 1.]], atol=1e-6)
                self.assertFalse(policy.pair_alignment.done)
                self.assertFalse(policy.debug['complete_dressing_claimed'])

    def test_distal_staging_preserves_observed_height_and_unknown_direction_falls_back(self):
        for available in (True, False):
            with self.subTest(surface_direction_available=available):
                obs = observation()
                policy = dual_hold_actor(obs)
                policy.USE_DISTAL_SURFACE_STAGING = True
                policy.phase_steps = 59
                policy.hands = dict(detected=True,
                    hand_points_world=[[.41, .5, 1.], [.79, .5, 1.]])
                policy.hand_observation_time = float(obs['simulation_time_s'])-7.
                target = [.6, .5-np.sqrt(.30**2-.15**2), 1.15]
                proposal = dict(available=available, target_grasp_midpoint_world=target,
                    hand_midpoint_world=[.6, .5, 1.], nominal_distal_offset_m=.30,
                    observation_age_s={'hands': 7., 'surfaces': 7.},
                    contains_weak_single_view_evidence=True)
                with patch.object(cooperative, 'plan_distal_staging', return_value=proposal) as planner:
                    policy(obs)
                self.assertIsNone(policy.failure)
                self.assertEqual(policy.phase, 'dual_position_before_hands')
                self.assertEqual(policy.hand_observation_time, float(obs['simulation_time_s'])-7.)
                np.testing.assert_allclose(policy.approach_waypoints.mean(axis=0),
                    target if available else [.6, .2, 1.], atol=1e-6)
                self.assertEqual(policy.staging_plan['selected'], available)
                self.assertTrue(planner.call_args.kwargs['stationary_human'])
                self.assertFalse(policy.debug['complete_dressing_claimed'])

    def test_inferred_three_dimensional_staging_gap_is_not_flattened_for_span_alignment(self):
        obs = observation()
        obs['gripper_close_command'][:] = True
        obs['base_pose_world'][:, :3] = [[-1., -.1, 0.], [1., -.1, 0.]]
        obs['base_pose_world'][1, 3:] = [0., 0., 0., 1.]
        obs['grasp_pose_base'][:, :3] = [.7, 0., 1.+np.sqrt(.3**2-.1**2)]
        policy = actor(obs)
        policy.hands = dict(detected=True, hand_points_world=[[-.19, 0., 1.], [.19, 0., 1.]])
        policy.hand_observation_time = float(obs['simulation_time_s'])
        policy.staging_plan = dict(selected=True)
        policy.begin_hand_span_alignment(obs)
        self.assertIsNone(policy.pair_alignment.failure)
        np.testing.assert_allclose(policy.pair_alignment.goal.mean(axis=0),
            [0., -.1, 1.+np.sqrt(.3**2-.1**2)], atol=1e-6)

    def test_valid_distal_plan_does_not_require_an_unrelated_radial_xy_direction(self):
        for available in (True, False):
            with self.subTest(available=available):
                obs = observation(); policy = dual_hold_actor(obs)
                policy.USE_DISTAL_SURFACE_STAGING = True
                policy.phase_steps = 59
                policy.hands = dict(detected=True,
                    hand_points_world=[[.41, -.1, 1.], [.79, -.1, 1.]])
                policy.hand_observation_time = float(obs['simulation_time_s'])
                target = [.6, -.1-np.sqrt(.3**2-.15**2), 1.15]
                proposal = dict(available=available, target_grasp_midpoint_world=target,
                    hand_midpoint_world=[.6, -.1, 1.], nominal_distal_offset_m=.30)
                with patch.object(cooperative, 'plan_distal_staging', return_value=proposal) as planner:
                    action = policy(obs)
                self.assertEqual(planner.call_count, 1)
                if available:
                    self.assertIsNone(policy.failure)
                    np.testing.assert_allclose(policy.approach_waypoints.mean(axis=0), target, atol=1e-6)
                else:
                    self.assertIn('ambiguous approach', policy.failure)
                    np.testing.assert_array_equal(action, np.zeros((2, 9)))

    def test_span_alignment_requires_recent_hands_and_a_real_staging_gap(self):
        for failure in ('stale', 'gap'):
            with self.subTest(failure=failure):
                obs = observation()
                policy = actor(obs)
                current = np.stack([grasp_world(obs, r) for r in (0, 1)])
                policy.hands = dict(detected=True, hand_points_world=current+[0., .30 if failure == 'stale' else .10, 0.])
                policy.hand_observation_time = float(obs['simulation_time_s'])-(100. if failure == 'stale' else 0.)
                with self.assertRaisesRegex(ValueError, 'recent|staging gap'):
                    policy.begin_hand_span_alignment(obs)

    def test_waiting_for_sleeves_holds_both_without_resuming_old_servo_motion(self):
        obs = observation()
        obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='await_sleeve_geometry')
        policy.execution.previous_closed[:] = True
        policy.previous_action[:, :8] = .05
        policy.approach_waypoints = np.stack([grasp_world(obs, r)+[.02, .02, 0] for r in (0, 1)])
        result = policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(result[:, :8], np.zeros((2, 8)))
        np.testing.assert_array_equal(result[:, 8], np.ones(2))

    def test_opening_approach_preserves_one_instance_and_zero_motion_holds(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='await_sleeve_geometry')
        policy.ENABLE_OBSERVED_OPENING_APPROACH = True
        policy.execution.previous_closed[:] = True
        policy.previous_action[:, :8] = .05
        calls = []
        hold = np.zeros((2, 9), np.float32); hold[:, 8] = 1
        coordinator = SimpleNamespace(started=True)
        def step(observation, report):
            calls.append(report)
            return dict(action=hold.copy(), done=len(calls) >= 2, failure=None,
                        debug={'persistent_calls': len(calls)})
        coordinator.step = step
        module = SimpleNamespace(OpeningApproachCoordinator=lambda **kwargs: coordinator)
        with patch.dict(sys.modules, opening_approach_coordinator=module), \
                patch.object(cooperative, 'diagnose_sleeve_observability', return_value={'current': True}):
            first = policy(obs)
            self.assertEqual(policy.phase, 'observed_sleeve_approach')
            self.assertIs(policy.opening_approach, coordinator)
            second = policy(obs)
        self.assertEqual(calls, [{'current': True}, None])
        self.assertEqual(policy.phase, 'await_sleeve_entry')
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(first, hold)
        np.testing.assert_array_equal(second, hold)
        self.assertFalse(policy.debug['complete_dressing_claimed'])

    def test_observed_approach_failure_stops_pair_and_does_not_reconstruct(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='observed_sleeve_approach')
        policy.execution.previous_closed[:] = True
        policy.opening_approach = SimpleNamespace(step=lambda *_: dict(action=np.ones((2, 9), np.float32),
            done=False, failure='fixed rim identity lost', debug={}))
        result = policy(obs)
        self.assertEqual(policy.phase, 'stopped')
        self.assertIn('fixed rim identity lost', policy.failure)
        np.testing.assert_array_equal(result, 0.)

    def test_observed_approach_target_cancellation_is_forwarded_without_smoothing(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='observed_sleeve_approach')
        policy.execution.previous_closed[:] = True
        policy.previous_action[:, :8] = .04
        cancel = np.zeros((2, 9), np.float32); cancel[:, 8] = 1
        cancel[:, 3] = -.001/1.54
        policy.opening_approach = SimpleNamespace(step=lambda *_: dict(action=cancel,
            done=False, failure=None, pending_failure='lost rim', cancellation_only=True,
            debug={'cancellation_only': True, 'pending_failure': 'lost rim'}))
        action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'observed_sleeve_approach')
        np.testing.assert_array_equal(action, cancel)
        self.assertTrue(policy.opening_approach_debug['cancellation_only'])

    def test_distal_wait_does_not_implicitly_insert(self):
        obs = observation(); obs['gripper_close_command'][:] = True
        policy = actor(obs, phase='await_sleeve_entry')
        policy.execution.previous_closed[:] = True
        policy.previous_action[:] = .04
        result = policy(obs)
        self.assertIsNone(policy.failure)
        np.testing.assert_array_equal(result[:, :8], 0.)
        np.testing.assert_array_equal(result[:, 8], 1.)
        self.assertFalse(policy.debug['complete_dressing_claimed'])


if __name__ == "__main__":
    unittest.main()
