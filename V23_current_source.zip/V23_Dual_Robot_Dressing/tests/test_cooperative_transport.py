"""CPU formation and navigation-coupling tests, not a physics evaluation."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import cooperative_transport as transport


def observation(yaws=(0., np.pi/2)):
    bases = np.array([[-1., 0, 0, 1, 0, 0, 0], [1., 0, 0, 1, 0, 0, 0]], float)
    for robot, yaw in enumerate(yaws):
        bases[robot, 3:] = [np.cos(yaw/2), 0, 0, np.sin(yaw/2)]
    return dict(base_pose_world=bases, grasp_pose_base=np.array([[.5, -.08, 1., 1, 0, 0, 0]]*2, float),
        gripper_close_command=np.ones((2, 1), bool), simulation_time_s=np.array(0.),
        depth=np.zeros((5, 256, 256, 1), np.float32), depth_valid=np.zeros((5, 256, 256, 1), bool))


def free_guard(obs, robot, body_velocity_xy, **kwargs):
    return dict(body_velocity_xy=np.asarray(body_velocity_xy).tolist(), reason='synthetic_free_guard')


def integrate(obs, action, moving=(True, True)):
    for robot in (0, 1):
        if not moving[robot]:
            continue
        rotation = transport._rotation(obs['base_pose_world'][robot, 3:])
        obs['base_pose_world'][robot, :2] += (rotation[:2, :2] @ (action[robot, :2]*.616))*.05
        obs['grasp_pose_base'][robot, 2] += action[robot, 3]*1.54*.05
    obs['simulation_time_s'][...] += .05


class TransportTests(unittest.TestCase):
    def test_yaw_roles_world_motion_and_no_arm_yaw_wrist_actions(self):
        for yaws in ((0., np.pi/2), (np.pi/2, 0.), (-np.pi/2, np.pi)):
            obs = observation(yaws); controller = transport.RigidPairTransport(obs, [.06, .03, .02])
            obs['simulation_time_s'][...] = .05
            with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
                result = controller.step(obs)
            self.assertIsNone(result['failure'])
            velocities = []
            for robot in (0, 1):
                action = result['action'][robot]
                velocities.append(np.r_[transport._rotation(obs['base_pose_world'][robot, 3:])[:2, :2] @ (action[:2]*.616), action[3]*1.54])
                np.testing.assert_array_equal(action[[2, 4, 5, 6, 7]], np.zeros(5))
            np.testing.assert_allclose(velocities[0], velocities[1], atol=1e-8)
            self.assertLessEqual(np.linalg.norm(velocities[0]), .03500001)
            self.assertLessEqual(result['debug']['reference_advance_m'], .00175)

    def test_static_observation_cannot_create_progress_or_finish(self):
        obs = observation(); controller = transport.RigidPairTransport(obs, [.05, 0, 0])
        with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(100): result = controller.step(obs)
        self.assertEqual(controller.reference, 0.)
        self.assertFalse(result['done'])
        np.testing.assert_array_equal(result['debug']['measured_progress_m'], [0., 0.])
        with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(50):
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
        self.assertLessEqual(controller.reference, .01675)
        self.assertTrue(result['debug']['pause_for_lag'])
        self.assertFalse(result['done'])

    def test_one_robot_lag_stops_common_reference_advance(self):
        for delayed in (0, 1):
            obs = observation(); controller = transport.RigidPairTransport(obs, [.10, 0, 0])
            paused = False
            with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
                for _ in range(60):
                    result = controller.step(obs)
                    if result['debug'].get('pause_for_lag'):
                        self.assertEqual(result['debug']['reference_advance_m'], 0.)
                        paused = True; break
                    integrate(obs, result['action'], moving=(delayed != 0, delayed != 1))
            self.assertTrue(paused)
            self.assertFalse(result['done'])

    def test_single_obstacle_stop_stops_both_and_reference(self):
        obs = observation(); controller = transport.RigidPairTransport(obs, [.1, 0, .04])
        obs['simulation_time_s'][...] = .05
        def blocked(o, robot, body, **kwargs):
            return {'body_velocity_xy': [0., 0.] if robot == 1 else np.asarray(body).tolist()}
        with patch.object(transport, 'guard_base_velocity', side_effect=blocked):
            result = controller.step(obs)
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
        self.assertEqual(controller.reference, 0.)
        self.assertTrue(result['debug']['navigation_paused_pair'])

    def test_actual_navigation_sees_other_base_and_stops_pair(self):
        obs = observation((0., 0.)); obs['base_pose_world'][1, 0] = -.39
        controller = transport.RigidPairTransport(obs, [.1, 0, 0])
        obs['simulation_time_s'][...] = .05
        result = controller.step(obs)
        self.assertIsNone(result['failure'])
        self.assertTrue(result['debug']['navigation_paused_pair'])
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))

    def test_measured_pair_transport_completes_once(self):
        obs = observation(); controller = transport.RigidPairTransport(obs, [.045, -.02, .015])
        with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(200):
                result = controller.step(obs)
                self.assertIsNone(result['failure'])
                if result['done']: break
                integrate(obs, result['action'])
        self.assertTrue(result['done'])
        self.assertGreater(min(result['debug']['measured_progress_m']), controller.length-.003)
        np.testing.assert_array_equal(controller.step(obs)['action'], np.zeros((2, 9)))

    def test_closed_relative_error_tilt_and_distance_failures_latch(self):
        for mode in ('closed', 'relative', 'tracking', 'tilt', 'distance'):
            obs = observation(); controller = transport.RigidPairTransport(obs, [.1, 0, 0])
            if mode == 'closed': obs['gripper_close_command'][0] = False
            if mode == 'relative': obs['grasp_pose_base'][0, 2] += .041
            if mode == 'tracking': obs['base_pose_world'][:, 0] += .051
            if mode == 'tilt': obs['base_pose_world'][0, 3:] = [np.cos(.05), np.sin(.05), 0, 0]
            if mode == 'distance': obs['base_pose_world'][1, 0] = -.5
            result = controller.step(obs)
            self.assertIsNotNone(result['failure'])
            np.testing.assert_array_equal(result['action'], np.zeros((2, 9)))
            self.assertEqual(controller.step(observation())['failure'], result['failure'])

    def test_closed_requirement_can_be_explicitly_disabled(self):
        obs = observation(); obs['gripper_close_command'][:] = False
        controller = transport.RigidPairTransport(obs, [.01, 0, 0], require_closed=False)
        with patch.object(transport, 'guard_base_velocity', side_effect=free_guard):
            result = controller.step(obs)
        self.assertIsNone(result['failure'])
        np.testing.assert_array_equal(result['action'][:, 8], [0, 0])


if __name__ == '__main__':
    unittest.main()
