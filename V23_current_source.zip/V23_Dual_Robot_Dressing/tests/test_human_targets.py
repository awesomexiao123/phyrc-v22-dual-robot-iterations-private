"""CPU-only geometry and abstention checks with explicitly synthetic images."""
import importlib.util
import sys
from pathlib import Path
import unittest

import numpy as np

PATH = Path(__file__).resolve().parents[1] / 'participant' / 'human_targets.py'
sys.path.insert(0, str(PATH.parent))
SPEC = importlib.util.spec_from_file_location('v23_human_targets_tested', PATH)
TARGETS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TARGETS)


def observation():
    pose = np.zeros((2, 7), np.float32)
    pose[:, 3] = 1
    return dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
                depth=np.full((5, 256, 256, 1), 1.2, np.float32),
                depth_valid=np.ones((5, 256, 256, 1), bool),
                base_pose_world=pose.copy(), grasp_pose_base=pose.copy())


def hands(obs, camera=3):
    # Face plus two smaller components on one side, matching the frozen detector.
    obs['rgb'][camera, 100:130, 70:90] = [200, 150, 150]
    obs['rgb'][camera, 100:108, 120:130] = [200, 150, 150]
    obs['rgb'][camera, 90:98, 145:155] = [200, 150, 150]


class PublicTargetsTests(unittest.TestCase):
    def test_empty_abstains(self):
        obs = observation()
        self.assertFalse(TARGETS.estimate_hands(obs)['detected'])
        self.assertEqual(TARGETS.garment_edge_candidates(obs)['yellow_trim_candidates'], [])

    def test_real_detector_single_view_and_translation_equivariance(self):
        obs = observation(); hands(obs)
        original = {k: v.copy() for k, v in obs.items()}
        first = TARGETS.estimate_hands(obs)
        self.assertTrue(first['detected'])
        self.assertFalse(first['anatomical_labels'])
        self.assertLess(first['confidence'], .6)
        self.assertEqual(first['camera'], 'robot_0_head')
        self.assertAlmostEqual(np.linalg.norm(first['approach_direction_world']), 1)
        for key in obs:
            np.testing.assert_array_equal(obs[key], original[key])
        delta = np.array([1.0, -.7, .2])
        obs['base_pose_world'][:, :3] += delta
        second = TARGETS.estimate_hands(obs)
        np.testing.assert_allclose(np.asarray(second['hand_points_world']) - first['hand_points_world'],
                                   np.tile(delta, (2, 1)), atol=1e-6)
        self.assertAlmostEqual(first['span_m'], second['span_m'])

    def test_consistent_views_and_inconsistent_views(self):
        obs = observation(); hands(obs, 3); hands(obs, 4)
        good = TARGETS.estimate_hands(obs)
        self.assertTrue(good['detected'])
        self.assertGreater(good['confidence'], .8)
        obs['base_pose_world'][1, 0] = 1
        bad = TARGETS.estimate_hands(obs)
        self.assertFalse(bad['detected'])
        self.assertEqual(bad['reason'], 'cross_view_hand_surfaces_disagree')

    def test_invalid_depth_rejected(self):
        obs = observation(); hands(obs)
        obs['depth_valid'][:] = False
        self.assertFalse(TARGETS.estimate_hands(obs)['detected'])

    def test_yellow_is_candidate_only_and_requires_blue_context(self):
        obs = observation()
        obs['rgb'][3, 100:105, 100:140] = [230, 220, 10]
        self.assertFalse(TARGETS.garment_edge_candidates(obs)['detected'])
        obs['rgb'][3, 105:130, 100:140] = [10, 20, 230]
        result = TARGETS.garment_edge_candidates(obs)
        self.assertTrue(result['detected'])
        self.assertFalse(result['sleeve_opening_verified'])
        candidate = result['yellow_trim_candidates'][0]
        self.assertEqual(candidate['kind'], 'unclassified_trim')
        self.assertFalse(candidate['opening_verified'])
        self.assertGreater(candidate['elongation'], 2)
        self.assertAlmostEqual(np.linalg.norm(candidate['principal_axis_world']), 1)

    def test_overview_is_not_used_for_world_targets(self):
        obs = observation(); hands(obs, 0)
        obs['rgb'][0, 150:155, 100:140] = [230, 220, 10]
        obs['rgb'][0, 155:180, 100:140] = [10, 20, 230]
        self.assertFalse(TARGETS.estimate_hands(obs)['detected'])
        self.assertFalse(TARGETS.garment_edge_candidates(obs)['detected'])


if __name__ == '__main__':
    unittest.main()
