"""Actual motion/governor composition under unequal actuator lag (CPU only)."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import grasp_pair_alignment as alignment
from hypothesis_contact_experiment import HypothesisContactExperiment, ContactPulseAlignment
from test_contact_motion_governor import observation, advance
from test_grasp_pair_alignment import free_guard
from public_vision import grasp_world


class ContactMotionIntegration(unittest.TestCase):
    def test_real_governor_and_pulse_controller_finish_with_unequal_joint_lag(self):
        obs = observation()
        initial = np.stack([grasp_world(obs,r) for r in (0,1)])
        obj = HypothesisContactExperiment(obs, {}, [0,1], {}, 0.)
        obj.phase = 'initial_settle'; obj.pending_stage = 'contact_pulse'
        obj.initial_goal = initial.copy()
        obj.hands = initial+np.array([0.,.02,0.])
        axis = np.array([.236,.831,-.504]); axis /= np.linalg.norm(axis)
        obj.axes = np.array([axis,axis])
        obj.grasp_baseline = initial.copy()
        def track(current, grasps):
            moved = grasps-initial
            obj.tracks = [dict(reliable=True, median_displacement_world=v.tolist()) for v in moved]
            return moved
        with patch.object(obj,'_refresh_skin'), patch.object(obj,'_check_clearance'), \
                patch.object(obj,'_track',side_effect=track), patch.object(obj,'_coverage',return_value=[10,10]), \
                patch.object(alignment,'guard_base_velocity',side_effect=free_guard):
            for _ in range(1600):
                result = obj.step(obs)
                self.assertIsNone(result['failure'], result['debug'])
                self.assertIsNone(obj.pending_failure, result['debug'])
                np.testing.assert_array_equal(result['action'][:,[2,5,6,7]],0.)
                if result['done']: break
                advance(obs,result['action'],follow=(.35,.7))
        self.assertTrue(result['done'], result['debug'])
        self.assertEqual(len(obj.pulse_results),6)
        self.assertAlmostEqual(obj.pulse_travel,.030)
        self.assertAlmostEqual(obj.contact_travel,.010)
        self.assertEqual(obj.governor_debug['mode'],'ready')
        self.assertGreaterEqual(obj.governor_debug['measured_rest_seconds'],.20-1e-8)
        measured = np.stack([grasp_world(obs,r) for r in (0,1)])-initial
        np.testing.assert_allclose(measured,.030*obj.axes,atol=.003)
        self.assertLess(np.max(np.abs(obs['controller_target'][:,:2]-np.column_stack(
            (obs['joint_position'][:,3],obs['joint_position'][:,4:8].sum(1))))),.00005)


if __name__ == '__main__':
    unittest.main()
