"""CPU orchestration checks; mocked perception does not certify contact."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import calibrated_dressing_policy as dressing
import cooperative_policy as cooperative
import sleeve_contact_policy as legacy
from test_sleeve_pair_policy import Baseline, observation, tick


def hold():
    result = np.zeros((2, 9), np.float32); result[:, 8] = 1.
    return result


def result(*, done=False, failure=None, action=None):
    return dict(action=hold() if action is None else action, done=done,
                failure=failure, debug={})


class CalibratedDressingPolicyTests(unittest.TestCase):
    def actor(self, phase):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = dressing.Policy('unused.pt')
        obs = observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.step = 2; actor.phase = phase; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor._cache_scene = Mock(); actor.observe_sleeves = Mock(return_value={})
        actor.hands = {'detected': True, 'observation_time_s': 3.}
        actor.hand_observation_time = 3.
        actor.initial_edge_report = {'original_prior': True}
        actor.pair_candidate_indices = [1, 0]
        return actor, obs

    def test_translation_completion_cannot_run_carry_until_a_fresh_frame(self):
        actor, obs = self.actor('translation_trial')
        actor.translation_trial = Mock(step=Mock(return_value=result(done=True)))
        np.testing.assert_array_equal(actor(obs), hold())
        self.assertEqual(actor.phase, 'dual_hold')
        with patch.object(dressing.TranslationPolicy, '__call__', return_value=hold()) as carry:
            np.testing.assert_array_equal(actor(obs), hold())
            carry.assert_not_called()
            tick(obs); actor(obs)
            carry.assert_called_once()

    def test_legacy_hypothesis_entry_is_intercepted_before_legacy_constructor(self):
        actor, obs = self.actor('hypothesis_contact')
        with patch.object(legacy, 'HypothesisContactExperiment') as old, \
                patch.object(dressing, 'CalibratedHypothesisContactExperiment') as contact:
            actor(obs)
            old.assert_not_called(); contact.assert_not_called()
        self.assertEqual(actor.phase, 'staging_calibrate')
        self.assertIsNone(actor.staging_handoff)

    def test_staging_completion_needs_fresh_frame_and_preserves_one_contact(self):
        actor, obs = self.actor('staging_calibrate')
        stamp = float(obs['simulation_time_s'])
        calibration = dict(observed_at_s=stamp, variant='staging_passive_prior_compatible')
        anchor = np.array([[1., 2., 3.], [2., 3., 4.]])
        handoff = Mock(skin_anchor=anchor, skin_anchor_stamp=stamp-.5,
            step=Mock(return_value=dict(result(done=True), calibration=calibration)))
        actor._create_staging_handoff = Mock(return_value=handoff)
        with patch.object(dressing, 'CalibratedHypothesisContactExperiment') as constructor:
            constructor.return_value.step.return_value = result()
            actor(obs)
            self.assertEqual(actor.phase, 'calibrated_contact')
            constructor.assert_not_called()
            actor(obs)
            constructor.assert_not_called()
            tick(obs); actor(obs)
            constructor.assert_called_once()
            args = constructor.call_args
            self.assertEqual(args.args[4], 3.)
            self.assertEqual(args.kwargs['skin_anchor_observed_at'], stamp-.5)
            np.testing.assert_array_equal(args.kwargs['skin_anchor'], anchor)
            self.assertEqual(args.kwargs['calibration'], calibration)
            child = actor.calibrated_contact
            for _ in range(3):
                tick(obs); actor(obs)
                self.assertIs(actor.calibrated_contact, child)
            constructor.assert_called_once()
            self.assertEqual(child.step.call_count, 4)
            actor._create_staging_handoff.assert_called_once()

    def test_failed_predecessors_cannot_enter_contact(self):
        for phase in ('translation_trial', 'staging_calibrate'):
            with self.subTest(phase=phase):
                actor, obs = self.actor(phase)
                if phase == 'translation_trial':
                    actor.translation_trial = Mock(step=Mock(return_value=result(failure='synthetic stage failure')))
                else:
                    actor._create_staging_handoff = Mock(return_value=Mock(step=Mock(
                        return_value=dict(result(failure='synthetic stage failure'), calibration=None))))
                with patch.object(dressing, 'CalibratedHypothesisContactExperiment') as constructor:
                    output = actor(obs)
                    constructor.assert_not_called()
                self.assertEqual(actor.phase, 'stopped')
                self.assertIn('synthetic stage failure', actor.failure)
                np.testing.assert_array_equal(output, 0.)

    def test_missing_completed_staging_calibration_rejects(self):
        actor, obs = self.actor('calibrated_contact')
        with patch.object(dressing, 'CalibratedHypothesisContactExperiment') as constructor:
            output = actor(obs)
            constructor.assert_not_called()
        self.assertIn('completed_staging_handoff_required', actor.failure)
        np.testing.assert_array_equal(output, 0.)

    def test_staging_requires_current_hands_and_retains_original_hand_timestamp(self):
        actor, obs = self.actor('staging_calibrate')
        actor.translation_calibration = {'observed_at_s': 4.}
        now = float(obs['simulation_time_s'])
        with patch.object(dressing, 'OpeningApproachCoordinator') as observer, \
                patch.object(dressing, 'StagingEquilibriumCalibration') as calibration:
            observer.return_value.fresh_hands = {'detected': True, 'observation_time_s': now-.05}
            with self.assertRaisesRegex(ValueError, 'current_staging_hand_pair_required'):
                actor._create_staging_handoff(obs)
            calibration.assert_not_called()
            observer.return_value.fresh_hands['observation_time_s'] = now
            actor._create_staging_handoff(obs)
            self.assertEqual(observer.call_args.kwargs['original_observed_at'], 3.)
            self.assertEqual(calibration.call_args.args[2], now)
            self.assertIs(calibration.call_args.kwargs['prior_calibration'], actor.translation_calibration)

    def test_execution_cannot_modify_an_already_governed_action(self):
        actor, obs = self.actor('calibrated_contact')
        action = hold(); action[:, 3] = .0002; action[:, 4] = -.0001
        actor.calibrated_contact = Mock(step=Mock(return_value=result(action=action)))
        actor.execution.apply = Mock(return_value=hold())
        output = actor(obs)
        self.assertIn('execution modified calibrated contact motion', actor.failure)
        self.assertEqual(actor.phase, 'stopped')
        np.testing.assert_array_equal(output, 0.)


if __name__ == '__main__':
    unittest.main()
