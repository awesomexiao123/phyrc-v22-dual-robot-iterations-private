"""Public RGBD eligibility and CPU integrated-target tests; no cloth physics."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_roll_observation as roll
from test_grasp_pair_alignment import observation as own_observation


def observation():
    obs = own_observation()
    q = obs['joint_position']
    targets = np.zeros((2, 9))
    targets[:, 0] = q[:, 3]; targets[:, 1] = q[:, 4:8].sum(1)
    targets[:, 2:5] = q[:, 8:11]; targets[:, 5] = .103
    obs['controller_target'] = targets
    obs['rgb'] = np.zeros((5, 256, 256, 3), np.uint8)
    # Actual cloth_cloud sees a supported patch close to each grasp through its
    # own wrist camera. This is synthetic current RGBD, not an attachment label.
    for camera in (1, 2):
        obs['rgb'][camera, 122:134, 122:134] = [8, 14, 220]
        obs['depth'][camera, 122:134, 122:134] = .24
        obs['depth_valid'][camera, 122:134, 122:134] = True
    return obs


def hands():
    return dict(detected=True, hand_points_world=[[-.2, 1.5, 1.], [.2, 1.5, 1.]], observation_time_s=0.)


def integrate(obs, action, *, follow=.5, advance_time=True):
    """Emulate integrated target plus measured position lag; not PhysX."""
    obs['controller_target'][:, 4] += action[:, 7]*5.5*.05
    before = obs['joint_position'][:, 10].copy()
    obs['joint_position'][:, 10] += follow*(obs['controller_target'][:, 4]-before)
    obs['joint_velocity'][:, 10] = (obs['joint_position'][:, 10]-before)/.05
    angles = obs['joint_position'][:, 10]
    obs['grasp_pose_base'][:, 3:] = np.column_stack((np.cos(angles/2), np.sin(angles/2), np.zeros((2, 2))))
    if advance_time:
        obs['simulation_time_s'][...] += .05


def visible(*args):
    return dict(observed_cloth_point_count=100, minimum_observed_cloth_to_hand_point_m=1.,
                minimum_grasp_to_hand_point_m=1., support_by_camera_per_grasp=[{1:50}, {2:50}])


class LoadedRollObservationTests(unittest.TestCase):
    def construct(self, obs=None, **kwargs):
        obs = observation() if obs is None else obs
        return obs, roll.LoadedRollObservation(obs, hands(), 0., stationary_human=True, **kwargs)

    def run_until(self, obs, controller, condition, *, limit=650, follow=.5, stop=False):
        with patch.object(roll, '_cloth_evidence', side_effect=visible):
            for _ in range(limit):
                result = controller.step(obs, stop_for_openings=stop)
                np.testing.assert_array_equal(result['action'][:, :7], 0.)
                np.testing.assert_array_equal(result['action'][:, 8], 1.)
                self.assertTrue(np.all(np.abs(result['action'][:, 7]*5.5) <= roll.LoadedRollObservation.RATE+1e-9))
                if condition(result):
                    return result
                integrate(obs, result['action'], follow=follow)
        self.fail('Bounded state not reached: '+str(result))

    def test_actual_public_rgbd_support_and_point_only_clearance(self):
        obs, controller = self.construct()
        result = controller.step(obs)
        self.assertTrue(result['eligible'], result)
        self.assertEqual(result['debug']['observed_cloth_point_count'], 288)
        self.assertTrue(result['debug']['observed_point_clearance_only'])
        self.assertFalse(result['debug']['full_human_or_wrist_sweep_clearance_verified'])
        self.assertFalse(result['debug']['attachment_verified'])
        self.assertIsNone(result['debug']['opening_visibility_improved'])

    def test_missing_near_cloth_static_assumption_stale_cache_and_near_hand_skip_before_motion(self):
        for fault in ('cloth', 'static', 'age', 'hand_near', 'timestamp', 'roll_limit', 'target_lag', 'invalid_time'):
            with self.subTest(fault=fault):
                obs = observation(); report = hands(); timestamp = 0.
                if fault == 'cloth': obs['depth_valid'][2] = False
                if fault == 'age': obs['simulation_time_s'][...] = 301.
                if fault == 'hand_near': report['hand_points_world'][0] = [-.3, .49, 1.]
                if fault == 'timestamp': report['observation_time_s'] = -.1
                if fault == 'roll_limit':
                    obs['joint_position'][0, 10] = roll.LoadedRollObservation.ROLL_LIMITS[1]-.01
                    obs['controller_target'][0, 4] = obs['joint_position'][0, 10]
                if fault == 'target_lag': obs['controller_target'][1, 4] = np.deg2rad(.2)
                if fault == 'invalid_time': timestamp = None
                controller = roll.LoadedRollObservation(obs, report, timestamp, stationary_human=fault != 'static')
                result = controller.step(obs)
                self.assertTrue(result['done']); self.assertTrue(result['skipped'])
                self.assertFalse(result['motion_started']); self.assertIsNone(result['failure'])
                self.assertFalse(result['experiment_completed'])
                np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_sequential_four_point_five_degrees_with_target_limits_and_half_second_settles(self):
        obs, controller = self.construct()
        active = []; starts = {}; finish_zero = {}
        with patch.object(roll, '_cloth_evidence', side_effect=visible):
            for _ in range(350):
                result = controller.step(obs)
                self.assertIsNone(result['failure'], result)
                action = result['action']; moving = np.flatnonzero(action[:, 7] > 0)
                self.assertLessEqual(len(moving), 1)
                np.testing.assert_array_equal(action[:, :7], 0.)
                for robot in moving:
                    starts.setdefault(int(robot), float(obs['simulation_time_s']))
                    active.append(int(robot))
                if result['debug']['phase'] in ('settle_0', 'settle_1'):
                    finish_zero.setdefault(result['debug']['phase'], float(obs['simulation_time_s']))
                self.assertTrue(np.all(obs['controller_target'][:, 4] <= controller.goals+1e-7))
                self.assertTrue(np.all(obs['controller_target'][:, 4]-obs['joint_position'][:, 10] <= controller.TARGET_LEAD+1e-7))
                if result['done']: break
                integrate(obs, action)
        self.assertTrue(result['done'], result); self.assertTrue(result['experiment_completed'])
        self.assertFalse(result['early_stopped'])
        self.assertEqual(active, sorted(active))
        self.assertGreaterEqual(starts[0], .5-1e-8)
        self.assertGreaterEqual(starts[1]-finish_zero['settle_0'], .5-1e-8)
        np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:, 10]), [4.5,4.5], atol=.01)
        self.assertLess(result['debug']['measured_total_absolute_roll_degrees'], 9.01)
        self.assertFalse(result['debug']['insertion_allowed'])

    def test_stalled_motor_limits_integrated_target_then_cancels_before_failure(self):
        obs, controller = self.construct()
        result = self.run_until(obs, controller, lambda r:r['cancellation_only'] or r['failure'], follow=0.)
        self.assertTrue(result['cancellation_only'], result)
        self.assertIsNone(result['failure']); self.assertIn('timed_out', result['pending_failure'])
        self.assertLessEqual(obs['controller_target'][0, 4], controller.TARGET_LEAD+1e-8)
        self.assertLess(result['action'][0, 7], 0.)
        integrate(obs, result['action'], follow=0.)
        result = self.run_until(obs, controller, lambda r:r['failure'], follow=0.)
        self.assertIn('timed_out', result['failure'])
        self.assertFalse(result['debug']['unresolved_target_lag'])
        self.assertLessEqual(abs(obs['controller_target'][0, 4]), controller.TARGET_TRACK_TOL)

    def test_integrated_target_past_goal_is_cancelled_not_zeroed_and_never_reports_success(self):
        obs, controller = self.construct()
        self.run_until(obs, controller, lambda r:np.any(r['action'][:,7] > 0))
        obs['joint_position'][0,10] = controller.goals[0]-np.deg2rad(.05)
        obs['controller_target'][0,4] = controller.goals[0]+np.deg2rad(.05)
        obs['joint_velocity'][0,10] = 0.
        obs['simulation_time_s'][...] += .05
        with patch.object(roll, '_cloth_evidence', side_effect=visible):
            result=controller.step(obs)
        self.assertTrue(result['cancellation_only']); self.assertIsNone(result['failure'])
        self.assertIn('outside_phase_goal', result['pending_failure'])
        self.assertLess(result['action'][0,7], 0.)
        integrate(obs, result['action'])
        result=self.run_until(obs, controller, lambda r:r['failure'])
        self.assertFalse(result['experiment_completed'])
        self.assertFalse(result['debug']['unresolved_target_lag'])

    def test_unbounded_target_lag_requires_external_stop_and_is_not_reported_as_frozen(self):
        obs, controller = self.construct()
        self.run_until(obs, controller, lambda r:np.any(r['action'][:,7] > 0))
        obs['controller_target'][0,4] = np.deg2rad(6.)
        obs['simulation_time_s'][...] += .05
        result=controller.step(obs)
        self.assertIsNotNone(result['failure'])
        self.assertTrue(result['debug']['unresolved_target_lag'])
        self.assertFalse(result['cancellation_only']); self.assertFalse(result['experiment_completed'])

    def test_absolute_travel_counts_reversals_and_other_robot_drift(self):
        obs, controller = self.construct()
        self.run_until(obs, controller, lambda r:np.any(r['action'][:,7] > 0))
        for robot, degrees in ((0,.05),(0,.02),(0,.04),(1,.03)):
            obs['joint_position'][robot,10] = np.deg2rad(degrees)
            obs['controller_target'][robot,4] = np.deg2rad(degrees)
            # Keep the inactive public target unchanged: its measured drift
            # alone still consumes budget, without authorizing a new target.
            if robot == 1: obs['controller_target'][robot,4] = 0.
            obs['joint_velocity'][:,10] = 0.; obs['simulation_time_s'][...] += .05
            with patch.object(roll, '_cloth_evidence', side_effect=visible): result=controller.step(obs)
            self.assertIsNone(result['failure'], result)
        np.testing.assert_allclose(np.rad2deg(controller.absolute_roll), [.10,.03], atol=1e-8)

    def test_small_reversals_exhaust_measured_budget_despite_small_net_rotation(self):
        obs,controller=self.construct()
        self.run_until(obs,controller,lambda r:np.any(r['action'][:,7]>0))
        with patch.object(roll,'_cloth_evidence',side_effect=visible):
            for index in range(110):
                # A small uncommanded oscillation consumes real travel even
                # though the net displacement always remains below .05 degree.
                angle=np.deg2rad(.05 if index%2==0 else 0.)
                obs['joint_position'][0,10]=obs['controller_target'][0,4]=angle
                obs['joint_velocity'][0,10]=0.; obs['simulation_time_s'][...] += .05
                result=controller.step(obs)
                if result['failure']: break
        self.assertIsNotNone(result['failure'])
        self.assertGreaterEqual(result['debug']['measured_absolute_roll_degrees'][0],4.99)
        self.assertLessEqual(abs(np.rad2deg(obs['joint_position'][0,10])),.051)
        self.assertFalse(result['experiment_completed'])

    def test_both_wrists_moving_before_first_command_spends_budget_and_cannot_skip(self):
        obs,controller=self.construct()
        # The caller has never applied an experiment action. Both public wrists
        # nevertheless changed after construction; these changes cannot become
        # a new zero reference or an innocuous pre-motion eligibility skip.
        obs['joint_position'][:,10]=np.deg2rad(6.)
        obs['controller_target'][:,4]=np.deg2rad(6.)
        obs['simulation_time_s'][...] += .05
        result=controller.step(obs)
        self.assertTrue(result['motion_started']); self.assertFalse(result['skipped'])
        self.assertIsNotNone(result['failure']); self.assertFalse(result['experiment_completed'])
        np.testing.assert_allclose(result['debug']['measured_absolute_roll_degrees'],[6.,6.])
        self.assertAlmostEqual(result['debug']['measured_total_absolute_roll_degrees'],12.)
        self.assertTrue(result['debug']['unresolved_target_lag'])
        np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_cancellation_cannot_run_forever_with_frozen_observation(self):
        obs,controller=self.construct()
        result=self.run_until(obs,controller,lambda r:np.any(r['action'][:,7]>0))
        integrate(obs,result['action'])
        with patch.object(roll,'_cloth_evidence',side_effect=ValueError('cloth_lost')):
            result=controller.step(obs)
            self.assertTrue(result['cancellation_only'])
            for _ in range(45): result=controller.step(obs)
        self.assertIsNotNone(result['failure'])
        self.assertTrue(result['debug']['unresolved_target_lag'])

    def test_drift_and_current_cloth_loss_after_command_cannot_be_skipped(self):
        for fault in ('grasp','base','cloth','joint','nonroll_target','cache'):
            with self.subTest(fault=fault):
                obs, controller = self.construct()
                first=self.run_until(obs, controller, lambda r:np.any(r['action'][:,7]>0))
                integrate(obs, first['action'])
                if fault=='grasp': obs['grasp_pose_base'][0,0] += .0031
                if fault=='base': obs['base_pose_world'][1,1] += .0031
                if fault=='joint': obs['joint_position'][1,9] += np.deg2rad(.25)
                if fault=='nonroll_target': obs['controller_target'][1,0] += .005
                if fault=='cache': controller.observed_at=-301.
                evidence=ValueError('current_cloth_disappeared') if fault=='cloth' else visible
                with patch.object(roll,'_cloth_evidence',side_effect=evidence): result=controller.step(obs)
                self.assertFalse(result['skipped']); self.assertTrue(result['motion_started'])
                self.assertTrue(result['failure'] or result['pending_failure'],result)
                self.assertFalse(result['experiment_completed'])
                if fault=='nonroll_target': self.assertTrue(result['debug']['unresolved_nonroll_target'])

    def test_optional_opening_stop_does_not_claim_detection_or_reverse_experiment(self):
        for start in (False,True):
            with self.subTest(after_motion=start):
                obs,controller=self.construct()
                if start:
                    result=self.run_until(obs,controller,lambda r:np.any(r['action'][:,7]>0))
                    integrate(obs,result['action'])
                result=self.run_until(obs,controller,lambda r:r['done'] or r['failure'],stop=True)
                self.assertIsNone(result['failure'],result)
                self.assertTrue(result['early_stopped']); self.assertFalse(result['experiment_completed'])
                self.assertIn('did not verify',result['debug']['early_stop_basis'])
                self.assertLess(result['debug']['measured_total_absolute_roll_degrees'],.2)

    def test_frozen_clock_does_not_move_and_is_bounded(self):
        obs,controller=self.construct()
        with patch.object(roll,'_cloth_evidence',side_effect=visible):
            for _ in range(602):
                result=controller.step(obs)
                np.testing.assert_array_equal(result['action'][:,:8],0.)
        self.assertTrue(result['done']); self.assertTrue(result['skipped'])
        self.assertIn('timed_out',result['debug']['ineligible_reason'])


if __name__ == '__main__':
    unittest.main()
