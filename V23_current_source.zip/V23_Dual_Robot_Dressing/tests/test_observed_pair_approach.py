"""CPU observation/control tests; synthetic cloth response is not physics proof."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import observed_pair_approach as approach
from public_vision import grasp_world, _rotation
from opening_rim_tracker import OpeningRimTracker
from test_grasp_pair_alignment import observation as own_observation, free_guard
from test_sleeve_probe import scene


def observation():
    obs = own_observation()
    obs['base_twist_world'] = np.zeros((2, 6))
    sync_targets(obs)
    return obs


def sync_targets(obs):
    q = obs['joint_position']; targets = np.zeros((2, 9))
    targets[:, 0] = q[:, 3]; targets[:, 1] = q[:, 4:8].sum(1)
    targets[:, 2:5] = q[:, 8:11]; targets[:, 5] = .103
    obs['controller_target'] = targets


def tracked_reports(sleeves):
    """Detector geometry wrapped in the separately tested tracker's contract.

    This helper does not test optical-flow identity; opening_rim_tracker's tests
    cover that. These tests exercise its consumer's RGBD provenance validation.
    """
    reports = []
    for row in sleeves['grasp_regions']:
        candidate = copy.deepcopy(row['depth_supported_opening_candidates'][0])
        candidate.update(current_rim_depth_valid_fraction=1., current_rim_depth_sample_count=40)
        reports.append(dict(reliable=True, kind='tracked_unclassified_rim', features_reseeded=False,
            tracked_count=12, median_displacement_world=[0., 0., 0.], rim_geometry=candidate,
            identity=dict(initial_camera_index=candidate['camera_index'],
                initial_source_camera=candidate['source_camera'], initial_observation_time_s=1.,
                initial_contour_pixels_uv=candidate['inner_aperture']['contour_pixels_uv'],
                initial_background_depth_supported=True, identity_basis='synthetic fixed cohort')))
    return reports


class RespondingScene:
    """Analytic tracked geometry for motor feedback tests, not an image detector."""
    def __init__(self, obs, gap=.030, direction=(0., 1., 0.), gains=(1., 1.)):
        self.initial_grasps = np.stack([grasp_world(obs, r) for r in (0, 1)])
        self.axis = np.asarray(direction, float); self.axis /= np.linalg.norm(self.axis)
        self.gap = np.broadcast_to(gap, (2,)).astype(float)
        self.gains = np.asarray(gains, float)
        self.rim0 = self.initial_grasps+.03*self.axis
        self.hands = self.rim0+self.gap[:, None]*self.axis
        self.identities = [dict(synthetic_fixed_feature_cohort=r) for r in (0, 1)]
        self.missing = False
        self.feature_gains = self.gains.copy()

    def measure(self, obs, *unused):
        if self.missing:
            raise ValueError('synthetic_missing_current_rim')
        grasps = np.stack([grasp_world(obs, r) for r in (0, 1)])
        shift = (grasps-self.initial_grasps)*self.gains[:, None]
        centers = self.rim0+shift
        return dict(centers=centers, normals=np.tile(self.axis, (2, 1)),
            identities=copy.deepcopy(self.identities),
            feature_displacements=(grasps-self.initial_grasps)*self.feature_gains[:, None],
            axes=np.tile(self.axis, (2, 1)), hands=self.hands.copy(),
            gaps=np.sum((self.hands-centers)*self.axis, axis=1), margins=np.full(2, .025),
            assignment=[0, 1], cameras=[3, 4], observation_time_s=float(obs['simulation_time_s']),
            weak_axes=False)


def integrate(obs, action, moving=(True, True), *, lift_follow=1.):
    """Public target integration plus actual measured lift response and twist."""
    obs['joint_velocity'][:] = 0.; obs['base_twist_world'][:] = 0.
    obs['controller_target'][:, 0] += action[:, 3]*1.54*.05
    obs['controller_target'][:, 6] = action[:, 0]*.616
    obs['controller_target'][:, 7] = -action[:, 1]*.616
    obs['controller_target'][:, 8] = action[:, 2]*1.54
    for robot in (0, 1):
        if not moving[robot]:
            continue
        rotation = _rotation(obs['base_pose_world'][robot, 3:])
        yaw = np.arctan2(rotation[1, 0], rotation[0, 0])
        planar = np.array([[np.cos(yaw), -np.sin(yaw)], [np.sin(yaw), np.cos(yaw)]])
        velocity = planar @ (action[robot, :2]*.616)
        obs['base_pose_world'][robot, :2] += velocity*.05
        obs['base_twist_world'][robot, :2] = velocity
        delta = lift_follow*(obs['controller_target'][robot, 0]-obs['joint_position'][robot, 3])
        obs['grasp_pose_base'][robot, 2] += delta
        obs['joint_position'][robot, 3] += delta
        obs['joint_velocity'][robot, 3] = delta/.05
    obs['simulation_time_s'][...] += .05


class GeometryContractTests(unittest.TestCase):
    def test_actual_tracker_reports_are_accepted_by_rgbd_consumer(self):
        obs, _, sleeves, hands, surfaces, _ = scene(hand_depth=1.04)
        cloth = obs['rgb'][3, :, :, 2] > 100
        texture = cv2.resize(np.random.default_rng(29).integers(120, 250, (128, 128), dtype=np.uint8),
                             (256, 256), interpolation=cv2.INTER_NEAREST)
        obs['rgb'][3, :, :, 2][cloth] = texture[cloth]
        trackers = [OpeningRimTracker(), OpeningRimTracker()]
        for tracker, row in zip(trackers, sleeves['grasp_regions']):
            initial = tracker.reset(obs, row['depth_supported_opening_candidates'][0])
            self.assertTrue(initial['reliable'], initial['reason'])
        obs['simulation_time_s'] = hands['observation_time_s'] = surfaces['observation_time_s'] = 1.05
        reports = [tracker.update(obs) for tracker in trackers]
        self.assertTrue(all(r['reliable'] for r in reports))
        geometry = approach._measure_geometry(obs, reports, hands, surfaces)
        np.testing.assert_allclose(geometry['gaps'], .04, atol=1e-7)

    def test_real_rgbd_footprints_bind_two_tracked_rims_to_hands(self):
        for reverse in (False, True):
            with self.subTest(reverse=reverse):
                obs, _, sleeves, hands, surfaces, axis = scene(hand_depth=1.04, reverse_grasps=reverse)
                reports = tracked_reports(sleeves)
                geometry = approach._measure_geometry(obs, reports, hands, surfaces)
                self.assertEqual(geometry['assignment'], [1, 0] if reverse else [0, 1])
                np.testing.assert_allclose(geometry['gaps'], .04, atol=2e-7)
                np.testing.assert_allclose(geometry['axes'], np.tile(axis, (2, 1)))
                self.assertTrue(geometry['weak_axes'])
                self.assertTrue(np.all(geometry['margins'] >= .01))

    def test_stale_reseeded_unbound_duplicate_and_nonfinite_rims_reject(self):
        for fault in ('stale_hand', 'stale_rim', 'reseed', 'camera', 'duplicate', 'depth_nan', 'few_features'):
            with self.subTest(fault=fault):
                obs, _, sleeves, hands, surfaces, _ = scene(hand_depth=1.04)
                reports = tracked_reports(sleeves)
                if fault == 'stale_hand': hands['observation_time_s'] = .9
                if fault == 'stale_rim': reports[0]['rim_geometry']['observation_time_s'] = .9
                if fault == 'reseed': reports[0]['features_reseeded'] = True
                if fault == 'camera': reports[0]['identity']['initial_camera_index'] = 2
                if fault == 'duplicate': reports[1] = copy.deepcopy(reports[0])
                if fault == 'depth_nan': reports[0]['rim_geometry']['current_rim_depth_valid_fraction'] = np.nan
                if fault == 'few_features': reports[0]['tracked_count'] = 7
                with self.assertRaises(ValueError):
                    approach._measure_geometry(obs, reports, hands, surfaces)

    def test_missing_hand_depth_or_signed_axis_does_not_allow_motion_geometry(self):
        for fault in ('depth', 'axis'):
            with self.subTest(fault=fault):
                obs, _, sleeves, hands, surfaces, _ = scene(hand_depth=1.04)
                reports = tracked_reports(sleeves)
                if fault == 'depth': obs['depth_valid'][4] = False
                if fault == 'axis': surfaces['hand_surfaces'][0]['axis_sign'] = 'unknown'
                with self.assertRaises(ValueError):
                    approach._measure_geometry(obs, reports, hands, surfaces)


class ObservedPairApproachTests(unittest.TestCase):
    def run_until(self, obs, controller, scene, predicate, limit=300, guard=free_guard, moving=(True, True), lift_follow=1.):
        with patch.object(approach, '_measure_geometry', side_effect=scene.measure), \
                patch.object(approach, 'guard_base_velocity', side_effect=guard):
            for _ in range(limit):
                result = controller.step(obs, [], {}, {})
                action = result['action']
                np.testing.assert_array_equal(action[:, [2, 4, 5, 6, 7]], 0.)
                np.testing.assert_array_equal(action[:, 8], 1.)
                velocities = np.asarray(result['debug'].get('command_world_velocities', np.zeros((2, 3))))
                self.assertLessEqual(np.linalg.norm(velocities, axis=1).max(), .003000001)
                if predicate(result):
                    return result
                integrate(obs, action, moving=moving, lift_follow=lift_follow)
        self.fail('bounded test loop did not reach expected state: '+str(result))

    def test_multiple_pulses_feedback_reobserve_and_stop_distal_without_traversal(self):
        obs = observation(); initial = obs['base_pose_world'].copy()
        scene = RespondingScene(obs, direction=(.3, .8, -.25))
        controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r: r['done'] or r['failure'])
        self.assertIsNone(result['failure'], result)
        self.assertTrue(result['done'])
        self.assertEqual(controller.verified_pulses, 3)
        self.assertAlmostEqual(controller.requested_path, .01, delta=.0002)
        self.assertLessEqual(max(result['debug']['distal_gaps_m']), .0205)
        self.assertGreaterEqual(min(result['debug']['distal_gaps_m']), .019)
        self.assertFalse(result['debug']['insertion_allowed'])
        self.assertFalse(result['debug']['traversal_performed'])
        self.assertEqual(result['debug']['phase'], 'distal_wait')
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        np.testing.assert_array_equal(obs['base_pose_world'][:, 3:], initial[:, 3:])
        # Opposed yaws need opposing body forward commands for one world shift.
        world_delta = obs['base_pose_world'][:, :2]-initial[:, :2]
        np.testing.assert_allclose(world_delta[0], world_delta[1], atol=1e-9)

    def test_tilted_lift_compensation_keeps_measured_world_pulse_aligned(self):
        obs = observation()
        for r, yaw in enumerate((0., np.pi)):
            tilt = .05
            obs['base_pose_world'][r, 3:] = [np.cos(yaw/2)*np.cos(tilt/2),
                -np.sin(yaw/2)*np.sin(tilt/2), np.cos(yaw/2)*np.sin(tilt/2),
                np.sin(yaw/2)*np.cos(tilt/2)]
        scene = RespondingScene(obs, gap=.025, direction=(0., 0., 1.))
        initial = scene.initial_grasps.copy(); controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r: r['done'] or r['failure'])
        self.assertIsNone(result['failure'], result)
        self.assertTrue(result['done'])
        measured = np.stack([grasp_world(obs, r) for r in (0, 1)])
        np.testing.assert_allclose(measured[:, :2], initial[:, :2], atol=1e-8)
        np.testing.assert_allclose(measured[:, 2]-initial[:, 2], .005, atol=.00075)

    def test_long_valid_29cm_gap_approach_includes_every_settle_and_persistent_budget(self):
        obs = observation(); scene = RespondingScene(obs, gap=.29)
        controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r: r['done'] or r['failure'], limit=3600)
        self.assertIsNone(result['failure'], result)
        self.assertTrue(result['done'])
        self.assertGreaterEqual(controller.verified_pulses, 67)
        self.assertLessEqual(controller.verified_pulses, 69)
        self.assertGreater(float(obs['simulation_time_s']), 120.)
        self.assertLess(float(obs['simulation_time_s']), 180.)
        self.assertGreater(controller.requested_path, .268)
        self.assertLessEqual(controller.requested_path, .271)
        self.assertTrue(np.all(controller.endpoint_path < .30))
        self.assertTrue(np.all(controller.base_path < .30))
        self.assertFalse(result['debug']['insertion_allowed'])

    def test_one_robot_guard_stop_holds_both_and_times_out_no_false_response(self):
        obs = observation(); scene = RespondingScene(obs); controller = approach.ObservedPairApproach(obs)
        def guard(obs, robot, body, **kw):
            return dict(body_velocity_xy=(np.asarray(body)*(robot == 0)).tolist(), reason='one blocked')
        initial = obs['base_pose_world'].copy()
        result = self.run_until(obs, controller, scene, lambda r: r['failure'], guard=guard)
        self.assertIn('timed_out', result['failure'])
        self.assertEqual(controller.verified_pulses, 0)
        self.assertEqual(controller.pulse['reference'], 0.)
        np.testing.assert_array_equal(obs['base_pose_world'], initial)
        np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_missing_geometry_immediate_hold_then_latched_failure(self):
        obs = observation(); scene = RespondingScene(obs); controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r: np.any(r['action'][:, :8]))
        integrate(obs, result['action']); scene.missing = True
        with patch.object(approach, '_measure_geometry', side_effect=scene.measure):
            result = controller.step(obs, [], {}, {})
        self.assertIsNone(result['failure'])
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        np.testing.assert_array_equal(result['debug']['command_world_velocities'], np.zeros((2, 3)))
        result = self.run_until(obs, controller, scene, lambda r: r['failure'])
        self.assertIn('reacquisition_timed_out', result['failure'])
        scene.missing = False
        self.assertEqual(controller.step(obs, [], {}, {})['failure'], result['failure'])

    def test_settle_requires_fresh_contiguous_reobservation_after_occlusion(self):
        obs = observation(); scene = RespondingScene(obs); controller = approach.ObservedPairApproach(obs)
        self.run_until(obs, controller, scene, lambda r: r['debug']['phase'] == 'settle')
        scene.missing = True
        with patch.object(approach, '_measure_geometry', side_effect=scene.measure):
            for _ in range(8):
                integrate(obs, controller._hold()); controller.step(obs, [], {}, {})
            scene.missing = False
            integrate(obs, controller._hold()); result = controller.step(obs, [], {}, {})
            self.assertEqual(controller.verified_pulses, 0)
            self.assertEqual(result['debug']['phase'], 'settle')
            for _ in range(4):
                integrate(obs, controller._hold()); controller.step(obs, [], {}, {})
            self.assertEqual(controller.verified_pulses, 0)
            integrate(obs, controller._hold()); result = controller.step(obs, [], {}, {})
        self.assertEqual(controller.verified_pulses, 1, result)

    def test_each_rim_must_respond_not_only_grasps_or_other_robot(self):
        for slow_rim in (0, 1):
            with self.subTest(slow_rim=slow_rim):
                obs = observation(); gains = [1., 1.]; gains[slow_rim] = 0.
                scene = RespondingScene(obs, gains=gains); controller = approach.ObservedPairApproach(obs)
                result = self.run_until(obs, controller, scene, lambda r: r['failure'])
                self.assertIn('both_rims_did_not_follow', result['failure'])
                self.assertEqual(controller.verified_pulses, 0)
                self.assertFalse(result['debug']['response']['accepted'])

    def test_feature_identity_response_disagreement_and_reseed_fail(self):
        for fault in ('feature_motion', 'identity'):
            with self.subTest(fault=fault):
                obs = observation(); scene = RespondingScene(obs); controller = approach.ObservedPairApproach(obs)
                self.run_until(obs, controller, scene, lambda r: r['debug']['phase'] == 'pulse')
                if fault == 'feature_motion': scene.feature_gains[1] = -1.
                else: scene.identities[1] = dict(synthetic_fixed_feature_cohort=99)
                result = self.run_until(obs, controller, scene, lambda r: r['failure'])
                self.assertIn('both_rims' if fault == 'feature_motion' else 'identity_changed', result['failure'])

    def test_gap_mismatch_lift_limit_and_arm_posture_require_regrasp(self):
        for fault in ('gap', 'lift', 'arm'):
            with self.subTest(fault=fault):
                obs = observation()
                if fault == 'lift':
                    obs['joint_position'][:, 3] = 1.193; sync_targets(obs)
                scene = RespondingScene(obs, gap=(.03, .04) if fault == 'gap' else .03,
                                        direction=(0., 0., 1.))
                controller = approach.ObservedPairApproach(obs)
                if fault == 'arm': obs['joint_position'][0, 4] += .004
                result = self.run_until(obs, controller, scene, lambda r: r['failure'])
                self.assertIn({'gap': 'differential_motion', 'lift': 'lift_workspace', 'arm': 'posture_change'}[fault], result['failure'])
                np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_persistent_budget_does_not_reset_after_response(self):
        obs = observation(); scene = RespondingScene(obs, gap=.05); controller = approach.ObservedPairApproach(obs)
        controller.MAX_TRAVEL_M = .0085  # Two pulses + feedback tolerance; no third pulse.
        result = self.run_until(obs, controller, scene, lambda r: r['failure'])
        self.assertIn('persistent_approach_travel_budget', result['failure'])
        self.assertEqual(controller.verified_pulses, 2)
        self.assertAlmostEqual(controller.requested_path, .008)
        self.assertTrue(np.all(controller.endpoint_path > .007))

    def test_unequal_distal_gaps_never_request_entry_and_high_lift_can_descend(self):
        for gaps, fails in (((.015, .020), True), ((.0161, .020), False)):
            with self.subTest(gaps=gaps):
                obs = observation(); scene = RespondingScene(obs, gap=gaps)
                controller = approach.ObservedPairApproach(obs)
                result = self.run_until(obs, controller, scene, lambda r: r['done'] or r['failure'])
                self.assertEqual(bool(result['failure']), fails)
                self.assertFalse(result['debug']['insertion_allowed'])
                np.testing.assert_array_equal(result['action'][:, :8], 0.)
        obs = observation(); obs['joint_position'][:, 3] = 1.189; sync_targets(obs)
        scene = RespondingScene(obs, gap=.024, direction=(0., 0., -1.))
        controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r: r['done'] or r['failure'])
        self.assertIsNone(result['failure'], result)
        self.assertTrue(result['done'])
        self.assertTrue(np.all(obs['joint_position'][:, 3] < 1.186))

    def test_uncommanded_pair_span_and_yaw_drift_fail_before_next_motion(self):
        for fault in ('span', 'yaw'):
            with self.subTest(fault=fault):
                obs = observation(); scene = RespondingScene(obs); controller = approach.ObservedPairApproach(obs)
                if fault == 'span': obs['base_pose_world'][0, 1] += .006
                else: obs['base_pose_world'][0, 3:] = [np.cos(.03/2), 0., 0., np.sin(.03/2)]
                with patch.object(approach, '_measure_geometry', side_effect=scene.measure):
                    result = controller.step(obs, [], {}, {})
                self.assertIn('relative_grasp' if fault == 'span' else 'yaw_drift', result['failure'])
                np.testing.assert_array_equal(result['action'][:, :8], 0.)

    def test_initial_integrated_lift_target_is_cancelled_before_new_pulse(self):
        obs = observation(); obs['controller_target'][:, 0] += .0002
        scene = RespondingScene(obs, gap=.024, direction=(0.,0.,1.))
        controller = approach.ObservedPairApproach(obs)
        with patch.object(approach, '_measure_geometry', side_effect=scene.measure):
            integrate(obs, controller._hold(), lift_follow=0.)
            result = controller.step(obs, [], {}, {})
        self.assertTrue(result['cancellation_only']); self.assertIsNone(result['failure'])
        self.assertTrue(np.all(result['action'][:, 3] < 0.))
        self.assertIsNone(controller.pulse); self.assertEqual(controller.requested_path, 0.)
        integrate(obs, result['action'], lift_follow=.3)
        result = self.run_until(obs, controller, scene, lambda r:r['done'] or r['failure'], lift_follow=.3)
        self.assertIsNone(result['failure'], result); self.assertTrue(result['done'])
        self.assertTrue(np.all(controller.endpoint_path > 0.))
        self.assertFalse(result['debug']['insertion_allowed'])

    def test_lagged_vertical_pulses_finish_only_after_measured_target_settling(self):
        obs = observation(); scene = RespondingScene(obs, direction=(.2,.1,1.))
        controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r:r['done'] or r['failure'], lift_follow=.3)
        self.assertIsNone(result['failure'], result); self.assertTrue(result['done'])
        self.assertTrue(result['debug']['measured_drive_settled'])
        self.assertGreaterEqual(controller.verified_pulses, 3)
        self.assertTrue(np.all(np.abs(obs['controller_target'][:,0]-obs['joint_position'][:,3]) <= controller.SETTLED_LIFT_LAG_M))
        self.assertGreaterEqual(min(result['debug']['distal_gaps_m']), .019)

    def test_geometry_loss_cancels_lift_lead_without_new_base_motion_then_holds(self):
        obs = observation(); scene = RespondingScene(obs, direction=(0.,0.,1.))
        controller = approach.ObservedPairApproach(obs)
        result = self.run_until(obs, controller, scene, lambda r:np.any(r['action'][:,3]), lift_follow=.3)
        integrate(obs, result['action'], lift_follow=.3)
        old_request=controller.requested_path; old_identity=copy.deepcopy(controller.identities)
        scene.missing=True
        with patch.object(approach, '_measure_geometry', side_effect=scene.measure): result=controller.step(obs,[],{},{})
        self.assertTrue(result['cancellation_only']); self.assertIsNone(result['pending_failure'])
        self.assertIsNone(result['failure']); self.assertTrue(np.all(result['action'][:,3]<0.))
        np.testing.assert_array_equal(result['action'][:,:3],0.)
        self.assertTrue(np.all(np.abs(result['action'][:,3]*1.54)<=.003000001))
        integrate(obs,result['action'],lift_follow=.3)
        result=self.run_until(obs,controller,scene,lambda r:bool(r['failure']),lift_follow=.3)
        self.assertIn('reacquisition_timed_out',result['failure'])
        self.assertFalse(result['debug']['unresolved_target_lag'])
        self.assertEqual(controller.requested_path,old_request); self.assertEqual(controller.identities,old_identity)
        self.assertEqual(controller.verified_pulses,0)

    def test_abort_with_pending_lift_returns_cancellation_action_before_latched_failure(self):
        obs=observation(); scene=RespondingScene(obs,direction=(0.,0.,1.)); controller=approach.ObservedPairApproach(obs)
        result=self.run_until(obs,controller,scene,lambda r:np.any(r['action'][:,3]))
        integrate(obs,result['action'],lift_follow=.3)
        scene.identities[0]={'different_rim':True}
        with patch.object(approach,'_measure_geometry',side_effect=scene.measure): result=controller.step(obs,[],{},{})
        self.assertTrue(result['cancellation_only']); self.assertIsNone(result['failure'])
        self.assertIn('identity_changed',result['pending_failure'])
        self.assertTrue(np.any(result['action'][:,3]))
        integrate(obs,result['action'],lift_follow=.3)
        result=self.run_until(obs,controller,scene,lambda r:bool(r['failure']),lift_follow=.3)
        self.assertIn('identity_changed',result['failure']); self.assertFalse(result['cancellation_only'])
        self.assertFalse(result['debug']['unresolved_target_lag'])

    def test_target_velocity_and_individual_segment_adversaries_require_external_stop(self):
        for fault in ('target','base_velocity','lift_velocity','opposing_segments','wrist','missing_twist','missing_targets'):
            with self.subTest(fault=fault):
                obs=observation(); scene=RespondingScene(obs); controller=approach.ObservedPairApproach(obs)
                if fault=='target': obs['controller_target'][0,0]+=.001
                if fault=='base_velocity': obs['base_twist_world'][0,1]=.01
                if fault=='lift_velocity': obs['joint_velocity'][0,3]=.01
                if fault=='opposing_segments':
                    obs['joint_position'][0,4]+=.0002; obs['joint_position'][0,5]-=.0002
                if fault=='wrist': obs['controller_target'][1,3]+=.001
                if fault=='missing_twist': del obs['base_twist_world']
                if fault=='missing_targets': del obs['controller_target']
                with patch.object(approach,'_measure_geometry',side_effect=scene.measure): result=controller.step(obs,[],{},{})
                self.assertIsNotNone(result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])
                self.assertFalse(result['done']); self.assertFalse(result['cancellation_only'])
                np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_pending_motion_must_fit_original_global_and_pulse_reserves(self):
        for fault in ('global','pulse'):
            with self.subTest(fault=fault):
                obs=observation(); scene=RespondingScene(obs,direction=(0.,0.,1.)); controller=approach.ObservedPairApproach(obs)
                result=self.run_until(obs,controller,scene,lambda r:np.any(r['action'][:,3]))
                integrate(obs,result['action'],lift_follow=.3)
                if fault=='global':
                    controller.endpoint_path[:]=controller.MAX_TRAVEL_M-.0001
                else:
                    # Existing real travel4.5mm plus queued0.7mm exceeds the
                    # original4mm pulse +1mm tolerance; cancelling is no excuse.
                    obs['grasp_pose_base'][:,2]=1.+.0045
                    obs['joint_position'][:,3]=1.-.1782204955816269+.0045
                    obs['controller_target'][:,0]=obs['joint_position'][:,3]+.0007
                    obs['joint_velocity'][:]=0.
                    controller.last_grasps=np.stack([grasp_world(obs,r) for r in (0,1)])
                    controller.endpoint_path[:]=.0045
                scene.missing=True
                with patch.object(approach,'_measure_geometry',side_effect=scene.measure): result=controller.step(obs,[],{},{})
                self.assertIsNotNone(result['failure'],result)
                self.assertTrue(result['debug']['unresolved_target_lag'])
                self.assertIn('persistent_path_reserve' if fault=='global' else 'current_pulse_reserve',result['failure'])

    def test_stalled_lift_target_cannot_wind_up_or_extend_original_pulse_deadline(self):
        obs=observation(); scene=RespondingScene(obs,direction=(0.,0.,1.)); controller=approach.ObservedPairApproach(obs)
        result=self.run_until(obs,controller,scene,lambda r:bool(r['failure']),lift_follow=0.)
        self.assertLessEqual(np.max(obs['controller_target'][:,0]-obs['joint_position'][:,3]),controller.TARGET_LEAD_M+1e-8)
        self.assertIn('pulse_deadline',result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])
        self.assertLessEqual(float(obs['simulation_time_s'])-controller.pulse['start_time'],8.06)
        self.assertEqual(controller.verified_pulses,0)

    def test_outgoing_base_motion_is_rejected_before_spending_unavailable_reserve(self):
        obs=observation(); scene=RespondingScene(obs); controller=approach.ObservedPairApproach(obs)
        self.run_until(obs,controller,scene,lambda r:r['debug']['phase']=='pulse')
        # Prior correction travel has used more measured distance than nominal
        # requested travel. The first outgoing150um base move has only50um left.
        controller.endpoint_path[:]=controller.MAX_TRAVEL_M-.00005
        controller.base_path[:]=controller.MAX_TRAVEL_M-.00005
        controller.pulse['endpoint_path_start']=controller.endpoint_path.copy()
        controller.requested_path=controller.MAX_TRAVEL_M
        integrate(obs,controller._hold())
        with patch.object(approach,'_measure_geometry',side_effect=scene.measure), patch.object(approach,'guard_base_velocity',side_effect=free_guard):
            result=controller.step(obs,[],{},{})
        self.assertIsNotNone(result['failure']); self.assertIn('persistent_path_reserve',result['failure'])
        self.assertFalse(result['debug']['unresolved_target_lag'])  # Nothing was queued.
        np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_cancellation_may_not_target_an_out_of_range_measured_lift(self):
        obs=observation(); scene=RespondingScene(obs); controller=approach.ObservedPairApproach(obs)
        obs['joint_position'][0,3]=1.1951
        obs['controller_target'][0,0]=1.195
        with patch.object(approach,'_measure_geometry',side_effect=scene.measure): result=controller.step(obs,[],{},{})
        self.assertIsNotNone(result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])
        self.assertFalse(result['cancellation_only']); np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_frozen_cancellation_observation_is_bounded_without_reintegrating_action(self):
        obs=observation(); scene=RespondingScene(obs,direction=(0.,0.,1.)); controller=approach.ObservedPairApproach(obs)
        result=self.run_until(obs,controller,scene,lambda r:np.any(r['action'][:,3]))
        integrate(obs,result['action'],lift_follow=.3); scene.missing=True
        with patch.object(approach,'_measure_geometry',side_effect=scene.measure):
            result=controller.step(obs,[],{},{})
            self.assertTrue(result['cancellation_only'])
            for _ in range(42):
                result=controller.step(obs,[],{},{})
                np.testing.assert_array_equal(result['action'][:,:8],0.)
        self.assertIsNotNone(result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])


if __name__ == '__main__':
    unittest.main()
