"""Public-frame boundaries and closed-gripper behavior of the passive handoff."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
import sleeve_pair_policy as sleeve
from side_contact_policy import Policy
from test_sleeve_pair_policy import Baseline, observation, transport_result, tick


class HandoffPolicyTests(unittest.TestCase):
    def actor(self):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = Policy('unused.pt')
        obs = observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.step = 2; actor.phase = 'pair_raise'; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor.pair_lift = Mock(step=Mock(return_value=transport_result(done=True)))
        actor._cache_scene = Mock()
        return actor, obs

    def test_raise_handoff_and_roll_use_separate_public_frames(self):
        actor, obs = self.actor()
        hold = np.zeros((2, 9), np.float32); hold[:, 8] = 1
        result = dict(action=hold, done=False, failure=None, debug={'stable_seconds': 0.})
        with patch.object(sleeve, 'LoadedWristHandoff') as gate, patch.object(sleeve, 'LoadedRollObservation') as roll:
            gate.return_value.step.return_value = result
            np.testing.assert_array_equal(actor(obs), hold)
            self.assertEqual(actor.phase, 'pair_settle_before_roll')
            gate.assert_not_called(); roll.assert_not_called()
            tick(obs); np.testing.assert_array_equal(actor(obs), hold)
            gate.assert_called_once(); roll.assert_not_called()
            tick(obs); result['done'] = True
            np.testing.assert_array_equal(actor(obs), hold)
            self.assertEqual(actor.phase, 'pair_observe_roll'); roll.assert_not_called()
            roll.return_value.step.return_value = dict(action=hold, done=False, failure=None, debug={})
            tick(obs); actor(obs)
            roll.assert_called_once()
            self.assertIsNone(actor.failure)

    def test_failed_handoff_preserves_diagnostic_and_never_starts_roll(self):
        actor, obs = self.actor(); actor.phase = 'pair_settle_before_roll'
        result = dict(action=np.zeros((2, 9), np.float32), done=True,
            failure='unresolved_target_lag_timeout', debug={'lag': [0.004, 0.005]})
        with patch.object(sleeve, 'LoadedWristHandoff') as gate, patch.object(sleeve, 'LoadedRollObservation') as roll:
            gate.return_value.step.return_value = result
            actor(obs)
            roll.assert_not_called()
            self.assertEqual(actor.phase, 'stopped')
            self.assertIn('unresolved_target_lag_timeout', actor.failure)
            self.assertEqual(actor.debug['loaded_wrist_handoff'], result['debug'])


if __name__ == '__main__':
    unittest.main()
