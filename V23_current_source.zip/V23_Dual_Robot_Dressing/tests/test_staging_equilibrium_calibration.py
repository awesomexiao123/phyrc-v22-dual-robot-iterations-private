"""CPU staging-window tests using public state and synthetic observed evidence.

These tests do not run a simulator or establish attachment, continuous rest,
or clearance of unobserved human surfaces.
"""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import staging_equilibrium_calibration as staging
from contact_motion_governor import ContactMotionGovernor
from gripper_skin_clearance import observed_gripper_skin_clearance
from wrist_sweep_envelope import jaw_sweep_envelope, wrist_sweep_envelope
from test_gripper_skin_clearance import observation as geometry_observation


def observation():
    """Measured fingertips, jaw state and wrist poses share the own FK tree."""
    obs = geometry_observation()
    obs['base_pose_world'][1, 1] = .7
    q = obs['joint_position']
    q[:, 3] = .5
    q[:, 4:8] = .05
    obs['joint_velocity'] = np.zeros((2, 13))
    obs['base_twist_world'] = np.zeros((2, 6))
    target = np.zeros((2, 9))
    target[:, 0] = q[:, 3]
    target[:, 1] = q[:, 4:8].sum(1)
    target[:, 2:5] = q[:, 8:11]
    target[:, 5] = .103
    obs['controller_target'] = target
    obs['previous_action'] = np.zeros((2, 9), np.float32)
    obs['previous_action'][:, 8] = 1.
    obs['gripper_close_command'] = np.ones((2, 1), dtype=bool)
    obs['fingertip_origin_distance'] = np.linalg.norm(
        obs['fingertip_position_base'][:, 1]-obs['fingertip_position_base'][:, 0], axis=1)
    return obs


def hands(obs):
    grasps = ContactMotionGovernor._read(obs)['grasps']
    return dict(detected=True, hand_points_world=(grasps-[0., 0., .10]).tolist(),
                observation_time_s=10.)


def prior():
    return dict(observed_at_s=9.9, window_start_s=9.4, frame_count=11,
                method='Synthetic completed public sampled equilibrium window.',
                controller_bias=np.zeros((2, 5)).tolist(),
                controller_bias_peak_deviation=np.zeros((2, 5)).tolist())


def visible_skin(obs, hand_points):
    points = np.asarray(hand_points, float)
    return np.repeat(points, 12, axis=0), [12, 12]


def visible_cloth(obs):
    grasps = ContactMotionGovernor._read(obs)['grasps']
    return dict(world_points=np.repeat(grasps, 24, axis=0),
                camera_ids=np.repeat([1, 2], 24),
                rgb=np.tile([8, 14, 220], (48, 1)).astype(np.uint8))


class StagingEquilibriumCalibrationTests(unittest.TestCase):
    def construct(self, obs=None, calibration=None, **kwargs):
        obs = observation() if obs is None else obs
        calibration = prior() if calibration is None else calibration
        report = hands(obs)
        controller = staging.StagingEquilibriumCalibration(
            obs, report, report['observation_time_s'], prior_calibration=calibration,
            stationary_human=True, **kwargs)
        return obs, controller

    def assert_passive(self, result):
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        np.testing.assert_array_equal(result['action'][:, 8], 1.)

    def advance(self, obs, controller, count=41):
        for frame in range(count):
            obs['simulation_time_s'][...] = 10.+frame*.05
            result = controller.step(obs)
            self.assert_passive(result)
            if result['done'] or result['failure']:
                break
        return result

    def test_real_own_geometry_requires_41_current_skin_frames_spanning_two_seconds(self):
        obs, controller = self.construct()
        sampled_times = []

        def current(observed, hand_points):
            sampled_times.append(float(observed['simulation_time_s']))
            return visible_skin(observed, hand_points)

        # Neither own-box clearance nor the articulated wrist envelope is
        # mocked: both consume the FK-consistent synthetic own observation.
        with patch.object(staging, '_current_skin_points', side_effect=current), \
                patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
            for frame in range(41):
                obs['simulation_time_s'][...] = 10.+frame*.05
                result = controller.step(obs)
                self.assert_passive(result)
                self.assertIsNone(result['failure'], result)
                self.assertEqual(result['done'], frame == 40, result)
                self.assertEqual(result['debug']['frame_count'], frame+1)
        np.testing.assert_allclose(sampled_times, 10.+np.arange(41)*.05)
        saved = result['calibration']
        self.assertEqual(saved['frame_count'], 41)
        self.assertAlmostEqual(saved['window_start_s'], 10.)
        self.assertAlmostEqual(saved['observed_at_s'], 12.)
        np.testing.assert_allclose(saved['controller_bias'], 0., atol=1e-14)
        saved['controller_bias'][0][0] = 99.
        self.assertAlmostEqual(controller.step(obs)['calibration']['controller_bias'][0][0], 0.)
        self.assertFalse(result['debug']['continuous_time_stationary_verified'])
        self.assertFalse(result['debug']['native_target_cancelled'])

    def test_missing_stale_incomplete_or_invalid_prior_never_enters_window(self):
        variants = {'missing': None}
        for name in ('stale', 'future', 'short_window', 'few_frames', 'missing_method',
                     'nonfinite_bias', 'bias_over_limit', 'negative_peak'):
            value = prior()
            if name == 'stale':
                value['observed_at_s'], value['window_start_s'] = -170.01, -170.51
            elif name == 'future':
                value['observed_at_s'], value['window_start_s'] = 10.1, 9.6
            elif name == 'short_window': value['window_start_s'] = 9.5
            elif name == 'few_frames': value['frame_count'] = 10
            elif name == 'missing_method': del value['method']
            elif name == 'nonfinite_bias': value['controller_bias'][0][0] = np.nan
            elif name == 'bias_over_limit': value['controller_bias'][0][0] = .00301
            elif name == 'negative_peak': value['controller_bias_peak_deviation'][0][0] = -.001
            variants[name] = value
        for name, value in variants.items():
            with self.subTest(prior=name):
                obs = observation()
                report = hands(obs)
                c = staging.StagingEquilibriumCalibration(
                    obs, report, 10., prior_calibration=value, stationary_human=True)
                result = c.step(obs)
                self.assert_passive(result)
                self.assertIsNotNone(result['failure'], result)
                self.assertFalse(result['done'])
                self.assertIsNone(result['calibration'])

    def test_lost_current_skin_on_final_frame_cannot_freeze_from_cached_support(self):
        obs, c = self.construct()

        def current(observed, hand_points):
            points, counts = visible_skin(observed, hand_points)
            if float(observed['simulation_time_s']) >= 12.:
                return points[:-1], [12, 11]
            return points, counts

        with patch.object(staging, '_current_skin_points', side_effect=current) as skin, \
                patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
            result = self.advance(obs, c)
        self.assertEqual(skin.call_count, 41)
        self.assertIsNotNone(result['failure'], result)
        self.assertFalse(result['done'])
        self.assertIsNone(result['calibration'])
        original_failure = result['failure']
        obs['simulation_time_s'][...] = 12.05
        with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
            restored = c.step(obs)
        self.assertEqual(restored['failure'], original_failure)
        self.assertFalse(restored['done'])
        self.assertIsNone(restored['calibration'])

    def test_new_bias_must_match_prior_peak_plus_candidate_peak_and_terminal_limit(self):
        for difference, prior_peak, accepted in ((.00009, 0., True), (.00011, 0., False),
                                                (.00011, .00002, True), (.00025, 0., False)):
            with self.subTest(lift_bias=difference, prior_peak=prior_peak):
                obs = observation()
                obs['controller_target'][:, 0] += difference
                calibration = prior()
                for r in (0, 1):
                    calibration['controller_bias_peak_deviation'][r][0] = prior_peak
                obs, c = self.construct(obs, calibration)
                with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                        patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
                    result = self.advance(obs, c)
                self.assertEqual(result['done'], accepted, result)
                if accepted:
                    self.assertIsNone(result['failure'])
                else:
                    self.assertIsNotNone(result['failure'], result)
                    self.assertIsNone(result['calibration'])
                    self.assertEqual(result['debug']['frame_count'], 41)

    def test_opposite_raw_excess_pending_keep_both_segments_and_add_angular_reserve(self):
        obs = observation()
        obs['controller_target'][:, 0] += .001
        obs['controller_target'][:, 2] += np.deg2rad(.1)
        obs['joint_velocity'][:, 3] = .004
        obs['joint_velocity'][:, 8] = .002
        calibration = prior()
        for r in (0, 1):
            calibration['controller_bias'][r][0] = .002
            calibration['controller_bias'][r][2] = np.deg2rad(.2)
            calibration['controller_bias_peak_deviation'][r][2] = np.deg2rad(.01)
        obs, c = self.construct(obs, calibration)
        calls = []

        def clearance(observed, robot, points, **kwargs):
            calls.append((robot, deepcopy(kwargs)))
            return observed_gripper_skin_clearance(observed, robot, points, **kwargs)

        with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                patch.object(staging, 'cloth_cloud', side_effect=visible_cloth), \
                patch.object(staging, 'observed_gripper_skin_clearance', side_effect=clearance):
            result = c.step(obs)
        self.assert_passive(result)
        self.assertIsNone(result['failure'], result)
        self.assertEqual(len(calls), 4)
        state = ContactMotionGovernor._read(obs)
        for r in (0, 1):
            q = obs['joint_position'][r, 8:11]
            target = obs['controller_target'][r, 2:5]
            rate = np.abs(obs['joint_velocity'][r, 8:11])*.05
            raw = np.column_stack((np.minimum(q, target)-rate, np.maximum(q, target)+rate))
            centre = obs['controller_target'][r, 2:5]-np.asarray(calibration['controller_bias'])[r, 2:5]
            peak = np.asarray(calibration['controller_bias_peak_deviation'])[r, 2:5]
            envelope = wrist_sweep_envelope(obs['joint_position'][r], raw,
                                            np.column_stack((np.minimum(q, centre-peak)-rate,
                                                             np.maximum(q, centre+peak)+rate)))
            self.assertTrue(envelope['valid'], envelope)
            reserve = envelope['max_displacement_reserve_m']
            self.assertGreater(reserve, 0.)
            self.assertEqual(envelope['existing_geometry_margin_consumed_m'], 0.)
            recorded = [kwargs for robot, kwargs in calls if robot == r]
            segments = np.array([k['proposed_translation_world'] for k in recorded])
            np.testing.assert_allclose(np.sort(segments[:, 2]), [-.001, .001], atol=1e-12)
            np.testing.assert_allclose(segments[:, :2], 0., atol=1e-12)
            for kwargs in recorded:
                self.assertAlmostEqual(kwargs['skin_observed_at'], 10.)
                self.assertAlmostEqual(kwargs['model_margin_m'],
                                       .003+.05*state['endpoint_speed'][r]+reserve, places=12)

    def test_small_measured_jaw_motion_remains_eligible_with_additional_reserve(self):
        obs, c = self.construct()

        def set_jaws(angles):
            actual = geometry_observation(jaw=angles)
            obs['joint_position'][:, 11:13] = actual['joint_position'][:, 11:13]
            obs['grasp_pose_base'] = actual['grasp_pose_base'].copy()
            obs['fingertip_position_base'] = actual['fingertip_position_base'].copy()
            obs['fingertip_origin_distance'] = np.linalg.norm(
                obs['fingertip_position_base'][:, 1]-obs['fingertip_position_base'][:, 0], axis=1)
            obs['joint_velocity'][:, 11:13] = [.00690, -.00906]

        with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
            for time, jaws in ((10., (.10321, .10349)), (10.05, (.10322, .10348))):
                obs['simulation_time_s'][...] = time
                set_jaws(jaws)
                result = c.step(obs)
                self.assert_passive(result)
                self.assertIsNone(result['failure'], result)
                self.assertFalse(result['done'])
                self.assertEqual(len(c.clearance), 4)
                for report in c.clearance:
                    robot = report['robot']
                    expected = jaw_sweep_envelope(obs['joint_position'][robot], .103,
                                                 obs['joint_velocity'][robot, 11:13])
                    reserve = expected['max_displacement_reserve_m']
                    self.assertGreater(reserve, 0.)
                    self.assertAlmostEqual(report['additional_jaw_reserve_m'], reserve, places=12)
                    self.assertAlmostEqual(report['model_margin_m'],
                                           .003+report['raw_rate_interval_reserve_m']
                                           +report['prior_linear_uncertainty_reserve_m']
                                           +report['additional_angular_reserve_m']+reserve, places=12)
                    np.testing.assert_allclose(report['report']['measured_jaw_angles_rad'], jaws)

    def test_each_grasp_needs_24_current_cloth_points_from_one_camera(self):
        for fault in ('missing_grasp', 'split_camera', 'outside_12cm'):
            with self.subTest(fault=fault):
                obs, c = self.construct()
                cloud = visible_cloth(obs)
                if fault == 'missing_grasp':
                    cloud['world_points'][24:] += [1., 0., 0.]
                elif fault == 'split_camera':
                    cloud['camera_ids'] = np.tile(np.repeat([1, 2], 12), 2)
                else:
                    cloud['world_points'] += [0., 0., .1201]
                with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                        patch.object(staging, 'cloth_cloud', return_value=cloud):
                    result = c.step(obs)
                self.assert_passive(result)
                self.assertIsNotNone(result['failure'], result)
                self.assertFalse(result['done'])
                self.assertIsNone(result['calibration'])

    def test_original_clearance_translation_and_margin_bounds_are_not_relaxed(self):
        for fault in ('translation_over_5mm', 'wrist_over_half_degree',
                      'model_margin_over_20mm', 'skin_within_20mm'):
            with self.subTest(fault=fault):
                obs = observation()
                if fault == 'translation_over_5mm': obs['controller_target'][:, 0] += .00501
                elif fault == 'wrist_over_half_degree': obs['controller_target'][:, 2] += np.deg2rad(.5001)
                elif fault == 'model_margin_over_20mm': obs['joint_velocity'][:, 3] = .341
                obs, c = self.construct(obs)

                def clearance(observed, robot, points, **kwargs):
                    report = observed_gripper_skin_clearance(observed, robot, points, **kwargs)
                    if fault == 'skin_within_20mm' and report['valid']:
                        report['observed_minimum_clearance_m'] = .019999
                    return report

                with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                        patch.object(staging, 'cloth_cloud', side_effect=visible_cloth), \
                        patch.object(staging, 'observed_gripper_skin_clearance', side_effect=clearance):
                    result = c.step(obs)
                self.assert_passive(result)
                self.assertIsNotNone(result['failure'], result)
                self.assertFalse(result['done'])
                self.assertIsNone(result['calibration'])

    def test_explicit_stationary_assumption_zero_inputs_and_original_3mm_budget(self):
        for fault in ('implicit_stationary', 'previous_motion', 'base_target', 'base_drift'):
            with self.subTest(fault=fault):
                obs = observation()
                if fault == 'implicit_stationary':
                    c = staging.StagingEquilibriumCalibration(obs, hands(obs), 10., prior_calibration=prior())
                else:
                    obs, c = self.construct(obs)
                if fault == 'previous_motion': obs['previous_action'][0, 3] = .001
                elif fault == 'base_target': obs['controller_target'][0, 6] = .001
                elif fault == 'base_drift': obs['base_pose_world'][0, 0] += .00301
                with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                        patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
                    result = c.step(obs)
                self.assert_passive(result)
                self.assertIsNotNone(result['failure'], result)
                self.assertFalse(result['done'])
                self.assertIsNone(result['calibration'])

    def test_clock_jaw_guards_and_original_observation_timestamps(self):
        for fault in (None, 'skipped_frame', 'backwards', 'same_time_changed_state', 'actual_jaw'):
            with self.subTest(fault=fault):
                obs, c = self.construct()
                with patch.object(staging, '_current_skin_points', side_effect=visible_skin), \
                        patch.object(staging, 'cloth_cloud', side_effect=visible_cloth):
                    first = c.step(obs)
                    self.assertIsNone(first['failure'], first)
                    self.assertEqual(first['debug']['frame_count'], 1)
                    repeated = c.step(obs)
                    self.assertIsNone(repeated['failure'], repeated)
                    self.assertEqual(repeated['debug']['frame_count'], 1)
                    self.assertEqual(repeated['debug']['current_skin_frame_count'], 1)
                    obs['simulation_time_s'][...] = 10.05
                    second = c.step(obs)
                    self.assertIsNone(second['failure'], second)
                    self.assertEqual(second['debug']['frame_count'], 2)
                    self.assertAlmostEqual(second['debug']['cached_hand_observed_at_s'], 10.)
                    self.assertAlmostEqual(second['debug']['prior_calibration_original_observed_at_s'], 9.9)
                    self.assertAlmostEqual(second['debug']['original_skin_anchor_observed_at_s'], 10.)
                    self.assertAlmostEqual(second['debug']['current_skin_observed_at_s'], 10.05)
                    self.assertFalse(second['debug']['prior_calibration_refreshed'])
                    if fault is None:
                        for frame in range(2, 41):
                            obs['simulation_time_s'][...] = 10.+frame*.05
                            result = c.step(obs)
                            self.assert_passive(result)
                            self.assertIsNone(result['failure'], result)
                        self.assertTrue(result['done'], result)
                        calibration = result['calibration']
                        self.assertAlmostEqual(calibration['prior_calibration_original_observed_at_s'], 9.9)
                        self.assertAlmostEqual(calibration['original_hand_observed_at_s'], 10.)
                        self.assertAlmostEqual(calibration['original_skin_anchor_observed_at_s'], 10.)
                        self.assertAlmostEqual(calibration['current_skin_observed_at_s'], 12.)
                    else:
                        if fault == 'skipped_frame': obs['simulation_time_s'][...] = 10.15
                        elif fault == 'backwards': obs['simulation_time_s'][...] = 10.
                        elif fault == 'same_time_changed_state': obs['joint_position'][0, 3] += .00001
                        elif fault == 'actual_jaw':
                            obs['simulation_time_s'][...] = 10.10
                            obs['joint_position'][0, 11] += .02
                        result = c.step(obs)
                        self.assert_passive(result)
                        self.assertIsNotNone(result['failure'], result)
                        self.assertFalse(result['done'])
                        self.assertIsNone(result['calibration'])


if __name__ == '__main__':
    unittest.main()
