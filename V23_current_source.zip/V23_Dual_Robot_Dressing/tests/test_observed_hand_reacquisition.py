"""Synthetic current RGB-D patches with static identity priors, CPU only."""
import copy
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import observed_hand_reacquisition as reacquire


def observation(camera=3):
    pose = np.zeros((2, 7)); pose[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.zeros((5, 256, 256, 1), np.float32),
        depth_valid=np.zeros((5, 256, 256, 1), bool),
        base_pose_world=pose.copy(), grasp_pose_base=pose.copy(), simulation_time_s=np.array(100.))
    values = reacquire._validated(obs, wrists=True)
    rotation, _ = reacquire._camera_transform(values, camera)
    hands = reacquire._world_pixels(values, camera, np.array([95, 160]), np.array([110, 140]), np.ones(2))
    prior = dict(detected=True, hand_points_world=hands.tolist(), observation_time_s=10.)
    return obs, prior, rotation


def render(obs, prior, rotation, assignments=((3, (0,)), (4, (1,))), shifts=None, radius=.018):
    """Render real world discs; depth is camera optical Z with +0.5 pixels."""
    shifts = shifts or {}
    hands = np.asarray(prior['hand_points_world'])
    yy, xx = np.indices((256, 256))
    local_rays = np.stack(((xx+.5-128)/reacquire._FOCAL, (yy+.5-128)/reacquire._FOCAL, np.ones((256, 256))), -1)
    normal = rotation[:, 2]
    values = reacquire._validated(obs, wrists=True)
    for camera, ids in assignments:
        camera_rotation, origin = reacquire._camera_transform(values, camera)
        rays = local_rays @ camera_rotation.T
        for hand_index in ids:
            for shift in shifts.get((camera, hand_index), [np.zeros(3)]):
                center = hands[hand_index]+shift
                denominator = rays @ normal
                good = np.abs(denominator) > .01
                depth = np.full((256, 256), np.nan)
                depth[good] = ((center-origin)@normal)/denominator[good]
                world = origin+rays*depth[..., None]
                hit = good & (depth > .03) & (np.linalg.norm(world-center, axis=2) <= radius)
                obs['rgb'][camera][hit] = [200, 150, 150]
                obs['depth'][camera, ..., 0][hit] = depth[hit]
                obs['depth_valid'][camera, ..., 0][hit] = True


class ObservedHandReacquisitionTests(unittest.TestCase):
    def call(self, obs, prior, **kwargs):
        return reacquire.reacquire_observed_hand_pair(obs, prior, 10., **kwargs)

    def test_one_hand_per_camera_without_face_is_current_pair_in_both_camera_families(self):
        for cameras in ((3, 4), (1, 2)):
            with self.subTest(cameras=cameras):
                obs, prior, rotation = observation(cameras[0])
                render(obs, prior, rotation, ((cameras[0], (0,)), (cameras[1], (1,))))
                before = {key: value.copy() for key, value in obs.items()}; original_prior = copy.deepcopy(prior)
                result = self.call(obs, prior)
                self.assertTrue(result['detected'], result)
                self.assertEqual(result['observation_time_s'], 100.)
                self.assertEqual(result['original_observed_at_s'], 10.)
                self.assertEqual(result['original_prior_age_s'], 90.)
                self.assertFalse(result['original_prior_timestamp_refreshed'])
                self.assertFalse(result['full_hand_geometry_observed'])
                self.assertFalse(result['insertion_allowed'])
                self.assertEqual(prior, original_prior)
                for key in obs:
                    np.testing.assert_array_equal(obs[key], before[key])
                for hand in result['hand_reports']:
                    self.assertTrue(hand['weak_single_view'])
                    camera = hand['selected_camera_index']; u, v = hand['selected_surface_pixel_uv']
                    measured = reacquire._world_pixels(reacquire._validated(obs, wrists=True), camera,
                        np.array([u]), np.array([v]), np.array([obs['depth'][camera, v, u, 0]]))[0]
                    np.testing.assert_allclose(hand['hand_surface_world'], measured, atol=1e-9)

    def test_camera_motion_does_not_move_static_measured_world_hands(self):
        obs, prior, rotation = observation()
        obs['base_pose_world'][0, :3] += [.03, -.025, .005]
        obs['base_pose_world'][1, :3] += [-.025, .02, -.005]
        render(obs, prior, rotation)
        result = self.call(obs, prior)
        self.assertTrue(result['detected'], result)
        np.testing.assert_allclose(result['hand_points_world'], prior['hand_points_world'], atol=.004)

    def test_world_rotation_translation_preserves_identity_and_measured_geometry(self):
        obs, prior, rotation = observation(); render(obs, prior, rotation)
        first = self.call(obs, prior)
        yaw = .65; c, s = np.cos(yaw), np.sin(yaw)
        transform = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        translation = np.array([.6, -.4, .2])
        obs['base_pose_world'][:, :3] = obs['base_pose_world'][:, :3]@transform.T+translation
        obs['base_pose_world'][:, 3:] = [np.cos(yaw/2), 0, 0, np.sin(yaw/2)]
        prior['hand_points_world'] = (np.asarray(prior['hand_points_world'])@transform.T+translation).tolist()
        second = self.call(obs, prior)
        self.assertTrue(second['detected'], second)
        np.testing.assert_allclose(second['hand_points_world'], np.asarray(first['hand_points_world'])@transform.T+translation, atol=1e-7)

    def test_missing_hand_never_copies_prior_or_makes_whole_pair_current(self):
        obs, prior, rotation = observation(); render(obs, prior, rotation, ((3, (0,)),))
        result = self.call(obs, prior)
        self.assertFalse(result['detected'])
        self.assertEqual(result['hand_points_world'], [])
        self.assertTrue(result['hand_reports'][0]['detected'])
        self.assertIsNone(result['hand_reports'][1]['hand_surface_world'])
        self.assertEqual(result['original_observed_at_s'], 10.)

    def test_disagreeing_views_and_two_components_reject_ambiguous_surface(self):
        for mode in ('views', 'components'):
            with self.subTest(mode=mode):
                obs, prior, rotation = observation(); lateral = .027*rotation[:, 0]
                if mode == 'views':
                    render(obs, prior, rotation, ((3, (0, 1)), (4, (0, 1))),
                        {(3, 0): [-lateral], (4, 0): [lateral]})
                else:
                    render(obs, prior, rotation, shifts={(3, 0): [-lateral, lateral]}, radius=.013)
                result = self.call(obs, prior)
                self.assertFalse(result['detected'], result)
                expected = 'conflict' if mode == 'views' else 'multiple_current_surface_patches'
                self.assertIn(expected, result['reason'])

    def test_agreeing_views_return_one_actual_medoid_not_average(self):
        obs, prior, rotation = observation()
        render(obs, prior, rotation, ((3, (0, 1)), (4, (0, 1))), {(4, 0): [.012*rotation[:, 0]]})
        result = self.call(obs, prior)
        self.assertTrue(result['detected'], result)
        self.assertFalse(result['hand_reports'][0]['weak_single_view'])
        for hand in result['hand_reports']:
            self.assertTrue(any(hand['hand_surface_world'] == view['hand_surface_world'] for view in hand['candidate_views']))

    def test_depth_loss_line_support_and_discontinuous_depth_do_not_fake_surface(self):
        for mode in ('invalid', 'line', 'discontinuity'):
            with self.subTest(mode=mode):
                obs, prior, rotation = observation(); render(obs, prior, rotation)
                if mode == 'invalid':
                    v, u = np.where(obs['depth_valid'][3, ..., 0]); obs['depth_valid'][3, v[:len(v)//2], u[:len(u)//2], 0] = False
                elif mode == 'line':
                    obs['rgb'][3] = 0; obs['depth_valid'][3] = False
                    obs['rgb'][3, 110, 88:103] = [200, 150, 150]
                    obs['depth'][3, 110, 88:103, 0] = 1.; obs['depth_valid'][3, 110, 88:103, 0] = True
                else:
                    obs['depth'][3, :, 95:, 0] += .035
                result = self.call(obs, prior)
                self.assertFalse(result['detected'], result)

    def test_original_prior_bounds_and_four_cm_medoid_shift(self):
        obs, prior, rotation = observation(); render(obs, prior, rotation)
        for kwargs in ({'stationary_human': False}, {'max_prior_age_s': 50.}, {'max_prior_age_s': 301.}):
            self.assertFalse(self.call(obs, prior, **kwargs)['detected'])
        future = copy.deepcopy(prior); future['observation_time_s'] = 101.
        self.assertFalse(reacquire.reacquire_observed_hand_pair(obs, future, 101.)['detected'])
        self.assertFalse(reacquire.reacquire_observed_hand_pair(obs, prior, 11.)['detected'])
        overlapping = copy.deepcopy(prior)
        overlapping['hand_points_world'][1] = (np.asarray(prior['hand_points_world'][0])+.10*rotation[:, 0]).tolist()
        self.assertIn('overlapping', self.call(obs, overlapping)['reason'])
        obs, prior, rotation = observation()
        render(obs, prior, rotation, shifts={(3, 0): [.050*rotation[:, 0]]})
        self.assertFalse(self.call(obs, prior)['detected'])

    def test_skin_cloth_own_model_and_overview_are_not_unqualified_hands(self):
        for color in ([160, 160, 160], [10, 20, 230]):
            obs, prior, rotation = observation(); render(obs, prior, rotation)
            obs['rgb'][3][obs['depth_valid'][3, ..., 0]] = color
            self.assertFalse(self.call(obs, prior)['detected'])
        obs, prior, rotation = observation(); render(obs, prior, rotation)
        with patch.object(reacquire, '_own_surface_mask', side_effect=lambda obs, pts: np.ones(len(pts), bool)):
            self.assertFalse(self.call(obs, prior)['detected'])
        obs['rgb'][0] = obs['rgb'][3]; obs['depth'][0] = obs['depth'][3]; obs['depth_valid'][0] = obs['depth_valid'][3]
        obs['rgb'][3] = 0
        self.assertFalse(self.call(obs, prior)['detected'])


if __name__ == '__main__':
    unittest.main()
