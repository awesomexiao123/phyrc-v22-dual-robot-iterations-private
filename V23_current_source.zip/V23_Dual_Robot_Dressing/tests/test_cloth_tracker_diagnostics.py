"""Diagnostic history must not change the fixed-feature acceptance behavior."""
import importlib.util
from pathlib import Path
import unittest

import numpy as np

from test_cloth_patch_tracker import MODULE, observation, two_view_observation, retain_depth_near_pixels, shift_pixels


def clone(obs, timestamp):
    result={key:value.copy() for key,value in obs.items()}
    result['simulation_time_s']=np.array(timestamp)
    return result


class ClothTrackerDiagnosticsTests(unittest.TestCase):
    def test_initial_camera_accounting_and_explicit_exclusion_reasons(self):
        obs,center,_=two_view_observation();obs=clone(obs,12.)
        tracker=MODULE.ClothPatchTracker();report=tracker.reset(obs,center)
        self.assertTrue(report['reliable'])
        self.assertEqual(report['observation_time_s'],12.)
        self.assertEqual(report['initial_observation_time_s'],12.)
        total=0
        for camera,stats in report['initialization_by_camera'].items():
            self.assertGreaterEqual(stats['proposed_feature_count'],stats['measurement_valid_feature_count'])
            self.assertGreaterEqual(stats['measurement_valid_feature_count'],stats['supported_in_patch_feature_count'])
            self.assertGreaterEqual(stats['supported_in_patch_feature_count'],stats['accepted_feature_count'])
            self.assertEqual(stats['proposed_feature_count']-stats['measurement_valid_feature_count'],stats['excluded_counts']['depth_or_cloth_support'])
            self.assertIsNotNone(stats['reason'])
            total+=stats['accepted_feature_count']
            if 'wrist' in camera:self.assertEqual(stats['reason'],'insufficient_fabric_valid_pixels')
        self.assertEqual(total,report['initial_feature_count'])
        self.assertEqual(sum(report['cumulative_rejected'].values()),0)
        self.assertIsNone(report['first_unreliable_after_initialization'])
        self.assertFalse(report['features_reseeded'])

    def test_cumulative_losses_keep_original_times_and_do_not_blame_final_frame(self):
        obs,center,_=two_view_observation();obs=clone(obs,30.)
        tracker=MODULE.ClothPatchTracker();initial=tracker.reset(obs,center)
        initial_ids=set(initial['feature_ids']);pixels=tracker.groups[3]['pixels'].copy()
        counts={c:g['initial_count'] for c,g in tracker.groups.items()}
        six=clone(obs,30.05)
        retain_depth_near_pixels(six,3,pixels[:6]);six['depth_valid'][4]=False
        first=tracker.update(six)
        self.assertTrue(first['reliable']);self.assertEqual(first['tracked_count'],6)
        self.assertIsNone(first['first_unreliable_after_initialization'])
        self.assertEqual(first['cumulative_rejected']['depth_or_cloth_support'],counts[3]+counts[4]-6)
        self.assertEqual(first['cumulative_rejected_by_camera']['robot_0_head']['depth_or_cloth_support'],counts[3]-6)
        self.assertEqual(first['cumulative_rejected_by_camera']['robot_1_head']['depth_or_cloth_support'],counts[4])
        self.assertEqual(first['first_view_below_motion_thresholds']['robot_1_head']['observation_time_s'],30.05)
        five=clone(obs,30.10)
        retain_depth_near_pixels(five,3,pixels[:5]);five['depth_valid'][4]=False
        second=tracker.update(five)
        self.assertFalse(second['reliable']);self.assertEqual(second['tracked_count'],5)
        self.assertEqual(second['first_unreliable_after_initialization']['observation_time_s'],30.10)
        self.assertEqual(second['first_unreliable_after_initialization']['update_count'],2)
        self.assertEqual(second['rejected']['depth_or_cloth_support'],1)
        third=tracker.update(clone(five,30.15))
        self.assertEqual(sum(third['rejected'].values()),0)
        self.assertEqual(third['cumulative_rejected'],second['cumulative_rejected'])
        self.assertEqual(third['first_unreliable_after_initialization'],second['first_unreliable_after_initialization'])
        self.assertEqual(third['observation_time_s'],30.15)
        self.assertEqual(third['initial_observation_time_s'],30.)
        self.assertTrue(set(third['feature_ids']).issubset(initial_ids))
        # Earlier reports must remain detached snapshots of earlier counters.
        self.assertEqual(first['cumulative_rejected']['depth_or_cloth_support'],counts[3]+counts[4]-6)
        self.assertNotIn('robot_0_head',first['first_view_below_motion_thresholds'])

    def test_empty_cohort_update_has_no_new_rejection_but_keeps_history(self):
        obs,center,_=observation();obs=clone(obs,5.)
        tracker=MODULE.ClothPatchTracker();initial=tracker.reset(obs,center)
        lost=clone(obs,5.05);lost['depth_valid'][:]=False
        first=tracker.update(lost)
        self.assertEqual(first['tracked_count'],0)
        final=tracker.update(clone(obs,5.10))
        self.assertEqual(final['reason'],'no_remaining_initial_features')
        self.assertEqual(final['cumulative_rejected']['depth_or_cloth_support'],initial['tracked_count'])
        self.assertEqual(sum(sum(c.values()) for c in final['rejected_by_camera_this_update'].values()),0)
        self.assertEqual(final['first_unreliable_after_initialization']['observation_time_s'],5.05)
        self.assertEqual(final['observation_time_s'],5.10)
        self.assertFalse(final['features_reseeded'])

    def test_explicit_reset_clears_history_without_changing_feature_selection(self):
        obs,center,_=observation();obs=clone(obs,50.)
        tracker=MODULE.ClothPatchTracker();initial=tracker.reset(obs,center)
        blocked=clone(obs,50.05);blocked['depth_valid'][:]=False
        self.assertFalse(tracker.update(blocked)['reliable'])
        reset=tracker.reset(clone(obs,60.),center)
        self.assertTrue(reset['reliable'])
        self.assertEqual(reset['feature_ids'],initial['feature_ids'])
        self.assertEqual(reset['initialization_by_camera'],initial['initialization_by_camera'])
        self.assertEqual(reset['update_count'],0)
        self.assertEqual(sum(reset['cumulative_rejected'].values()),0)
        self.assertEqual(reset['first_view_below_motion_thresholds'],{})
        self.assertIsNone(reset['first_unreliable_after_initialization'])
        self.assertEqual(reset['initial_observation_time_s'],60.)

    def test_missing_public_clock_is_explicitly_unknown_and_does_not_change_result(self):
        obs,center,_=observation();tracker=MODULE.ClothPatchTracker()
        initial=tracker.reset(obs,center)
        self.assertTrue(initial['reliable']);self.assertIsNone(initial['observation_time_s'])
        obs['depth_valid'][:]=False;failed=tracker.update(obs)
        self.assertFalse(failed['reliable'])
        self.assertIsNone(failed['first_unreliable_after_initialization']['observation_time_s'])
        self.assertEqual(failed['first_unreliable_after_initialization']['update_count'],1)

    def test_acceptance_and_displacements_match_immutable_pre_diagnostic_tracker(self):
        root=Path(__file__).resolve().parents[1]
        path=root/'results/evaluate_20261017T103541_462789Z/participant_snapshot/cloth_patch_tracker.py'
        if not path.exists():self.skipTest('Optional immutable pre-change reference not installed')
        spec=importlib.util.spec_from_file_location('tracker_pre_diagnostics_reference',path)
        old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        a=MODULE.ClothPatchTracker();b=old.ClothPatchTracker()
        obs,center,_=observation();obs=clone(obs,90.)
        frames=[obs,clone(shift_pixels(obs,3,4),90.05),clone(shift_pixels(obs,3,8),90.10)]
        blocked=clone(frames[-1],90.15);blocked['depth_valid'][:]=False
        frames.extend([blocked,clone(obs,90.20)])
        for index,frame in enumerate(frames):
            new=a.reset(frame,center) if index==0 else a.update(frame)
            previous=b.reset(frame,center) if index==0 else b.update(frame)
            for key,value in previous.items():
                self.assertEqual(new[key],value,(index,key))


if __name__=='__main__':unittest.main()
