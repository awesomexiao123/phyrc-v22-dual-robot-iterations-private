"""Optional diagnostic stop routing; measured child failures remain decisive."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import cooperative_policy as cooperative
from sleeve_pair_policy import Policy as SleeveSidePolicy
from side_contact_policy import Policy as SideContactPolicy
from test_sleeve_pair_policy import Baseline, observation


class WristOpeningStopPolicyTests(unittest.TestCase):
    def case(self, policy_class, phase, *, failure=None):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = policy_class('unused.pt')
        obs = observation(); obs['gripper_close_command'][:] = True
        actor.handoff_done = True; actor.active, actor.helper = 0, 1
        actor.step = 2; actor.phase = phase; actor.phase_steps = 0
        actor.execution.previous_closed[:] = True; actor.execution.stable[:] = 30
        actor.observe_sleeves = Mock(return_value=dict(both_regions_have_depth_supported_opening=True))
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        child = Mock()
        child.step.return_value = dict(action=action, done=False, failure=failure, debug={})
        setattr(actor, 'loaded_roll' if phase == 'pair_observe_roll' else 'loaded_pitch', child)
        return actor, obs, child

    def test_original_policy_keeps_optional_opening_stop_in_both_wrist_stages(self):
        for phase in ('pair_observe_roll', 'pair_observe_pitch'):
            with self.subTest(phase=phase):
                actor, obs, child = self.case(SleeveSidePolicy, phase)
                actor(obs)
                self.assertTrue(child.step.call_args.kwargs['stop_for_openings'])
                actor.observe_sleeves.assert_called_once()
                self.assertIsNone(actor.failure)

    def test_contact_variant_collects_diagnostics_without_optional_early_stop(self):
        for phase in ('pair_observe_roll', 'pair_observe_pitch'):
            with self.subTest(phase=phase):
                actor, obs, child = self.case(SideContactPolicy, phase)
                actor(obs)
                self.assertFalse(child.step.call_args.kwargs['stop_for_openings'])
                actor.observe_sleeves.assert_called_once()
                self.assertTrue(actor.sleeve_observability['both_regions_have_depth_supported_opening'])
                self.assertEqual(actor.phase, phase)
                self.assertIsNone(actor.failure)

    def test_contact_variant_still_stops_for_measured_child_guard_failures(self):
        for phase in ('pair_observe_roll', 'pair_observe_pitch'):
            with self.subTest(phase=phase):
                actor, obs, child = self.case(SideContactPolicy, phase, failure='measured_grasp_center_drift_over_3mm')
                action = actor(obs)
                self.assertFalse(child.step.call_args.kwargs['stop_for_openings'])
                self.assertIn('measured_grasp_center_drift_over_3mm', actor.failure)
                self.assertEqual(actor.phase, 'stopped')
                np.testing.assert_array_equal(action[:, :8], 0.)

    def test_eligibility_skip_stops_contact_variant_but_preserves_legacy_continuation(self):
        for phase, next_phase in (('pair_observe_roll', 'pair_observe_pitch'), ('pair_observe_pitch', 'dual_hold')):
            for policy_class in (SideContactPolicy, SleeveSidePolicy):
                with self.subTest(phase=phase, policy=policy_class.VERSION):
                    actor, obs, child = self.case(policy_class, phase)
                    child.step.return_value.update(done=True, skipped=True, experiment_completed=False,
                        debug=dict(phase='ineligible_before_motion', ineligible_reason='initial_target_not_settled'))
                    actor(obs)
                    diagnostic = actor.loaded_roll_debug if phase == 'pair_observe_roll' else actor.loaded_pitch_debug
                    self.assertTrue(diagnostic['skipped'])
                    self.assertEqual(diagnostic['ineligible_reason'], 'initial_target_not_settled')
                    if policy_class is SideContactPolicy:
                        self.assertEqual(actor.phase, 'stopped')
                        self.assertIn('initial_target_not_settled', actor.failure)
                        self.assertIn('roll' if phase == 'pair_observe_roll' else 'pitch', actor.failure)
                    else:
                        self.assertEqual(actor.phase, next_phase)
                        self.assertIsNone(actor.failure)

    def test_pending_cancellation_passes_through_until_child_finishes(self):
        for phase in ('pair_observe_roll', 'pair_observe_pitch'):
            with self.subTest(phase=phase):
                actor, obs, child = self.case(SideContactPolicy, phase)
                action = child.step.return_value['action']
                action[:, 7 if phase == 'pair_observe_roll' else 6] = -.0001
                child.step.return_value.update(done=False, cancellation_only=True,
                    pending_failure='bounded_abort', experiment_completed=False)
                result = actor(obs)
                self.assertEqual(actor.phase, phase)
                self.assertIsNone(actor.failure)
                np.testing.assert_array_equal(result, action)


if __name__ == '__main__':
    unittest.main()
