"""CPU own-FK and integrated-target tests; no cloth physics or GPU.

Synthetic depth demonstrates the actual visual eligibility path. Controller
tests hold its evidence provider fixed to separate kinematic lag from cloth
simulation; they cannot establish physical grip, cloth response or clearance.
"""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_pitch_observation as pitch
from public_vision import _rotation, grasp_world
from test_loaded_roll_observation import observation as roll_observation, hands, visible


def quaternion_product(a, b):
    w, v = a[0], np.asarray(a[1:]); x, u = b[0], np.asarray(b[1:])
    return np.r_[w*x-v@u, w*u+x*v+np.cross(v, u)]


def update_pose(obs):
    """Own static pitch FK; keep base-world changes independent of FK."""
    q = obs['joint_position']
    for r in (0, 1):
        yaw, angle, roll = q[r, 8:11]
        # Static yaw pivot X = neutral graspX - pitch lever.
        offset = np.array([pitch.LoadedPitchObservation.LEVER*np.cos(angle), -.0874191597,
                           -.0452-pitch.LoadedPitchObservation.LEVER*np.sin(angle)])
        rz = _rotation([np.cos(yaw/2), 0, 0, np.sin(yaw/2)])
        obs['grasp_pose_base'][r, :3] = np.array([.4662579894065857-pitch.LoadedPitchObservation.LEVER+q[r, 4:8].sum(),
                                                0., .1782204955816269+.0452+q[r, 3]]) + rz@offset
        obs['grasp_pose_base'][r, 3:] = quaternion_product(
            quaternion_product([np.cos(yaw/2), 0., 0., np.sin(yaw/2)],
                               [np.cos(angle/2), 0., np.sin(angle/2), 0.]),
            [np.cos(roll/2), np.sin(roll/2), 0., 0.])


def observation(yaw=0., base_tilt=0.):
    obs = roll_observation()
    obs['joint_position'][:, 3] = 1.15
    obs['joint_position'][:, 4:8] = .35/4
    obs['joint_position'][:, 8] = yaw
    obs['joint_position'][:, 9] = np.deg2rad(41.)
    obs['controller_target'][:, 0] = 1.15; obs['controller_target'][:, 1] = .35
    obs['controller_target'][:, 2:5] = obs['joint_position'][:, 8:11]
    if base_tilt:
        for r in (0, 1):
            obs['base_pose_world'][r, 3:] = quaternion_product(obs['base_pose_world'][r, 3:],
                [np.cos(base_tilt/2), 0., np.sin(base_tilt/2), 0.])
    update_pose(obs)
    return obs


def integrate(obs, action, follow=(.5, .5, .5), *, advance=True):
    """Integrated targets with independently lagging lift/arm/pitch actuators."""
    before = obs['joint_position'].copy()
    cols = pitch.LoadedPitchObservation.TARGET_COLUMNS
    obs['controller_target'][:, cols] += action[:, [3, 4, 6]]*np.array([1.54,1.21,5.5])*.05
    q = obs['joint_position']; target = obs['controller_target']
    q[:, 3] += follow[0]*(target[:, 0]-q[:, 3])
    q[:, 4:8] += follow[1]*(target[:, 1, None]/4-q[:, 4:8])
    q[:, 9] += follow[2]*(target[:, 3]-q[:, 9])
    obs['joint_velocity'] = (q-before)/.05
    update_pose(obs)
    if advance:
        obs['simulation_time_s'][...] += .05


class LoadedPitchObservationTests(unittest.TestCase):
    def construct(self, obs=None, **kwargs):
        obs = observation() if obs is None else obs
        return obs, pitch.LoadedPitchObservation(obs, hands(), 0., stationary_human=True, **kwargs)

    def until(self, obs, controller, condition, *, follow=(.5,.5,.5), limit=470, evidence=visible):
        with patch.object(pitch, '_cloth_evidence', side_effect=evidence):
            for _ in range(limit):
                result = controller.step(obs)
                np.testing.assert_array_equal(result['action'][:, [0,1,2,5,7]], 0.)
                np.testing.assert_array_equal(result['action'][:, 8], 1.)
                rates = result['action'][:, [3,4,6]]*np.array([1.54,1.21,5.5])
                self.assertTrue(np.all(np.abs(rates) <= controller.MAX_RATES+1e-9))
                if condition(result):
                    return result
                integrate(obs, result['action'], follow)
        self.fail('Expected bounded state not reached: '+str(result))

    def test_real_public_rgbd_and_no_opening_claim(self):
        obs, controller = self.construct()
        result = controller.step(obs)
        self.assertTrue(result['eligible'], result)
        self.assertEqual(result['debug']['observed_cloth_point_count'], 288)
        self.assertTrue(result['debug']['observed_point_clearance_only'])
        self.assertFalse(result['debug']['attachment_verified'])
        self.assertFalse(result['debug']['insertion_allowed'])
        self.assertIsNone(result['debug']['opening_visibility_improved'])

    def test_preconditions_and_goal_workspace_skip_without_commands(self):
        for fault in ('static','time','stamp','stale','cloth','near_hand','gripper','yaw','lift','arm','pitch_limit','stage','target','fixed_target'):
            with self.subTest(fault=fault):
                obs = observation(yaw=np.deg2rad(15.) if fault=='yaw' else 0.)
                report = hands(); stamp = None if fault=='time' else 0.
                if fault=='stamp': report['observation_time_s']=-.1
                if fault=='stale': obs['simulation_time_s'][...]=301.
                if fault=='cloth': obs['depth_valid'][2]=False
                if fault=='near_hand': report['hand_points_world'][0]=grasp_world(obs,0).tolist()
                if fault=='gripper': obs['gripper_close_command'][1]=False
                if fault=='lift': obs['joint_position'][:,3]=obs['controller_target'][:,0]=.008
                if fault=='arm':
                    obs['joint_position'][:,4:8]=.008/4; obs['controller_target'][:,1]=.008
                if fault=='pitch_limit': obs['joint_position'][:,9]=obs['controller_target'][:,3]=pitch.LoadedPitchObservation.PITCH_LIMITS[0]+.01
                if fault=='stage':
                    obs['joint_position'][0,4]+=.002; obs['joint_position'][0,5]-=.002
                if fault=='target': obs['controller_target'][0,0]+=.0005
                if fault=='fixed_target': obs['controller_target'][0,4]+=.01
                controller=pitch.LoadedPitchObservation(obs,report,stamp,stationary_human=fault!='static')
                result=controller.step(obs)
                self.assertTrue(result['skipped'],result); self.assertFalse(result['motion_started'])
                self.assertIsNone(result['failure']); np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_opposed_and_tilted_bases_sequential_negative_two_degrees_under_unequal_lag(self):
        obs, controller = self.construct(observation(base_tilt=.025))
        first_times={}; settle_times={}; max_drift=0.
        with patch.object(pitch,'_cloth_evidence',side_effect=visible):
            for _ in range(300):
                result=controller.step(obs)
                self.assertIsNone(result['failure'],result); self.assertIsNone(result['pending_failure'],result)
                action=result['action']; moving=np.flatnonzero(action[:,6]<0)
                self.assertLessEqual(len(moving),1)
                self.assertTrue(np.all(action[:,6]<=0))
                np.testing.assert_array_equal(action[:,[0,1,2,5,7]],0.)
                for r in moving: first_times.setdefault(int(r),float(obs['simulation_time_s']))
                if result['debug']['phase'].startswith('settle_'):
                    settle_times.setdefault(result['debug']['phase'],float(obs['simulation_time_s']))
                max_drift=max(max_drift,np.max(np.linalg.norm(np.stack([grasp_world(obs,r) for r in (0,1)])-controller.grasp0,axis=1)))
                if result['done']: break
                integrate(obs,action,follow=(.3,.65,.5))
        self.assertTrue(result['experiment_completed'],result)
        self.assertGreaterEqual(first_times[0],.5-1e-8)
        self.assertGreaterEqual(first_times[1]-settle_times['settle_0'],.5-1e-8)
        self.assertLess(max_drift,.001)
        np.testing.assert_allclose(np.rad2deg(obs['joint_position'][:,9]),39.,atol=.01)
        np.testing.assert_allclose(obs['joint_position'][:,3],1.15-.007897470284889513,atol=.00015)
        np.testing.assert_allclose(obs['joint_position'][:,4:8].sum(1),.35-.006626764403284307,atol=.00015)
        self.assertLess(result['debug']['measured_total_absolute_pitch_degrees'],4.01)

    def test_feedback_corrects_measured_xz_error_without_resetting_reference(self):
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'])
        original_reference=controller.grasp0.copy()
        # Actual own grasp offset differs from the nominal static model by
        # 0.8mm. The next target uses public measured center, not FK equality.
        obs['grasp_pose_base'][0,0]+=.0008
        with patch.object(pitch,'_cloth_evidence',side_effect=visible): result=controller.step(obs)
        self.assertIsNone(result['failure']); self.assertIsNone(result['pending_failure'])
        self.assertLess(result['action'][0,4],0.)
        self.assertGreater(result['debug']['measured_grasp_center_drift_m'][0],.0005)
        np.testing.assert_array_equal(controller.grasp0,original_reference)

    def test_no_lateral_degree_of_freedom_and_small_yaw_bound(self):
        accepted=observation(yaw=np.deg2rad(5.))
        _,controller=self.construct(accepted)
        self.assertTrue(controller.eligible)
        self.assertLess(max(controller.debug['predicted_unactuated_lateral_excursion_m']),.001)
        rejected=observation(yaw=np.deg2rad(15.))
        _,controller=self.construct(rejected)
        self.assertTrue(controller.skipped)
        self.assertIn('lateral_residual',controller.ineligible_reason)

    def test_stalled_pitch_does_not_wind_up_three_axis_targets(self):
        obs,controller=self.construct()
        result=self.until(obs,controller,lambda r:r['cancellation_only'] or r['failure'],follow=(0.,0.,0.))
        self.assertTrue(result['cancellation_only'],result)
        self.assertIn('timed_out',result['pending_failure'])
        self.assertGreater(result['action'][0,6],0.)
        self.assertGreater(result['action'][0,3],0.)
        self.assertGreater(result['action'][0,4],0.)
        lag=np.abs(obs['controller_target'][:,[0,1,3]]-controller._measured(obs['joint_position']))
        self.assertTrue(np.all(lag<=controller.NORMAL_LAG+1e-8))
        integrate(obs,result['action'],follow=(0.,0.,0.))
        result=self.until(obs,controller,lambda r:bool(r['failure']),follow=(0.,0.,0.))
        self.assertFalse(result['debug']['unresolved_target_lag'])

    def test_scene_loss_cancels_all_three_targets_together_then_fails(self):
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'],follow=(.4,.4,.4))
        q=controller._measured(obs['joint_position']); t=obs['controller_target'][:,[0,1,3]].copy()
        with patch.object(pitch,'_cloth_evidence',side_effect=ValueError('current_cloth_lost')):
            result=controller.step(obs)
        self.assertTrue(result['cancellation_only'],result); self.assertIsNone(result['failure'])
        delta=result['action'][:,[3,4,6]]*controller.scales*.05
        np.testing.assert_allclose(delta[0],q[0]-t[0],atol=1e-9)
        integrate(obs,result['action'])
        result=self.until(obs,controller,lambda r:bool(r['failure']))
        self.assertIn('current_cloth_lost',result['failure']); self.assertFalse(result['experiment_completed'])
        self.assertFalse(result['debug']['unresolved_target_lag'])

    def test_incoherent_or_large_target_lag_requires_external_stop(self):
        for fault in ('pitch','lift','fixed','segment'):
            with self.subTest(fault=fault):
                obs,controller=self.construct()
                first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
                integrate(obs,first['action'])
                if fault=='pitch': obs['controller_target'][0,3]-=np.deg2rad(.7)
                if fault=='lift': obs['controller_target'][0,0]+=.0018
                if fault=='fixed': obs['controller_target'][0,4]+=.01
                if fault=='segment':
                    obs['joint_position'][0,4]+=.002; obs['joint_position'][0,5]-=.002
                with patch.object(pitch,'_cloth_evidence',side_effect=visible): result=controller.step(obs)
                self.assertIsNotNone(result['failure'],result)
                self.assertTrue(result['debug']['unresolved_target_lag']); self.assertFalse(result['skipped'])

    def test_joint_target_overrun_is_cancelled_without_reverse_pilot(self):
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'])
        # A coherent target just past the pilot endpoint is still disallowed.
        p=controller.goals[0]-np.deg2rad(.03)
        q=obs['joint_position']; q[0,9]=controller.goals[0]+np.deg2rad(.03)
        d=controller._pitch_delta(0,controller.u0[0,2],q[0,9])
        q[0,3]=controller.u0[0,0]-d[2]; q[0,4:8]=(controller.u0[0,1]-d[0])/4
        d=controller._pitch_delta(0,controller.u0[0,2],p)
        obs['controller_target'][0,[0,1,3]]=[controller.u0[0,0]-d[2],controller.u0[0,1]-d[0],p]
        obs['joint_velocity'][:]=0.; update_pose(obs)
        with patch.object(pitch,'_cloth_evidence',side_effect=visible): result=controller.step(obs)
        self.assertTrue(result['cancellation_only'],result)
        self.assertGreater(result['action'][0,6],0.)
        self.assertFalse(result['experiment_completed']); self.assertIn('negative_pilot',result['pending_failure'])

    def test_precommand_both_wrist_motion_spends_persistent_budget(self):
        obs,controller=self.construct()
        obs['joint_position'][:,9]-=np.deg2rad(3.)
        obs['controller_target'][:,3]=obs['joint_position'][:,9]
        obs['simulation_time_s'][...]+=.05
        result=controller.step(obs)
        self.assertFalse(result['skipped']); self.assertTrue(result['motion_started'])
        self.assertIsNotNone(result['failure'])
        np.testing.assert_allclose(result['debug']['measured_absolute_pitch_degrees'],[3.,3.])
        self.assertAlmostEqual(result['debug']['measured_total_absolute_pitch_degrees'],6.)

    def test_uncommanded_small_reversals_exhaust_absolute_budget_without_net_progress(self):
        obs,controller=self.construct()
        with patch.object(pitch,'_cloth_evidence',side_effect=visible):
            for i in range(60):
                obs['joint_position'][0,9]=controller.u0[0,2]+np.deg2rad(.025 if i%2 else -.025)
                obs['joint_velocity'][:]=0.; obs['simulation_time_s'][...]+=.05
                update_pose(obs)
                result=controller.step(obs)
                # No new pilot targets: waiting for real actuator stability.
                if result['failure']: break
        self.assertIsNotNone(result['failure'],result)
        self.assertGreater(result['debug']['measured_absolute_pitch_degrees'][0],2.49)
        self.assertLess(abs(np.rad2deg(obs['joint_position'][0,9]-controller.u0[0,2])),.026)
        self.assertFalse(result['skipped']); self.assertFalse(result['experiment_completed'])

    def test_unbounded_actual_pitch_velocity_cannot_be_hidden_by_zero_target_lag(self):
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'])
        obs['joint_velocity'][0,9]=np.deg2rad(-3.)
        with patch.object(pitch,'_cloth_evidence',side_effect=visible): result=controller.step(obs)
        self.assertIsNotNone(result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])
        self.assertIn('velocity',result['failure'])

    def test_base_or_center_drift_and_inactive_motion_abort(self):
        for fault in ('base','center','inactive'):
            with self.subTest(fault=fault):
                obs,controller=self.construct()
                first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
                integrate(obs,first['action'])
                if fault=='base': obs['base_pose_world'][1,1]+=.0031
                if fault=='center': obs['grasp_pose_base'][0,0]+=.0031
                if fault=='inactive': obs['joint_position'][1,9]-=np.deg2rad(.15)
                with patch.object(pitch,'_cloth_evidence',side_effect=visible): result=controller.step(obs)
                self.assertTrue(result['pending_failure'] or result['failure'],result)
                self.assertFalse(result['skipped']); self.assertFalse(result['experiment_completed'])

    def test_frozen_clock_and_cancellation_are_bounded(self):
        obs,controller=self.construct()
        with patch.object(pitch,'_cloth_evidence',side_effect=visible):
            for _ in range(452): result=controller.step(obs)
        self.assertTrue(result['skipped']); self.assertIn('timed_out',result['debug']['ineligible_reason'])
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'])
        with patch.object(pitch,'_cloth_evidence',side_effect=ValueError('cloth_lost')):
            result=controller.step(obs)
            for _ in range(42): result=controller.step(obs)
        self.assertIsNotNone(result['failure']); self.assertTrue(result['debug']['unresolved_target_lag'])

    def test_optional_inspection_stop_cancels_but_makes_no_opening_claim(self):
        obs,controller=self.construct()
        first=self.until(obs,controller,lambda r:np.any(r['action'][:,6]<0))
        integrate(obs,first['action'])
        with patch.object(pitch,'_cloth_evidence',side_effect=visible):
            result=controller.step(obs,stop_for_openings=True)
        self.assertTrue(result['cancellation_only']); self.assertIsNone(result['pending_failure'])
        integrate(obs,result['action'])
        result=self.until(obs,controller,lambda r:r['done'] or bool(r['failure']))
        self.assertTrue(result['early_stopped']); self.assertFalse(result['experiment_completed'])
        self.assertIn('did not verify',result['debug']['early_stop_basis'])


if __name__ == '__main__':
    unittest.main()
