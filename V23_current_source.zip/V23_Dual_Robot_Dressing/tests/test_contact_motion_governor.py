"""20 Hz integrated-target adversarial tests, not physics/contact validation."""
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
from contact_motion_governor import ContactMotionGovernor as Governor
from public_vision import _rotation
from test_loaded_pitch_observation import observation as pitch_observation, update_pose


def observation():
    obs = pitch_observation()
    obs['base_twist_world'] = np.zeros((2, 6), dtype=float)
    return obs


def request(base=(0., 0.), lift=0., arm=0.):
    result = np.zeros((2, 9), np.float32); result[:, 8] = 1.
    result[:, :2] = np.asarray(base)/.616
    result[:, 3] = lift/1.54; result[:, 4] = arm/1.21
    return result


def advance(obs, action, *, follow=(1., 1.), base_follow=(1., 1.), coast=None):
    q = obs['joint_position']; before = q.copy(); target = obs['controller_target']
    target[:, 0] += action[:, 3]*1.54*.05
    target[:, 1] += action[:, 4]*1.21*.05
    target[:, 6:8] = action[:, :2]*.616
    obs['base_twist_world'][:] = 0.
    for robot in (0, 1):
        q[robot, 3] += follow[robot]*(target[robot, 0]-q[robot, 3])
        q[robot, 4:8] += follow[robot]*(target[robot, 1]/4-q[robot, 4:8])
        rotation = _rotation(obs['base_pose_world'][robot, 3:])
        forward=rotation[:2,0]/np.linalg.norm(rotation[:2,0])
        planar=np.column_stack((forward,[-forward[1],forward[0]]))
        velocity = planar@(action[robot, :2]*.616)*base_follow[robot]
        if coast is not None: velocity = np.asarray(coast[robot])
        obs['base_pose_world'][robot, :2] += velocity*.05
        obs['base_twist_world'][robot, :2] = velocity
    obs['joint_velocity'] = (q-before)/.05
    update_pose(obs)
    obs['simulation_time_s'][...] += .05


class ContactMotionGovernorTests(unittest.TestCase):
    def ready(self, obs=None):
        obs = observation() if obs is None else obs
        governor = Governor(obs)
        for _ in range(8):
            result = governor.step(obs, request(), halt=True)
            self.assertIsNone(result['failure'], result)
            if result['settled']: return obs, governor
            advance(obs, result['action'])
        self.fail('Initial rest was not established')

    def check_action(self, result, max_speed=.01):
        action = result['action']
        self.assertEqual(action.shape, (2, 9))
        np.testing.assert_array_equal(action[:, [2, 5, 6, 7]], 0.)
        np.testing.assert_array_equal(action[:, 8], 1.)
        rates = action[:, Governor.COLUMNS]*Governor.SCALES
        self.assertLessEqual(float(np.linalg.norm(rates[:, :2], axis=1).max()), max_speed+1e-9)
        self.assertLessEqual(float(np.linalg.norm(rates[:, 2:], axis=1).max()), max_speed+1e-9)

    def test_initial_handoff_requires_actual_rest_for_200ms(self):
        obs = observation(); governor = Governor(obs)
        result = governor.step(obs, request(lift=.003))
        self.assertFalse(result['settled']); self.assertTrue(result['cancellation_only'])
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        for _ in range(3):
            advance(obs, result['action']); result = governor.step(obs, request(lift=.003))
            self.assertFalse(result['settled'])
        advance(obs, result['action']); result = governor.step(obs, request(lift=.003))
        self.assertTrue(result['settled'])
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        advance(obs, result['action']); result = governor.step(obs, request(lift=.003))
        self.assertGreater(result['action'][0, 3], 0.)

    def test_previous_base_velocity_handoff_never_reports_zero_command_as_stopped(self):
        obs = observation(); obs['base_twist_world'][:, 0] = .03
        obs['controller_target'][:, 6] = .03
        governor = Governor(obs)
        result = governor.step(obs, request(base=(.003, 0.)))
        self.assertIsNone(result['failure']); self.assertFalse(result['settled'])
        self.assertEqual(result['debug']['common_command_scale'], 0.)
        for _ in range(4):
            advance(obs, result['action'], coast=[[.005,0],[.005,0]])
            result = governor.step(obs, request(base=(.003,0.)))
            self.assertIsNone(result['failure'], result); self.assertFalse(result['settled'])
        for _ in range(6):
            advance(obs, result['action']); result = governor.step(obs, request(), halt=True)
        self.assertTrue(result['settled'])

    def test_common_scale_covers_both_robots_every_axis_and_next_target_lead(self):
        obs, governor = self.ready()
        proposal = request(base=(.006,.004), lift=.008, arm=.005)
        proposal[1, :2] *= -.5; proposal[1, 3:5] *= .5
        advance(obs, request())
        result = governor.step(obs, proposal)
        self.assertIsNone(result['failure'], result); self.check_action(result)
        alpha = result['debug']['common_command_scale']
        self.assertGreater(alpha, 0.); self.assertLess(alpha, 1.)
        np.testing.assert_allclose(result['action'][:, Governor.COLUMNS], proposal[:, Governor.COLUMNS]*alpha, rtol=1e-6)
        predicted = np.asarray(result['debug']['outgoing_linear_target_lag_m'])
        self.assertLessEqual(np.abs(predicted).max(), .0003+1e-9)

    def test_contact_three_mm_rate_and_unequal_target_lag_are_bounded(self):
        obs, governor = self.ready(); proposal = request(lift=.003, arm=-.003)
        result = None
        for _ in range(50):
            advance(obs, request() if result is None else result['action'], follow=(.7,.4))
            result=governor.step(obs, proposal, max_speed_mps=.003)
            self.assertIsNone(result['failure'], result); self.check_action(result, .003)
            self.assertLessEqual(np.abs(np.asarray(result['debug']['outgoing_linear_target_lag_m'])).max(), .0003+1e-9)

    def test_halt_cancels_arm_and_lift_with_one_common_fraction(self):
        obs, governor = self.ready()
        obs['controller_target'][:, 0] += [.0004, -.0002]
        obs['controller_target'][:, 1] += [-.0003, .0001]
        advance(obs, request(), follow=(0.,0.))
        result = governor.step(obs, request(base=(.003,0.)), halt=True, max_speed_mps=.003)
        self.assertIsNone(result['failure']); self.assertTrue(result['cancellation_only'])
        self.assertFalse(result['settled']); self.assertEqual(result['debug']['common_command_scale'],0.)
        np.testing.assert_array_equal(result['action'][:, :3], 0.)
        before_lag = obs['controller_target'][:, :2]-np.column_stack((obs['joint_position'][:,3], obs['joint_position'][:,4:8].sum(1)))
        rate = result['action'][:,3:5]*[1.54,1.21]
        np.testing.assert_allclose(rate*.05, -before_lag*result['debug']['cancellation_common_fraction'], atol=1e-11)
        for _ in range(20):
            advance(obs,result['action'],follow=(0.,0.))
            result=governor.step(obs,request(),halt=True,max_speed_mps=.003)
            self.assertIsNone(result['failure'],result)
            if result['settled']:break
        self.assertTrue(result['settled'])
        self.assertLess(np.abs(obs['controller_target'][:,:2]-np.column_stack((obs['joint_position'][:,3],obs['joint_position'][:,4:8].sum(1)))).max(), 1e-8)

    def test_same_timestamp_never_duplicates_integrated_target_cancel(self):
        obs, governor = self.ready();obs['controller_target'][:,0]+=.0003
        advance(obs,request(),follow=(0.,0.))
        first=governor.step(obs,request(),halt=True,max_speed_mps=.003)
        second=governor.step(obs,request(),halt=True,max_speed_mps=.003)
        self.assertLess(first['action'][0,3],0.)
        np.testing.assert_array_equal(second['action'][:,:8],0.)
        self.assertFalse(second['settled']);self.assertEqual(second['debug']['common_command_scale'],0.)

    def test_invalid_proposal_cancels_before_latching_failure(self):
        obs,governor=self.ready();obs['controller_target'][:,1]+=.0003
        advance(obs,request(),follow=(0.,0.));bad=request();bad[:,6]=.01
        result=governor.step(obs,bad,max_speed_mps=.003)
        self.assertIsNone(result['failure']);self.assertEqual(result['pending_failure'],'unsupported_proposed_action')
        self.assertTrue(result['cancellation_only']);self.assertLess(result['action'][0,4],0.)
        for _ in range(20):
            advance(obs,result['action'],follow=(0.,0.))
            result=governor.step(obs,request(),halt=True,max_speed_mps=.003)
            if result['failure']:break
        self.assertEqual(result['failure'],'unsupported_proposed_action')
        self.assertFalse(result['debug']['unresolved_target_lag'])

    def test_excess_pending_linear_motion_fails_explicitly_unresolved(self):
        obs,governor=self.ready();obs['controller_target'][:,0]+=.0005;obs['controller_target'][:,1]+=.0003
        advance(obs,request(),follow=(0.,0.))
        result=governor.step(obs,request(),halt=True)
        self.assertIn('0_75mm',result['failure']);self.assertTrue(result['debug']['unresolved_target_lag'])
        self.assertFalse(result['settled']);np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_individual_arm_stage_residual_cannot_hide_behind_zero_sum(self):
        obs,governor=self.ready();obs['joint_position'][:,4]+=.0002;obs['joint_position'][:,5]-=.0002
        update_pose(obs);obs['simulation_time_s'][...]+=.05
        result=governor.step(obs,request(),halt=True)
        self.assertFalse(result['settled']);self.assertTrue(result['cancellation_only'])
        # Aggregate cancellation is zero, but individual driven joints remain.
        np.testing.assert_array_equal(result['action'][:,:8],0.)
        for _ in range(35):
            advance(obs,result['action'],follow=(0.,0.))
            result=governor.step(obs,request(),halt=True)
            if result['failure']:break
        self.assertIn('rest_timeout',result['failure']);self.assertTrue(result['debug']['unresolved_target_lag'])

    def test_one_frozen_arm_stops_both_then_fails_after_bounded_stall(self):
        obs,governor=self.ready();result=None;max_good_move=0.;start=obs['joint_position'][0,3]
        for _ in range(90):
            advance(obs,request() if result is None else result['action'],follow=(1.,0.))
            result=governor.step(obs,request(lift=.003),max_speed_mps=.003)
            max_good_move=max(max_good_move,obs['joint_position'][0,3]-start)
            if result['pending_failure'] or result['failure']:break
        self.assertIn('no_measured_pair_progress',result['pending_failure'] or result['failure'])
        self.assertLessEqual(max_good_move,.0003+1e-8)

    def test_one_frozen_base_cannot_accumulate_other_robot_translation(self):
        obs,governor=self.ready();result=None;start=obs['base_pose_world'][:,:2].copy()
        for _ in range(90):
            advance(obs,request() if result is None else result['action'],base_follow=(1.,0.))
            result=governor.step(obs,request(base=(.003,0.)),max_speed_mps=.003)
            if result['pending_failure'] or result['failure']:break
        self.assertIn('no_measured_pair_progress',result['pending_failure'] or result['failure'])
        self.assertLessEqual(np.linalg.norm(obs['base_pose_world'][0,:2]-start[0]),.00075+1e-8)

    def test_only_one_requested_robot_can_make_legitimate_progress(self):
        obs,governor=self.ready();proposal=request(lift=.001);proposal[1,:8]=0.;result=None
        for _ in range(75):
            advance(obs,request() if result is None else result['action'])
            result=governor.step(obs,proposal,max_speed_mps=.003)
            self.assertIsNone(result['failure'],result);self.assertIsNone(result['pending_failure'],result)

    def test_missing_clock_jump_fixed_wrist_velocity_and_fixed_yaw_fail_closed(self):
        for fault in ('missing','clock','wrist_lag','wrist_velocity','yaw','measured_velocity'):
            obs,governor=self.ready();advance(obs,request())
            if fault=='missing':del obs['controller_target']
            if fault=='clock':obs['simulation_time_s'][...]+=.2
            if fault=='wrist_lag':obs['controller_target'][0,3]+=.001
            if fault=='wrist_velocity':obs['joint_velocity'][1,9]=.01
            if fault=='yaw':obs['controller_target'][0,8]=.01
            if fault=='measured_velocity':obs['base_twist_world'][0,0]=.02
            result=governor.step(obs,request(lift=.003),max_speed_mps=.003)
            self.assertIsNotNone(result['failure'],(fault,result));self.assertTrue(result['debug']['unresolved_target_lag'])
            np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_yaw_and_tilt_use_official_horizontal_forward_perpendicular_left(self):
        obs=observation()
        # Unit quaternion with simultaneous tilt and heading: simply projecting
        # both X and Y would not keep planar columns perpendicular.
        q=np.array([.96,.12,.16,.20]);q/=np.linalg.norm(q)
        obs['base_pose_world'][0,3:]=q
        state=Governor._read(obs)
        planar=state['planar'][0]
        np.testing.assert_allclose(planar.T@planar,np.eye(2),atol=1e-12)
        forward=_rotation(q)[:2,0];forward/=np.linalg.norm(forward)
        np.testing.assert_allclose(planar[:,0],forward,atol=1e-12)
        np.testing.assert_allclose(planar[:,1],[-forward[1],forward[0]],atol=1e-12)

    def test_outgoing_workspace_limit_cancels_without_clipping_to_another_goal(self):
        obs=observation();obs['joint_position'][:,3]=obs['controller_target'][:,0]=1.1949
        update_pose(obs);obs,governor=self.ready(obs)
        advance(obs,request());result=governor.step(obs,request(lift=.003))
        self.assertIsNone(result['failure']);self.assertEqual(result['pending_failure'],'proposed_linear_target_outside_own_workspace')
        np.testing.assert_array_equal(result['action'][:,:8],0.)

    def test_cancellation_latches_failure_if_actual_velocity_never_settles(self):
        obs,governor=self.ready();result=None
        for _ in range(36):
            advance(obs,request() if result is None else result['action'],coast=[[.0004,0],[.0004,0]])
            result=governor.step(obs,request(),halt=True,max_speed_mps=.003)
            if result['failure']:break
        self.assertIsNotNone(result['failure']);self.assertIn('rest_timeout',result['failure'])
        self.assertFalse(result['settled']);self.assertTrue(result['debug']['unresolved_target_lag'])


if __name__=='__main__':unittest.main()
