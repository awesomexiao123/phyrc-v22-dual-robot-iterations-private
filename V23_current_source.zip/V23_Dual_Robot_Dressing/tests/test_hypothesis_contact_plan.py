"""Synthetic public camera surfaces and own poses; no simulator or cuff truth."""
import copy
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import hypothesis_contact_plan as plan
from camera_geometry import pixel_rays, project_optical
from human_targets import _camera_transform, _world_pixels, _validated, _FOCAL
from public_vision import _rotation


def scene(pitch_degrees=30.):
    bases = np.zeros((2, 7)); bases[:, :3] = [[-.8, -.16, 0.], [.8, -.16, 0.]]
    bases[:, 3] = [1., 0.]; bases[1, 6] = 1.
    pitch = np.deg2rad(pitch_degrees)
    grasp = np.zeros((2, 7)); grasp[:, :3] = [.60, 0., 1.18]
    grasp[:, 3] = np.cos(pitch/2); grasp[:, 5] = np.sin(pitch/2)
    q = np.zeros((2, 13)); q[:, 3] = 1.18-.17822049558+.29535798728*np.sin(pitch)
    q[:, 4:8] = .075; q[:, 9] = pitch; q[:, 11:13] = .103
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.zeros((5, 256, 256, 1), float), depth_valid=np.zeros((5, 256, 256, 1), bool),
        base_pose_world=bases, grasp_pose_base=grasp, joint_position=q,
        gripper_close_command=np.ones((2, 1), bool), fingertip_origin_distance=np.full((2, 1), .02),
        simulation_time_s=np.array(10.))
    hands = np.array([[-.20, 0., 1.14], [.20, 0., 1.14]])
    axis = np.array([0., np.sqrt(.75), -.5])
    values = _validated(obs, wrists=True)
    yy, xx = np.indices((256, 256)); rays = pixel_rays(xx, yy, _FOCAL)
    for camera in (3, 4):
        rotation, origin = _camera_transform(values, camera)
        world_ray = rays @ rotation.T
        for hand in hands:
            # Two actual finite patches of horizontal visible skin, not hidden hands.
            depth = (hand[2]-origin[2])/world_ray[..., 2]
            points = origin+world_ray*depth[..., None]
            hit = (depth > .03) & (np.linalg.norm(points-hand, axis=2) < .019)
            obs['rgb'][camera][hit] = [200, 150, 150]
            obs['depth'][camera, ..., 0][hit] = depth[hit]
            obs['depth_valid'][camera, ..., 0][hit] = True
    _, grasps, _, _, _ = plan._snapshot(obs)
    hypotheses, rows = [], []
    for robot in (0, 1):
        rotation, origin = _camera_transform(values, 3)
        optical = (grasps[robot]+[0., -.015, -.008]-origin) @ rotation
        u, v = np.rint(project_optical(optical, _FOCAL)).astype(int)
        uv = np.column_stack((np.full(7, u), np.arange(v-3, v+4)))
        obs['rgb'][3, uv[:, 1], uv[:, 0]] = [10, 20, 230]
        obs['depth'][3, uv[:, 1], uv[:, 0], 0] = optical[2]
        obs['depth_valid'][3, uv[:, 1], uv[:, 0], 0] = True
        arc = _world_pixels(values, 3, uv[:, 0], uv[:, 1], np.full(7, optical[2]))
        point = arc[3]
        hypotheses.append(dict(robot_index=robot, observation_time_s=10., camera_index=3,
            edge_point_world=point.tolist(), edge_source_pixel_uv=[int(u), int(v)],
            measured_edge_depth_z_m=float(optical[2]), current_grasp_world=grasps[robot].tolist(),
            edge_from_current_grasp_world=(point-grasps[robot]).tolist(),
            arc_source_pixels_uv=uv.tolist(), arc_measured_points_world=arc.tolist()))
        rows.append(dict(robot_index=robot, current_grasp_world=grasps[robot].tolist(),
            hypothesis_available=True, ambiguous=False, ambiguous_camera_indices=[], current_camera_agreement=[],
            initial_size_prior=dict(initial_candidate_index=robot, initial_observed_boundary_span_m=.17,
                initial_boundary_observation_time_s=1., initial_boundary_camera_index=4)))
    edges = dict(detected=True, distinct_current_regions=True, observation_time_s=10., hypotheses=hypotheses, robots=rows)
    surfaces = []
    for index, hand in enumerate(hands):
        view = dict(camera_index=3, hand_index=index, axis_world=axis.tolist(),
            axis_sign='measured_hand_toward_one_sided_visible_proximal_surface',
            proximal_observed_surface_point_world=(hand+.17*axis).tolist())
        surfaces.append(dict(hand_index=index, hand_surface_world=hand.tolist(), axis_world=None,
            status='single_view_candidate', candidate_views=[view], conflicting_pairs=[],
            axis_sign='hand_surface_toward_visible_proximal_surface', supporting_parallax_pairs=[]))
    return obs, edges, dict(detected=True, hand_points_world=hands.tolist(), observation_time_s=10.), \
        dict(hand_surfaces=surfaces, observation_time_s=10.)


class HypothesisContactPlanTests(unittest.TestCase):
    def call(self, data, **kwargs):
        return plan.plan_hypothesis_contact(*data, **kwargs)

    def test_actual_pixels_offsets_and_distal_footprint_form_hypothesis_without_hole(self):
        data = scene(); original = copy.deepcopy(data); result = self.call(data)
        self.assertTrue(result['available'], result)
        self.assertTrue(result['contains_weak_single_view_evidence'])
        self.assertEqual(result['robot_to_hand_assignment'], [0, 1])
        self.assertFalse(result['motion_authorized'])
        self.assertFalse(result['closed_opening_required'])
        self.assertFalse(result['physical_opening_verified'])
        self.assertNotIn('action', result)
        for robot, model in enumerate(result['per_robot_hypotheses']):
            hand_index = model['hand_index']; hand = result['hand_surface_observations'][hand_index]
            axis = np.asarray(result['robot_ordered_axis_world'][robot])
            down = np.asarray(model['projected_gravity_down_world'])
            self.assertAlmostEqual(axis @ down, 0., places=10)
            self.assertLess(down[2], 0)
            self.assertAlmostEqual(model['hypothesized_radius_m'], .17/np.pi)
            np.testing.assert_allclose(model['radius_hypothesis_bounds_m'], [.034, .068])
            target = np.asarray(result['target_grasps_world'][robot])
            expected = (np.asarray(hand['inferred_visible_distal_footprint_center_world'])-.02*axis
                        -.17/np.pi*down-np.asarray(model['edge_from_current_grasp_world']))
            np.testing.assert_allclose(target, expected, atol=1e-12)
            distal = np.asarray(hand['actual_distal_surface_point_world'])
            self.assertAlmostEqual((distal-np.asarray(model['target_hypothesized_mouth_center_world'])) @ axis, .02)
            self.assertGreater(np.linalg.norm(model['edge_from_current_grasp_world']), .005)
            self.assertTrue(1.18 < target[2] < 1.24)  #1.14m hands, not old1.29m staging target.
        values = _validated(data[0], wrists=True)
        for point, source in zip(result['skin_surface_points_world'], result['skin_surface_source_pixels']):
            u, v = source['source_pixel_uv']; camera = source['camera_index']
            measured = _world_pixels(values, camera, u, v, data[0]['depth'][camera, v, u, 0])
            np.testing.assert_allclose(point, measured, atol=1e-12)
        for key in data[0]:
            np.testing.assert_array_equal(data[0][key], original[0][key])
        self.assertEqual(data[1:], original[1:])

    def test_current_pitch_reach_is_diagnostic_and_never_silently_clamps_goal(self):
        lower, higher = scene(25.), scene(41.)
        a, b = self.call(lower), self.call(higher)
        self.assertTrue(a['available'], a)
        self.assertTrue(b['available'], b)
        np.testing.assert_allclose(a['target_grasps_world'], b['target_grasps_world'], atol=1e-12)
        self.assertTrue(a['feasibility']['lift_reachable_at_current_wrist'])
        self.assertFalse(b['feasibility']['lift_reachable_at_current_wrist'])
        self.assertGreater(max(b['feasibility']['predicted_lift_joint_positions_m']), 1.185)

    def test_common_base_translation_not_rejected_as_fixed_base_arm_overreach(self):
        obs, _, _, _ = scene()
        bases, grasps, yaw, _, _ = plan._snapshot(obs)
        goals = grasps+[.25, 0., 0.]
        result = plan._feasibility(obs, bases, grasps, yaw, goals, np.array([[8., 8., 8.]]), .015)
        self.assertFalse(result['fixed_base_alignment_arm_feasible'])
        self.assertTrue(result['alignment_then_common_translation_arm_feasible'])
        self.assertTrue(result['common_translation_requires_base_xy_route'])
        self.assertTrue(result['common_translation_keeps_measured_arm_extension'])
        self.assertTrue(result['endpoint_travel_within_30cm'])
        self.assertTrue(result['feasible_at_current_wrist'])

    def test_travel_and_stretch_limits_are_reported_without_changing_requested_geometry(self):
        obs, _, _, _ = scene()
        bases, grasps, yaw, _, _ = plan._snapshot(obs)
        long = plan._feasibility(obs, bases, grasps, yaw, grasps+[0., .31, 0.], np.array([[8., 8., 8.]]), .015)
        self.assertFalse(long['endpoint_travel_within_30cm'])
        self.assertFalse(long['feasible_at_current_wrist'])
        wider = grasps+np.array([[-.03, 0., 0.], [.03, 0., 0.]])
        stretched = plan._feasibility(obs, bases, grasps, yaw, wider, np.array([[8., 8., 8.]]), .015)
        self.assertFalse(stretched['span_does_not_exceed_initial_plus_2cm'])
        self.assertFalse(stretched['feasible_at_current_wrist'])
        data = scene(); data[0]['joint_position'][0, 3] = 1.21
        self.assertFalse(self.call(data)['available'])

    def test_housing_collision_is_seen_even_when_grasp_center_is_far_from_skin(self):
        obs, _, _, _ = scene()
        bases, grasps, yaw, _, _ = plan._snapshot(obs)
        rotation = _rotation(bases[0, 3:]) @ _rotation(obs['grasp_pose_base'][0, 3:])
        skin = (grasps[0]+rotation @ np.array([-.17, 0., 0.]))[None]
        self.assertGreater(np.linalg.norm(skin[0]-grasps[0]), .15)
        result = plan._feasibility(obs, bases, grasps, yaw, grasps, skin, .015)
        self.assertTrue(result['observed_housing_screen'][0]['observed_housing_conflict'])
        self.assertEqual(result['observed_housing_screen'][0]['conservative_straight_translation_distance_lower_bound_m'], 0.)
        self.assertFalse(result['full_gripper_skin_swept_clearance_verified'])

    def test_stale_or_inconsistent_evidence_never_fabricates_a_current_plan(self):
        for fault in ('edge_time', 'hand_time', 'axis_time', 'pixel', 'offset', 'ambiguity', 'same_initial_edge'):
            with self.subTest(fault=fault):
                data = scene(); obs, edges, hands, forearms = data
                if fault == 'edge_time': edges['hypotheses'][0]['observation_time_s'] = 9.9
                elif fault == 'hand_time': hands['observation_time_s'] = 9.9
                elif fault == 'axis_time': forearms['observation_time_s'] = 9.9
                elif fault == 'pixel':
                    u, v = edges['hypotheses'][0]['edge_source_pixel_uv']; obs['depth_valid'][3, v, u, 0] = False
                elif fault == 'offset': edges['hypotheses'][0]['edge_from_current_grasp_world'][2] += .01
                elif fault == 'ambiguity': edges['robots'][0]['ambiguous'] = True
                else: edges['robots'][1]['initial_size_prior']['initial_candidate_index'] = 0
                result = self.call(data)
                self.assertFalse(result['available'], result)
                self.assertIsNone(result['target_grasps_world'])

    def test_hand_or_axis_missing_conflicting_or_gravity_degenerate_returns_unknown(self):
        for fault in ('missing_skin', 'wrong_color', 'view_conflict', 'hand_identity', 'vertical_axis'):
            with self.subTest(fault=fault):
                data = scene(); obs, _, hands, forearms = data
                if fault in ('missing_skin', 'wrong_color'):
                    skin = (obs['rgb'][..., 0] == 200)
                    if fault == 'missing_skin': obs['depth_valid'][skin] = False
                    else: obs['rgb'][skin] = [150, 150, 150]
                elif fault == 'view_conflict': forearms['hand_surfaces'][0]['conflicting_pairs'] = [dict(camera_indices=[3, 4])]
                elif fault == 'hand_identity': forearms['hand_surfaces'][0]['hand_surface_world'][0] += .03
                else:
                    for index, surface in enumerate(forearms['hand_surfaces']):
                        view = surface['candidate_views'][0]; view['axis_world'] = [0., 0., -1.]
                        view['proximal_observed_surface_point_world'] = (np.asarray(hands['hand_points_world'][index])+[0., 0., -.17]).tolist()
                self.assertFalse(self.call(data)['available'])

    def test_closed_controls_and_actual_gap_required_without_claiming_attachment(self):
        for fault in ('open', 'gap', 'nan'):
            data = scene()
            if fault == 'open': data[0]['gripper_close_command'][1] = False
            else: data[0]['fingertip_origin_distance'][1] = .09 if fault == 'gap' else np.nan
            self.assertFalse(self.call(data)['available'])
        result = self.call(scene())
        self.assertFalse(result['attachment_verified'])

    def test_role_swap_and_world_yaw_do_not_change_world_geometry(self):
        data = scene(); initial = self.call(data); self.assertTrue(initial['available'], initial)
        obs, edges, hands, forearms = data
        for key in ('base_pose_world', 'grasp_pose_base', 'joint_position', 'gripper_close_command', 'fingertip_origin_distance'):
            obs[key] = obs[key][::-1].copy()
        for key in ('rgb', 'depth', 'depth_valid'):
            obs[key][[1, 2]] = obs[key][[2, 1]]; obs[key][[3, 4]] = obs[key][[4, 3]]
        edges['hypotheses'].reverse(); edges['robots'].reverse()
        for robot in (0, 1):
            edges['hypotheses'][robot]['robot_index'] = robot; edges['hypotheses'][robot]['camera_index'] = 4
            edges['robots'][robot]['robot_index'] = robot
        swapped = self.call(data)
        self.assertTrue(swapped['available'], swapped)
        self.assertEqual(swapped['robot_to_hand_assignment'], [1, 0])
        np.testing.assert_allclose(swapped['target_grasps_world'], initial['target_grasps_world'][::-1], atol=1e-10)
        # Common world yaw changes coordinates, not the gravity-based hypothesis.
        data = scene(); obs, edges, hands, forearms = data
        angle = .55; c, s = np.cos(angle), np.sin(angle)
        R = np.array([[c, -s, 0.], [s, c, 0.], [0., 0., 1.]])
        translation = np.array([.1, -.3, .04])
        obs['base_pose_world'][:, :3] = obs['base_pose_world'][:, :3] @ R.T+translation
        for robot, yaw in enumerate((angle, angle+np.pi)):
            obs['base_pose_world'][robot, 3:] = [np.cos(yaw/2), 0., 0., np.sin(yaw/2)]
        hands['hand_points_world'] = (np.asarray(hands['hand_points_world']) @ R.T+translation).tolist()
        for item, row in zip(edges['hypotheses'], edges['robots']):
            for key in ('edge_point_world', 'current_grasp_world'):
                item[key] = (R @ item[key]+translation).tolist()
            item['edge_from_current_grasp_world'] = (R @ item['edge_from_current_grasp_world']).tolist()
            item['arc_measured_points_world'] = (np.asarray(item['arc_measured_points_world']) @ R.T+translation).tolist()
            row['current_grasp_world'] = (R @ row['current_grasp_world']+translation).tolist()
        for surface in forearms['hand_surfaces']:
            surface['hand_surface_world'] = (R @ surface['hand_surface_world']+translation).tolist()
            for view in surface['candidate_views']:
                view['axis_world'] = (R @ view['axis_world']).tolist()
                view['proximal_observed_surface_point_world'] = (R @ view['proximal_observed_surface_point_world']+translation).tolist()
        rotated = self.call(data)
        self.assertTrue(rotated['available'], rotated)
        np.testing.assert_allclose(rotated['target_grasps_world'], np.asarray(initial['target_grasps_world']) @ R.T+translation, atol=1e-9)


if __name__ == '__main__':
    unittest.main()
