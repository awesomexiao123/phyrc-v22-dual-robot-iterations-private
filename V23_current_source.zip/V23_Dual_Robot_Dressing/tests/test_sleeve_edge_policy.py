"""Public boundary evidence must survive the actual pre-contact handoff."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import sleeve_edge_policy as edge
import cooperative_policy as cooperative
from test_sleeve_pair_policy import Baseline, observation


def proposal(now=10.):
    return dict(detected=True, observation_time_s=now,
        candidates=[{'target_world': [-.3, 0., .6]}, {'target_world': [.3, 0., .6]}])


class EdgePolicyTests(unittest.TestCase):
    def actor(self):
        with patch.object(cooperative, 'baseline_class', return_value=Baseline):
            actor = edge.Policy('unused.pt')
        actor.shirt = proposal(9.); actor.shirt_observed_at = 9.
        return actor

    def test_handoff_uses_current_measured_boundary_and_preserves_old_timestamp(self):
        actor = self.actor(); fresh = proposal()
        fresh['candidates'][0]['target_world'][0] += .005
        with patch.object(edge, 'estimate_planar_sleeve_edges', return_value=fresh), \
                patch.object(edge.SleeveSidePolicy, '_prepare_pair') as prepare:
            actor._prepare_pair(observation())
        prepare.assert_called_once()
        self.assertEqual(actor.shirt_observed_at, 10.)
        self.assertEqual(actor.shirt['prior_pair_observed_at_s'], 9.)
        self.assertAlmostEqual(actor.shirt['prior_to_handoff_shift_m'][0], .005)
        self.assertNotIn('prior_pair_observed_at_s', fresh)

    def test_missing_stale_or_displaced_edges_do_not_fall_back_to_interior_patch(self):
        for fault in ('missing', 'stale', 'displaced'):
            actor = self.actor(); original = deepcopy(actor.shirt); fresh = proposal()
            if fault == 'missing': fresh['detected'] = False
            elif fault == 'stale': fresh['observation_time_s'] = 9.95
            else: fresh['candidates'][1]['target_world'][0] += .031
            with self.subTest(fault=fault), \
                    patch.object(edge, 'estimate_planar_sleeve_edges', return_value=fresh), \
                    patch.object(edge.SleeveSidePolicy, '_prepare_pair') as prepare:
                with self.assertRaises(ValueError): actor._prepare_pair(observation())
                prepare.assert_not_called()
                self.assertEqual(actor.shirt, original)
                self.assertEqual(actor.shirt_observed_at, 9.)


if __name__ == '__main__':
    unittest.main()
