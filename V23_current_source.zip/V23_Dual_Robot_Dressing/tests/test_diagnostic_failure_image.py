"""A terminal failure must retain its public still after transition quota use."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('v23_adapter_diagnostic_test', ROOT/'participant/policy.py')
adapter = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(adapter)


class FailureStillTests(unittest.TestCase):
    def test_failure_after_transition_quota_keeps_one_still(self):
        with tempfile.TemporaryDirectory() as directory:
            diagnostic = adapter.Diagnostics(Path(directory), 1)
            diagnostic.transition_images = 10
            diagnostic.previous = ('pair_testlift', None, None, None)
            diagnostic.image = Mock()
            obs = {key: np.zeros(1) for key in ('simulation_time_s', 'base_pose_world',
                'grasp_pose_base', 'joint_position', 'joint_velocity', 'controller_target',
                'base_twist_world', 'gripper_close_command', 'fingertip_origin_distance')}
            obs['rgb'] = np.zeros((5, 256, 256, 3), np.uint8)
            debug = dict(step=2476, phase='stopped', failure='visual evidence unavailable')
            diagnostic.write(obs, np.zeros((2, 9), np.float32), debug)
            diagnostic.image.assert_called_once()
            diagnostic.write(obs, np.zeros((2, 9), np.float32), dict(debug, step=2477))
            diagnostic.image.assert_called_once()


if __name__ == '__main__':
    unittest.main()
