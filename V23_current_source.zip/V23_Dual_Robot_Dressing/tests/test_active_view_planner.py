"""Public RGB-D fixtures and measured-joint planning checks, no robot executor."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import active_view_planner as planner


def scene():
    base = np.zeros((2, 7)); base[:, 3] = 1.; base[:, 0] = (-1., 1.)
    local = np.zeros((2, 7)); local[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.zeros((5, 256, 256, 1), np.float32),
               depth_valid=np.zeros((5, 256, 256, 1), bool),
               base_pose_world=base, grasp_pose_base=local,
               joint_position=np.zeros((2, 13)), simulation_time_s=0.,
               gripper_close_command=np.ones((2, 1), bool),
               fingertip_origin_distance=np.full((2, 1), .02))
    for x in (80, 176):
        for y, color in ((92, (10, 20, 230)), (192, (190, 150, 120))):
            obs['rgb'][3, y-12:y+13, x-12:x+13] = color
            obs['depth'][3, y-12:y+13, x-12:x+13, 0] = 1.
            obs['depth_valid'][3, y-12:y+13, x-12:x+13, 0] = True
    values = planner._validated(obs, wrists=True)
    grasps = planner._world_pixels(values, 3, np.array([80, 176]), np.array([92, 92]), np.ones(2))
    hands = planner._world_pixels(values, 3, np.array([80, 176]), np.array([192, 192]), np.ones(2))
    obs['grasp_pose_base'][:, :3] = grasps-base[:, :3]
    report = dict(grasp_regions=[dict(grasp_index=r, grasp_world=grasps[r].tolist(),
        observed_cloth_point_count=625, opening_visible_in_rgbd=False) for r in (0, 1)])
    detected = dict(detected=True, hand_points_world=hands.tolist(), cross_view_error_m=.01, confidence=.8)
    return obs, grasps, report, detected


def settled(state, obs, grasps, report, start=0.):
    result = None
    for index in range(12):
        obs['simulation_time_s'] = start+index*.05
        result = state.recommend(obs, grasps, report)
    return result


class ActiveViewPlannerTests(unittest.TestCase):
    def test_depth_supported_stable_pair_proposes_one_five_degree_wrist_only_and_no_executor(self):
        obs, grasps, report, hands = scene()
        original = copy.deepcopy(obs)
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            result = settled(state, obs, grasps, report)
        self.assertEqual(result['recommendation'], 'wrist_scan_candidate')
        proposal = result['candidate']
        self.assertEqual((proposal['robot'], proposal['axis'], proposal['action_index']), (0, 'pitch', 6))
        self.assertAlmostEqual(abs(proposal['proposed_delta_degrees']), 5.)
        self.assertGreater(min(result['observation_evidence']['minimum_observed_distance_m']), .28)
        self.assertNotIn('action', result)
        for key in ('motion_executor_included', 'attachment_verified', 'collision_free_verified', 'insertion_allowed'):
            self.assertFalse(result[key])
        self.assertTrue(result['constraints']['grasp_center_feedback_compensation_required'])
        self.assertTrue(result['constraints']['no_head_camera_action'])
        for key in original:
            if key != 'simulation_time_s':
                np.testing.assert_array_equal(obs[key], original[key])

    def test_frozen_clock_never_establishes_stability_and_grasp_drift_resets_window(self):
        obs, grasps, report, hands = scene()
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            for _ in range(20):
                result = state.recommend(obs, grasps, report)
                self.assertEqual(result['recommendation'], 'hold')
            for index in range(7):
                obs['simulation_time_s'] = .05*index
                state.recommend(obs, grasps, report)
            obs['grasp_pose_base'][0, 0] += .006
            grasps[0, 0] += .006; report['grasp_regions'][0]['grasp_world'] = grasps[0].tolist()
            obs['simulation_time_s'] = .4
            result = state.recommend(obs, grasps, report)
            self.assertEqual(result['recommendation'], 'hold')
            self.assertIn('not_stable', result['reason'])

    def test_all_visible_fabric_checked_including_patch_far_from_both_grips(self):
        obs, grasps, report, hands = scene()
        # Another visible piece by the second hand is more than .5m from grips.
        obs['rgb'][3, 188:193, 177:182] = [10, 20, 230]
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            result = settled(state, obs, grasps, report)
        self.assertEqual(result['recommendation'], 'hold')
        self.assertEqual(result['reason'], 'observed_garment_too_close_to_a_hand_surface')
        self.assertLess(result['observation_evidence']['minimum_observed_distance_m'][1], .05)

    def test_missing_hands_depth_closed_state_or_stale_report_cannot_propose(self):
        for fault in ('missing_hand', 'single_view', 'cloth_depth', 'hand_depth', 'open', 'gap', 'stale_report'):
            with self.subTest(fault=fault):
                obs, grasps, report, hands = scene()
                if fault == 'missing_hand':
                    hands['detected'] = False
                elif fault == 'single_view':
                    hands['cross_view_error_m'] = None
                elif fault == 'cloth_depth':
                    obs['depth_valid'][3, 80:100, 68:93] = False
                elif fault == 'hand_depth':
                    obs['depth_valid'][3, 180:205, 164:189] = False
                elif fault == 'open':
                    obs['gripper_close_command'][1, 0] = False
                elif fault == 'gap':
                    obs['fingertip_origin_distance'][0, 0] = .11
                else:
                    report['grasp_regions'][0]['grasp_world'][0] += .02
                with patch.object(planner, 'estimate_hands', return_value=hands):
                    result = settled(planner.CandidateActiveViewPlanner(), obs, grasps, report)
                self.assertEqual(result['recommendation'], 'hold')
                self.assertIsNone(result['candidate'])

    def test_repeated_unexecuted_plan_is_same_absolute_target_then_measured_budget_stops_after_ten_degrees(self):
        obs, grasps, report, hands = scene()
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            first = settled(state, obs, grasps, report)['candidate']
            for index in range(12):
                obs['simulation_time_s'] = .6+index*.05
                result = state.recommend(obs, grasps, report)
                self.assertEqual(result['candidate'], first)
                self.assertEqual(result['measured_cumulative_scan_degrees'], 0.)
            obs['joint_position'][0, 9] = first['target_angle_rad']
            obs['simulation_time_s'] = 1.2
            reached = state.recommend(obs, grasps, report)
            self.assertEqual(reached['recommendation'], 'hold')
            self.assertEqual(reached['completed_scans'], 1)
            second = settled(state, obs, grasps, report, start=1.25)['candidate']
            self.assertEqual((second['robot'], second['axis'], second['action_index']), (1, 'roll', 7))
            obs['joint_position'][1, 10] = second['target_angle_rad']
            obs['simulation_time_s'] = 1.85
            reached = state.recommend(obs, grasps, report)
            self.assertAlmostEqual(reached['measured_cumulative_scan_degrees'], 10.)
            result = settled(state, obs, grasps, report, start=1.9)
            self.assertEqual(result['recommendation'], 'hold')
            self.assertIn('budget_finished', result['reason'])

    def test_return_motion_spends_budget_and_other_robot_cannot_move_during_pending_scan(self):
        obs, grasps, report, hands = scene()
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            settled(state, obs, grasps, report)
            for index, degrees in enumerate((4., 0.)):
                obs['joint_position'][0, 9] = np.deg2rad(degrees)
                obs['simulation_time_s'] = .6+index*.05
                result = state.recommend(obs, grasps, report)
            self.assertIn('remaining_cumulative_budget', result['failure'])
            self.assertAlmostEqual(result['measured_cumulative_scan_degrees'], 8.)
            self.assertEqual(result['recommendation'], 'hold')
        obs, grasps, report, hands = scene()
        state = planner.CandidateActiveViewPlanner()
        with patch.object(planner, 'estimate_hands', return_value=hands):
            settled(state, obs, grasps, report)
            obs['joint_position'][1, 10] = np.deg2rad(1.)
            obs['simulation_time_s'] = .6
            result = state.recommend(obs, grasps, report)
        self.assertIn('unplanned_other_wrist', result['failure'])

    def test_visible_opening_is_not_insertion_permission_and_robot_selection_is_symmetric(self):
        for visible_robot in (0, 1):
            obs, grasps, report, hands = scene()
            report['grasp_regions'][visible_robot]['opening_visible_in_rgbd'] = True
            with patch.object(planner, 'estimate_hands', return_value=hands):
                result = settled(planner.CandidateActiveViewPlanner(), obs, grasps, report)
            self.assertEqual(result['candidate']['robot'], 1-visible_robot)
            self.assertFalse(result['insertion_allowed'])
        for region in report['grasp_regions']:
            region['opening_visible_in_rgbd'] = True
        with patch.object(planner, 'estimate_hands', return_value=hands):
            result = settled(planner.CandidateActiveViewPlanner(), obs, grasps, report)
        self.assertEqual(result['recommendation'], 'hold')
        self.assertIn('resolve_identity', result['reason'])
        self.assertFalse(result['collision_free_verified'])


if __name__ == '__main__':
    unittest.main()
