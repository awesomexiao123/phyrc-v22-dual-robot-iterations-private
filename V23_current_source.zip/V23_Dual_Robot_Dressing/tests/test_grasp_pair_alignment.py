"""CPU pose integration for bounded two-end adjustment, not cloth simulation."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import grasp_pair_alignment as alignment
from public_vision import grasp_world

NEUTRAL_GRASP_X = .4662579894065857
PITCH_PIVOT_TO_GRASP_X = .29535798728466034


def observation(yaws=(0., np.pi)):
    grasps = np.array([[-.3, 0, 1.], [.3, 0, 1.]])
    bases = np.zeros((2, 7)); bases[:, 3] = 1.
    local = np.array([[.7, -.08, 1., 1, 0, 0, 0]]*2, float)
    for robot, yaw in enumerate(yaws):
        bases[robot, 3:] = [np.cos(yaw/2), 0, 0, np.sin(yaw/2)]
        bases[robot, :2] = grasps[robot, :2] - alignment._rotation(bases[robot, 3:])[:2, :2] @ local[robot, :2]
    joints = np.zeros((2, 13), float)
    joints[:, 3] = local[:, 2]-.1782204955816269
    joints[:, 4:8] = (local[:, 0]-NEUTRAL_GRASP_X)[:, None]/4
    joints[:, 11:13] = .103
    return dict(base_pose_world=bases, grasp_pose_base=local,
                joint_position=joints, joint_velocity=np.zeros((2, 13), float),
                gripper_close_command=np.ones((2, 1), bool),
                fingertip_origin_distance=np.full((2, 1), .04),
                simulation_time_s=np.array(0.), depth=np.zeros((5, 256, 256, 1), np.float32),
                depth_valid=np.zeros((5, 256, 256, 1), bool))


def desired(angle=15.):
    axis = np.array([np.cos(np.deg2rad(angle)), np.sin(np.deg2rad(angle)), 0.])
    return np.stack([-.19*axis+[0, 0, 1.02], .19*axis+[0, 0, 1.02]])


def free_guard(obs, robot, body, **kwargs):
    return {'body_velocity_xy': np.asarray(body).tolist(), 'reason': 'synthetic free guard'}


def integrate(obs, action, moving=(True, True)):
    for robot in (0, 1):
        if not moving[robot]:
            continue
        rotation = alignment._rotation(obs['base_pose_world'][robot, 3:])
        obs['base_pose_world'][robot, :2] += rotation[:2, :2] @ (action[robot, :2]*.616*.05)
        obs['grasp_pose_base'][robot, 0] += action[robot, 4]*1.21*.05
        obs['grasp_pose_base'][robot, 2] += action[robot, 3]*1.54*.05
        obs['joint_position'][robot, 4:8] += action[robot, 4]*1.21*.05/4
        obs['joint_position'][robot, 3] += action[robot, 3]*1.54*.05
    obs['simulation_time_s'][...] += .05


class GraspPairAlignmentTests(unittest.TestCase):
    def test_lift_joint_limit_uses_measured_lift_not_world_grasp_height(self):
        obs, _ = self.pitched_observation()
        obs['joint_position'][:, 3] = 1.19
        current = np.stack([grasp_world(obs, r) for r in (0, 1)])
        for rise, accepted in ((.004, True), (.006, False)):
            with self.subTest(rise=rise):
                controller = alignment.GraspPairAlignment(obs, current+[0., 0., rise])
                self.assertEqual(controller.failure is None, accepted)
                if not accepted:
                    self.assertIn('lift joint range', controller.failure)
                    np.testing.assert_array_equal(controller.step(obs)['action'][:, :8], 0.)

    def test_lift_output_preserves_joint_margin_for_both_robots(self):
        obs = observation()
        obs['joint_position'][:, 3] = 1.194
        current = np.stack([grasp_world(obs, r) for r in (0, 1)])
        controller = alignment.GraspPairAlignment(obs, current+[0., 0., .001])
        self.assertIsNone(controller.failure)
        # A near-limit measured change between calls cannot be overridden by
        # a still-lagging world-height error; the whole pair uses one scale.
        obs['joint_position'][0, 3] = 1.195-1e-6
        obs['simulation_time_s'][...] += .05
        with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
            result = controller.step(obs)
        self.assertIsNone(result['failure'])
        delta = result['action'][:, 3]*1.54*.05
        self.assertLessEqual(delta[0], 1.0001e-6)
        self.assertLessEqual(delta[1], 1.0001e-6)

    @staticmethod
    def pitched_observation(grasp_x=.76):
        """Recorded R1 wrist posture, with explicit consistent synthetic stages.

        Public v09 step 1865 R1 grasp quaternion was
        [0.93672490,-0.00002747,0.35006636,-0.00001790], about +41 degrees.
        We round pitch to 41 degrees and use the own static lever, not hidden
        scene geometry; these arm positions are constructed, not recorded.
        """
        obs = observation()
        pitch = np.deg2rad(41.)
        offset = NEUTRAL_GRASP_X+PITCH_PIVOT_TO_GRASP_X*(np.cos(pitch)-1)
        obs['grasp_pose_base'][:, 0] = grasp_x
        obs['grasp_pose_base'][:, 3:] = [np.cos(pitch/2), 0., np.sin(pitch/2), 0.]
        obs['joint_position'][:, 4:8] = (grasp_x-offset)/4
        obs['joint_position'][:, 9] = pitch
        obs['joint_position'][:, 3] = 1.-.1782204955816269+PITCH_PIVOT_TO_GRASP_X*np.sin(pitch)
        return obs, offset

    @staticmethod
    def target_local_x(obs, value):
        return np.stack([grasp_world(obs, r)+alignment._rotation(obs['base_pose_world'][r, 3:])[:, 0]*
                         (value-obs['grasp_pose_base'][r, 0]) for r in (0, 1)])

    def test_recorded_41_degree_posture_rejects_917mm_and_accepts_892mm(self):
        for target_x, accepted in ((.917, False), (.892, True)):
            with self.subTest(target_x=target_x):
                obs, offset = self.pitched_observation()
                controller = alignment.GraspPairAlignment(obs, self.target_local_x(obs, target_x))
                bounds = np.asarray(controller.arm_workspace['guarded_grasp_x_bounds_m'])
                np.testing.assert_allclose(bounds[:, 1], .908809505, atol=1e-8)
                np.testing.assert_allclose(bounds[:, 0], .48)
                self.assertEqual(controller.failure is None, accepted)
                if accepted:
                    with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
                        result = controller.step(obs)
                    self.assertIsNone(result['failure'])
                    self.assertIn('public joint_position', result['debug']['arm_workspace']['source'])
                    np.testing.assert_allclose(result['debug']['arm_workspace']['zero_extension_grasp_x_m'], offset)
                else:
                    self.assertIn('wrist-dependent own arm reach', controller.failure)
                    np.testing.assert_array_equal(controller.step(obs)['action'][:, :8], np.zeros((2, 8)))

    def test_workspace_is_per_robot_and_retains_legacy_envelope(self):
        obs, offset = self.pitched_observation()
        obs['joint_position'][0, 4:8] = (obs['grasp_pose_base'][0, 0]-NEUTRAL_GRASP_X)/4
        obs['joint_position'][0, 9] = 0.
        obs['grasp_pose_base'][0, 3:] = [1., 0., 0., 0.]
        targets = self.target_local_x(obs, .892)
        controller = alignment.GraspPairAlignment(obs, targets)
        self.assertIsNone(controller.failure)
        np.testing.assert_allclose(controller.arm_workspace['guarded_grasp_x_bounds_m'],
                                   [[.48, .92], [.48, offset+.515]])
        # A posture with extra physical reach still cannot expand the old .92m envelope.
        target = np.stack([grasp_world(obs, r) for r in (0, 1)])
        target[0] = self.target_local_x(obs, .925)[0]
        self.assertIn('reach', alignment.GraspPairAlignment(obs, target).failure)

    def test_missing_nonfinite_wrong_shape_or_out_of_range_joints_latch_stop(self):
        for at_start in (True, False):
            for mode in ('missing', 'nan', 'inf_other_joint', 'shape', 'low', 'high'):
                with self.subTest(at_start=at_start, mode=mode):
                    obs = observation()
                    controller = None if at_start else alignment.GraspPairAlignment(obs, desired())
                    if mode == 'missing': del obs['joint_position']
                    if mode == 'nan': obs['joint_position'][0, 4] = np.nan
                    if mode == 'inf_other_joint': obs['joint_position'][1, 0] = np.inf
                    if mode == 'shape': obs['joint_position'] = obs['joint_position'][:, :12]
                    if mode == 'low': obs['joint_position'][0, 4] = -.002
                    if mode == 'high': obs['joint_position'][1, 7] = .14  # Total remains below .52m.
                    if at_start:
                        controller = alignment.GraspPairAlignment(obs, desired())
                    result = controller.step(obs)
                    self.assertIsNotNone(result['failure'])
                    np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                    np.testing.assert_array_equal(result['action'][:, 8], np.ones(2))
                    self.assertEqual(controller.step(observation())['failure'], result['failure'])

    def test_measured_extension_entering_five_mm_margin_stops_pair(self):
        obs, offset = self.pitched_observation()
        controller = alignment.GraspPairAlignment(obs, self.target_local_x(obs, .892))
        obs['grasp_pose_base'][0, 0] = offset+.516
        obs['joint_position'][0, 4:8] = .516/4
        result = controller.step(obs)
        self.assertIn('measured arm reach outside wrist-dependent', result['failure'])
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))

    def test_outgoing_rate_cannot_cross_posture_dependent_joint_margin(self):
        _, offset = self.pitched_observation()
        upper = offset+.515
        obs, _ = self.pitched_observation(grasp_x=upper-.0001)
        controller = alignment.GraspPairAlignment(obs, self.target_local_x(obs, upper))
        obs['simulation_time_s'][...] = .05
        with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
            result = controller.step(obs)
        self.assertIsNone(result['failure'])
        self.assertGreater(result['debug']['common_constraint_scale'], 0.)
        self.assertLess(result['debug']['common_constraint_scale'], 1.)
        predicted_x = obs['grasp_pose_base'][:, 0]+result['action'][:, 4]*1.21*.05
        self.assertTrue(np.all(predicted_x <= upper+1e-9))
        self.assertTrue(np.all(result['action'][:, 4] > 0.))
        integrate(obs, result['action'])
        self.assertTrue(np.all(obs['joint_position'][:, 4:8].sum(axis=1) <= .515+1e-9))

    def test_actual_pose_feedback_compresses_sixty_to_thirty_eight_cm_and_rotates_fifteen_degrees(self):
        for yaws in ((0., np.pi), (np.pi/2, -np.pi/2), (-np.pi/2, np.pi/2)):
            for angle in (-15., 15.):
                with self.subTest(yaws=yaws, angle=angle):
                    obs = observation(yaws); target = desired(angle)
                    controller = alignment.GraspPairAlignment(obs, target)
                    initial = obs['base_pose_world'].copy()
                    with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
                        for _ in range(420):
                            result = controller.step(obs)
                            self.assertIsNone(result['failure'], result)
                            action = result['action']
                            np.testing.assert_array_equal(action[:, [0, 2, 5, 6, 7]], np.zeros((2, 5)))
                            np.testing.assert_array_equal(action[:, 8], np.ones(2))
                            self.assertLessEqual(result['debug']['maximum_reference_advance_m'], .000500001)
                            self.assertTrue(np.all(np.linalg.norm(result['debug']['command_world_velocities'], axis=1) <= .010000001))
                            self.assertLessEqual(result['debug']['measured_grasp_span_m'], .62000001)
                            if result['done']:
                                break
                            integrate(obs, action)
                    self.assertTrue(result['done'], result)
                    measured = np.stack([grasp_world(obs, r) for r in (0, 1)])
                    np.testing.assert_allclose(measured, target, atol=.003)
                    self.assertAlmostEqual(np.linalg.norm(measured[1]-measured[0]), .38, delta=.004)
                    final_angle = np.rad2deg(np.arctan2(*(measured[1]-measured[0])[[1, 0]]))
                    self.assertAlmostEqual(final_angle, angle, delta=1.)
                    np.testing.assert_array_equal(obs['base_pose_world'][:, 3:], initial[:, 3:])
                    for robot, yaw in enumerate(yaws):
                        forward = np.array([np.cos(yaw), np.sin(yaw)])
                        self.assertAlmostEqual(forward @ (obs['base_pose_world'][robot, :2]-initial[robot, :2]), 0., places=7)
                    self.assertTrue(np.all(controller.endpoint_travel <= .30))
                    self.assertTrue(np.all(controller.base_lateral_travel <= .15))
                    np.testing.assert_array_equal(controller.step(obs)['action'][:, :8], np.zeros((2, 8)))

    def test_frozen_observation_cannot_advance_reference_or_finish_and_eventually_stops(self):
        obs = observation(); controller = alignment.GraspPairAlignment(obs, desired())
        with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(80):
                result = controller.step(obs)
            self.assertEqual(controller.reference_fraction, 0.)
            self.assertFalse(result['done'])
            for _ in range(260):
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
                if result['failure']:
                    break
        self.assertIn('no measured pair progress', result['failure'])
        self.assertFalse(result['done'])
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))

    def test_one_endpoint_lag_pauses_common_fraction(self):
        for delayed in (0, 1):
            with self.subTest(delayed=delayed):
                obs = observation(); controller = alignment.GraspPairAlignment(obs, desired())
                with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
                    for _ in range(100):
                        result = controller.step(obs)
                        self.assertIsNone(result['failure'])
                        if result['debug']['pause_reference_for_lag']:
                            self.assertEqual(result['debug']['reference_advance_fraction'], 0.)
                            break
                        integrate(obs, result['action'], moving=(delayed != 0, delayed != 1))
                self.assertTrue(result['debug']['pause_reference_for_lag'])
                self.assertFalse(result['done'])

    def test_guard_stop_on_either_base_stops_both_whole_endpoints_without_leaking_old_motion(self):
        for blocked_robot in (0, 1):
            with self.subTest(blocked_robot=blocked_robot):
                obs = observation(); controller = alignment.GraspPairAlignment(obs, desired())
                obs['simulation_time_s'][...] += .05
                with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
                    moving = controller.step(obs)
                self.assertTrue(np.any(moving['action'][:, :8]))
                integrate(obs, moving['action'])
                reference_before = controller.reference_fraction
                def blocked(o, robot, body, **kwargs):
                    return {'body_velocity_xy': [0., 0.] if robot == blocked_robot else np.asarray(body).tolist()}
                with patch.object(alignment, 'guard_base_velocity', side_effect=blocked):
                    result = controller.step(obs)
                self.assertIsNone(result['failure'])
                self.assertTrue(result['debug']['navigation_paused_pair'])
                self.assertEqual(controller.reference_fraction, reference_before)
                np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                np.testing.assert_array_equal(result['action'][:, 8], np.ones(2))

    def test_invalid_reach_span_endpoint_or_lateral_targets_stop_without_clamping(self):
        for mode in ('reach', 'span', 'endpoint', 'lateral'):
            with self.subTest(mode=mode):
                obs = observation(); target = np.stack([grasp_world(obs, r) for r in (0, 1)])
                if mode == 'reach': target[0, 0] += .25
                if mode == 'span': target[:, 0] += [-.02, .02]
                if mode == 'endpoint': target[:, 2] += .31
                if mode == 'lateral': target[:, 1] += .16
                controller = alignment.GraspPairAlignment(obs, target)
                with patch.object(alignment, 'guard_base_velocity') as guard:
                    result = controller.step(obs)
                    guard.assert_not_called()
                self.assertIsNotNone(result['failure'])
                self.assertIn(mode if mode != 'span' else 'span', result['failure'])
                np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                np.testing.assert_array_equal(result['action'][:, 8], np.ones(2))

    def test_small_repeated_uncommanded_deviations_are_checked_against_original_reference(self):
        obs = observation(); controller = alignment.GraspPairAlignment(obs, desired())
        with patch.object(alignment, 'guard_base_velocity', side_effect=free_guard):
            for _ in range(6):
                obs['grasp_pose_base'][1, 2] += .01
                obs['simulation_time_s'][...] += .05
                result = controller.step(obs)
                if result['failure']:
                    break
        self.assertIn('cumulative tracking deviation', result['failure'])
        self.assertFalse(result['done'])
        np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))

    def test_closed_reach_tilt_yaw_forward_and_measured_span_guards_latch(self):
        for mode in ('closed', 'gap', 'reach', 'tilt', 'yaw', 'forward', 'span'):
            with self.subTest(mode=mode):
                obs = observation(); controller = alignment.GraspPairAlignment(obs, desired())
                if mode == 'closed': obs['gripper_close_command'][1] = False
                if mode == 'gap': obs['fingertip_origin_distance'][0] = .09
                if mode == 'reach': obs['grasp_pose_base'][0, 0] = .93
                if mode == 'tilt': obs['base_pose_world'][0, 3:] = [np.cos(.05), np.sin(.05), 0., 0.]
                if mode == 'yaw': obs['base_pose_world'][0, 3:] = [np.cos(.02), 0., 0., np.sin(.02)]
                if mode == 'forward': obs['base_pose_world'][0, 0] += .02
                if mode == 'span': obs['grasp_pose_base'][:, 0] -= .011
                result = controller.step(obs)
                self.assertIsNotNone(result['failure'])
                np.testing.assert_array_equal(result['action'][:, :8], np.zeros((2, 8)))
                self.assertEqual(controller.step(observation())['failure'], result['failure'])


if __name__ == '__main__':
    unittest.main()
