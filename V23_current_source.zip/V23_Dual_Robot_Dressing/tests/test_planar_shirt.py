"""Repeatable synthetic public geometry; no simulator or garment mesh labels."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import planar_shirt as shirt


def strip(center, axis, extent, camera=3, elongation=5):
    return dict(centroid_world=list(center), principal_axis_world=list(axis), extent_m=extent,
                camera_index=camera, confidence=.6, elongation=elongation)


def synthetic_t(rectangle=False):
    x, y = np.meshgrid(np.arange(-.5, .501, .01), np.arange(0, .651, .01))
    shape = (np.abs(x) <= .255) | ((y >= .43) & (y <= .63))
    if rectangle:
        shape = np.abs(x) <= .255
    points = np.column_stack((x[shape], y[shape], np.full(np.count_nonzero(shape), .75)))
    cloud = dict(world_points=points, camera_ids=np.full(len(points), 3),
                 rgb=np.tile(np.array([10, 20, 220], np.uint8), (len(points), 1)))
    edges = [strip([0, .02, .75], [1, 0, 0], .50),
             strip([0, .56, .75], [1, 0, 0], .12)]
    return cloud, edges


def curved_collar(kind='v'):
    """Actual observed V/round contour geometry summarized as the public PCA.

    The V's shoulders, like the round contour's endpoints, lie transverse to
    garment length. Its principal axis therefore points along the hem.
    """
    if kind == 'v':
        x = np.linspace(-.075, .075, 81)
        y = .53+.8*np.abs(x)
    else:
        angle = np.linspace(-np.pi/2, np.pi/2, 81)
        x = .075*np.sin(angle)
        y = .59-.045*np.cos(angle)
    points = np.column_stack((x, y, np.full(len(x), .75)))
    center = np.median(points, axis=0)
    _, singular, axes = np.linalg.svd(points-center, full_matrices=False)
    extent = float(np.ptp(np.percentile((points-center)@axes[0], [5, 95])))
    return strip(center, axes[0], extent, elongation=singular[0]/singular[1])


def estimate(cloud, edges):
    with patch.object(shirt, 'cloth_cloud', return_value=cloud), \
         patch.object(shirt, 'garment_edge_candidates', return_value={'yellow_trim_candidates': edges}):
        return shirt.estimate_planar_shirt({})


class PlanarShirtTest(unittest.TestCase):
    def test_flat_t_proposes_supported_blue_points_without_opening_claim(self):
        cloud, edges = synthetic_t()
        result = estimate(cloud, edges)
        self.assertTrue(result['detected'])
        self.assertFalse(result['opening_verified'])
        self.assertFalse(result['anatomical_left_right_verified'])
        self.assertEqual(len(result['candidates']), 2)
        for candidate in result['candidates']:
            point = np.asarray(candidate['target_world'])
            self.assertLess(np.min(np.linalg.norm(cloud['world_points']-point, axis=1)), 1e-10)
            self.assertGreaterEqual(candidate['support_pixel_count'], 24)
            self.assertGreater(abs(point[0]), .3)
            self.assertTrue(candidate['heuristic'])
        self.assertGreater(result['candidate_span_m'], .6)

    def test_v_neck_and_round_contours_with_transverse_axis_are_compatible(self):
        for kind in ('v', 'round'):
            with self.subTest(contour=kind):
                cloud, edges = synthetic_t()
                edges[1] = curved_collar(kind)
                self.assertGreater(abs(np.dot(edges[0]['principal_axis_world'], edges[1]['principal_axis_world'])), .99)
                result = estimate(cloud, edges)
                self.assertTrue(result['detected'])
                self.assertEqual(result['compatible_pair_count'], 1)
                self.assertEqual(len(result['candidates']), 2)
                self.assertFalse(result['opening_verified'])
                self.assertFalse(result['collar_principal_axis_is_orientation_constraint'])

    def test_collar_position_still_must_follow_garment_length(self):
        cloud, edges = synthetic_t()
        edges[1] = strip([.35, .30, .75], [1, 0, 0], .12)
        result = estimate(cloud, edges)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'unknown_no_compatible_hem_collar_pair')

    def test_nonplanar_fold_abstains(self):
        cloud, edges = synthetic_t()
        cloud['world_points'][:, 2] += .25*np.sin(cloud['world_points'][:, 0]*8)
        result = estimate(cloud, edges)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'unknown_fabric_not_sufficiently_planar')

    def test_sparse_boundary_depth_outliers_are_excluded_from_targets(self):
        cloud, edges = synthetic_t()
        original = cloud['world_points'].copy()
        count = int(.03*len(original))
        # Simulate blue boundary pixels inheriting distant floor depth, without
        # making any assumption about the plane's world height in the detector.
        outliers = original[np.linspace(0, len(original)-1, count).astype(int)].copy()
        outliers[:, 1] -= 1.0
        outliers[:, 2] -= .7
        cloud['world_points'] = np.concatenate((original, outliers))
        cloud['camera_ids'] = np.full(len(cloud['world_points']), 3)
        cloud['rgb'] = np.tile([10, 20, 220], (len(cloud['world_points']), 1)).astype(np.uint8)
        result = estimate(cloud, edges)
        self.assertTrue(result['detected'])
        self.assertGreater(result['plane']['spatial_inlier_fraction'], .94)
        self.assertLess(result['plane']['spatial_inlier_fraction'], .99)
        self.assertEqual(result['plane']['rejected_blue_pixel_count'], count)
        self.assertGreaterEqual(result['plane']['connected_inlier_fraction'], .97)
        for candidate in result['candidates']:
            self.assertLess(np.min(np.linalg.norm(original-candidate['target_world'], axis=1)), 1e-10)

    def test_real_second_fold_cannot_be_discarded_as_a_depth_tail(self):
        cloud, edges = synthetic_t()
        # Two genuine fabric planes; the majority plane alone must not pass.
        cloud['world_points'][cloud['world_points'][:, 0] > .30, 2] += .16
        result = estimate(cloud, edges)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'unknown_fabric_not_sufficiently_planar')
        self.assertLess(result['plane']['spatial_inlier_fraction'], .94)

    def test_dense_fold_pixels_cannot_hide_behind_voxel_reduction(self):
        cloud, edges = synthetic_t()
        folded = cloud['world_points'][:80].copy()
        folded[:, 2] += .15
        folded = np.repeat(folded, 10, axis=0)
        cloud['world_points'] = np.concatenate((cloud['world_points'], folded))
        cloud['camera_ids'] = np.full(len(cloud['world_points']), 3)
        cloud['rgb'] = np.tile([10, 20, 220], (len(cloud['world_points']), 1)).astype(np.uint8)
        result = estimate(cloud, edges)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'unknown_fabric_not_sufficiently_planar')
        self.assertGreater(result['plane']['spatial_inlier_fraction'], .94)
        self.assertLess(result['plane']['pixel_inlier_fraction'], .94)

    def test_separate_flat_blue_pieces_are_not_one_connected_garment(self):
        cloud, edges = synthetic_t()
        detached = cloud['world_points'][:, 0] > .30
        cloud['world_points'][detached, 0] += .30
        result = estimate(cloud, edges)
        self.assertFalse(result['detected'])
        self.assertEqual(result['reason'], 'unknown_disconnected_planar_fabric_support')
        self.assertLess(result['plane']['connected_inlier_fraction'], .97)

    def test_two_competing_collars_abstain(self):
        for center in ([.05, .52, .75], [.02, .54, .75]):
            with self.subTest(second_collar=center):
                cloud, edges = synthetic_t()
                edges.append(strip(center, [1, 0, 0], .13))
                result = estimate(cloud, edges)
                self.assertFalse(result['detected'])
                self.assertEqual(result['reason'], 'unknown_ambiguous_hem_collar_pairs')

    def test_same_strip_from_second_camera_is_not_a_second_collar(self):
        cloud, edges = synthetic_t()
        edges.append(strip([.005, .56, .75], [-1, 0, 0], .12, camera=4))
        result = estimate(cloud, edges)
        self.assertTrue(result['detected'])
        self.assertEqual(len(result['collar_hypothesis']['cameras']), 2)

    def test_rectangle_with_trim_is_not_claimed_as_sleeve_side_shape(self):
        for collar in (strip([0, .56, .75], [1, 0, 0], .12), curved_collar('v'), curved_collar('round')):
            with self.subTest(collar_axis=collar['principal_axis_world']):
                cloud, edges = synthetic_t(rectangle=True)
                edges[1] = collar
                result = estimate(cloud, edges)
                self.assertFalse(result['detected'])
                self.assertEqual(result['compatible_pair_count'], 1)
                self.assertEqual(result['reason'], 'unknown_no_supported_wider_sleeve_side_shape')

    def test_missing_trim_or_one_side_support_abstains(self):
        cloud, edges = synthetic_t()
        self.assertFalse(estimate(cloud, edges[:1])['detected'])
        # Remove all but a few observed points on the right extension.
        keep = cloud['world_points'][:, 0] < .28
        for key in cloud:
            cloud[key] = cloud[key][keep]
        self.assertFalse(estimate(cloud, edges)['detected'])

    def test_rigid_transform_moves_targets_without_world_position_prior(self):
        cloud, edges = synthetic_t()
        original = estimate(cloud, edges)
        rotation = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1.]])
        translation = np.array([2., -1.5, .4])
        cloud['world_points'] = cloud['world_points']@rotation.T+translation
        for edge in edges:
            edge['centroid_world'] = (rotation@edge['centroid_world']+translation).tolist()
            edge['principal_axis_world'] = (rotation@edge['principal_axis_world']).tolist()
        transformed = estimate(cloud, edges)
        self.assertTrue(transformed['detected'])
        expected = np.array([c['target_world'] for c in original['candidates']])@rotation.T+translation
        actual = np.array([c['target_world'] for c in transformed['candidates']])
        for point in expected:
            self.assertLess(np.min(np.linalg.norm(actual-point, axis=1)), .025)


if __name__ == '__main__':
    unittest.main()
