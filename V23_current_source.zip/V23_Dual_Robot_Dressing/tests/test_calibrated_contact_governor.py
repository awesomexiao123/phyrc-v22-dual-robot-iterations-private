"""Biased synthetic dynamics around the real core; no physical contact claims."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
from calibrated_contact_governor import CalibratedContactGovernor
from contact_motion_governor import ContactMotionGovernor
from public_vision import _rotation
from test_contact_motion_governor import observation, request
from test_loaded_pitch_observation import update_pose


def fixture():
    obs = observation(); obs['simulation_time_s'][...] = 1.
    bias = np.tile([.0026, .001, .0001, -.004, .00008], (2, 1))
    offsets = np.tile([.00015, -.0001, .00005, -.0001], (2, 1))
    obs['joint_position'][:, 4:8] += offsets
    obs['controller_target'][:, :5] += bias
    obs['joint_velocity'][:, 3] = .0105; obs['joint_velocity'][:, 9] = -.022
    c = dict(observed_at_s=1., window_start_s=.5, frame_count=11,
        method='synthetic zero-input loaded window, not physical evidence',
        controller_bias=bias.tolist(), arm_position_offsets=offsets.tolist(),
        controller_bias_peak_deviation=np.zeros((2, 5)).tolist(),
        arm_position_offsets_peak_deviation=np.zeros((2, 4)).tolist(),
        raw_joint_velocity_median=obs['joint_velocity'].tolist(),
        raw_joint_velocity_peak_deviation=np.full((2, 13), .0001).tolist(),
        last_joint_position=obs['joint_position'].tolist(), last_base_pose=obs['base_pose_world'].tolist(),
        controller_target_reference=obs['controller_target'].tolist())
    return obs, c


def advance(obs, action, calibration, *, follow=(.7, .5), load_bias=None):
    """Fixed-bias plant plus separately reported instantaneous velocity offset."""
    q = obs['joint_position']; previous = q.copy(); target = obs['controller_target']
    bias = np.asarray(calibration['controller_bias'] if load_bias is None else load_bias)
    offsets = np.asarray(calibration['arm_position_offsets'])
    target[:, 0] += action[:, 3]*1.54*.05; target[:, 1] += action[:, 4]*1.21*.05
    target[:, 6:8] = action[:, :2]*.616
    obs['base_twist_world'][:] = 0.
    for r in (0, 1):
        q[r, 3] += follow[r]*(target[r, 0]-bias[r, 0]-q[r, 3])
        q[r, 4:8] += follow[r]*((target[r, 1]-bias[r, 1])/4+offsets[r]-q[r, 4:8])
        rotation = _rotation(obs['base_pose_world'][r, 3:])
        forward = rotation[:2, 0]/np.linalg.norm(rotation[:2, 0])
        planar = np.column_stack((forward, [-forward[1], forward[0]]))
        v = planar@(action[r, :2]*.616)
        obs['base_pose_world'][r, :2] += v*.05; obs['base_twist_world'][r, :2] = v
    obs['joint_velocity'] = np.asarray(calibration['raw_joint_velocity_median'])+(q-previous)/.05
    update_pose(obs); obs['simulation_time_s'][...] += .05


class CalibratedContactGovernorTests(unittest.TestCase):
    def ready(self, obs=None, c=None):
        if obs is None: obs, c = fixture()
        governor = CalibratedContactGovernor(obs, calibration=c)
        self.assertIsNone(governor.failure)
        for _ in range(30):
            r = governor.step(obs, request(), halt=True)
            self.assertIsNone(r['failure'], r)
            if r['settled']: return obs, c, governor
            advance(obs, r['action'], c)
        self.fail('Calibrated rest not reached')

    def until_rest(self, obs, c, governor, action, **kwargs):
        for _ in range(32):
            advance(obs, action, c, **kwargs)
            r = governor.step(obs, request(), halt=True, max_speed_mps=.003)
            self.assertIsNone(r['failure'], r)
            if r['settled']: return r
            action = r['action']
        self.fail('Cancellation/rest not bounded')

    def test_both_robots_lift_arm_pause_resume_preserve_bias_and_cumulative_motion(self):
        obs, c, g = self.ready(); start = obs['joint_position'].copy()
        self.assertIsInstance(g.core, ContactMotionGovernor)
        total_before = np.zeros(2); last = request()
        for sign in (1., -1.):
            for _ in range(25):
                advance(obs, last, c)
                r = g.step(obs, request(lift=.001*sign, arm=-.0008*sign), max_speed_mps=.003)
                self.assertIsNone(r['failure'], r); self.assertIsNone(r['pending_failure'])
                last = r['action']
            moved = obs['joint_position'][:, 3]-start[:, 3]
            if sign > 0: self.assertTrue(np.all(moved > .0007))
            r = self.until_rest(obs, c, g, last)
            current_path = np.asarray(r['motion_evidence']['cumulative_actual_endpoint_path_m'])
            self.assertTrue(np.all(current_path > total_before)); total_before = current_path
            measured = np.column_stack((obs['joint_position'][:, 3], obs['joint_position'][:, 4:8].sum(1)))
            np.testing.assert_allclose(obs['controller_target'][:, :2]-measured, np.asarray(c['controller_bias'])[:, :2], atol=2.5e-5)
            last = r['action']
        np.testing.assert_allclose(obs['joint_position'][:, 3], start[:, 3], atol=.0001)
        np.testing.assert_array_equal(g.calibration['controller_bias'], c['controller_bias'])

    def test_common_scale_and_same_frame_raw_excess_geometry_evidence(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        proposal = request(base=(.006, .004), lift=.008, arm=.005); proposal[1, :5] *= .5
        r = g.step(obs, proposal); alpha = r['debug']['common_command_scale']
        self.assertGreater(alpha, 0.); self.assertLess(alpha, 1.)
        np.testing.assert_allclose(r['action'][:, ContactMotionGovernor.COLUMNS],
                                   proposal[:, ContactMotionGovernor.COLUMNS]*alpha, rtol=1e-6)
        e = r['motion_evidence']; self.assertEqual(e['observation_time_s'], float(obs['simulation_time_s']))
        self.assertTrue(e['valid'])
        self.assertGreater(np.linalg.norm(e['raw_pending_translation_world'][0]), .002)
        self.assertLess(np.linalg.norm(e['excess_pending_translation_world'][0]), .000025)
        self.assertGreater(np.linalg.norm(e['raw_wrist_target_lag_rad'][0]), .003)
        self.assertFalse(e['native_arm_stage_targets_observed']); self.assertFalse(e['angular_sweep_bounded'])
        self.assertFalse(e['geometry_checked']); self.assertNotIn('individual_arm_target_lag_m', r['debug'])

    def test_cancel_new_lead_only_with_common_fraction_and_unchanged_baseline(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        proposal = request(lift=.003, arm=-.002); proposal[1, 3:5] *= .5
        r = g.step(obs, proposal, max_speed_mps=.003)
        advance(obs, r['action'], c, follow=(0., 0.))
        before = obs['controller_target'][:, :2].copy()
        e = before-np.column_stack((obs['joint_position'][:, 3], obs['joint_position'][:, 4:8].sum(1)))-np.asarray(c['controller_bias'])[:, :2]
        r = g.step(obs, request(), halt=True, max_speed_mps=.003)
        self.assertTrue(r['cancellation_only']); self.assertIsNone(r['failure'])
        np.testing.assert_allclose(r['action'][:, 3:5]*[1.54, 1.21]*.05,
                                   -e*r['debug']['cancellation_common_fraction'], atol=1e-11)
        r = self.until_rest(obs, c, g, r['action'], follow=(0., 0.))
        measured = np.column_stack((obs['joint_position'][:, 3], obs['joint_position'][:, 4:8].sum(1)))
        np.testing.assert_allclose(obs['controller_target'][:, :2]-measured, np.asarray(c['controller_bias'])[:, :2], atol=1e-8)

    def test_rest_requires_original_200ms_plus_actual_position_window(self):
        obs, c = fixture(); g = CalibratedContactGovernor(obs, calibration=c)
        r = g.step(obs, request(lift=.001))
        for _ in range(4):
            advance(obs, r['action'], c); r = g.step(obs, request(lift=.001))
            self.assertFalse(r['settled']); np.testing.assert_array_equal(r['action'][:, :8], 0.)
        for _ in range(10):
            advance(obs, r['action'], c); r = g.step(obs, request(), halt=True)
            if r['settled']: break
        self.assertTrue(r['settled']); self.assertGreaterEqual(float(obs['simulation_time_s'])-1., .4-1e-8)

    def test_nonzero_uncertainty_cannot_be_ignored_or_expand_rest_tolerance(self):
        obs, c = fixture(); c['controller_bias_peak_deviation'][0][0] = .00003
        g = CalibratedContactGovernor(obs, calibration=c); r = g.step(obs, request(), halt=True)
        for _ in range(35):
            self.assertFalse(r['settled']); advance(obs, r['action'], c)
            r = g.step(obs, request(), halt=True)
            if r['failure']: break
        self.assertIn('rest_timeout', r['failure'])

    def test_shape_changes_do_not_cancel_in_aggregate(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        obs['joint_position'][0, 4] += .0004; obs['joint_position'][0, 5] -= .0004
        r = g.step(obs, request(lift=.001))
        self.assertIn('0_75mm', r['failure']); self.assertFalse(r['settled'])
        np.testing.assert_array_equal(r['action'][:, :8], 0.)

    def test_raw_actual_and_predicted_limits_are_checked_separately(self):
        obs, c = fixture(); obs['controller_target'][0, 0] = 1.196
        c['controller_target_reference'] = obs['controller_target'].tolist()
        self.assertIn('raw_target', CalibratedContactGovernor(obs, calibration=c).step(obs, request())['failure'])
        obs, c = fixture(); obs['joint_position'][:, 3] = 1.1923
        obs['controller_target'][:, 0] = 1.1949; update_pose(obs)
        c['last_joint_position'] = obs['joint_position'].tolist(); c['controller_target_reference'] = obs['controller_target'].tolist()
        obs, c, g = self.ready(obs, c); advance(obs, request(), c)
        r = g.step(obs, request(lift=.003))
        self.assertIn('raw_target', r['failure']); np.testing.assert_array_equal(r['action'][:, :8], 0.)

    def test_target_prediction_mismatch_and_repeated_clock_never_hide_new_commands(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        r = g.step(obs, request(lift=.001)); calls = g.core.calls
        for _ in range(4):
            repeat = g.step(obs, request(lift=.001))
            np.testing.assert_array_equal(repeat['action'][:, :8], 0.)
            np.testing.assert_array_equal(repeat['motion_evidence']['proposed_interval_translation_world'], 0.)
            np.testing.assert_array_equal(repeat['motion_evidence']['predicted_next_raw_controller_target'], obs['controller_target'])
        self.assertEqual(g.core.calls, calls)
        advance(obs, r['action'], c); obs['controller_target'][0, 0] += .00002
        failure = g.step(obs, request())
        self.assertIn('previous_raw_prediction', failure['failure'])
        self.assertFalse(failure['motion_evidence']['valid'])
        self.assertFalse(failure['debug']['motion_evidence_valid'])
        self.assertIsNone(failure['motion_evidence']['observation_time_s'])
        self.assertEqual(failure['motion_evidence']['last_valid_observation_time_s'], r['motion_evidence']['observation_time_s'])
        self.assertEqual(failure['motion_evidence']['failed_observation_time_s'], float(obs['simulation_time_s']))

    def test_unsupported_proposal_cancels_before_terminal_failure_and_keeps_resolved_status(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        r = g.step(obs, request(lift=.002), max_speed_mps=.003)
        advance(obs, r['action'], c, follow=(0., 0.))
        invalid = request(); invalid[:, 5] = .1
        r = g.step(obs, invalid, max_speed_mps=.003)
        self.assertIsNone(r['failure']); self.assertEqual(r['pending_failure'], 'unsupported_proposed_action')
        self.assertTrue(r['cancellation_only']); self.assertTrue(np.all(r['action'][:, 3] < 0.))
        for _ in range(30):
            advance(obs, r['action'], c, follow=(0., 0.))
            r = g.step(obs, request(), halt=True, max_speed_mps=.003)
            if r['failure']: break
        self.assertEqual(r['failure'], 'unsupported_proposed_action')
        self.assertFalse(r['debug']['unresolved_target_lag'])
        self.assertFalse(r['cancellation_only'])
        repeat = g.step(obs, request())
        self.assertFalse(repeat['debug']['unresolved_target_lag'])
        self.assertFalse(repeat['motion_evidence']['valid'])

    def test_changed_same_clock_gap_and_missing_uncertainty_fail(self):
        for fault in ('changed_time', 'gap', 'uncertainty', 'stale'):
            obs, c = fixture()
            if fault == 'uncertainty': del c['arm_position_offsets_peak_deviation']
            if fault == 'stale': obs['simulation_time_s'][...] += .1
            g = CalibratedContactGovernor(obs, calibration=c)
            if fault == 'changed_time':
                g.step(obs, request()); obs['joint_velocity'][0, 3] += .001
            if fault == 'gap': obs['simulation_time_s'][...] += .1
            self.assertIsNotNone(g.step(obs, request())['failure'])

    def test_load_change_and_new_raw_velocity_anomaly_fail_without_rebaselining(self):
        for fault in ('load', 'raw_velocity'):
            obs, c, g = self.ready(); original = g.calibration['controller_bias'].copy()
            if fault == 'load':
                bias = np.asarray(c['controller_bias']).copy(); bias[:, 0] += .001
                advance(obs, request(), c, follow=(1., 1.), load_bias=bias)
            else:
                advance(obs, request(), c); obs['joint_velocity'][0, 3] += .1
            r = g.step(obs, request(), halt=True)
            self.assertIsNotNone(r['failure']); self.assertFalse(r['settled'])
            np.testing.assert_array_equal(g.calibration['controller_bias'], original)

    def test_first_raw_velocity_anomaly_evidence_persists_after_recovery(self):
        obs, c, g = self.ready(); advance(obs, request(), c)
        obs['joint_velocity'][1, 4] += .1
        first = g.step(obs, request(), halt=True)
        self.assertEqual(first['pending_failure'], 'new_raw_joint_velocity_anomaly')
        self.assertEqual(first['failure'], first['pending_failure'])
        evidence = deepcopy(first['debug']['first_raw_velocity_anomaly'])
        self.assertEqual(evidence['observation_time_s'], float(obs['simulation_time_s']))
        self.assertEqual(evidence['offending'][0]['robot'], 1)
        self.assertEqual(evidence['offending'][0]['joint_index'], 4)
        np.testing.assert_array_equal(evidence['raw_joint_velocity'], obs['joint_velocity'])
        np.testing.assert_array_equal(evidence['raw_joint_position'], obs['joint_position'])
        np.testing.assert_array_equal(evidence['raw_controller_target'], obs['controller_target'])
        first['debug']['first_raw_velocity_anomaly']['offending'][0]['limit'] = 999.
        for _ in range(4):
            advance(obs, request(), c)
            recovered = g.step(obs, request(lift=.001))
            self.assertEqual(recovered['debug']['first_raw_velocity_anomaly'], evidence)
            self.assertEqual(recovered['pending_failure'], 'new_raw_joint_velocity_anomaly')
            self.assertEqual(recovered['failure'], first['failure'])
            np.testing.assert_array_equal(recovered['action'][:, :8], 0.)

    def test_input_and_calibration_not_mutated(self):
        obs, c = fixture(); before = deepcopy(obs); calibration = deepcopy(c)
        g = CalibratedContactGovernor(obs, calibration=c); g.step(obs, request())
        for key in obs: np.testing.assert_array_equal(obs[key], before[key])
        self.assertEqual(c, calibration)
        c['controller_bias'][0][0] = 0.; self.assertAlmostEqual(g.calibration['controller_bias'][0, 0], .0026)


if __name__ == '__main__':
    unittest.main()
