"""Synthetic CPU evidence tests; no physical sleeve-success claim."""
import importlib.util
import sys
from pathlib import Path
import unittest

import cv2
import numpy as np

PATH = Path(__file__).resolve().parents[1] / 'participant' / 'opening_candidates.py'
sys.path.insert(0, str(PATH.parent))
SPEC = importlib.util.spec_from_file_location('v23_opening_tested', PATH)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def scene(camera=3, gap=1.0):
    pose = np.zeros((2, 7), np.float32); pose[:, 3] = 1
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.full((5, 256, 256, 1), 2.0, np.float32),
               depth_valid=np.ones((5, 256, 256, 1), bool),
               base_pose_world=pose.copy(), grasp_pose_base=pose.copy())
    ring = np.zeros((256, 256), np.uint8)
    cv2.circle(ring, (128, 128), 40, 1, cv2.FILLED)
    cv2.circle(ring, (128, 128), 20, 0, cv2.FILLED)
    obs['rgb'][camera][ring.astype(bool)] = [10, 20, 230]
    obs['depth'][camera, ..., 0][ring.astype(bool)] = 1.0
    interior = np.zeros_like(ring); cv2.circle(interior, (128, 128), 20, 1, cv2.FILLED)
    obs['depth'][camera, ..., 0][interior.astype(bool)] = 1.0 + gap
    return obs, ring.astype(bool), interior.astype(bool)


def hand_pixels(obs, pixels, depth=1.08, camera=4):
    """Synthetic visible surface in the other public head camera."""
    pixels = np.asarray(pixels, int)
    u, v = pixels.T
    obs['rgb'][camera, v, u] = [180, 140, 120]
    obs['depth'][camera, v, u, 0] = depth
    obs['depth_valid'][camera, v, u, 0] = True
    return dict(camera_indices=[camera]*len(pixels), source_pixels_uv=pixels.tolist())


class OpeningCandidateTests(unittest.TestCase):
    def test_closed_ring_with_background_is_unclassified_candidate(self):
        obs, _, _ = scene()
        before = {key: value.copy() for key, value in obs.items()}
        result = MODULE.opening_candidates(obs)
        self.assertTrue(result['detected'])
        candidate = result['opening_candidates'][0]
        self.assertEqual(candidate['kind'], 'unclassified_opening')
        self.assertFalse(candidate['opening_verified'])
        self.assertFalse(candidate['collar_like'])
        self.assertLess(candidate['planarity'], 1e-5)
        self.assertAlmostEqual(np.linalg.norm(candidate['normal_world']), 1)
        self.assertGreater(candidate['observed_depth_support']['median_background_gap_m'], .9)
        for key in obs:
            np.testing.assert_array_equal(obs[key], before[key])

    def test_foreground_and_same_depth_patch_are_rejected(self):
        for gap in (-.2, 0, .01):
            obs, _, _ = scene(gap=gap)
            result = MODULE.opening_candidates(obs)
            self.assertFalse(result['detected'])
            self.assertIn('foreground_occlusion_or_no_background_gap', result['rejected_candidate_counts'])

    def test_partial_foreground_obstruction_is_rejected(self):
        obs, _, interior = scene()
        left = np.indices((256, 256))[1] < 128
        obs['depth'][3, ..., 0][interior & left] = .7
        self.assertFalse(MODULE.opening_candidates(obs)['detected'])

    def test_missing_depth_abstains(self):
        for part in ('ring', 'interior'):
            obs, ring, interior = scene()
            obs['depth_valid'][3, ..., 0][ring if part == 'ring' else interior] = False
            result = MODULE.opening_candidates(obs)
            self.assertEqual(result['status'], 'unknown')
            self.assertFalse(result['detected'])

    def test_open_edge_is_not_closed_by_algorithm(self):
        obs, _, _ = scene()
        obs['rgb'][3, 126:131, 128:175] = 0
        self.assertEqual(MODULE.opening_candidates(obs)['status'], 'unknown')

    def test_yellow_ring_is_collar_hint_only(self):
        obs, _, _ = scene()
        trim = np.zeros((256, 256), np.uint8)
        cv2.circle(trim, (128, 128), 22, 1, cv2.FILLED)
        cv2.circle(trim, (128, 128), 20, 0, cv2.FILLED)
        obs['rgb'][3][trim.astype(bool)] = [230, 220, 10]
        candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
        self.assertTrue(candidate['collar_like'])
        self.assertFalse(candidate['opening_verified'])
        self.assertEqual(candidate['kind'], 'unclassified_opening')

    def test_own_pose_translation_equivariance_and_wrist_camera(self):
        for camera in (1, 3):
            obs, _, _ = scene(camera=camera)
            a = MODULE.opening_candidates(obs)['opening_candidates'][0]
            delta = np.array([1.0, -.6, .2])
            obs['base_pose_world'][:, :3] += delta
            b = MODULE.opening_candidates(obs)['opening_candidates'][0]
            np.testing.assert_allclose(np.asarray(b['centroid_world']) - a['centroid_world'], delta, atol=1e-6)
            np.testing.assert_allclose(b['normal_world'], a['normal_world'], atol=1e-6)

    def test_human_mounted_overview_excluded(self):
        obs, _, _ = scene(camera=0)
        self.assertFalse(MODULE.opening_candidates(obs)['detected'])

    def test_inner_polygon_uses_noncloth_boundary_pixels_and_plane_projection_not_cloth_band(self):
        for camera in (1, 2, 3, 4):
            with self.subTest(camera=camera):
                obs, cloth, _ = scene(camera=camera); obs['simulation_time_s'] = 4.2
                candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
                aperture = candidate['inner_aperture']
                self.assertTrue(aperture['available'])
                uv = np.asarray(aperture['contour_pixels_uv'])
                self.assertLessEqual(len(uv), 512)
                self.assertFalse(cloth[uv[:, 1], uv[:, 0]].any())
                self.assertEqual(aperture['camera_index'], camera)
                self.assertEqual(aperture['observation_time_s'], 4.2)
                expected = MODULE._PUBLIC._world_pixels(MODULE._PUBLIC._validated(obs, wrists=True),
                    camera, uv[:, 0], uv[:, 1], np.ones(len(uv)))
                np.testing.assert_allclose(aperture['contour_world_on_plane'], expected, atol=1e-7)
                origin = np.asarray(aperture['plane_origin_world'])
                basis = np.asarray(aperture['plane_basis_world'])
                np.testing.assert_allclose((expected-origin) @ basis.T, aperture['polygon_plane_xy_m'], atol=1e-7)
                # Actual inner area is smaller than the surrounding band's box.
                self.assertLess(aperture['area_on_plane_m2'], np.prod(candidate['visible_ring_extent_m']))
                self.assertFalse(aperture['physical_opening_verified'])

    def test_partial_visible_surface_footprint_projects_from_public_pixels_and_keeps_unknowns(self):
        obs, _, _ = scene(); obs['simulation_time_s'] = 5.
        pixels = [(x, y) for x in (121, 125, 129, 133) for y in (122, 127, 132)]
        samples = hand_pixels(obs, pixels)
        candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
        direction = np.asarray(candidate['normal_world']); original = direction.copy()
        result = MODULE.compare_hand_surface_footprint(obs, candidate, samples, direction)
        self.assertTrue(result['observed_footprint_fits'])
        self.assertGreater(result['minimum_edge_clearance_m'], .01)
        self.assertEqual(result['sample_count'], 12)
        self.assertFalse(result['physical_hand_complete'])
        self.assertFalse(result['insertion_allowed'])
        np.testing.assert_array_equal(direction, original)
        projected = np.asarray(result['projected_surface_points_world'])
        np.testing.assert_allclose((projected-np.asarray(candidate['plane_centre_world'])) @ direction, 0., atol=1e-7)

    def test_ring_box_corner_is_not_inner_aperture_and_concave_gap_cannot_be_bridged(self):
        obs, _, _ = scene(); obs['simulation_time_s'] = 1.
        samples = hand_pixels(obs, [(x, y) for x in (140, 142, 144, 146) for y in (140, 143, 146)])
        candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
        result = MODULE.compare_hand_surface_footprint(obs, candidate, samples, candidate['normal_world'])
        self.assertFalse(result['observed_footprint_fits'])
        self.assertLess(result['minimum_edge_clearance_m'], 0.)
        # A U-shaped aperture: both hand-envelope ends are inside the legs, but
        # their connecting footprint crosses the cloth-filled middle notch.
        obs, _, _ = scene(); obs['simulation_time_s'] = 2.
        outer = np.zeros((256, 256), np.uint8); outer[70:186, 70:186] = 1
        hole = np.zeros_like(outer)
        vertices = np.array([[95, 95], [160, 95], [160, 160], [140, 160],
                             [140, 120], [115, 120], [115, 160], [95, 160]])
        cv2.fillPoly(hole, [vertices], 1)
        cloth = (outer > 0) & (hole == 0)
        obs['rgb'][3] = 0; obs['rgb'][3][cloth] = [10, 20, 230]
        obs['depth'][3, ..., 0] = 2.; obs['depth'][3, ..., 0][cloth] = 1.
        samples = hand_pixels(obs, [(x, y) for x in (100, 110, 145, 155) for y in (130, 137, 145)], depth=1.04)
        candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
        self.assertTrue(candidate['inner_aperture']['available'])
        polygon = np.asarray(candidate['inner_aperture']['polygon_plane_xy_m'], np.float32)
        self.assertFalse(cv2.isContourConvex(polygon))
        result = MODULE.compare_hand_surface_footprint(obs, candidate, samples, candidate['normal_world'], margin_m=0.)
        self.assertFalse(result['observed_footprint_fits'])
        self.assertAlmostEqual(result['minimum_edge_clearance_m'], 0., places=7)
        for point in result['observed_footprint_hull_plane_xy_m']:
            self.assertGreater(cv2.pointPolygonTest(polygon, tuple(point), True), 0.)

    def test_cloth_island_inside_image_hole_does_not_supply_single_aperture_polygon(self):
        obs, _, _ = scene()
        obs['rgb'][3, 125:132, 125:132] = [10, 20, 230]
        obs['depth'][3, 125:132, 125:132, 0] = 1.
        result = MODULE.opening_candidates(obs)
        self.assertTrue(result['detected'])
        self.assertFalse(result['opening_candidates'][0]['inner_aperture']['available'])
        self.assertIn('islands', result['opening_candidates'][0]['inner_aperture']['reason'])

    def test_footprint_rejects_old_frame_missing_depth_overview_oblique_axis_and_long_projection(self):
        for fault in ('old_frame', 'missing_depth', 'overview', 'parallel', 'far'):
            with self.subTest(fault=fault):
                obs, _, _ = scene(); obs['simulation_time_s'] = 1.
                samples = hand_pixels(obs, [(x, y) for x in (121, 125, 129, 133) for y in (122, 127, 132)],
                                      depth=1.3 if fault == 'far' else 1.08)
                candidate = MODULE.opening_candidates(obs)['opening_candidates'][0]
                direction = candidate['normal_world']
                if fault == 'old_frame':
                    obs['simulation_time_s'] = 1.05
                elif fault == 'missing_depth':
                    obs['depth_valid'][4, 122, 121, 0] = False
                elif fault == 'overview':
                    samples['camera_indices'][0] = 0
                elif fault == 'parallel':
                    direction = candidate['principal_axis_world']
                result = MODULE.compare_hand_surface_footprint(obs, candidate, samples, direction)
                self.assertEqual(result['status'], 'unknown')
                self.assertFalse(result['observed_footprint_fits'])
                self.assertFalse(result['insertion_allowed'])

    def test_projected_footprint_comparison_is_invariant_to_public_rigid_world_pose_change(self):
        obs, _, _ = scene(); obs['simulation_time_s'] = 1.
        samples = hand_pixels(obs, [(x, y) for x in (121, 125, 129, 133) for y in (122, 127, 132)])
        first = MODULE.opening_candidates(obs)['opening_candidates'][0]
        before = MODULE.compare_hand_surface_footprint(obs, first, samples, first['normal_world'])
        obs['base_pose_world'][:, :3] = [.3, -.4, .2]
        obs['base_pose_world'][:, 3:] = [np.cos(.4), 0, 0, np.sin(.4)]
        second = MODULE.opening_candidates(obs)['opening_candidates'][0]
        after = MODULE.compare_hand_surface_footprint(obs, second, samples, second['normal_world'])
        self.assertTrue(before['observed_footprint_fits'])
        self.assertTrue(after['observed_footprint_fits'])
        self.assertAlmostEqual(before['minimum_edge_clearance_m'], after['minimum_edge_clearance_m'], places=6)


if __name__ == '__main__':
    unittest.main()
