"""CPU handoff/routing tests; synthetic observations do not prove cloth grasps."""
import sys
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import cooperative_policy as cooperative
import tabletop_policy as tabletop
from public_vision import grasp_world


def observation():
    return dict(base_pose_world=np.array([[-1., 0, 0, 1, 0, 0, 0], [1., 0, 0, 1, 0, 0, 0]], np.float32),
        grasp_pose_base=np.array([[.6, -.1, .7, 1, 0, 0, 0], [.6, -.1, .7, 1, 0, 0, 0]], np.float32),
        gripper_close_command=np.ones((2, 1), bool), fingertip_origin_distance=np.full((2, 1), .04, np.float32),
        joint_velocity=np.zeros((2, 13), np.float32), simulation_time_s=np.array(0., np.float64),
        rgb=np.zeros((5, 256, 256, 3), np.uint8), depth=np.zeros((5, 256, 256, 1), np.float32),
        depth_valid=np.zeros((5, 256, 256, 1), bool))


class Baseline:
    def __init__(self, *args, **kwargs):
        self.calls = 0; self.failure = None; self.debug = {}; self.active = 0; self.idle = 1
        self.observer_calls = 0; self.mode = 'search'
        self.parent = SimpleNamespace(stage='pickup', pickup=SimpleNamespace(robot=0, phase='neural_lift',
            debug={'executed_phase': 'close_wait', 'lift_specialist_action': None}))

    def __call__(self, obs):
        self.calls += 1
        action = np.zeros((2, 9), np.float32)
        action[0, 8] = 1; action[1, 2] = .07
        return action

    def _observe_idle(self, obs):
        self.observer_calls += 1
        return np.array([0., 0., .07])


def actor():
    with patch.object(cooperative, 'baseline_class', return_value=Baseline):
        return tabletop.Policy('unused-checkpoint')


def cloth_at(points):
    x, y = np.meshgrid(np.linspace(-.008, .008, 5), np.linspace(-.008, .008, 5))
    offsets = np.column_stack((x.ravel(), y.ravel(), np.zeros(x.size)))
    return dict(world_points=np.concatenate([p + offsets for p in points]))


def lifted_actor(obs):
    policy = actor(); policy.active = 0; policy.helper = 1; policy.tabletop_handoff_done = True
    policy.active_hold = grasp_world(obs, 0)
    policy.execution.previous_closed[:] = True; policy.execution.stable[:] = 30
    with patch.object(cooperative, 'cloth_cloud', return_value=cloth_at([grasp_world(obs, r) for r in (0, 1)])):
        policy._begin_pair_lift(obs)
    return policy


class TabletopTests(unittest.TestCase):
    def test_exact_handoff_clears_both_motion_rows(self):
        obs = observation(); obs['gripper_close_command'][1] = False
        policy = actor(); action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertTrue(policy.tabletop_handoff_done)
        self.assertEqual(policy.phase, 'helper_survey')
        self.assertEqual(policy.baseline.calls, 1)
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
        self.assertEqual(action[0, 8], 1); self.assertEqual(action[1, 8], -1)
        policy(obs)
        self.assertEqual(policy.baseline.calls, 1)

    def test_recent_hand_cache_skips_survey(self):
        obs = observation(); policy = actor()
        policy.hands = {'detected': True, 'hand_points_world': [[0, 0, 1], [0, .3, 1]]}
        policy.hand_observation_time = 0.
        policy(obs)
        self.assertEqual(policy.phase, 'helper_locate')
        self.assertEqual(policy.baseline.observer_calls, 0)

    def test_survey_routes_only_helper_and_confirms_public_hands(self):
        obs = observation(); policy = actor(); policy(obs)
        action = policy(obs)
        np.testing.assert_array_equal(action[0, :8], np.zeros(8))
        self.assertGreater(action[1, 2], 0)
        self.assertEqual(action[0, 8], 1.)
        self.assertEqual(policy.baseline.calls, 1)
        self.assertEqual(policy.baseline.observer_calls, 1)
        policy.baseline.mode = 'view_hold'
        observed = {'detected': True, 'hand_points_world': [[0, 0, 1], [0, .3, 1]]}
        with patch.object(cooperative, 'estimate_hands', return_value=observed):
            for _ in range(11):
                obs['simulation_time_s'][...] += .05
                action = policy(obs)
        self.assertEqual(policy.phase, 'helper_locate')
        self.assertEqual(policy.tabletop_survey_hand_streak, 3)
        self.assertTrue(policy.hands['detected'])
        self.assertEqual(policy.baseline.calls, 1)
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))

    def test_survey_exception_timeout_role_and_drift_stop(self):
        for mode in ('exception', 'timeout', 'role', 'drift'):
            obs = observation(); policy = actor(); policy(obs)
            if mode == 'timeout': obs['simulation_time_s'][...] = 31.
            if mode == 'role': policy.baseline.idle = 0
            if mode == 'drift': obs['base_pose_world'][1, 0] += .06
            if mode == 'exception':
                with patch.object(policy.baseline, '_observe_idle', side_effect=ValueError('idle_lost_target')):
                    action = policy(obs)
            else:
                action = policy(obs)
            np.testing.assert_array_equal(action, np.zeros((2, 9)))
            self.assertIsNotNone(policy.failure)

    def test_already_executed_lift_aborts_handoff(self):
        obs = observation(); policy = actor()
        policy.baseline.parent.pickup.debug['executed_phase'] = 'neural_lift'
        np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
        self.assertIn('missed pre-lift', policy.failure)

    def test_helper_close_transitions_to_pair_without_single_lift(self):
        obs = observation(); policy = actor()
        policy.tabletop_handoff_done = True; policy.active = 0; policy.helper = 1
        policy.active_hold = grasp_world(obs, 0); policy.phase = 'helper_close'
        policy.execution.previous_closed[:] = True; policy.execution.stable[:] = 30
        with patch.object(cooperative, 'cloth_cloud', return_value=cloth_at([grasp_world(obs, r) for r in (0, 1)])):
            action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'tabletop_dual_lift')
        np.testing.assert_array_equal(action[:, :8], np.zeros((2, 8)))
        np.testing.assert_array_equal(action[:, 8], np.ones(2))

    def test_opening_either_gripper_stops_both(self):
        for robot in (0, 1):
            obs = observation(); policy = lifted_actor(obs)
            obs['gripper_close_command'][robot] = False
            np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
            self.assertIn('gripper opened', policy.failure)

    def test_matched_pair_rise_and_speed_bound(self):
        obs = observation(); policy = lifted_actor(obs)
        obs['simulation_time_s'][...] = 2.
        action = policy(obs)
        self.assertIsNone(policy.failure)
        self.assertGreater(action[0, 3], 0)
        self.assertAlmostEqual(action[0, 3], action[1, 3])
        speeds = action[:, [4, 3]] * [1.21, 1.54]
        self.assertTrue(np.all(np.linalg.norm(speeds, axis=1) <= .0300001))

    def test_execution_guard_after_smoothing_stops_both(self):
        obs = observation(); policy = lifted_actor(obs)
        policy.execution.pending[1] = True; policy.execution.stable[1] = 0
        policy.previous_action[:, 3] = .02
        obs['simulation_time_s'][...] = 2.
        np.testing.assert_array_equal(policy(obs)[:, :8], np.zeros((2, 8)))

    def test_asymmetric_height_and_timeout_abort(self):
        for mode in ('height', 'time', 'steps'):
            obs = observation(); policy = lifted_actor(obs)
            if mode == 'height': obs['grasp_pose_base'][0, 2] += .07
            if mode == 'time': obs['simulation_time_s'][...] = 36.
            if mode == 'steps': policy.phase_steps = 900
            np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
            self.assertIsNotNone(policy.failure)

    def test_tilt_base_separation_drift_and_gripper_gap_guards(self):
        for mode in ('tilt', 'separation', 'base_drift', 'grasp_drift', 'gap'):
            obs = observation(); policy = lifted_actor(obs)
            if mode == 'tilt':
                obs['base_pose_world'][0, 3:] = [np.cos(.05), np.sin(.05), 0., 0.]
            if mode == 'separation': obs['base_pose_world'][1, 0] = -.8
            if mode == 'base_drift': obs['base_pose_world'][0, 0] += .07
            if mode == 'grasp_drift': obs['grasp_pose_base'][0, 0] += .07
            if mode == 'gap': obs['fingertip_origin_distance'][0, 0] = .09
            np.testing.assert_array_equal(policy(obs), np.zeros((2, 9)))
            self.assertIsNotNone(policy.failure)

    def test_completion_requires_cloth_motion_then_never_restarts(self):
        obs = observation(); policy = lifted_actor(obs)
        initial = policy.tabletop_initial_patches.copy()
        obs['grasp_pose_base'][:, 2] += .35; obs['simulation_time_s'][...] = 20.
        with patch.object(cooperative, 'cloth_cloud', return_value=cloth_at(initial)):
            policy(obs)
        self.assertFalse(policy.tabletop_lift_done)
        with patch.object(cooperative, 'cloth_cloud', return_value=cloth_at(initial + [0, 0, .35])):
            for _ in range(20): policy(obs)
        self.assertIsNone(policy.failure)
        self.assertEqual(policy.phase, 'dual_hold')
        self.assertTrue(policy.tabletop_lift_done)
        self.assertEqual(policy.baseline.calls, 0)
        policy(obs)
        self.assertEqual(policy.phase, 'dual_hold')
        self.assertEqual(policy.baseline.calls, 0)
        with self.assertRaisesRegex(ValueError, 'cannot restart'):
            policy._begin_pair_lift(obs)


if __name__ == '__main__':
    unittest.main()
