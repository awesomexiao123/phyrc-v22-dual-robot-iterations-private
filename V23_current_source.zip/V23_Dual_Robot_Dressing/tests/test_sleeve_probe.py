"""Synthetic public RGB-D one-shot probe hypotheses, never physics success."""
import copy
from pathlib import Path
import sys
import unittest

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import sleeve_probe as probe
from human_targets import _camera_transform
from sleeve_observation import diagnose_sleeve_observability


def scene(hand_depth=1.01, inner=20, hand_half=5, reverse_grasps=False):
    poses = np.zeros((2, 7)); poses[:, 3] = 1.
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.full((5, 256, 256, 1), 2., np.float32),
        depth_valid=np.zeros((5, 256, 256, 1), bool),
        base_pose_world=poses.copy(), grasp_pose_base=poses.copy(),
        simulation_time_s=1., gripper_close_command=np.ones((2, 1), bool),
        fingertip_origin_distance=np.full((2, 1), .02))
    cloth = np.zeros((256, 256), np.uint8)
    for x in (80, 176):
        cv2.circle(cloth, (x, 128), 30, 1, -1)
        cv2.circle(cloth, (x, 128), inner, 0, -1)
        obs['rgb'][4, 128-hand_half:129+hand_half, x-hand_half:x+hand_half+1] = [180, 140, 120]
        obs['depth'][4, 128-hand_half:129+hand_half, x-hand_half:x+hand_half+1, 0] = hand_depth
        obs['depth_valid'][4, 128-hand_half:129+hand_half, x-hand_half:x+hand_half+1, 0] = True
    obs['rgb'][3][cloth.astype(bool)] = [10, 20, 230]
    obs['depth'][3, ..., 0][cloth.astype(bool)] = 1.
    obs['depth_valid'][3] = True
    values = probe._validated(obs, wrists=True)
    grasps = probe._world_pixels(values, 3, np.array([56, 200]), np.array([128, 128]), np.ones(2))
    if reverse_grasps:
        grasps = grasps[::-1].copy()
    obs['grasp_pose_base'][:, :3] = grasps
    hands = probe._world_pixels(values, 4, np.array([80, 176]), np.array([128, 128]), np.full(2, hand_depth))
    axis = _camera_transform(values, 4)[0][:, 2]
    rows = []
    for index, hand in enumerate(hands):
        views = [dict(camera_index=camera, hand_index=index, axis_world=axis.tolist(),
            axis_sign='measured_hand_toward_one_sided_visible_proximal_surface',
            proximal_observed_surface_point_world=(hand+.17*axis).tolist())
            for camera in ((4,) if index == 0 else (3, 4))]
        rows.append(dict(hand_index=index, hand_surface_world=hand.tolist(),
            status='single_view_candidate' if index == 0 else 'multi_view_consistent_candidate',
            axis_world=None if index == 0 else axis.tolist(), candidate_views=views,
            axis_sign='hand_surface_toward_visible_proximal_surface', conflicting_pairs=[],
            supporting_parallax_pairs=[] if index == 0 else [dict(camera_indices=[3, 4])]))
    report = diagnose_sleeve_observability(obs, grasps)
    return obs, grasps, report, dict(detected=True, hand_points_world=hands.tolist(), observation_time_s=1.), \
        dict(hand_surfaces=rows, observation_time_s=1.), axis


class SleeveProbeTests(unittest.TestCase):
    def test_current_two_holes_allow_only_one_five_mm_hypothesis_with_explicit_weak_axis(self):
        obs, grasps, sleeves, hands, forearms, axis = scene()
        original = {key: value.copy() if isinstance(value, np.ndarray) else value for key, value in obs.items()}
        result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
        self.assertEqual(result['recommendation'], 'one_shot_5mm_simulation_hypothesis', result)
        np.testing.assert_allclose(np.asarray(result['target_grasps_world'])-grasps, np.tile(.005*axis, (2, 1)), atol=1e-12)
        self.assertTrue(result['contains_weak_single_view_evidence'])
        self.assertEqual(result['recommended_max_speed_m_s'], .003)
        self.assertEqual(result['caller_must_enforce_global_probe_limit_m'], .01)
        self.assertNotIn('action', result)
        self.assertFalse(result['physical_traversal_verified'])
        self.assertFalse(result['full_hand_geometry_observed'])
        for row in result['per_grasp_hypotheses']:
            self.assertAlmostEqual(row['nearest_observed_hand_distal_gap_m'], .01, places=6)
            self.assertGreaterEqual(row['minimum_observed_footprint_margin_m'], .01)
        self.assertEqual(result, probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms))
        for key in original:
            np.testing.assert_array_equal(obs[key], original[key])

    def test_geometry_assignment_follows_grasp_roles_not_hand_order_or_cached_candidate_indices(self):
        for reverse in (False, True):
            with self.subTest(reverse=reverse):
                obs, grasps, sleeves, hands, forearms, _ = scene(reverse_grasps=reverse)
                for row in sleeves['grasp_regions']:
                    row['depth_supported_opening_candidates'][0]['candidate_index'] = 777
                result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
                self.assertEqual(result['recommendation'], 'one_shot_5mm_simulation_hypothesis', result)
                self.assertEqual([row['hand_index'] for row in result['per_grasp_hypotheses']], [1, 0] if reverse else [0, 1])

    def test_no_blind_staging_advance_or_probe_from_plane_already_proximal_to_observed_hand(self):
        for depth in (1.30, 1.021, .99):
            with self.subTest(depth=depth):
                obs, grasps, sleeves, hands, forearms, _ = scene(hand_depth=depth)
                result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
                self.assertEqual(result['recommendation'], 'hold')
                self.assertIn('0_to_20mm', result['reason'])
                self.assertIsNone(result['target_grasps_world'])

    def test_insufficient_hand_margin_and_missing_current_hand_depth_hold(self):
        obs, grasps, sleeves, hands, forearms, _ = scene(inner=12, hand_half=12)
        result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
        self.assertEqual(result['recommendation'], 'hold')
        obs, grasps, sleeves, hands, forearms, _ = scene()
        obs['depth_valid'][4, :, :128] = False
        result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
        self.assertEqual(result['recommendation'], 'hold')
        self.assertIn('current_depth_connected_hand', result['reason'])

    def test_stale_ambiguous_or_same_opening_twice_does_not_produce_pair_targets(self):
        for fault in ('stale', 'ambiguous', 'same_hole', 'old_hand', 'old_axis', 'open_grip'):
            with self.subTest(fault=fault):
                obs, grasps, sleeves, hands, forearms, _ = scene()
                if fault == 'stale':
                    sleeves['grasp_regions'][0]['depth_supported_opening_candidates'][0]['observation_time_s'] = .9
                elif fault == 'ambiguous':
                    sleeves['grasp_regions'][0]['ambiguous_candidate_indices'] = [0]
                elif fault == 'same_hole':
                    sleeves['grasp_regions'][1]['depth_supported_opening_candidates'] = copy.deepcopy(sleeves['grasp_regions'][0]['depth_supported_opening_candidates'])
                elif fault == 'old_hand':
                    hands['observation_time_s'] = .9
                elif fault == 'old_axis':
                    forearms['observation_time_s'] = .9
                else:
                    obs['gripper_close_command'][1, 0] = False
                result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
                self.assertEqual(result['recommendation'], 'hold')
                self.assertIsNone(result['target_grasps_world'])

    def test_signed_axis_reversal_oblique_axis_and_conflicting_views_hold(self):
        for fault in ('reversed', 'oblique', 'conflict'):
            with self.subTest(fault=fault):
                obs, grasps, sleeves, hands, forearms, axis = scene()
                row = forearms['hand_surfaces'][0]
                if fault == 'conflict':
                    row['conflicting_pairs'] = [dict(camera_indices=[3, 4])]
                else:
                    if fault == 'oblique':
                        lateral = _camera_transform(probe._validated(obs, wrists=True), 4)[0][:, 0]
                        axis = .5*axis+np.sqrt(.75)*lateral
                    else:
                        axis = -axis
                    row['candidate_views'][0]['axis_world'] = axis.tolist()
                    row['candidate_views'][0]['proximal_observed_surface_point_world'] = (np.asarray(hands['hand_points_world'][0])+.17*axis).tolist()
                result = probe.propose_sleeve_probe(obs, grasps, sleeves, hands, forearms)
                self.assertEqual(result['recommendation'], 'hold')


if __name__ == '__main__':
    unittest.main()
