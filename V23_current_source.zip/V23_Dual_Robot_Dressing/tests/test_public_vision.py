import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "participant"))
import public_vision as vision


def observation():
    obs = dict(rgb=np.zeros((5, 32, 32, 3), np.uint8),
               depth=np.ones((5, 32, 32, 1), np.float32),
               depth_valid=np.ones((5, 32, 32, 1), bool),
               base_pose_world=np.array([[1, 2, .1, 1, 0, 0, 0],
                                         [-2, 4, .2, np.sqrt(.5), 0, 0, np.sqrt(.5)]]),
               grasp_pose_base=np.array([[.5, -.1, .8, 1, 0, 0, 0],
                                         [.7, -.1, .9, np.sqrt(.5), 0, np.sqrt(.5), 0]]))
    return obs


def hanging_observation(active=0):
    obs = observation()
    obs['base_pose_world'][:] = [0, 0, 0, 1, 0, 0, 0]
    obs['grasp_pose_base'][active, :3] = [.7, 0, 1.1]
    return obs


def surface_patch(center, camera, width=8, height=8, extent=.025):
    x, y = np.meshgrid(np.linspace(-extent, extent, width),
                       np.linspace(-extent, extent, height))
    points = np.asarray(center) + np.column_stack((x.ravel(), y.ravel(), np.zeros(x.size)))
    return dict(world_points=points, camera_ids=np.full(len(points), camera),
                rgb=np.tile(np.array([10, 20, 200], np.uint8), (len(points), 1)))


def combined_cloud(*clouds):
    return {key: np.concatenate([cloud[key] for cloud in clouds])
            for key in ('world_points', 'camera_ids', 'rgb')}


class GeometryTest(unittest.TestCase):
    def test_pose_rotation_robot_identity_and_inverse(self):
        obs = observation()
        point = np.array([.3, .2, .8])
        np.testing.assert_allclose(vision.base_to_world(obs, 0, point), [1.3, 2.2, .9])
        np.testing.assert_allclose(vision.base_to_world(obs, 1, point), [-2.2, 4.3, 1.])
        for robot in (0, 1):
            np.testing.assert_allclose(vision.world_to_base(obs, robot,
                vision.base_to_world(obs, robot, point)), point, atol=1e-12)

    def test_head_and_wrist_extrinsics_use_correct_robot(self):
        obs = observation()
        for camera in (1, 2, 3, 4):
            obs["rgb"][:] = 0
            obs["rgb"][camera, 14:19, 14:19] = [10, 30, 220]
            cloud = vision.cloth_cloud(obs, [camera])
            robot = camera-3 if camera >= 3 else camera-1
            transform = vision.HEAD if camera >= 3 else vision.WRIST
            # Pixel [16,16] in this 32x32 fixture samples centre [16.5,16.5].
            focal = 32/(2*np.tan(np.deg2rad(vision.CALIBRATION['fov_degrees']/2)))
            midpoint = transform[:3, :3] @ [.5/focal, .5/focal, 1] + transform[:3, 3]
            if camera < 3:
                grasp = obs["grasp_pose_base"][robot]
                midpoint = vision._rotation(grasp[3:]) @ midpoint + grasp[:3]
            expected = vision.base_to_world(obs, robot, midpoint)
            np.testing.assert_allclose(cloud["world_points"][12], expected, atol=1e-12)
            self.assertEqual(cloud["world_points"].shape, (25, 3))
            self.assertTrue(np.all(cloud["camera_ids"] == camera))

    def test_yellow_requires_blue_support_and_invalid_depth_rejected(self):
        obs = observation()
        obs["rgb"][3, 5:10, 5:10] = [200, 180, 10]
        self.assertEqual(len(vision.cloth_cloud(obs)["world_points"]), 0)
        obs["rgb"][3, 11:16, 11:16] = [10, 20, 200]
        obs["rgb"][3, 11:16, 16:18] = [200, 180, 10]
        cloud = vision.cloth_cloud(obs)
        self.assertTrue(np.any(cloud["rgb"][:, 0] == 200))
        obs["depth_valid"][3] = False
        self.assertEqual(len(vision.cloth_cloud(obs)["world_points"]), 0)

    def test_overview_not_assigned_an_invented_transform(self):
        with self.assertRaises(ValueError):
            vision.cloth_cloud(observation(), [0])

    def test_target_separation_and_loss_do_not_jump_patch(self):
        obs = observation()
        obs["base_pose_world"][:] = [0, 0, 0, 1, 0, 0, 0]
        obs["grasp_pose_base"][0, :3] = [.7, 0, .9]
        x, y = np.meshgrid(np.linspace(.5, .54, 8), np.linspace(.30, .34, 8))
        points = np.column_stack((x.ravel(), y.ravel(), np.full(x.size, .9)))
        cloud = dict(world_points=points, camera_ids=np.full(len(points), 3),
                     rgb=np.zeros((len(points), 3), np.uint8))
        with patch.object(vision, "cloth_cloud", return_value=cloud):
            result = vision.helper_grasp_target(obs, 0, 1)
            self.assertIsNotNone(result["target_world"])
            self.assertGreaterEqual(result["active_separation_m"], .18)
            tracked = vision.helper_grasp_target(obs, 0, 1, result)
            np.testing.assert_allclose(tracked["target_world"], result["target_world"], atol=.02)
            lost = vision.helper_grasp_target(obs, 0, 1, [2, 2, 1])
            self.assertIsNone(lost["target_world"])
            self.assertEqual(lost["reason"], "previous_fabric_patch_not_visible")

    def test_background_and_same_robot_are_rejected(self):
        obs = observation()
        self.assertIsNone(vision.helper_grasp_target(obs, 0, 1)["target_world"])
        with self.assertRaises(ValueError):
            vision.helper_grasp_target(obs, 0, 0)

    def test_sparse_high_outlier_cannot_beat_dense_hanging_patch_in_either_role(self):
        results = []
        center = np.array([.6, .35, .85])
        for active in (0, 1):
            helper = 1-active
            obs = hanging_observation(active)
            cloud = combined_cloud(surface_patch(center, 3+helper),
                                   surface_patch([.65, .38, 1.35], 3+active, width=4, height=2))
            with patch.object(vision, 'cloth_cloud', return_value=cloud):
                result = vision.helper_grasp_target(obs, active, helper)
            self.assertIsNotNone(result['target_world'])
            self.assertLess(np.linalg.norm(np.asarray(result['target_world'])-center), .04)
            self.assertEqual(result['source_cameras'], [3+helper])
            self.assertGreaterEqual(result['local_support_count'], 24)
            self.assertEqual(result['excluded_above_held_grasp_pixels'], 8)
            self.assertFalse(result['is_verified_edge'])
            results.append(result['target_world'])
        np.testing.assert_allclose(results[0], results[1])

    def test_dense_helper_head_view_precedes_more_extreme_active_head_patch(self):
        obs = hanging_observation()
        center = np.array([.6, .30, .90])
        cloud = combined_cloud(surface_patch(center, 4),
                               surface_patch([.8, .6, 1.05], 3, width=10, height=10))
        with patch.object(vision, 'cloth_cloud', return_value=cloud):
            result = vision.helper_grasp_target(obs, 0, 1)
        self.assertEqual(result['support_basis'], 'dense_helper_head_view')
        self.assertEqual(result['source_cameras'], [4])
        self.assertLess(np.linalg.norm(np.asarray(result['target_world'])-center), .04)

    def test_sparse_tracked_patch_abstains_despite_dense_patch_elsewhere(self):
        obs = hanging_observation()
        old = np.array([.6, .35, .85])
        cloud = combined_cloud(surface_patch(old, 4, width=4, height=2, extent=.008),
                               surface_patch([.7, .65, .85], 4))
        with patch.object(vision, 'cloth_cloud', return_value=cloud):
            result = vision.helper_grasp_target(obs, 0, 1, previous=old)
        self.assertIsNone(result['target_world'])
        self.assertEqual(result['reason'], 'insufficient_local_fabric_support')

    def test_static_density_gradient_does_not_walk_up_garment_after_50_updates(self):
        obs = hanging_observation()
        points = []
        for z in np.linspace(.7, 1.05, 71):
            count = 30+int(250*(z-.7)/.35)
            points.extend([[.6, y, z] for y in np.linspace(.32, .38, count)])
        points = np.asarray(points)
        cloud = dict(world_points=points, camera_ids=np.full(len(points), 4),
                     rgb=np.tile([10, 20, 220], (len(points), 1)).astype(np.uint8))
        initial = np.array([.6, .35, .7])
        # Both legacy point callers and full-result callers must stay put in a
        # static density gradient. Only the full result carries an initial anchor.
        for preserve_result in (False, True):
            with self.subTest(preserve_result=preserve_result):
                previous = initial
                with patch.object(vision, 'cloth_cloud', return_value=cloud):
                    for _ in range(50):
                        result = vision.helper_grasp_target(obs, 0, 1, previous)
                        self.assertIsNotNone(result['target_world'])
                        target = np.asarray(result['target_world'])
                        self.assertLess(np.linalg.norm(target-initial), .002)
                        self.assertAlmostEqual(target[2], initial[2])
                        self.assertLess(np.min(np.linalg.norm(points-target, axis=1)), 1e-12)
                        previous = result if preserve_result else target

    def test_observed_patch_motion_is_small_and_bounded_by_original_anchor(self):
        obs = hanging_observation()
        center = np.array([.6, .35, .85])
        # A vertical observed surface moving along its normal makes true small
        # movement observable; a plane translated within itself would not.
        y, z = np.meshgrid(np.linspace(-.025, .025, 9), np.linspace(-.025, .025, 9))
        points = center+np.column_stack((np.zeros(y.size), y.ravel(), z.ravel()))
        cloud = dict(world_points=points, camera_ids=np.full(len(points), 4),
                     rgb=np.tile([10, 20, 220], (len(points), 1)).astype(np.uint8))
        previous = center
        for displacement in (0., .01, .025, .04, .04, .02):
            moved = dict(cloud, world_points=points+[displacement, 0, 0])
            with patch.object(vision, 'cloth_cloud', return_value=moved):
                result = vision.helper_grasp_target(obs, 0, 1, previous)
            np.testing.assert_allclose(result['tracking_anchor_world'], center)
            if displacement == .04:
                self.assertIsNone(result['target_world'])
                self.assertEqual(result['reason'], 'previous_fabric_patch_not_visible')
                np.testing.assert_allclose(result['last_valid_target_world'], center+[.025, 0, 0])
            else:
                np.testing.assert_allclose(result['target_world'], center+[displacement, 0, 0])
                self.assertLessEqual(result['tracking_anchor_displacement_m'], .03)
                self.assertLessEqual(result['tracking_observation_correction_m'], .015+1e-9)
            previous = result

    def test_lost_result_retains_patch_and_does_not_relocate_to_other_dense_fabric(self):
        obs = hanging_observation()
        center = np.array([.6, .35, .85])
        cloud = surface_patch(center, 4, width=9, height=9)
        with patch.object(vision, 'cloth_cloud', return_value=cloud):
            first = vision.helper_grasp_target(obs, 0, 1, previous=center)
        empty = {key: value[:0] for key, value in cloud.items()}
        with patch.object(vision, 'cloth_cloud', return_value=empty):
            lost = vision.helper_grasp_target(obs, 0, 1, previous=first)
        self.assertIsNone(lost['target_world'])
        self.assertEqual(lost['reason'], 'no_visible_fabric')
        np.testing.assert_allclose(lost['tracking_anchor_world'], center)
        elsewhere = surface_patch([.65, .70, .85], 4)
        with patch.object(vision, 'cloth_cloud', return_value=elsewhere):
            still_lost = vision.helper_grasp_target(obs, 0, 1, previous=lost)
        self.assertIsNone(still_lost['target_world'])
        self.assertEqual(still_lost['reason'], 'previous_fabric_patch_not_visible')
        np.testing.assert_allclose(still_lost['tracking_anchor_world'], center)

    def test_multiple_sparse_views_require_actual_local_3d_agreement(self):
        obs = hanging_observation()
        center = np.array([.6, .35, .85])
        for offset, accepted in ((.003, True), (.065, False)):
            with self.subTest(view_offset=offset):
                cloud = combined_cloud(surface_patch(center, 2, width=4, height=3, extent=.005),
                                       surface_patch(center+[offset, 0, 0], 3, width=4, height=3, extent=.005))
                with patch.object(vision, 'cloth_cloud', return_value=cloud):
                    result = vision.helper_grasp_target(obs, 0, 1)
                self.assertEqual(result['target_world'] is not None, accepted)
                if accepted:
                    self.assertEqual(result['support_basis'], 'agreeing_multiple_camera_patches')
                    self.assertEqual(result['source_cameras'], [2, 3])

    def test_hanging_height_guard_moves_with_public_grasp_not_world_origin(self):
        obs = hanging_observation()
        cloud = combined_cloud(surface_patch([.6, .35, .85], 4),
                               surface_patch([.65, .38, 1.35], 3))
        with patch.object(vision, 'cloth_cloud', return_value=cloud):
            first = vision.helper_grasp_target(obs, 0, 1)
        translated = {key: value.copy() for key, value in cloud.items()}
        translated['world_points'][:, 2] += .3
        obs['base_pose_world'][:, 2] += .3
        with patch.object(vision, 'cloth_cloud', return_value=translated):
            second = vision.helper_grasp_target(obs, 0, 1)
        np.testing.assert_allclose(np.asarray(second['target_world'])-first['target_world'], [0, 0, .3])
        self.assertEqual(first['excluded_above_held_grasp_pixels'], second['excluded_above_held_grasp_pixels'])


if __name__ == "__main__":
    unittest.main()
