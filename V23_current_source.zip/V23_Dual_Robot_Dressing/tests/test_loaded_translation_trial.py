"""Far-field synthetic dynamics with the real calibrated governor; no PhysX."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_translation_trial as trial
from calibrated_contact_governor import CalibratedContactGovernor
from public_vision import grasp_world
from test_calibrated_contact_governor import fixture, advance as integrate
from test_loaded_roll_observation import hands, visible


class LoadedTranslationTrialTests(unittest.TestCase):
    def construct(self):
        obs, calibration = fixture()
        controller = trial.LoadedTranslationTrial(obs,hands(),0.,calibration=calibration)
        self.assertIsNone(controller.failure)
        self.assertIsInstance(controller.governor,CalibratedContactGovernor)
        return obs,calibration,controller

    def check(self, result):
        np.testing.assert_array_equal(result['action'][:,[0,1,2,5,6,7]],0.)
        np.testing.assert_array_equal(result['action'][:,8],1.)
        self.assertLessEqual(np.max(abs(result['action'][:,3:5]*[1.54,1.21])),trial.LoadedTranslationTrial.SPEED+1e-9)

    def until(self, obs, calibration, controller, predicate, limit=610, follow=(.7,.5)):
        with patch.object(trial,'_cloth_evidence',side_effect=visible):
            for _ in range(limit):
                result=controller.step(obs);self.check(result)
                if predicate(result):return result
                if result['failure']:self.fail(str(result))
                integrate(obs,result['action'],calibration,follow=follow)
        self.fail('Bounded condition not reached: '+str(result))

    def test_real_governor_completes_all_four_stages_and_actual_return_with_frozen_bias(self):
        obs,calibration,c=self.construct();governor=c.governor
        original=deepcopy(calibration)
        initial_q=obs['joint_position'].copy()
        initial_g=np.stack([grasp_world(obs,r) for r in (0,1)])
        stages=[]
        with patch.object(trial,'_cloth_evidence',side_effect=visible), \
                patch.object(trial,'CalibratedContactGovernor',side_effect=AssertionError('must never reconstruct governor')):
            for _ in range(610):
                result=c.step(obs);self.check(result)
                self.assertIs(c.governor,governor)
                self.assertIsNone(result['failure'],result)
                if not stages or stages[-1]!=c.phase:stages.append(c.phase)
                if result['done']:break
                integrate(obs,result['action'],calibration,follow=(.7,.5))
        self.assertTrue(result['done'],result)
        self.assertEqual([s['stage'] for s in c.segments],[s[0] for s in c.STAGES])
        for s in c.segments:
            change=np.array(s['actual_lift_arm_change_m'])
            expected=np.zeros((2,2))
            if s['stage']=='lift_out':expected[:,0]=.002
            if s['stage']=='arm_out':expected[:,1]=.002
            np.testing.assert_allclose(change,expected,atol=.0001)
        final_g=np.stack([grasp_world(obs,r) for r in (0,1)])
        self.assertLess(np.linalg.norm(final_g-initial_g,axis=1).max(),.0005)
        self.assertLess(np.max(abs(obs['joint_position'][:,3]-initial_q[:,3])),.0001)
        self.assertLess(np.max(abs(obs['joint_position'][:,4:8].sum(1)-initial_q[:,4:8].sum(1))),.0001)
        self.assertTrue(np.all(c.path>.0075));self.assertTrue(np.all(c.path<.02))
        self.assertEqual(calibration,original)
        self.assertTrue(result['debug']['governor']['actual_position_window_stable'])
        self.assertFalse(result['debug']['physical_stopping_certified'])

    def test_position_reached_without_measured_rest_cannot_advance(self):
        obs,calibration,c=self.construct()
        result=self.until(obs,calibration,c,lambda r:c.phase=='lift_out_settle')
        self.assertFalse(result['done']);self.assertEqual(c.index,0)
        self.assertEqual(c.segments,[])
        self.assertFalse(result['debug']['governor'].get('actual_position_window_stable',True))
        for _ in range(3):
            integrate(obs,result['action'],calibration)
            with patch.object(trial,'_cloth_evidence',side_effect=visible):result=c.step(obs)
            self.assertEqual(c.index,0)
        result=self.until(obs,calibration,c,lambda r:c.index==1)
        self.assertEqual(len(c.segments),1)

    def test_identical_frames_do_not_spend_path_time_or_switch_stage(self):
        obs,calibration,c=self.construct()
        result=self.until(obs,calibration,c,lambda r:c.phase=='lift_out_settle')
        before=(c.index,c.phase,c.last_time,c.path.copy(),deepcopy(c.segments))
        for _ in range(25):
            with patch.object(trial,'_cloth_evidence',side_effect=visible):repeat=c.step(obs)
            np.testing.assert_array_equal(repeat['action'][:,:8],0.)
            self.assertEqual((c.index,c.phase,c.last_time),before[:3])
            np.testing.assert_array_equal(c.path,before[3]);self.assertEqual(c.segments,before[4])
            self.assertFalse(repeat['done'])

    def test_pending_failure_latches_halt_and_preserves_bounded_cancel_action(self):
        obs,calibration,c=self.construct()
        self.until(obs,calibration,c,lambda r:c.phase=='lift_out')
        pending=deepcopy(c.governor._result())
        cancel=np.zeros((2,9),np.float32);cancel[:,8]=1.;cancel[:,3]=-.0002/1.54
        pending.update(action=cancel,settled=False,failure=None,pending_failure='synthetic pending stop',cancellation_only=True)
        with patch.object(c.governor,'step',return_value=pending) as step, \
                patch.object(trial,'_cloth_evidence',side_effect=visible):
            obs['simulation_time_s'][...]+=.05
            first=c.step(obs)
            np.testing.assert_array_equal(first['action'],cancel)
            self.assertTrue(first['cancellation_only']);self.assertIsNone(first['failure'])
            obs['simulation_time_s'][...]+=.05
            pending['settled']=True  # Defensive inconsistent result cannot advance.
            second=c.step(obs)
            self.assertTrue(step.call_args.kwargs['halt'])
            np.testing.assert_array_equal(step.call_args.args[1][:,:8],0.)
            self.assertEqual(c.index,0);self.assertFalse(second['done'])
            self.assertEqual(second['pending_failure'],'synthetic pending stop')

    def test_missing_cloth_new_drift_and_original_budgets_never_fake_completion(self):
        for fault in ('cloth','base','grasp','coordinate','path','time','closed'):
            with self.subTest(fault=fault):
                obs,calibration,c=self.construct()
                result=self.until(obs,calibration,c,lambda r:c.phase=='lift_out')
                integrate(obs,result['action'],calibration)
                if fault=='cloth':obs['depth_valid'][:]=False
                if fault=='base':obs['base_pose_world'][0,0]+=.0031
                if fault=='grasp':obs['grasp_pose_base'][0,0]+=.0046
                if fault=='coordinate':obs['joint_position'][0,3]+=.0033
                if fault=='path':c.path[0]=.02001
                if fault=='time':c.time0=float(obs['simulation_time_s'])-30.01
                if fault=='closed':obs['gripper_close_command'][0]=False
                if fault=='cloth':result=c.step(obs)  # Real RGB-D support rejection.
                else:
                    with patch.object(trial,'_cloth_evidence',side_effect=visible):result=c.step(obs)
                self.assertIsNotNone(result['failure'],result)
                self.assertFalse(result['done']);self.assertEqual(c.segments,[])
                self.assertTrue(result['debug']['simulation_level_stop_required'])
                np.testing.assert_array_equal(result['action'][:,:8],0.)


if __name__=='__main__':unittest.main()
