"""Offline report fixtures only; no actor, simulator or physical-run writes."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


path = Path(__file__).resolve().parents[1]/'inspect_results.py'
spec = importlib.util.spec_from_file_location('contact_result_review', path)
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


def pulse(shift=.005):
    return dict(measured_grasp_shift_world=[[shift, 0., 0.], [shift, 0., 0.]],
        fixed_cloth_shift_world=[[shift-.0002, 0., 0.], [shift-.0001, 0., 0.]],
        cloth_proximal_progress_m=[shift-.0002, shift-.0001], cloth_vs_grasp_error_m=[.0002, .0001],
        current_proximal_cloth_voxels=[30, 31], previous_proximal_cloth_voxels=[10, 12],
        sleeve_entry_verified=False)


def row(step=1, now=12., pulses=(), advance=.005, nominal=0., phase='contact_pulse'):
    return dict(step=step, simulation_time_s=now,
        debug=dict(phase='hypothesis_contact', failure=None,
            hypothesis_contact=dict(phase=phase, pending_failure=None,
                commanded_advance_from_distal_goal_m=advance,
                nominal_advance_beyond_distal_surface_m=nominal, pulse_results=deepcopy(list(pulses)),
                skin=dict(retained_observation_time_s=11., fixed_stationary_anchor_observation_time_s=5.),
                own_geometry_clearance=[dict(valid=True, robot=0, checked_segment='existing_pending_target',
                    observed_minimum_clearance_m=.030, skin_observed_at=5., skin_age_s=now-5.),
                    dict(valid=True, robot=1, checked_segment='proposed_interval', observed_minimum_clearance_m=.025,
                         skin_observed_at=5., skin_age_s=now-5.)])))


class InspectContactResultsTests(unittest.TestCase):
    def test_cumulative_pulses_not_recounted_and_vectors_remain_actual_measurements(self):
        first, second = pulse(), pulse(.0049)
        rows = [row(pulses=[first]), row(step=2, now=12.05, pulses=[first]),
                row(step=3, now=15., pulses=[first, second], advance=.01)]
        result = review.hypothesis_contact_statistics(rows)
        self.assertEqual(result['pulse_response_count'], 2)
        self.assertEqual(result['diagnostic_records'], 3)
        self.assertEqual(result['pulse_conflicts'], [])
        self.assertEqual(result['pulse_responses'][0]['response']['measured_grasp_shift_world'],
                         first['measured_grasp_shift_world'])
        self.assertEqual(result['pulse_responses'][1]['response']['fixed_cloth_shift_world'],
                         second['fixed_cloth_shift_world'])
        self.assertIsNone(result['pulse_responses'][0]['pulse_measurement_time_s'])
        self.assertEqual(result['pulse_responses'][0]['first_logged_public_time_s'], 12.)

    def test_retained_payload_preserves_skin_timestamps_and_ages_at_later_log_clock(self):
        initial = row(pulses=[pulse()])
        later = deepcopy(initial); later.update(step=20, simulation_time_s=40.)
        result = review.hypothesis_contact_statistics([initial, later])
        latest = result['latest']
        self.assertEqual(latest['current_skin']['observation_time_s'], 11.)
        self.assertEqual(latest['current_skin']['age_at_log_record_s'], 29.)
        self.assertEqual(latest['fixed_skin_anchor']['observation_time_s'], 5.)
        self.assertEqual(latest['fixed_skin_anchor']['age_at_log_record_s'], 35.)
        self.assertEqual(latest['current_skin']['status'], 'older_than_declared_age_limit')
        self.assertIsNone(latest['experiment_observation_time_s'])
        self.assertEqual(result['pulse_response_count'], 1)

    def test_missing_future_and_nonfinite_values_stay_unknown_not_zero_or_fresh(self):
        source = row(now=10.)
        contact = source['debug']['hypothesis_contact']
        contact['skin'] = dict(retained_observation_time_s=12.)
        contact['commanded_advance_from_distal_goal_m'] = float('nan')
        contact['nominal_advance_beyond_distal_surface_m'] = True
        contact['own_geometry_clearance'] = [dict(valid=True, observed_minimum_clearance_m=float('nan')),
            dict(valid=False, observed_minimum_clearance_m=.0001), None]
        contact['pulse_results'] = [dict(measured_grasp_shift_world=[[float('nan'), 0, 0], [0, 0, 0]])]
        result = review.hypothesis_contact_statistics([source])
        latest = result['latest']
        self.assertIsNone(latest['commanded_advance_from_distal_goal_m'])
        self.assertIsNone(latest['nominal_advance_beyond_distal_surface_m'])
        self.assertIsNone(latest['observed_skin_clearance_min_m'])
        self.assertIsNone(result['minimum_saved_observed_skin_clearance_m'])
        self.assertEqual(latest['current_skin']['status'], 'future_timestamp_invalid')
        self.assertIsNone(latest['current_skin']['age_at_log_record_s'])
        self.assertIsNone(latest['fixed_skin_anchor']['observation_time_s'])
        self.assertIsNone(result['pulse_responses'][0]['response']['measured_grasp_shift_world'])
        json.dumps(result, allow_nan=False)

    def test_phase_pending_stop_failure_and_minimum_valid_clearance_are_reported(self):
        initial = row()
        stopped = row(step=2, now=15., phase='stopped')
        contact = stopped['debug']['hypothesis_contact']
        contact['pending_failure'] = 'cloth cohort lost'
        stopped['debug']['failure'] = 'hypothesis contact: cloth cohort lost'
        contact['own_geometry_clearance'][0]['observed_minimum_clearance_m'] = .019
        result = review.hypothesis_contact_statistics([initial, stopped])
        self.assertEqual(result['latest']['phase'], 'stopped')
        self.assertEqual(result['latest']['pending_failure'], 'cloth cohort lost')
        self.assertIn('cloth cohort lost', result['latest']['failure'])
        self.assertEqual(result['minimum_saved_observed_skin_clearance_m'], .019)
        self.assertEqual([p['phase'] for p in result['phase_transitions']], ['contact_pulse', 'stopped'])

    def test_conflicting_same_pulse_index_is_flagged_without_counting_an_extra_pulse(self):
        initial = row(pulses=[pulse()])
        changed = row(step=2, pulses=[pulse(.006)])
        result = review.hypothesis_contact_statistics([initial, changed])
        self.assertEqual(result['pulse_response_count'], 1)
        self.assertEqual(result['pulse_conflicts'][0]['pulse_index'], 1)
        self.assertEqual(result['pulse_responses'][0]['response']['measured_grasp_shift_world'][0][0], .005)

    def test_legacy_actor_records_keep_existing_output_without_contact_key(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'progress.jsonl'
            path.write_text(json.dumps(dict(step=1, simulation_time_s=2., debug=dict(phase='pair_navigate')))+'\n')
            result = review.actor_statistics(path)
        self.assertEqual(result['latest_phase'], 'pair_navigate')
        self.assertEqual(result['latest_step'], 1)
        self.assertNotIn('hypothesis_contact', result)
        self.assertIsNone(review.hypothesis_contact_statistics([{'debug': None}, {'debug': {'hypothesis_contact': {}}}]))

    def test_approach_nominal_advance_and_visible_growth_do_not_override_official_success(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory)/'fixture_run'
            ep = run/'official_evaluation/episodes/000'; ep.mkdir(parents=True)
            diag = run/'diagnostics/episode_001'; diag.mkdir(parents=True)
            (run/'launch.json').write_text(json.dumps(dict(seeds=[0], seconds=300)))
            (run/'completion.json').write_text(json.dumps(dict(exit_code=0)))
            (ep/'samples.jsonl').write_text(json.dumps(dict(time_s=1.))+'\n')
            (ep/'result.json').write_text(json.dumps(dict(valid=True, reason='policy_horizon',
                result=dict(raw_points=0, max_raw_points=100, success=False, dressing_complete=False, final_score=0))))
            rows = [row(pulses=[pulse()], advance=.020, nominal=0.),
                    row(step=2, now=15., pulses=[pulse(), pulse()], advance=.040, nominal=.020,
                        phase='bounded_contact_trial_finished')]
            rows[-1]['debug']['hypothesis_contact']['physical_contact_or_entry_verified'] = True
            (diag/'progress.jsonl').write_text('\n'.join(json.dumps(item) for item in rows)+'\n')
            result = review.summarize_run(run)
            official = result['episodes'][0]['official']['score']
            contact = result['episodes'][0]['actor']['hypothesis_contact']
            text = review.chinese_report(result)
        self.assertFalse(official['success'])
        self.assertFalse(official['dressing_complete'])
        self.assertEqual(official['raw_points'], 0)
        self.assertEqual(contact['snapshots'][0]['commanded_advance_from_distal_goal_m'], .020)
        self.assertEqual(contact['snapshots'][0]['nominal_advance_beyond_distal_surface_m'], 0.)
        self.assertEqual(contact['latest']['nominal_advance_beyond_distal_surface_m'], .020)
        self.assertFalse(contact['actual_sleeve_entry_verified'])
        self.assertFalse(contact['success_inferred_from_contact_diagnostics'])
        self.assertIn('实际袖口进入未验证', text)
        self.assertIn('完整穿衣成功：False', text)
        self.assertIn('脉冲 2：实测双夹爪位移', text)

    def test_invalid_official_result_is_not_promoted_by_completed_contact_phase(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'result.json'
            path.write_text(json.dumps(dict(valid=False, reason='error', result=dict(success=True, raw_points=100))))
            result = review.official_result(path)
        self.assertFalse(result['usable_score'])
        self.assertNotIn('score', result)


if __name__ == '__main__':
    unittest.main()
