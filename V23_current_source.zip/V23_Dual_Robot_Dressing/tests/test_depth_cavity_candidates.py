"""Synthetic public-RGBD evidence tests, not physical cuff or insertion proof."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'participant'))
import depth_cavity_candidates as cavity
from human_targets import _world_pixels, _validated
from opening_candidates import detect_opening_candidates


def scene(gap=.03, camera=3, shape='rectangle'):
    pose = np.zeros((2, 7), np.float32); pose[:, 3] = 1
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
               depth=np.zeros((5, 256, 256, 1), np.float32),
               depth_valid=np.zeros((5, 256, 256, 1), bool),
               base_pose_world=pose.copy(), grasp_pose_base=pose.copy(),
               simulation_time_s=np.array(2.5, np.float32))
    obs['rgb'][camera] = [10, 20, 230]
    obs['depth'][camera, ..., 0] = 1.
    obs['depth_valid'][camera] = True
    mask = np.zeros((256, 256), np.uint8)
    mask[108:149, 108:149] = 1
    if shape == 'concave':
        mask[108:132, 123:134] = 0
    obs['depth'][camera, ..., 0][mask.astype(bool)] = 1.+gap
    world = _world_pixels(_validated(obs, wrists=True), camera, np.array([105]), np.array([128]), np.array([1.]))[0]
    grasps = np.stack((world, world+np.array([2., 0., 0.])))
    return obs, grasps, mask.astype(bool)


class DepthCavityTests(unittest.TestCase):
    def detect(self, obs, grasps, **kwargs):
        return cavity.detect_depth_cavity_candidates(obs, grasps, **kwargs)

    def test_blue_inner_wall_proposed_without_colour_hole_and_input_unchanged(self):
        obs, grasps, mask = scene()
        before = deepcopy(obs)
        self.assertFalse(detect_opening_candidates(obs)['detected'])
        result = self.detect(obs, grasps)
        self.assertTrue(result['detected'], result)
        self.assertEqual(len(result['depth_cavity_candidates']), 1)
        candidate = result['depth_cavity_candidates'][0]
        self.assertEqual(candidate['kind'], 'unclassified_depth_cavity')
        self.assertEqual(candidate['depth_evidence']['deeper_cloth_fraction'], 1.)
        self.assertAlmostEqual(candidate['depth_evidence']['optical_z_recession_m']['median'], .03, places=6)
        self.assertEqual(candidate['depth_evidence']['interior_pixel_count'], int(mask.sum()))
        for key, value in obs.items():
            np.testing.assert_array_equal(value, before[key])
        self.assertFalse(candidate['insertion_allowed'])
        self.assertFalse(candidate['physical_opening_verified'])
        self.assertFalse(candidate['attachment_verified'])
        self.assertFalse(candidate['depth_evidence']['free_advance_verified'])
        self.assertIsNone(candidate['depth_evidence']['permitted_advance_m'])

    def test_flat_shallow_and_smooth_fold_do_not_invent_closed_rim(self):
        for gap in (0., .005, .012):
            obs, grasps, _ = scene(gap)
            self.assertFalse(self.detect(obs, grasps)['detected'])
        obs, grasps, _ = scene(0.)
        v, u = np.indices((256, 256))
        # A smoothly varying cloth depression, without a measured near/far lip.
        obs['depth'][3, ..., 0] = 1.+.06*np.exp(-((u-128)**2+(v-128)**2)/(2*18.**2))
        self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_depth_step_fold_cannot_be_semantically_called_a_cuff(self):
        # A folded cloth pocket may be observationally identical to this scene.
        obs, grasps, _ = scene()
        candidate = self.detect(obs, grasps)['depth_cavity_candidates'][0]
        self.assertFalse(candidate['fold_or_depression_excluded'])
        self.assertFalse(candidate['garment_topology_known'])
        self.assertFalse(candidate['sleeve_identity_verified'])
        self.assertFalse(candidate['motion_authorized'])

    def test_concave_notch_remains_in_both_ordered_contours(self):
        obs, grasps, _ = scene(shape='concave')
        result = self.detect(obs, grasps)
        self.assertTrue(result['detected'], result)
        candidate = result['depth_cavity_candidates'][0]
        polygon = np.asarray(candidate['projected_aperture']['contour_pixels_uv'], np.float32)
        rim = np.asarray(candidate['ordered_inner_lip']['source_pixels_uv'], np.float32)
        self.assertFalse(cv2.isContourConvex(polygon))
        self.assertFalse(cv2.isContourConvex(rim))
        self.assertLess(cv2.pointPolygonTest(polygon, (128., 120.), False), 0)
        self.assertGreater(cv2.pointPolygonTest(polygon, (115., 120.), False), 0)

    def test_rim_coordinates_are_measured_current_pixels(self):
        obs, grasps, _ = scene()
        candidate = self.detect(obs, grasps)['depth_cavity_candidates'][0]
        lip = candidate['ordered_inner_lip']
        uv = np.asarray(lip['source_pixels_uv'])
        z = obs['depth'][3, uv[:, 1], uv[:, 0], 0]
        np.testing.assert_allclose(lip['measured_depth_z_m'], z)
        expected = _world_pixels(_validated(obs, wrists=True), 3, uv[:, 0], uv[:, 1], z)
        np.testing.assert_allclose(lip['measured_points_world'], expected, atol=1e-7)
        self.assertTrue(lip['closed_observed'])
        self.assertEqual(candidate['observation_time_s'], 2.5)

    def test_foreground_island_and_intruding_occluder_reject(self):
        for rectangle in ((123, 134, 123, 134), (105, 128, 123, 134)):
            obs, grasps, _ = scene()
            top, bottom, left, right = rectangle
            obs['depth'][3, top:bottom, left:right, 0] = .9
            obs['rgb'][3, top:bottom, left:right] = [160, 120, 110]
            self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_missing_interior_or_rim_depth_rejects(self):
        for pixel in ((128, 128), (107, 128)):
            obs, grasps, _ = scene()
            u, v = pixel
            obs['depth_valid'][3, v, u, 0] = False
            self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_open_edge_to_image_boundary_is_not_closed(self):
        obs, grasps, _ = scene()
        obs['depth'][3, 120:137, :109, 0] = 1.03
        result = self.detect(obs, grasps)
        self.assertFalse(result['detected'])
        self.assertTrue(result['rejected_candidate_counts'])

    def test_partial_rim_colour_occlusion_does_not_get_filled(self):
        obs, grasps, _ = scene()
        obs['rgb'][3, 107, 120:135] = [150, 150, 150]
        self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_remote_grasps_and_overview_do_not_seed_candidates(self):
        obs, grasps, _ = scene()
        self.assertFalse(self.detect(obs, grasps+10)['detected'])
        obs['rgb'][0] = obs['rgb'][3]
        obs['depth'][0] = obs['depth'][3]
        obs['depth_valid'][0] = obs['depth_valid'][3]
        obs['rgb'][3] = 0
        self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_any_interior_colour_and_optical_depth_distribution(self):
        obs, grasps, mask = scene()
        obs['rgb'][3][mask] = [180, 180, 180]
        candidate = self.detect(obs, grasps)['depth_cavity_candidates'][0]
        depth = candidate['depth_evidence']
        self.assertEqual(depth['deeper_cloth_fraction'], 0.)
        self.assertGreaterEqual(depth['first_surface_distance_behind_plane_along_camera_ray_m']['min'],
                                depth['optical_z_recession_m']['min'])
        self.assertEqual(depth['foreground_obstruction_pixels'], 0)
        self.assertEqual(depth['missing_depth_pixels'], 0)

    def test_current_frame_change_is_recomputed_not_cached(self):
        obs, grasps, _ = scene()
        self.assertTrue(self.detect(obs, grasps)['detected'])
        obs['simulation_time_s'] = np.array(2.55)
        obs['depth'][3] = 1.
        self.assertFalse(self.detect(obs, grasps)['detected'])

    def test_tilted_near_cloth_plane_and_cavity_use_ray_plane_depth(self):
        obs, grasps, mask = scene()
        v, u = np.indices((256, 256))
        rays = cavity.pixel_rays(u, v, cavity._FOCAL)
        plane_depth = 1./(1.+.2*rays[..., 0])
        obs['depth'][3, ..., 0] = plane_depth
        point = _world_pixels(_validated(obs, wrists=True), 3, np.array([105]), np.array([128]),
                              np.array([plane_depth[128, 105]]))[0]
        grasps = np.stack((point, point+[2., 0., 0.]))
        self.assertFalse(self.detect(obs, grasps)['detected'])
        obs['depth'][3, ..., 0][mask] += .03
        result = self.detect(obs, grasps)
        self.assertTrue(result['detected'], result)
        candidate = result['depth_cavity_candidates'][0]
        self.assertAlmostEqual(candidate['depth_evidence']['optical_z_recession_m']['median'], .03, places=5)

    def test_robot_camera_provenance_including_both_wrists(self):
        for camera in (1, 2, 3, 4):
            obs, grasps, _ = scene(camera=camera)
            result = self.detect(obs, grasps)
            self.assertTrue(result['detected'], result)
            self.assertEqual({c['camera_index'] for c in result['depth_cavity_candidates']}, {camera})
            self.assertTrue(all(c['observation_time_s'] == 2.5 for c in result['depth_cavity_candidates']))

    def test_invalid_time_and_parameters_reject(self):
        obs, grasps, _ = scene()
        for keyword in ({'min_recession_m': 0}, {'radius_m': 2}):
            with self.assertRaises(ValueError):
                self.detect(obs, grasps, **keyword)
        obs['simulation_time_s'] = np.array(float('nan'))
        with self.assertRaises(ValueError):
            self.detect(obs, grasps)


if __name__ == '__main__':
    unittest.main()
