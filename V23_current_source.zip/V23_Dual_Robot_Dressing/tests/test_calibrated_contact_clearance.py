"""CPU evidence/own-box checks only; no simulation or physical safety claims."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import calibrated_contact_clearance as clearance
from calibrated_contact_governor import CalibratedContactGovernor
from contact_motion_governor import ContactMotionGovernor
from gripper_skin_clearance import observed_gripper_skin_clearance
from test_gripper_skin_clearance import observation as geometry_observation
from wrist_sweep_envelope import jaw_sweep_envelope, wrist_sweep_envelope


SEGMENTS = {
    'raw_pending_target': 'raw_pending_translation_world',
    'raw_pending_plus_proposed': 'raw_pending_plus_proposed_world',
    'prior_excess_pending_target': 'excess_pending_translation_world',
    'excess_pending_plus_proposed': 'excess_pending_plus_proposed_world',
}


def fixture(*, raw_lift=0., lift_bias=0., wrist_bias=0., jaw=.103,
            jaw_target=None, jaw_speed=(0., 0.), wrist_speed=0.,
            lift_speed=0., linear_peak=(0., 0.), wrist_peak=0.):
    """Real governor evidence from raw poses consistent with the own FK tree."""
    obs = geometry_observation(jaw=jaw)
    obs['base_pose_world'][1, 1] = .7
    q = obs['joint_position']
    q[:, 3] = .5
    q[:, 4:8] = .05
    obs['joint_velocity'] = np.zeros((2, 13))
    obs['joint_velocity'][:, 3] = lift_speed
    obs['joint_velocity'][:, 8] = wrist_speed
    obs['joint_velocity'][:, 11:13] = jaw_speed
    obs['base_twist_world'] = np.zeros((2, 6))
    target = np.zeros((2, 9))
    target[:, 0] = q[:, 3]+raw_lift
    target[:, 1] = q[:, 4:8].sum(1)
    target[:, 2:5] = q[:, 8:11]
    target[:, 2] += wrist_bias
    target[:, 5] = jaw if jaw_target is None else jaw_target
    obs['controller_target'] = target
    hold = np.zeros((2, 9), np.float32)
    hold[:, 8] = 1.
    obs['previous_action'] = hold.copy()
    obs['gripper_close_command'] = np.ones((2, 1), dtype=bool)
    obs['fingertip_origin_distance'] = np.linalg.norm(
        obs['fingertip_position_base'][:, 1]-obs['fingertip_position_base'][:, 0], axis=1)
    bias, peak = np.zeros((2, 5)), np.zeros((2, 5))
    bias[:, 0], bias[:, 2] = lift_bias, wrist_bias
    peak[:, :2], peak[:, 2] = linear_peak, wrist_peak
    calibration = dict(
        observed_at_s=10., window_start_s=9.5, frame_count=11,
        method='Synthetic public sampled equilibrium; not physical evidence.',
        controller_bias=bias.tolist(), controller_bias_peak_deviation=peak.tolist(),
        arm_position_offsets=np.zeros((2, 4)).tolist(),
        arm_position_offsets_peak_deviation=np.zeros((2, 4)).tolist(),
        raw_joint_velocity_median=obs['joint_velocity'].tolist(),
        raw_joint_velocity_peak_deviation=np.zeros((2, 13)).tolist(),
        last_joint_position=q.tolist(), last_base_pose=obs['base_pose_world'].tolist(),
        controller_target_reference=target.tolist())
    governor = CalibratedContactGovernor(obs, calibration=calibration)
    result = governor.step(obs, hold, halt=True)
    if result['failure'] or not result['motion_evidence']['valid']:
        raise AssertionError(result)
    points = ContactMotionGovernor._read(obs)['grasps']-[0., 0., .10]
    return obs, result['motion_evidence'], result['action'], points


def evaluate(obs, evidence, action, points, **kwargs):
    options = dict(current_skin_observed_at=10., original_skin_observed_at=9.9,
                   stationary_skin=True)
    options.update(kwargs)
    return clearance.calibrated_contact_clearance(
        obs, evidence, action, points, points.copy(), **options)


class CalibratedContactClearanceTests(unittest.TestCase):
    def test_public_wrapper_checks_real_own_geometry_for_all_eight_segments(self):
        obs, evidence, action, points = fixture()
        before_obs, before_evidence, before_action = deepcopy(obs), deepcopy(evidence), action.copy()
        result = clearance.check_calibrated_contact_clearance(
            obs, evidence, action, skin=points, skin_observed_at=10.,
            skin_anchor=points.copy(), skin_anchor_observed_at=9.9)
        self.assertTrue(result['valid'], result)
        self.assertEqual(len(result['checks']), 8)
        self.assertEqual({(r['robot'], r['checked_segment']) for r in result['checks']},
                         {(robot, name) for robot in (0, 1) for name in SEGMENTS})
        for report in result['checks']:
            geometry = report['clearance']
            self.assertTrue(geometry['valid'], geometry)
            self.assertGreaterEqual(geometry['observed_minimum_clearance_m'], .020)
            self.assertFalse(geometry['collision_free'])
            self.assertFalse(geometry['fullbody_clearance'])
            self.assertFalse(geometry['insertion_allowed'])
            self.assertFalse(geometry['unobserved_skin_clearance_known'])
            np.testing.assert_allclose(report['translation_world_m'],
                                       evidence[SEGMENTS[report['checked_segment']]][report['robot']])
        for key in obs:
            np.testing.assert_array_equal(obs[key], before_obs[key])
        self.assertEqual(evidence, before_evidence)
        np.testing.assert_array_equal(action, before_action)

    def test_reverse_pending_is_checked_even_when_proposed_move_cancels_it(self):
        obs, evidence, action, points = fixture(raw_lift=.0005, lift_bias=.001)
        self.assertGreater(evidence['raw_pending_translation_world'][0][2], 0.)
        self.assertLess(evidence['excess_pending_translation_world'][0][2], 0.)
        np.testing.assert_allclose(evidence['excess_pending_plus_proposed_world'], 0., atol=1e-10)
        inspected = []

        def geometric_obstacle(observed, robot, skin, **kwargs):
            delta = np.asarray(kwargs['proposed_translation_world'])
            inspected.append(delta.copy())
            report = observed_gripper_skin_clearance(observed, robot, skin, **kwargs)
            if delta[2] < -.0001:
                report['observed_minimum_clearance_m'] = .019
            return report

        with patch.object(clearance, 'observed_gripper_skin_clearance', side_effect=geometric_obstacle):
            result = evaluate(obs, evidence, action, points)
        self.assertFalse(result['valid'], result)
        self.assertTrue(any(delta[2] < -.0001 for delta in inspected))
        self.assertTrue(any(r['checked_segment'] == 'prior_excess_pending_target'
                            for r in result['reports']))

    def test_evidence_must_be_valid_current_and_match_every_raw_motion_input(self):
        obs, evidence, action, points = fixture()
        for fault in ('invalid', 'stale', 'raw_joint_position', 'raw_joint_velocity',
                      'raw_controller_target', 'raw_base_twist_world'):
            with self.subTest(fault=fault):
                altered = deepcopy(evidence)
                if fault == 'invalid': altered['valid'] = False
                elif fault == 'stale': altered['observation_time_s'] -= .05
                else: altered[fault][0][3 if fault != 'raw_base_twist_world' else 0] += .0001
                result = evaluate(obs, altered, action, points)
                self.assertFalse(result['valid'], result)

    def test_action_prediction_and_pending_vectors_are_recomputed(self):
        obs, evidence, action, points = fixture()
        for fault in ('action', 'predicted_next_raw_controller_target',
                      'proposed_interval_translation_world', 'raw_pending_translation_world',
                      'excess_pending_translation_world', 'raw_pending_plus_proposed_world',
                      'excess_pending_plus_proposed_world'):
            with self.subTest(fault=fault):
                altered, wrong_action = deepcopy(evidence), action.copy()
                if fault == 'action': wrong_action[0, 3] += .001
                else: altered[fault][0][0] += .0001
                result = evaluate(obs, altered, wrong_action, points)
                self.assertFalse(result['valid'], result)

    def test_angular_rate_and_sampled_bias_reserves_add_to_original_3mm(self):
        obs, evidence, action, points = fixture(
            wrist_bias=np.deg2rad(.1), jaw=.14, lift_speed=.004,
            linear_peak=(.000001, .000002), wrist_peak=np.deg2rad(.004), wrist_speed=.001)
        actual_q = []

        def envelope(q, raw, excess, **kwargs):
            actual_q.append(np.asarray(q).copy())
            return wrist_sweep_envelope(q, raw, excess, **kwargs)

        with patch.object(clearance, 'wrist_sweep_envelope', side_effect=envelope):
            result = evaluate(obs, evidence, action, points)
        self.assertTrue(result['valid'], result)
        self.assertGreaterEqual(len(actual_q), 2)
        for q in actual_q:
            np.testing.assert_allclose(q[11:13], [.14, .14])
        for report in result['reports']:
            robot = report['robot']
            q = obs['joint_position'][robot, 8:11]
            target = obs['controller_target'][robot, 2:5]
            rate = np.abs(obs['joint_velocity'][robot, 8:11])*.05
            raw = np.column_stack((np.minimum(q, target)-rate, np.maximum(q, target)+rate))
            centre = (obs['controller_target'][robot, 2:5]
                      -np.asarray(evidence['frozen_controller_bias'])[robot, 2:5])
            peak = np.asarray(evidence['sampled_bias_peak_deviation'])[robot, 2:5]
            expected = wrist_sweep_envelope(obs['joint_position'][robot], raw,
                                            np.column_stack((np.minimum(q, centre-peak)-rate,
                                                             np.maximum(q, centre+peak)+rate)))
            without_rate = wrist_sweep_envelope(
                obs['joint_position'][robot], np.column_stack((target, target)),
                np.column_stack((centre-peak, centre+peak)))
            reserve = expected['max_displacement_reserve_m']
            self.assertGreater(reserve, without_rate['max_displacement_reserve_m'])
            self.assertAlmostEqual(report['additional_angular_reserve_m'], reserve, places=12)
            self.assertAlmostEqual(report['rate_reserve_m'],
                                   evidence['conservative_geometry_rate_reserve_m'][robot], places=12)
            self.assertAlmostEqual(report['sampled_bias_reserve_m'], .000003, places=12)
            self.assertAlmostEqual(report['model_margin_m'],
                                   .003+report['rate_reserve_m']+.000003+reserve
                                   +report['additional_jaw_reserve_m'], places=12)

    def test_measured_small_jaw_motion_adds_reserve_and_excess_wrist_rate_rejects(self):
        obs, evidence, action, points = fixture(
            jaw=(.10321, .10349), jaw_target=.103, jaw_speed=(.00690, -.00906))
        result = evaluate(obs, evidence, action, points)
        self.assertTrue(result['valid'], result)
        self.assertEqual(len(result['reports']), 8)
        for report in result['reports']:
            robot = report['robot']
            expected = jaw_sweep_envelope(obs['joint_position'][robot], .103,
                                         obs['joint_velocity'][robot, 11:13])
            reserve = expected['max_displacement_reserve_m']
            self.assertGreater(reserve, 0.)
            self.assertAlmostEqual(report['additional_jaw_reserve_m'], reserve, places=12)
            self.assertAlmostEqual(report['model_margin_m'],
                                   .003+report['rate_reserve_m']+report['sampled_bias_reserve_m']
                                   +report['additional_angular_reserve_m']+reserve, places=12)
            np.testing.assert_allclose(report['clearance']['measured_jaw_angles_rad'], [.10321, .10349])
        obs, evidence, action, points = fixture(wrist_bias=np.deg2rad(.3), wrist_speed=.2)
        rejected = evaluate(obs, evidence, action, points)
        self.assertFalse(rejected['valid'], rejected)

    def test_original_skin_timestamps_and_explicit_stationary_assumption_are_required(self):
        obs, evidence, action, points = fixture()
        for options in (
                {'stationary_skin': False},
                {'current_skin_observed_at': -10.0001},
                {'original_skin_observed_at': -170.0001},
                {'current_skin_observed_at': 10.0001},
                {'original_skin_observed_at': 10.0001}):
            with self.subTest(options=options):
                self.assertFalse(evaluate(obs, evidence, action, points, **options)['valid'])
        at_bounds = evaluate(obs, evidence, action, points,
                             current_skin_observed_at=-10., original_skin_observed_at=-170.)
        self.assertTrue(at_bounds['valid'], at_bounds)
        implicit = clearance.calibrated_contact_clearance(
            obs, evidence, action, points, points,
            current_skin_observed_at=10., original_skin_observed_at=9.9)
        self.assertFalse(implicit['valid'], implicit)

    def test_nonfinite_inputs_and_measured_jaws_outside_own_limits_are_rejected(self):
        for fault in ('raw_nan', 'action_nan', 'skin_nan', 'bias_nan', 'negative_peak',
                      'actual_jaw_outside_own_limit'):
            with self.subTest(fault=fault):
                obs, evidence, action, points = fixture()
                if fault == 'raw_nan':
                    obs['joint_position'][0, 3] = np.nan
                    evidence['raw_joint_position'][0][3] = np.nan
                elif fault == 'action_nan': action[0, 3] = np.nan
                elif fault == 'skin_nan': points[0, 0] = np.nan
                elif fault == 'bias_nan': evidence['frozen_controller_bias'][0][0] = np.nan
                elif fault == 'negative_peak': evidence['sampled_bias_peak_deviation'][0][0] = -.0001
                else:
                    obs['joint_position'][0, 11] = .6
                    evidence['raw_joint_position'][0][11] = .6
                result = evaluate(obs, evidence, action, points)
                self.assertFalse(result['valid'], result)


if __name__ == '__main__':
    unittest.main()
