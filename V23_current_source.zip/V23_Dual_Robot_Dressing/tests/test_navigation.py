"""CPU-only velocity guard checks; no simulator, scene truth, or movement."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import navigation


def observation(yaw=0.):
    return dict(depth=np.zeros((5, 256, 256, 1), np.float32),
                depth_valid=np.zeros((5, 256, 256, 1), bool),
                joint_position=np.zeros((2, 13), np.float32),
                base_pose_world=np.array([[0, 0, 0, np.cos(yaw/2), 0, 0, np.sin(yaw/2)],
                                          [3, 3, 0, 1, 0, 0, 0]], np.float32),
                grasp_pose_base=np.array([[.6, -.1, 1., 1, 0, 0, 0],
                                          [.6, -.1, 1., 1, 0, 0, 0]], np.float32))


def geometry(points):
    return dict(points=np.asarray(points, dtype=float).reshape(-1, 3),
                sampled_valid_count=len(points), filtered_self_count=0)


def v06_public_nearest_rays():
    """Eight PUBLIC depth samples recovered from v06 step648 diagnostics.

    Pixel/depth source was recovered by reprojection to stride-8 grid. The
    integer-index mast reconstruction was 3.531334 mm outside its visual; the
    +.5 pixel-centre reconstruction is 0.000212 mm from the exact contour.
    Chassis points then agree with published visual triangles within 0.0004 mm
    before 10-micrometre mesh quantization. No evaluator truth is used.
    """
    obs = observation()
    obs['base_pose_world'] = np.array([
        [-1.1037094593048096, -.12215159088373184, -.0036288066767156124,
         -.9965724945068359, .001476468751206994, .0031278885435312986, -.08265114575624466],
        [1.1401846408843994, -.5820048451423645, -.003629095386713743,
         -.7072257399559021, .0033400433603674173, .0008962142746895552, .7069792151451111]])
    obs['grasp_pose_base'] = np.array([
        [.47999194264411926, -.08724536746740341, .8331663608551025,
         .9999977946281433, -.000027396548830438405, .002070880960673094, .00029411050491034985],
        [.4926087260246277, -.08745309710502625, .8321753144264221,
         .9362996220588684, -.000011445613381511066, .35120224952697754, -.0000566542221349664]])
    sources = [(3, 184, 104, 2.2013733386993404), (3, 200, 136, 2.372663021087646),
        (3, 184, 136, 2.3584237098693843), (1, 176, 152, 2.0792424678802495),
        (1, 184, 160, 1.8755080699920654), (3, 176, 128, 2.40707778930664),
        (1, 176, 160, 1.9936852455139162), (3, 240, 104, 2.20531415939331)]
    for camera, u, v, depth in sources:
        obs['depth'][camera, v, u, 0] = depth
        obs['depth_valid'][camera, v, u, 0] = True
    return obs


class NavigationTest(unittest.TestCase):
    def test_yaw_rotates_forward_velocity_to_world_left(self):
        obs = observation(np.pi/2)
        with patch.object(navigation, '_depth_obstacle_points', return_value=geometry([])):
            result = navigation.guard_base_velocity(obs, 0, [.1, 0])
        np.testing.assert_allclose(result['speed_bounded_world_velocity_xy'], [0, .1], atol=1e-8)
        np.testing.assert_allclose(result['applied_world_velocity_xy'], [0, .03], atol=1e-8)
        self.assertEqual(result['reason'], 'unknown_direction_limited_speed')

    def test_approaching_swept_obstacle_slows_or_stops(self):
        obs = observation()
        for distance, expected in ((.60, 'approaching_obstacle_slowdown'),
                                   (.40, 'approaching_obstacle_stop')):
            with self.subTest(distance=distance):
                points = [[distance, y, .4] for y in (-.005, 0, .005)]
                with patch.object(navigation, '_depth_obstacle_points', return_value=geometry(points)):
                    result = navigation.guard_base_velocity(obs, 0, [.1, 0])
                self.assertEqual(result['reason'], expected)
                speed = np.linalg.norm(result['body_velocity_xy'])
                self.assertLess(speed, .1)
                self.assertEqual(speed == 0, distance == .40)
                self.assertFalse(result['space_is_certified_free'])

    def test_moving_away_from_close_obstacle_is_not_locked(self):
        obs = observation()
        points = [[.25, y, .4] for y in (-.005, 0, .005)]
        with patch.object(navigation, '_depth_obstacle_points', return_value=geometry(points)):
            result = navigation.guard_base_velocity(obs, 0, [-.1, 0])
        self.assertLess(result['body_velocity_xy'][0], 0)
        self.assertIsNone(result['restricting_obstacle'])
        self.assertTrue(result['unknown_direction'])

    def test_other_robot_base_blocks_without_any_depth(self):
        obs = observation()
        obs['base_pose_world'][1, :2] = [.65, 0]
        result = navigation.guard_base_velocity(obs, 0, [.1, 0])
        self.assertEqual(result['observed_point_count'], 0)
        self.assertEqual(result['reason'], 'approaching_obstacle_stop')
        self.assertEqual(result['restricting_obstacle']['kind'], 'other_robot_base')
        np.testing.assert_array_equal(result['body_velocity_xy'], [0, 0])

    def test_unknown_depth_never_claims_free_and_caps_speed(self):
        obs = observation()
        result = navigation.guard_base_velocity(obs, 0, [.5, .5])
        self.assertEqual(result['reason'], 'unknown_direction_limited_speed')
        self.assertLessEqual(np.linalg.norm(result['body_velocity_xy']), .03000001)
        self.assertTrue(result['unknown_direction'])
        self.assertFalse(result['space_is_certified_free'])

    def test_real_head_depth_projects_low_obstacle_and_excludes_floor(self):
        obs = observation(np.pi/2)
        obs['depth'][3, 160, 128, 0] = 1.4
        obs['depth_valid'][3, 160, 128, 0] = True
        result = navigation._depth_obstacle_points(obs, 0)
        self.assertEqual(len(result['points']), 1)
        point = result['points'][0]
        focal = 256/(2*np.tan(np.deg2rad(35)))
        self.assertAlmostEqual(point[0], .5*1.4/focal, places=5)
        self.assertGreater(point[1], 1.)
        self.assertTrue(.12 <= point[2] <= .70)
        obs['depth'][3, 160, 128, 0] = 2.1
        self.assertEqual(len(navigation._depth_obstacle_points(obs, 0)['points']), 0)

    def test_near_own_grasp_is_explicitly_filtered_as_approximate_self(self):
        obs = observation()
        obs['grasp_pose_base'][0, 2] = .4
        obs['depth'][1, 128, 128, 0] = .3
        obs['depth_valid'][1, 128, 128, 0] = True
        result = navigation._depth_obstacle_points(obs, 0)
        self.assertEqual(result['sampled_valid_count'], 1)
        self.assertEqual(result['filtered_self_count'], 1)
        self.assertEqual(len(result['points']), 0)

    def test_guard_does_not_mutate_caller_command_or_observation(self):
        obs = observation()
        original = {key: value.copy() for key, value in obs.items()}
        command = np.array([.4, .3], dtype=float)
        navigation.guard_base_velocity(obs, 0, command)
        np.testing.assert_array_equal(command, [.4, .3])
        for key in obs:
            np.testing.assert_array_equal(obs[key], original[key])

    def test_saved_public_observation_no_longer_stops_on_own_gripper_housing(self):
        path = Path(__file__).resolve().parents[1]/'participant/sample_observation.npz'
        with np.load(path, allow_pickle=False) as sample:
            obs = {key: sample[key] for key in sample.files}
        for robot in (0, 1):
            with self.subTest(robot=robot):
                # Reproduce the previous filter exactly, without removing any
                # actual depth pixels from the saved public observation.
                with patch.object(navigation, '_model_gripper_self_mask',
                                  side_effect=lambda obs, robot, points: np.zeros(len(points), bool)):
                    before = navigation.guard_base_velocity(obs, robot, [.1, 0])
                after = navigation.guard_base_velocity(obs, robot, [.1, 0])
                self.assertEqual(before['reason'], 'approaching_obstacle_stop')
                self.assertLess(before['nearest_obstacle']['distance_m'], .30)
                self.assertEqual(after['reason'], 'observed_constraints_only_no_free_space_guarantee')
                np.testing.assert_allclose(after['body_velocity_xy'], [.1, 0])
                self.assertGreater(after['filtered_model_gripper_point_count'], 90)
                # The observed table front remains in the guard, ~0.98 m away.
                self.assertTrue(.90 < after['nearest_obstacle']['distance_m'] < 1.05)
                self.assertFalse(after['space_is_certified_free'])

    def test_obstacle_five_mm_above_housing_stays_visible_and_stops_base(self):
        for robot in (0, 1):
            with self.subTest(robot=robot):
                obs = observation()
                obs['base_pose_world'][robot] = [0, 0, 0, 1, 0, 0, 0]
                obs['base_pose_world'][1-robot] = [3, 3, 0, 1, 0, 0, 0]
                obs['grasp_pose_base'][robot] = [.466258, -.087419, .17822, 1, 0, 0, 0]
                camera, row = 1+robot, 168
                focal = 256/(2*np.tan(np.deg2rad(35)))
                # Public wrist rays hitting a surface 5 mm above the model
                # housing, within a few cm of self. This is not in a broad
                # radius around the grasp that can be silently suppressed.
                target_z_in_grasp = navigation._HOUSING_HI[2]+.005
                for col in (120, 128, 136):
                    ray = navigation.WRIST[:3, :3] @ navigation.pixel_rays(col, row, focal)
                    depth = (target_z_in_grasp-navigation.WRIST[2, 3])/ray[2]
                    obs['depth'][camera, row, col, 0] = depth
                    obs['depth_valid'][camera, row, col, 0] = True
                measured = navigation._depth_obstacle_points(obs, robot)
                self.assertEqual(len(measured['points']), 3)
                self.assertEqual(measured['filtered_model_gripper_count'], 0)
                result = navigation.guard_base_velocity(obs, robot, [.1, 0])
                self.assertEqual(result['reason'], 'approaching_obstacle_stop')
                np.testing.assert_array_equal(result['body_velocity_xy'], [0, 0])

    def test_model_self_mask_follows_wrist_rotation_and_keeps_finger_cavity(self):
        obs = observation(np.pi/2)
        obs['grasp_pose_base'][0, 3:] = [np.sqrt(.5), 0, np.sqrt(.5), 0]
        for opening in (0., .5):
            with self.subTest(opening=opening):
                obs['joint_position'][0, 11:13] = opening
                c, s = np.cos(opening), np.sin(opening)
                turn = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
                # First is on the model's thin bent finger; second is in its
                # concave empty interior, which a convex hull would erase.
                finger = np.array([[.10, -.0087, 0], [.10, -.028, 0]]) @ turn.T
                finger += [-.1971472, .0222607, 0]
                housing = (navigation._HOUSING_LO+navigation._HOUSING_HI)/2
                local = np.vstack((housing, finger))
                grasp = obs['grasp_pose_base'][0]
                body = local @ navigation._rotation(grasp[3:]).T+grasp[:3]
                world = navigation.base_to_world(obs, 0, body)
                mask = navigation._model_gripper_self_mask(obs, 0, world)
                np.testing.assert_array_equal(mask, [True, True, False])

    def test_mast_mask_uses_full_base_quaternion_and_preserves_front_recess(self):
        for robot in (0, 1):
            with self.subTest(robot=robot):
                obs = observation()
                axis = np.array([.5, .2, .8]); axis /= np.linalg.norm(axis)
                obs['base_pose_world'][robot] = np.r_[[.8, -.4, .05],
                    np.cos(.15), axis*np.sin(.15)]
                local = np.array([
                    [-.131104, -.0994, .60],  # Actual visible mast wall.
                    [-.093, -.10, .60],      # Inside the solid visual envelope.
                    [-.093, -.0792, .60],    # Front recess, inside convex hull.
                    [-.136104, -.0994, .60], # Five mm beyond the mast side.
                    [-.093, -.10, 1.585]])   # Above the physical mast top in base_footprint.
                world = navigation.base_to_world(obs, robot, local)
                np.testing.assert_array_equal(navigation._model_mast_self_mask(obs, robot, world),
                                              [True, True, False, False, False])
                # Measured robot identity matters even with the same mesh.
                self.assertFalse(navigation._model_mast_self_mask(obs, 1-robot, world).any())

    def mast_depth_from_other_robot(self, robot, outside_m=0.):
        """A real public-head projection onto a 60 cm high mast-side point.

        The observer is positioned from the calibration, without mocking cloud
        reconstruction. This is synthetic geometry, not the missing v05 depth.
        """
        obs = observation()
        obs['base_pose_world'][robot] = [0, 0, 0, 1, 0, 0, 0]
        target = np.array([-.131104-outside_m, -.0994, .60])
        row, col = 160, 128
        focal = 256/(2*np.tan(np.deg2rad(35)))
        ray = navigation.HEAD[:3, :3] @ navigation.pixel_rays(col, row, focal)
        depth = (target[2]-navigation.HEAD[2, 3])/ray[2]
        observer = 1-robot
        obs['base_pose_world'][observer, :3] = target-(ray*depth+navigation.HEAD[:3, 3])
        obs['base_pose_world'][observer, 3:] = [1, 0, 0, 0]
        obs['depth'][3+observer, row, col, 0] = depth
        obs['depth_valid'][3+observer, row, col, 0] = True
        return obs

    def test_other_camera_observing_own_upper_mast_no_longer_blocks_base(self):
        for robot in (0, 1):
            with self.subTest(robot=robot):
                obs = self.mast_depth_from_other_robot(robot)
                with patch.object(navigation, '_model_mast_self_mask',
                                  side_effect=lambda obs, robot, points: np.zeros(len(points), bool)):
                    before = navigation.guard_base_velocity(obs, robot, [-.1, 0])
                after = navigation.guard_base_velocity(obs, robot, [-.1, 0])
                self.assertEqual(before['reason'], 'approaching_obstacle_stop')
                self.assertEqual(before['observed_point_count'], 1)
                self.assertEqual(after['filtered_model_mast_point_count'], 1)
                self.assertEqual(after['observed_point_count'], 0)
                self.assertEqual(after['reason'], 'unknown_direction_limited_speed')
                np.testing.assert_allclose(after['body_velocity_xy'], [-.03, 0])
                self.assertFalse(after['space_is_certified_free'])

    def test_real_depth_five_mm_beside_mast_is_kept_and_stops_base(self):
        for robot in (0, 1):
            with self.subTest(robot=robot):
                obs = self.mast_depth_from_other_robot(robot, outside_m=.005)
                measured = navigation._depth_obstacle_points(obs, robot)
                self.assertEqual(measured['filtered_model_mast_count'], 0)
                self.assertEqual(len(measured['points']), 1)
                np.testing.assert_allclose(measured['points'][0], [-.136104, -.0994, .60], atol=1e-6)
                result = navigation.guard_base_velocity(obs, robot, [-.1, 0])
                self.assertEqual(result['reason'], 'approaching_obstacle_stop')
                np.testing.assert_array_equal(result['body_velocity_xy'], [0, 0])

    def test_exact_v06_public_rays_remove_own_body_but_retain_table_and_sources(self):
        obs = v06_public_nearest_rays()
        measured = navigation._depth_obstacle_points(obs, 1)
        self.assertEqual(measured['sampled_valid_count'], 8)
        self.assertEqual(measured['filtered_self_count'], 7)
        self.assertEqual(measured['filtered_model_mast_count'], 1)
        self.assertEqual(measured['filtered_model_base_count'], 5)
        self.assertEqual(measured['filtered_model_wheel_count'], 1)
        self.assertEqual(len(measured['points']), 1)
        np.testing.assert_array_equal(measured['source_camera_ids'], [3])
        np.testing.assert_array_equal(measured['source_pixel_uv'], [[240, 104]])
        np.testing.assert_allclose(measured['optical_depth_m'], [2.20531415939331])
        table_local = navigation.world_to_base(obs, 1, measured['points'])[0]
        np.testing.assert_allclose(table_local, [.54225959, .00079078, .54318931], atol=1e-7)
        guard = navigation.guard_base_velocity(obs, 1, [.1, 0])
        self.assertEqual(guard['nearest_obstacle']['source_camera_id'], 3)
        self.assertEqual(guard['nearest_obstacle']['source_pixel_uv'], [240, 104])
        # One retained ray is insufficient directional coverage: the unknown
        # speed cap is more restrictive than this table's geometric slowdown.
        self.assertEqual(guard['reason'], 'unknown_direction_limited_speed')
        self.assertGreater(guard['body_velocity_xy'][0], 0)

    def test_reusable_mask_removes_companion_only_when_explicitly_requested(self):
        obs = v06_public_nearest_rays()
        # For R0 these are actual observed R1 obstacles and must stay visible.
        measured = navigation._depth_obstacle_points(obs, 0)
        self.assertEqual(len(measured['points']), 8)
        own = navigation.own_geometry_mask(obs, 0, measured['points'])
        companion = navigation.own_geometry_mask(obs, 1, measured['points'])
        self.assertFalse(own.any())
        self.assertEqual(int(companion.sum()), 7)
        table = measured['points'][~companion]
        self.assertEqual(len(table), 1)
        np.testing.assert_allclose(navigation.world_to_base(obs, 1, table)[0],
                                   [.54225959, .00079078, .54318931], atol=1e-7)

    def test_five_mm_outside_chassis_and_wheel_envelopes_remain_obstacles(self):
        obs = observation()
        body = np.array([.14484015, -.15105513, .12448339])
        outer = body.copy(); outer[:2] += .005*body[:2]/np.linalg.norm(body[:2])
        wheel = np.array([-.0624597, -.19713183, .1334747])
        beyond_wheel_cap = wheel.copy(); beyond_wheel_cap[1] = -.174-.026499845-.005
        above_body = np.array([.15, -.14, .223])
        points = np.stack((body, outer, wheel, beyond_wheel_cap, above_body))
        np.testing.assert_array_equal(navigation.own_geometry_mask(obs, 0, points),
                                      [True, False, True, False, False])
        for point in (outer, beyond_wheel_cap, above_body):
            with self.subTest(point=point):
                direction = point[:2]/np.linalg.norm(point[:2])*.1
                with patch.object(navigation, '_depth_obstacle_points', return_value=geometry([point])):
                    result = navigation.guard_base_velocity(obs, 0, direction)
                self.assertEqual(result['reason'], 'approaching_obstacle_stop')

    def test_role_reversal_has_same_guard_behavior(self):
        obs = observation()
        points = [[.4, y, .4] for y in (-.005, 0, .005)]
        with patch.object(navigation, '_depth_obstacle_points', return_value=geometry(points)):
            first = navigation.guard_base_velocity(obs, 0, [.1, 0])
            obs['base_pose_world'] = obs['base_pose_world'][::-1].copy()
            obs['grasp_pose_base'] = obs['grasp_pose_base'][::-1].copy()
            second = navigation.guard_base_velocity(obs, 1, [.1, 0])
        self.assertEqual(first['reason'], second['reason'])
        np.testing.assert_array_equal(first['body_velocity_xy'], second['body_velocity_xy'])

    def test_invalid_command_rejected(self):
        with self.assertRaises(ValueError):
            navigation.guard_base_velocity(observation(), 0, [np.nan, 0])


if __name__ == '__main__':
    unittest.main()
