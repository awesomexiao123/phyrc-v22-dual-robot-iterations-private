"""CPU public-observation tests; passive commands are not a stopping proof."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_wrist_handoff as handoff
from test_loaded_roll_observation import observation, hands


class LoadedWristHandoffTests(unittest.TestCase):
    def construct(self, obs=None, report=None, **kwargs):
        obs = observation() if obs is None else obs
        obs.setdefault('base_twist_world', np.zeros((2, 6)))
        controller = handoff.LoadedWristHandoff(obs, hands() if report is None else report, 0., **kwargs)
        return obs, controller

    def step(self, obs, controller, advance=0.):
        obs['simulation_time_s'][...] += advance
        result = controller.step(obs)
        np.testing.assert_array_equal(result['action'][:, :8], 0.)
        np.testing.assert_array_equal(result['action'][:, 8], 1.)
        return result

    def test_real_rgbd_continuous_quarter_second_hold_and_no_mutation(self):
        obs, controller = self.construct()
        targets = obs['controller_target'].copy(); joints = obs['joint_position'].copy()
        result = self.step(obs, controller)
        self.assertEqual(result['debug']['observed_cloth_point_count'], 288)
        for i in range(5):
            result = self.step(obs, controller, .05)
            self.assertEqual(result['done'], i == 4)
        self.assertIsNone(result['failure']); self.assertFalse(result['debug']['target_cancellation_performed'])
        self.assertFalse(result['debug']['zero_action_cancels_integrated_target'])
        np.testing.assert_array_equal(obs['controller_target'], targets)
        np.testing.assert_array_equal(obs['joint_position'], joints)

    def test_constructor_only_captures_then_current_cloth_checked(self):
        obs = observation()
        with patch.object(handoff, '_cloth_evidence', side_effect=ValueError('cloth missing')) as evidence:
            obs, controller = self.construct(obs)
            evidence.assert_not_called(); self.assertFalse(controller.done)
            result = self.step(obs, controller)
        self.assertEqual(result['failure'], 'cloth missing'); self.assertTrue(result['done'])

    def test_excess_target_lag_waits_without_cancelling_and_resets_stable_time(self):
        obs, controller = self.construct()
        self.step(obs, controller)
        self.step(obs, controller, .05)
        obs['controller_target'][0, 0] += .002
        result = self.step(obs, controller, .05)
        self.assertFalse(result['done']); self.assertIsNone(result['failure'])
        self.assertEqual(result['debug']['measured_stable_seconds'], 0.)
        self.assertAlmostEqual(result['debug']['fixed_joint_target_lag_lift_arm_yaw_pitch'][0][0], .002)
        # Synthetic servo catches up, with current public geometry still inside bounds.
        obs['joint_position'][0, 3] += .002
        self.step(obs, controller, .05)
        for i in range(5):
            result = self.step(obs, controller, .05)
            self.assertEqual(result['done'], i == 4)

    def test_all_original_lag_and_rate_limits_block_completion(self):
        cases = [
            ('lift_lag', lambda o:o['controller_target'].__setitem__((0, 0), o['controller_target'][0, 0]+.0016)),
            ('arm_lag', lambda o:o['controller_target'].__setitem__((0, 1), o['controller_target'][0, 1]+.0031)),
            ('yaw_lag', lambda o:o['controller_target'].__setitem__((0, 2), o['controller_target'][0, 2]+np.deg2rad(.16))),
            ('pitch_lag', lambda o:o['controller_target'].__setitem__((0, 3), o['controller_target'][0, 3]+np.deg2rad(.16))),
            ('roll_lag', lambda o:o['controller_target'].__setitem__((0, 4), o['controller_target'][0, 4]+np.deg2rad(.011))),
            ('lift_speed', lambda o:o['joint_velocity'].__setitem__((0, 3), .0031)),
            ('arm_aggregate_speed', lambda o:o['joint_velocity'].__setitem__((0, slice(4, 8)), .001)),
            ('wrist_speed', lambda o:o['joint_velocity'].__setitem__((0, 9), np.deg2rad(.11))),
            ('base_speed', lambda o:o['base_twist_world'].__setitem__((0, 0), .0021)),
            ('base_angular_speed', lambda o:o['base_twist_world'].__setitem__((0, 5), .0021)),
            ('base_target', lambda o:o['controller_target'].__setitem__((0, 6), .0001)),
        ]
        for name, mutate in cases:
            with self.subTest(name=name):
                obs, controller = self.construct(); mutate(obs)
                self.step(obs, controller)
                for _ in range(6): result = self.step(obs, controller, .05)
                self.assertFalse(result['done']); self.assertIsNone(result['failure'])
                self.assertFalse(result['debug']['currently_settled'])

    def test_repeated_frames_do_not_accumulate_and_missing_intervals_fail(self):
        obs, controller = self.construct(); self.step(obs, controller)
        for _ in range(20): result = self.step(obs, controller)
        self.assertEqual(result['debug']['measured_stable_seconds'], 0.)
        self.assertFalse(result['done'])
        result = self.step(obs, controller, .2)
        self.assertIn('nonconsecutive', result['failure'])
        obs, controller = self.construct(); self.step(obs, controller)
        self.assertIn('nonconsecutive', self.step(obs, controller, -.01)['failure'])

    def test_three_second_timeout_is_latched_and_keeps_hold(self):
        obs, controller = self.construct(); obs['joint_velocity'][0, 3] = .008
        self.step(obs, controller)
        for _ in range(60): result = self.step(obs, controller, .05)
        self.assertTrue(result['done']); self.assertIn('timeout', result['failure'])
        obs['joint_velocity'][:] = 0
        self.assertEqual(self.step(obs, controller, .05)['failure'], result['failure'])

    def test_current_missing_cloth_near_hand_gripper_and_invalid_public_state_fail(self):
        for fault in ('cloth', 'near_hand', 'open', 'gap', 'missing_depth', 'target_nan', 'twist_nan'):
            with self.subTest(fault=fault):
                obs = observation(); report = hands()
                if fault == 'near_hand': report['hand_points_world'][0] = [-.3, .49, 1.]
                obs, controller = self.construct(obs, report)
                if fault == 'cloth': obs['rgb'][2] = 0
                if fault == 'missing_depth': obs['depth_valid'][2] = False
                if fault == 'open': obs['gripper_close_command'][1] = False
                if fault == 'gap': obs['fingertip_origin_distance'][0] = .081
                if fault == 'target_nan': obs['controller_target'][0, 0] = np.nan
                if fault == 'twist_nan': obs['base_twist_world'][0, 0] = np.nan
                result = self.step(obs, controller)
                self.assertTrue(result['done']); self.assertIsNotNone(result['failure'])

    def test_hand_prior_timestamp_never_refreshed_and_stationary_assumption_required(self):
        obs, controller = self.construct(max_hand_age_s=.1)
        self.step(obs, controller); self.step(obs, controller, .05); self.step(obs, controller, .05)
        result = self.step(obs, controller, .05)
        self.assertIn('stale', result['failure']); self.assertEqual(result['debug']['cached_hand_observed_at_s'], 0.)
        obs, controller = self.construct(stationary_human=False)
        self.assertIn('stationary_human', self.step(obs, controller)['failure'])
        report = hands(); report['observation_time_s'] = -.01
        obs, controller = self.construct(report=report)
        self.assertIn('timestamp', self.step(obs, controller)['failure'])
        report = hands(); report['observation_time_s'] = np.nan
        obs, controller = self.construct(report=report)
        self.assertIn('timestamp', self.step(obs, controller)['failure'])

    def test_drift_limits_apply_from_original_state_not_rolling_references(self):
        for fault in ('grasp', 'base', 'rotation'):
            with self.subTest(fault=fault):
                obs, controller = self.construct(); self.step(obs, controller)
                if fault == 'grasp': obs['grasp_pose_base'][0, 0] += .0101
                if fault == 'base': obs['base_pose_world'][0, 0] += .0031
                if fault == 'rotation':
                    angle = np.deg2rad(.26)
                    obs['base_pose_world'][0, 3:] = [np.cos(angle/2), 0, 0, np.sin(angle/2)]
                result = self.step(obs, controller, .05)
                self.assertTrue(result['done']); self.assertIn('drift', result['failure'])


if __name__ == '__main__':
    unittest.main()
