"""Finite static-own wrist envelopes; no simulator or assets are imported."""
from itertools import product
from pathlib import Path
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'participant'))
import gripper_skin_clearance as geometry
import wrist_sweep_envelope as sweep


def state(jaws=(0.0, 0.0)):
    q = np.zeros(13)
    q[8:11] = [0.21, -0.31, 0.18]
    q[11:13] = jaws
    return q


def ranges(q, delta=None):
    target = q[8:11] if delta is None else q[8:11]+np.asarray(delta)
    return np.column_stack((target, target))


def rows(report):
    return {row['link']: row for row in report['per_box']}


class WristSweepEnvelopeTests(unittest.TestCase):
    def test_zero_change_has_exactly_zero_reserve_and_preserves_margin(self):
        q = state()
        report = sweep.wrist_sweep_envelope(q, ranges(q), ranges(q))
        self.assertTrue(report['valid'], report)
        self.assertEqual(len(report['per_box']), 13)
        self.assertEqual(report['max_displacement_reserve_m'], 0.0)
        self.assertTrue(all(row['displacement_reserve_m'] == 0.0 for row in report['per_box']))
        self.assertTrue(report['reserve_is_additional_to_existing_geometry_margin'])
        self.assertEqual(report['existing_geometry_margin_consumed_m'], 0.0)
        for key in ('physical_safety_proven', 'inertia_or_dynamics_bounded',
                    'fullbody_clearance', 'collision_free', 'jaw_motion_bounded',
                    'root_motion_bounded'):
            self.assertFalse(report[key])
        self.assertNotIn('action', report)

    def test_each_axis_only_moves_its_descendants(self):
        q = state()
        for axis in range(3):
            delta = np.zeros(3); delta[axis] = np.deg2rad(0.3)
            report = sweep.wrist_sweep_envelope(q, ranges(q, delta), ranges(q))
            self.assertTrue(report['valid'], report)
            by_link = rows(report)
            for link in ('wrist_link', 'wrist_aruco_link', 'wrist_reflector_link'):
                self.assertEqual(by_link[link]['displacement_reserve_m'], 0.0)
            for shell, shell_axis in (('wrist_yaw_link', 0), ('wrist_pitch_link', 1),
                                      ('wrist_roll_link', 2)):
                reserve = by_link[shell]['displacement_reserve_m']
                if axis <= shell_axis:
                    self.assertGreater(reserve, 0.0)
                else:
                    self.assertEqual(reserve, 0.0)
            self.assertGreater(by_link['gripper_fingertip_left_link']['displacement_reserve_m'], 0.0)

    def test_combined_angles_add_descendant_contributions(self):
        q = state()
        delta = np.deg2rad([0.21, -0.32, 0.43])
        combined = sweep.wrist_sweep_envelope(q, ranges(q, delta), ranges(q))
        singles = []
        for axis in range(3):
            single = np.zeros(3); single[axis] = delta[axis]
            singles.append(rows(sweep.wrist_sweep_envelope(q, ranges(q, single), ranges(q))))
        for row in combined['per_box']:
            expected = sum(item[row['link']]['raw_displacement_reserve_m'] for item in singles)
            self.assertAlmostEqual(row['displacement_reserve_m'], expected, places=15)

    def test_opposite_raw_and_excess_do_not_cancel(self):
        q = state()
        delta = np.deg2rad([0.25, -0.30, 0.40])
        report = sweep.wrist_sweep_envelope(q, ranges(q, delta), ranges(q, -delta))
        self.assertTrue(report['valid'], report)
        self.assertGreater(report['max_displacement_reserve_m'], 0.0)
        for row in report['per_box']:
            self.assertEqual(row['displacement_reserve_m'],
                             max(row['raw_displacement_reserve_m'], row['excess_displacement_reserve_m']))

    def test_union_is_max_of_candidates_not_axiswise_mixed_configuration(self):
        q = state()
        report = sweep.wrist_sweep_envelope(q, ranges(q, [0.006, 0, 0]),
                                           ranges(q, [0, 0.007, 0]))
        self.assertTrue(report['valid'], report)
        for row in report['per_box']:
            self.assertEqual(row['displacement_reserve_m'],
                             max(row['raw_displacement_reserve_m'], row['excess_displacement_reserve_m']))

    def test_dense_corners_and_random_configurations_stay_inside_bound(self):
        rng = np.random.default_rng(44271)
        jaw_limit = next(j['limits_rad'][1] for j in geometry._OWN_GEOMETRY_DATA['joints']
                         if j['public_index'] == 11)
        # 8 workspace poses x 3 measured jaw pairs x 2 candidate intervals,
        # each with 27 grid configurations and 45 random configurations. Every
        # configuration checks all eight corners of each of the thirteen boxes.
        for pose in range(8):
            for jaws in ((0.0, 0.0), (jaw_limit, jaw_limit), (0.12, 0.41)):
                q = state(jaws)
                q[8:11] = rng.uniform([-0.9, -3.8, -0.9], [3.8, 0.9, 3.8])
                offsets = rng.uniform(-0.0079, 0.0079, (2, 3, 2))
                offsets.sort(axis=2)
                candidates = offsets+q[None, 8:11, None]
                report = sweep.wrist_sweep_envelope(q, *candidates)
                self.assertTrue(report['valid'], report)
                self.assertEqual(report['fixed_measured_jaw_angles_rad'], list(jaws))
                by_link = rows(report)
                start = geometry._relative_link_poses(q)
                for candidate_index, target_range in enumerate(candidates):
                    lo = np.minimum(target_range[:, 0], q[8:11])
                    hi = np.maximum(target_range[:, 1], q[8:11])
                    grid = np.asarray(list(product(*[np.linspace(a, b, 3) for a, b in zip(lo, hi)])))
                    samples = np.vstack((grid, rng.uniform(lo, hi, (45, 3))))
                    for angles in samples:
                        next_q = q.copy(); next_q[8:11] = angles
                        finish = geometry._relative_link_poses(next_q)
                        for collider in geometry._OWN_GEOMETRY_DATA['colliders']:
                            link = collider['link']
                            corners = np.asarray(list(product(*zip(collider['lower_m'], collider['upper_m']))))
                            begin = corners@start[link][:3, :3].T+start[link][:3, 3]
                            end = corners@finish[link][:3, :3].T+finish[link][:3, 3]
                            measured = np.linalg.norm(end-begin, axis=1).max()
                            key = ('raw', 'excess')[candidate_index]+'_displacement_reserve_m'
                            self.assertLessEqual(measured, by_link[link][key]+2e-14,
                                                 (pose, jaws, link, measured, by_link[link]))
                            self.assertLessEqual(measured, report['max_displacement_reserve_m']+2e-14)

    def test_non_finite_bad_shapes_ranges_and_caps_rejected(self):
        q = state(); same = ranges(q)
        for value in (np.zeros(12), np.zeros((1, 13)), np.r_[np.nan, np.zeros(12)],
                      np.r_[np.zeros(12), np.inf], None):
            with self.subTest(current=value):
                self.assertFalse(sweep.wrist_sweep_envelope(value, same, same)['valid'])
        for value in (np.zeros(3), np.zeros((2, 3)), [[0, np.nan]]*3,
                      [[0, np.inf]]*3, [[1, 0]]*3, None):
            for which in range(2):
                candidates = [same, same]; candidates[which] = value
                result = sweep.wrist_sweep_envelope(q, *candidates)
                self.assertFalse(result['valid'], result)
                self.assertIsNone(result['max_displacement_reserve_m'])
                self.assertEqual(result['per_box'], [])
        for cap in (0, -0.01, np.nan, np.inf, np.deg2rad(0.50001),
                    [0.005, 0.01, 0.005], [0.005, 0.005]):
            self.assertFalse(sweep.wrist_sweep_envelope(q, same, same, max_axis_change_rad=cap)['valid'])
        for which in range(2):
            candidates = [same, same]; candidates[which] = ranges(q, [0, 0.0088, 0])
            self.assertFalse(sweep.wrist_sweep_envelope(q, *candidates)['valid'])
        self.assertFalse(sweep.wrist_sweep_envelope(
            q, ranges(q, [0.003, 0, 0]), same, max_axis_change_rad=[0.002, 0.003, 0.004])['valid'])

    def test_current_wrist_jaws_and_both_target_limits_are_strict(self):
        for joint in geometry._OWN_GEOMETRY_DATA['joints']:
            index = joint['public_index']
            if index is None:
                continue
            for edge, direction in zip(joint['limits_rad'], (-1, 1)):
                q = state(); q[index] = edge+direction*1e-7
                self.assertFalse(sweep.wrist_sweep_envelope(q, ranges(q), ranges(q))['valid'])
                if index in (8, 9, 10):
                    q[index] = edge
                    candidate = ranges(q); candidate[index-8] = edge+direction*1e-7
                    for pair in ((candidate, ranges(q)), (ranges(q), candidate)):
                        self.assertFalse(sweep.wrist_sweep_envelope(q, *pair)['valid'])

    def test_both_jaw_sweeps_and_combined_wrist_sweeps_bound_every_box_corner(self):
        corners_by_link = {
            collider['link']: np.asarray(list(product(*zip(collider['lower_m'], collider['upper_m']))))
            for collider in geometry._OWN_GEOMETRY_DATA['colliders']}
        for wrist in ([.21, -.31, .18], [3.2, -3.4, 2.8]):
            q = state((.10321, .10349)); q[8:11] = wrist
            velocity = np.array([.00690, -.00906])
            jaw = sweep.jaw_sweep_envelope(q, .103, velocity)
            self.assertTrue(jaw['valid'], jaw)
            expected = np.column_stack((np.minimum(q[11:13], .103)-np.abs(velocity)*.05,
                                        np.maximum(q[11:13], .103)+np.abs(velocity)*.05))
            np.testing.assert_allclose(jaw['jaw_target_ranges_rad'], expected)
            raw = ranges(q, [.003, -.004, .005])
            excess = ranges(q, [-.004, .002, -.003])
            wrist_report = sweep.wrist_sweep_envelope(q, raw, excess)
            self.assertTrue(wrist_report['valid'], wrist_report)
            jaw_rows, wrist_rows = rows(jaw), rows(wrist_report)
            for link, row in jaw_rows.items():
                if 'finger' not in link:
                    self.assertEqual(row['displacement_reserve_m'], 0.)
            self.assertGreater(jaw_rows['gripper_fingertip_left_link']['displacement_reserve_m'], 0.)
            self.assertGreater(jaw_rows['gripper_fingertip_right_link']['displacement_reserve_m'], 0.)
            start = geometry._relative_link_poses(q)
            start_corners = {link: c@start[link][:3, :3].T+start[link][:3, 3]
                             for link, c in corners_by_link.items()}
            for target in (raw, excess):
                wrist_samples = product(*[np.linspace(min(q[8+i], limits[0]),
                                                      max(q[8+i], limits[1]), 3)
                                          for i, limits in enumerate(target)])
                for angles in wrist_samples:
                    for jaws in product(*[np.linspace(lo, hi, 5) for lo, hi in expected]):
                        next_q = q.copy(); next_q[8:11] = angles; next_q[11:13] = jaws
                        finish = geometry._relative_link_poses(next_q)
                        for link, corners in corners_by_link.items():
                            end = corners@finish[link][:3, :3].T+finish[link][:3, 3]
                            measured = np.linalg.norm(end-start_corners[link], axis=1).max()
                            reserve = (wrist_rows[link]['displacement_reserve_m']
                                       +jaw_rows[link]['displacement_reserve_m'])
                            self.assertLessEqual(measured, reserve+2e-14, (wrist, angles, jaws, link))
                            self.assertLessEqual(measured, wrist_report['max_displacement_reserve_m']
                                                 +jaw['max_displacement_reserve_m']+2e-14)

    def test_jaw_full_target_plus_rate_interval_rejects_invalid_inputs_and_limits(self):
        q = state((.10321, .10349))
        for current, target, velocity, options in (
                (np.zeros(12), .103, [0., 0.], {}),
                (np.r_[np.nan, q[1:]], .103, [0., 0.], {}),
                (q, np.nan, [0., 0.], {}),
                (q, [.103, .103], [0., 0.], {}),
                (q, .103, [0.], {}),
                (q, .103, [np.inf, 0.], {}),
                (q, .123, [0., 0.], {}),
                (q, .103, [.2, 0.], {}),
                (q, .103, [0., 0.], {'interval_s': np.nan}),
                (q, .103, [0., 0.], {'interval_s': -.05}),
                (q, .103, [0., 0.], {'max_axis_change_rad': np.deg2rad(.50001)})):
            result = sweep.jaw_sweep_envelope(current, target, velocity, **options)
            self.assertFalse(result['valid'], result)
            self.assertIsNone(result['max_displacement_reserve_m'])
        limits = next(j['limits_rad'] for j in geometry._OWN_GEOMETRY_DATA['joints']
                      if j['public_index'] == 11)
        for edge, direction in zip(limits, (-1, 1)):
            current = state((edge-direction*.001, edge-direction*.001))
            # The target itself is legal. The rate-expanded target endpoint
            # crosses the limit and must be rejected rather than clipped.
            result = sweep.jaw_sweep_envelope(current, edge, [.001, -.001])
            self.assertFalse(result['valid'], result)
        # Each component alone is below the cap, but their full outward sum is not.
        result = sweep.jaw_sweep_envelope(q, q[11]+.008, [.02, 0.])
        self.assertFalse(result['valid'], result)


if __name__ == '__main__':
    unittest.main()
