"""CPU image-motion tests; they do not certify any simulator attachment."""
import importlib.util
import sys
from pathlib import Path
import unittest

import cv2
import numpy as np

PATH = Path(__file__).resolve().parents[1] / 'participant' / 'cloth_patch_tracker.py'
sys.path.insert(0, str(PATH.parent))
SPEC = importlib.util.spec_from_file_location('v23_cloth_tracker_tested', PATH)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def observation(camera=3, vertical=False):
    pose = np.zeros((2, 7), np.float32); pose[:, 3] = 1
    obs = dict(rgb=np.zeros((5, 256, 256, 3), np.uint8),
        depth=np.full((5, 256, 256, 1), 2., np.float32),
        depth_valid=np.ones((5, 256, 256, 1), bool),
        base_pose_world=pose.copy(), grasp_pose_base=pose.copy())
    image = obs['rgb'][camera]
    image[75:185, 75:185] = [20, 30, 190]
    for y in range(87, 177, 10):
        for x in range(87, 177, 10):
            image[y:y+4, x:x+4] = [230, 215, 20]
    obs['depth'][camera, 75:185, 75:185, 0] = 1.
    rotation, origin = MODULE._PUBLIC._camera_transform(obs, camera)
    if vertical:
        v, u = np.indices((256, 256))
        rays = np.stack(((u+.5-128)/MODULE._PUBLIC._FOCAL, (v+.5-128)/MODULE._PUBLIC._FOCAL, np.ones_like(u)), axis=-1)
        dz = (rays @ rotation.T)[..., 0]
        z = .8 / np.maximum(dz, .1)
        obs['depth'][camera, 75:185, 75:185, 0] = z[75:185, 75:185]
    depth = float(obs['depth'][camera, 128, 128, 0])
    center = rotation @ np.array([0., 0., depth]) + origin
    return obs, center, rotation


def shift_pixels(obs, camera, dx):
    result = {key: value.copy() for key, value in obs.items()}
    matrix = np.array([[1, 0, dx], [0, 1, 0]], np.float32)
    result['rgb'][camera] = cv2.warpAffine(obs['rgb'][camera], matrix, (256, 256))
    result['depth'][camera, ..., 0] = cv2.warpAffine(obs['depth'][camera, ..., 0], matrix,
        (256, 256), flags=cv2.INTER_NEAREST, borderValue=2.)
    return result


def retain_depth_near_pixels(obs, camera, pixels):
    """Simulate depth occlusion while leaving only specified feature patches."""
    obs['depth_valid'][camera] = False
    for pixel in pixels:
        x, y = np.rint(pixel).astype(int)
        obs['depth_valid'][camera, y-1:y+2, x-1:x+2, 0] = True


def two_view_observation():
    obs, center, rotation = observation(3)
    # Two actual image cohorts: a sparsely textured view and a dense view.
    # Their public camera poses coincide here to isolate visibility loss.
    obs['rgb'][4] = obs['rgb'][3]
    obs['depth'][4] = obs['depth'][3]
    obs['rgb'][3, 75:185, 75:185] = [20, 30, 190]
    for x, y in ((118, 118), (131, 118), (118, 131), (131, 131)):
        obs['rgb'][3, y:y+4, x:x+4] = [230, 215, 20]
    return obs, center, rotation


class ClothTrackTests(unittest.TestCase):
    def test_stationary_vertical_cloth_ignores_moving_gripper(self):
        for camera in (3, 4):
            obs, center, _ = observation(camera, vertical=True)
            tracker = MODULE.ClothPatchTracker()
            self.assertTrue(tracker.reset(obs, center)['reliable'])
            initial_ids = set(tracker.update(obs)['feature_ids'])
            moved = {k: v.copy() for k, v in obs.items()}
            moved['grasp_pose_base'][:, 2] += .04
            result = tracker.update(moved)
            self.assertTrue(result['reliable'])
            np.testing.assert_allclose(result['median_displacement_world'], 0., atol=1e-5)
            self.assertTrue(set(result['feature_ids']).issubset(initial_ids))

    def test_camera_motion_with_static_cloth_is_compensated_head_and_wrist(self):
        for camera in (1, 2, 3, 4):
            obs, center, rotation = observation(camera)
            tracker = MODULE.ClothPatchTracker(); self.assertTrue(tracker.reset(obs, center)['reliable'])
            moved = shift_pixels(obs, camera, -4)
            translation = rotation @ np.array([4 / MODULE._PUBLIC._FOCAL, 0., 0.])
            robot = camera-3 if camera >= 3 else camera-1
            key = 'base_pose_world' if camera >= 3 else 'grasp_pose_base'
            moved[key][robot, :3] += translation
            result = tracker.update(moved)
            self.assertTrue(result['reliable'], result)
            np.testing.assert_allclose(result['median_displacement_world'], 0., atol=.001)

    def test_true_cloth_translation_accumulates_without_reseeding(self):
        for camera in (3, 4):
            obs, center, rotation = observation(camera)
            tracker = MODULE.ClothPatchTracker(); start = tracker.reset(obs, center)
            previous_ids = set(start['feature_ids'])
            for dx in (4, 8, 12):
                result = tracker.update(shift_pixels(obs, camera, dx))
                self.assertTrue(result['reliable'], result)
                expected = rotation @ np.array([dx / MODULE._PUBLIC._FOCAL, 0., 0.])
                np.testing.assert_allclose(result['median_displacement_world'], expected, atol=.001)
                self.assertTrue(set(result['feature_ids']).issubset(previous_ids))
                previous_ids = set(result['feature_ids'])
                self.assertFalse(result['features_reseeded'])
                self.assertFalse(result['attachment_verified'])

    def test_robot_occlusion_loses_identity_and_does_not_reseed(self):
        obs, center, _ = observation()
        tracker = MODULE.ClothPatchTracker(); tracker.reset(obs, center)
        blocked = {key: value.copy() for key, value in obs.items()}
        blocked['rgb'][3, 75:185, 75:185] = [180, 180, 180]
        blocked['depth'][3, 75:185, 75:185, 0] = .6
        result = tracker.update(blocked)
        self.assertFalse(result['reliable'])
        self.assertIsNone(result['median_displacement_world'])
        result = tracker.update(obs)
        self.assertFalse(result['reliable'])
        self.assertEqual(result['tracked_count'], 0)

    def test_occluded_other_view_does_not_penalize_six_consistent_fixed_identities(self):
        obs, center, rotation = two_view_observation()
        tracker = MODULE.ClothPatchTracker()
        initial = tracker.reset(obs, center)
        pixels = tracker.groups[3]['pixels'][:6].copy()
        initial_ids = set(initial['feature_ids'])
        self.assertGreater(initial['initial_feature_count'], 24)
        self.assertTrue(6/tracker.groups[3]['initial_count'] >= .25)
        for dx in (4, 8):
            moved = shift_pixels(obs, 3, dx)
            moved['rgb'][4] = 0  # The dense view is fully occluded.
            retain_depth_near_pixels(moved, 3, pixels+[dx, 0])
            result = tracker.update(moved)
            self.assertTrue(result['reliable'], result)
            self.assertEqual(result['tracked_count'], 6)
            self.assertLess(result['initial_feature_retention_fraction'], .25)
            self.assertGreaterEqual(result['view_cohorts']['robot_0_head']['initial_feature_retention_fraction'], .25)
            self.assertEqual(result['view_cohorts']['robot_1_head']['tracked_count'], 0)
            self.assertEqual(result['reliable_source_cameras'], ['robot_0_head'])
            self.assertEqual(len(result['displacement_feature_ids']), 6)
            self.assertTrue(set(result['feature_ids']).issubset(initial_ids))
            np.testing.assert_allclose(result['median_displacement_world'],
                                       rotation @ [dx/MODULE._PUBLIC._FOCAL, 0., 0.], atol=.001)
            self.assertFalse(result['features_reseeded'])

    def test_five_remaining_identities_cannot_pass_even_with_good_view_retention(self):
        obs, center, _ = two_view_observation()
        tracker = MODULE.ClothPatchTracker(); tracker.reset(obs, center)
        moved = {key: value.copy() for key, value in obs.items()}
        moved['rgb'][4] = 0
        retain_depth_near_pixels(moved, 3, tracker.groups[3]['pixels'][:5])
        result = tracker.update(moved)
        self.assertEqual(result['tracked_count'], 5)
        self.assertGreaterEqual(result['view_cohorts']['robot_0_head']['initial_feature_retention_fraction'], .25)
        self.assertFalse(result['reliable'])
        self.assertIsNone(result['median_displacement_world'])
        self.assertEqual(result['displacement_feature_ids'], [])

    def test_six_survivors_from_a_largely_lost_same_view_still_abstain(self):
        obs, center, _ = observation(3)
        tracker = MODULE.ClothPatchTracker(); tracker.reset(obs, center)
        self.assertGreater(tracker.groups[3]['initial_count'], 24)
        moved = {key: value.copy() for key, value in obs.items()}
        retain_depth_near_pixels(moved, 3, tracker.groups[3]['pixels'][:6])
        result = tracker.update(moved)
        self.assertEqual(result['tracked_count'], 6)
        self.assertLess(result['view_cohorts']['robot_0_head']['initial_feature_retention_fraction'], .25)
        self.assertFalse(result['reliable'])
        self.assertIsNone(result['median_displacement_world'])

    def test_depth_jump_rejected_even_if_rgb_matches(self):
        obs, center, _ = observation()
        tracker = MODULE.ClothPatchTracker(); tracker.reset(obs, center)
        obs['depth'][3, 75:185, 75:185, 0] = .7
        result = tracker.update(obs)
        self.assertFalse(result['reliable'])

    def test_featureless_patch_and_overview_abstain(self):
        obs, center, _ = observation()
        obs['rgb'][3, 75:185, 75:185] = [20, 30, 190]
        tracker = MODULE.ClothPatchTracker()
        self.assertFalse(tracker.reset(obs, center)['reliable'])
        self.assertFalse(tracker.update(obs)['reliable'])
        obs, center, _ = observation()
        obs['rgb'][0] = obs['rgb'][3]; obs['rgb'][3] = 0
        self.assertFalse(tracker.reset(obs, center)['reliable'])


if __name__ == '__main__':
    unittest.main()
