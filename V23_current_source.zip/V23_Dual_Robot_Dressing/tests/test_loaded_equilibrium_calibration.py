"""CPU public-state/RGB-D tests; no PhysX rest or attachment claims."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'participant'))
import loaded_equilibrium_calibration as equilibrium
from test_loaded_roll_observation import observation as roll_observation, hands, visible


def observation():
    obs = roll_observation()
    obs['previous_action'] = np.zeros((2, 9), np.float32)
    obs['previous_action'][:, 8] = 1.
    # Reproduce a bounded static target offset despite a discrepant raw qdot.
    obs['controller_target'][:, 0] += .0026
    obs['controller_target'][:, 3] -= np.deg2rad(.23)
    obs['joint_velocity'][:, 3] = .0108
    obs['joint_velocity'][:, 9] = -.02
    return obs


class LoadedEquilibriumCalibrationTests(unittest.TestCase):
    def construct(self, obs=None, **kwargs):
        obs = observation() if obs is None else obs
        return obs, equilibrium.LoadedEquilibriumCalibration(obs, hands(), 0., **kwargs)

    def advance(self, obs, controller, count=1, mutate=None, mock_cloth=True):
        context = patch.object(equilibrium, '_cloth_evidence', side_effect=visible) if mock_cloth else None
        if context: context.start()
        try:
            for i in range(count):
                if mutate: mutate(obs, i)
                result = controller.step(obs)
                np.testing.assert_array_equal(result['action'][:, :8], 0.)
                np.testing.assert_array_equal(result['action'][:, 8], 1.)
                if result['done'] or result['failure']: break
                obs['simulation_time_s'][...] += .05
            return result
        finally:
            if context: context.stop()

    def test_real_synthetic_rgbd_stable_bias_needs_eleven_frames_and_half_second(self):
        obs, c = self.construct()
        first = c.step(obs)
        self.assertFalse(first['done']); self.assertEqual(first['debug']['frame_count'], 1)
        for _ in range(20):
            repeated = c.step(obs)
            self.assertEqual(repeated['debug']['frame_count'], 1)
        for i in range(1, 11):
            obs['simulation_time_s'][...] = i*.05
            result = c.step(obs)
            self.assertEqual(result['done'], i == 10, result)
        self.assertIsNone(result['failure'])
        calibration = result['calibration']
        self.assertEqual(calibration['frame_count'], 11)
        self.assertEqual(calibration['observed_at_s'], .5)
        self.assertEqual(calibration['window_start_s'], 0.)
        np.testing.assert_allclose(np.array(calibration['controller_bias'])[:, 0], .0026)
        np.testing.assert_allclose(np.array(calibration['controller_bias'])[:, 3], -np.deg2rad(.23))
        np.testing.assert_allclose(np.array(calibration['raw_joint_velocity_median'])[:, 3], .0108)
        self.assertFalse(result['debug']['continuous_time_stationary_verified'])
        self.assertFalse(result['debug']['native_target_cancelled'])
        self.assertEqual(result['debug']['observed_cloth_point_count'], 288)

    def test_raw_noise_summary_and_zero_sum_arm_shape_are_frozen_copies(self):
        obs, c = self.construct()
        offsets = np.array([.00006, -.00002, -.00003, -.00001])
        obs['joint_position'][:, 4:8] += offsets
        def vary(o, i): o['joint_velocity'][:, 3] = .0108+(i-5)*.0001
        result = self.advance(obs, c, 11, vary)
        self.assertTrue(result['done'], result)
        cal = result['calibration']
        np.testing.assert_allclose(cal['arm_position_offsets'], np.tile(offsets, (2, 1)), atol=1e-10)
        np.testing.assert_allclose(np.sum(cal['arm_position_offsets'], axis=1), 0., atol=1e-14)
        np.testing.assert_allclose(np.array(cal['raw_joint_velocity_peak_deviation'])[:, 3], .0005)
        cal['controller_bias'][0][0] = 100.
        self.assertAlmostEqual(c.step(obs)['calibration']['controller_bias'][0][0], .0026)

    def test_nonzero_previous_input_and_base_targets_cannot_enter_window(self):
        for kind in ('previous', 'base_target'):
            with self.subTest(kind=kind):
                obs, c = self.construct()
                if kind == 'previous': obs['previous_action'][1, 6] = .001
                else: obs['controller_target'][1, 6] = .001
                result = self.advance(obs, c, 8)
                self.assertFalse(result['done']); self.assertEqual(result['debug']['frame_count'], 0)
                obs['previous_action'][:, :8] = 0.
                obs['controller_target'][:, 6:9] = 0.
                result = self.advance(obs, c, 11)
                self.assertTrue(result['done'], result)
                self.assertGreater(result['calibration']['window_start_s'], 0.)

    def test_sampled_deviation_keeps_lift_and_opposed_arm_motion_separate(self):
        obs, c = self.construct()
        initial = obs['joint_position'].copy()
        samples = [-1.]*5+[0.]+[1.]*5
        def vary(o, i):
            o['joint_position'][:, 3] = initial[:, 3]+samples[i]*.000005
            o['joint_position'][:, 4:8] = initial[:, 4:8]+samples[i]*np.array([.000002, -.000002, 0., 0.])
        result = self.advance(obs, c, 11, vary)
        self.assertTrue(result['done'], result)
        cal = result['calibration']
        deviations = np.asarray(cal['controller_bias_peak_deviation'])
        np.testing.assert_allclose(deviations[:, 0], .000005, atol=1e-12)
        np.testing.assert_allclose(deviations[:, 1], 0., atol=1e-12)
        np.testing.assert_allclose(cal['arm_position_offsets_peak_deviation'],
            np.tile([.000002, .000002, 0., 0.], (2, 1)), atol=1e-12)
        cal['controller_bias_peak_deviation'][0][0] = 1.
        self.assertAlmostEqual(c.step(obs)['calibration']['controller_bias_peak_deviation'][0][0], .000005)

    def test_base_diagnostic_window_preserves_original_samples_and_missing_twist(self):
        for present in (False, True):
            with self.subTest(present=present):
                obs, c = self.construct()
                obs.pop('base_twist_world', None)
                if present: obs['base_twist_world'] = np.full((2, 6), .003)
                result = self.advance(obs, c, 11)
                self.assertTrue(result['done'], result)
                window = result['calibration']['base_diagnostic_window']
                np.testing.assert_allclose(window['public_times_s'], np.arange(11)*.05)
                self.assertEqual(len(window['base_pose_world']), 11)
                np.testing.assert_allclose(np.asarray(window['previous_action'])[:, :, :8], 0.)
                saved_target = np.asarray(window['raw_controller_target']).copy()
                obs['controller_target'][:] = 99.
                np.testing.assert_array_equal(window['raw_controller_target'], saved_target)
                self.assertEqual(np.asarray(window['raw_joint_velocity']).shape, (11, 2, 13))
                self.assertEqual(np.asarray(window['grasp_position_world']).shape, (11, 2, 3))
                if present:
                    obs['base_twist_world'][:] = 1.
                    np.testing.assert_allclose(window['raw_base_twist_world'], .003)
                else:
                    self.assertEqual(window['raw_base_twist_world'], [None]*11)

    def test_native_target_change_requires_new_complete_stable_window(self):
        obs, c = self.construct()
        self.advance(obs, c, 3)
        obs['controller_target'][0, 0] += 2e-6
        result = self.advance(obs, c)
        changed_at = float(obs['simulation_time_s'])-.05
        self.assertIsNone(result['failure'])
        self.assertFalse(result['done'])
        self.assertIsNone(result['calibration'])
        self.assertEqual(result['debug']['frame_count'], 1)
        self.assertIn('native_target_changed', result['debug']['last_window_reset_reason'])
        self.assertEqual(result['debug']['original_target_observed_at_s'], 0.)
        result = self.advance(obs, c, 9)
        self.assertFalse(result['done'])
        result = self.advance(obs, c)
        self.assertTrue(result['done'], result)
        self.assertAlmostEqual(result['calibration']['window_start_s'], changed_at)
        self.assertAlmostEqual(result['calibration']['observed_at_s']-changed_at, .5)
        self.assertAlmostEqual(result['calibration']['controller_bias'][0][0], .002602)

    def test_continuously_changing_native_target_times_out_without_learning(self):
        obs, c = self.construct()
        def change_target(o, i): o['controller_target'][0, 0] += 2e-6
        result = self.advance(obs, c, 63, change_target)
        self.assertIn('timed_out', result['failure'], result)
        self.assertIsNone(result['calibration'])
        self.assertGreater(result['debug']['window_reset_count'], 40)
        self.assertEqual(result['debug']['original_target_observed_at_s'], 0.)

    def test_slow_drift_resets_window_without_resetting_three_second_timeout(self):
        obs, c = self.construct()
        def drift(o, i): o['joint_position'][0, 3] += .00003  # 0.6mm/s.
        result = self.advance(obs, c, 63, drift)
        self.assertIn('timed_out', result['failure'], result)
        self.assertGreater(result['debug']['window_reset_count'], 10)
        self.assertIsNone(result['calibration'])

    def test_opposed_arm_segment_drift_cannot_hide_behind_constant_total(self):
        obs, c = self.construct()
        initial_sum = obs['joint_position'][0, 4:8].sum()
        def drift(o, i):
            o['joint_position'][0, 4] += .00003
            o['joint_position'][0, 5] -= .00003
        result = self.advance(obs, c, 63, drift)
        self.assertAlmostEqual(obs['joint_position'][0, 4:8].sum(), initial_sum)
        self.assertIn('timed_out', result['failure'])
        self.assertIsNone(result['calibration'])

    def test_wrist_reversal_range_rejects_even_when_window_net_speed_is_small(self):
        obs, c = self.construct()
        # End-to-start speed is only .06deg/s, yet the observed diameter is
        # .055deg. Raw qdot is not used to excuse that real sampled excursion.
        degrees = [0., .005, .010, .015, .020, .025, .014, .003, -.008, -.019, -.030]
        initial = obs['joint_position'][0, 8]
        def vary(o, i): o['joint_position'][0, 8] = initial+np.deg2rad(degrees[i])
        result = self.advance(obs, c, len(degrees), vary)
        self.assertIsNone(result['failure'])
        self.assertFalse(result['done'])
        self.assertLess(result['debug']['wrist_net_speed_radps'], c.WRIST_NET_SPEED)
        self.assertGreater(result['debug']['wrist_window_range_rad'], c.WRIST_RANGE)
        self.assertEqual(result['debug']['frame_count'], 1)
        self.assertGreater(result['debug']['window_reset_count'], 0)

    def test_slow_wrist_then_static_waits_for_a_new_window_before_bias_freeze(self):
        obs, c = self.construct()
        # Previously this accepted .08deg/s and froze a median .02deg behind
        # the final roll, which could never satisfy the .01deg hold threshold.
        initial = obs['joint_position'][0, 10]
        def drift(o, i): o['joint_position'][0, 10] = initial+np.deg2rad(i*.004)
        result = self.advance(obs, c, 11, drift)
        self.assertIsNone(result['failure'])
        self.assertFalse(result['done'])
        self.assertIsNone(result['calibration'])
        self.assertIn('terminal_frame_not_settled', result['debug']['last_window_reset_reason'])
        self.assertEqual(result['debug']['frame_count'], 1)
        original_start = c.time0
        result = self.advance(obs, c, 9)
        self.assertFalse(result['done'])
        result = self.advance(obs, c)
        self.assertTrue(result['done'], result)
        self.assertEqual(c.time0, original_start)
        self.assertAlmostEqual(result['calibration']['window_start_s'], .5)
        self.assertAlmostEqual(result['calibration']['observed_at_s'], 1.)
        bias = np.array(result['calibration']['controller_bias'])
        residual = obs['controller_target'][0, 4]-bias[0, 4]-obs['joint_position'][0, 10]
        self.assertLessEqual(abs(residual), np.deg2rad(.01))

    def test_arm_redistribution_median_must_match_final_individual_segments(self):
        obs, c = self.construct()
        initial = obs['joint_position'][0, 4:8].copy()
        def drift(o, i):
            o['joint_position'][0, 4:8] = initial+np.array([i*.000024, -i*.000024, 0., 0.])
        result = self.advance(obs, c, 11, drift)
        self.assertFalse(result['done'])
        residual = np.array(result['debug']['terminal_candidate_arm_segment_residual_m'])
        self.assertGreater(abs(residual[0, 0]), .0001)
        result = self.advance(obs, c, 10)
        self.assertTrue(result['done'], result)
        cal = result['calibration']
        effective_arm = obs['controller_target'][:, 1]-np.array(cal['controller_bias'])[:, 1]
        final_residual = effective_arm[:, None]/4-(obs['joint_position'][:, 4:8]-cal['arm_position_offsets'])
        self.assertLessEqual(np.max(abs(final_residual)), .0001)

    def test_grasp_or_base_hard_budget_is_original_reference_after_window_restarts(self):
        for key in ('base_pose_world', 'grasp_pose_base'):
            with self.subTest(key=key):
                obs, c = self.construct()
                def drift(o, i): o[key][0, 0] += .0002
                result = self.advance(obs, c, 25, drift)
                self.assertIn('3mm_budget', result['failure'], result)
                self.assertGreater(result['debug']['window_reset_count'], 0)

    def test_gap_restarts_and_backwards_clock_fails(self):
        obs, c = self.construct()
        self.advance(obs, c, 5)
        obs['simulation_time_s'][...] += .15
        result = self.advance(obs, c)
        self.assertEqual(result['debug']['frame_count'], 1)
        self.assertIn('20hz', result['debug']['last_window_reset_reason'])
        obs['simulation_time_s'][...] -= .1
        result = self.advance(obs, c)
        self.assertIn('backwards', result['failure'])

    def test_controller_bias_has_finite_absolute_cap(self):
        for column, excess in ((0,.0031),(1,.0031),(2,np.deg2rad(.31)),(3,np.deg2rad(.31)),(4,np.deg2rad(.31))):
            with self.subTest(column=column):
                obs = observation()
                actual = np.column_stack((obs['joint_position'][:, 3], obs['joint_position'][:, 4:8].sum(1), obs['joint_position'][:, 8:11]))
                obs['controller_target'][:, column] = actual[:, column]+excess
                _, c = self.construct(obs)
                result = self.advance(obs, c, 11)
                self.assertIn('bias_exceeds_bound', result['failure'])
                self.assertIsNone(result['calibration'])

    def test_missing_cloth_closed_gap_original_hand_stamp_and_public_state_reject(self):
        for fault in ('cloth', 'closed', 'gap', 'old_hand', 'static', 'previous_action', 'nonfinite'):
            with self.subTest(fault=fault):
                obs = observation()
                if fault == 'cloth': obs['depth_valid'][2] = False
                if fault == 'closed': obs['gripper_close_command'][1] = False
                if fault == 'gap': obs['fingertip_origin_distance'][1] = .09
                if fault == 'old_hand': obs['simulation_time_s'][...] = 301.
                if fault == 'previous_action': obs.pop('previous_action')
                if fault == 'nonfinite': obs['joint_velocity'][0, 3] = np.nan
                _, c = self.construct(obs, stationary_human=fault != 'static')
                result = c.step(obs)
                self.assertIsNotNone(result['failure'], fault)
                self.assertIsNone(result['calibration'])


class LongLoadedEquilibriumCalibrationTests(unittest.TestCase):
    def test_only_41_contiguous_frames_over_two_seconds_can_freeze_and_capture_raw_peak(self):
        obs=observation()
        c=equilibrium.LongLoadedEquilibriumCalibration(obs,hands(),0.)
        with patch.object(equilibrium,'_cloth_evidence',side_effect=visible):
            for i in range(41):
                obs['simulation_time_s'][...] = i*.05
                obs['joint_velocity'][0,3] = .0108+(.012 if i==15 else 0.)
                result=c.step(obs)
                self.assertIsNone(result['failure'],result)
                self.assertEqual(result['done'],i==40)
                if i==10:
                    self.assertEqual(result['debug']['frame_count'],11)
                    for _ in range(5):
                        repeated=c.step(obs)
                        self.assertFalse(repeated['done'])
                        self.assertEqual(repeated['debug']['frame_count'],11)
        cal=result['calibration']
        self.assertEqual(cal['frame_count'],41)
        self.assertAlmostEqual(cal['observed_at_s']-cal['window_start_s'],2.)
        self.assertAlmostEqual(cal['raw_joint_velocity_median'][0][3],.0108)
        self.assertAlmostEqual(cal['raw_joint_velocity_peak_deviation'][0][3],.012)
        self.assertIn('41 consecutive',cal['method']);self.assertIn('spanning 2s',cal['method'])
        self.assertEqual(result['debug']['required_window_seconds'],2.)
        self.assertEqual(result['debug']['required_frame_count'],41)
        self.assertEqual(result['debug']['original_total_time_budget_s'],6.)
        self.assertEqual(equilibrium.LoadedEquilibriumCalibration.WINDOW_SECONDS,.5)
        self.assertEqual(equilibrium.LoadedEquilibriumCalibration.MIN_FRAMES,11)

    def test_window_restarts_preserve_original_six_second_and_three_mm_limits(self):
        for fault in ('target_restarts','grasp_drift'):
            with self.subTest(fault=fault):
                obs=observation();c=equilibrium.LongLoadedEquilibriumCalibration(obs,hands(),0.)
                with patch.object(equilibrium,'_cloth_evidence',side_effect=visible):
                    for i in range(125):
                        obs['simulation_time_s'][...] = i*.05
                        if fault=='target_restarts':obs['controller_target'][0,0]+=.000002
                        else:obs['grasp_pose_base'][0,0]+=.0002
                        result=c.step(obs)
                        self.assertFalse(result['done'])
                        if result['failure']:break
                self.assertIn('timed_out' if fault=='target_restarts' else '3mm_budget',result['failure'])
                self.assertEqual(c.time0,0.)
                self.assertGreater(result['debug']['window_reset_count'],0)
                self.assertIsNone(result['calibration'])
                if fault=='target_restarts':
                    self.assertGreater(result['debug']['elapsed_since_original_start_s'],6.)

    def test_long_window_still_rejects_median_to_terminal_drift_then_requires_fresh_window(self):
        obs=observation();c=equilibrium.LongLoadedEquilibriumCalibration(obs,hands(),0.)
        initial=obs['joint_position'][0,10]
        with patch.object(equilibrium,'_cloth_evidence',side_effect=visible):
            for i in range(81):
                obs['simulation_time_s'][...] = i*.05
                obs['joint_position'][0,10]=initial+np.deg2rad(min(i,40)*.001)
                result=c.step(obs)
                self.assertIsNone(result['failure'],result)
                if i==40:
                    self.assertFalse(result['done'])
                    self.assertIn('terminal_frame_not_settled',result['debug']['last_window_reset_reason'])
                if i<80:self.assertFalse(result['done'])
        self.assertTrue(result['done'])
        self.assertAlmostEqual(result['calibration']['window_start_s'],2.)
        self.assertAlmostEqual(result['calibration']['observed_at_s'],4.)
        self.assertEqual(c.time0,0.)


if __name__ == '__main__':
    unittest.main()
