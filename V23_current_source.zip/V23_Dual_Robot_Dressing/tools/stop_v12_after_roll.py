from pathlib import Path
import json, time
run=Path('/home/xiao/Documents/Codex/2026-10-16/22/outputs/V23_Dual_Robot_Dressing/results/evaluate_20261017T093501_703268Z')
while not (run/'completion.json').exists():
    try:
        d=json.loads((run/'diagnostics/latest.json').read_text())
        policy=d.get('policy',d.get('debug',d))
        # Inspect the known report structure without accepting an unrelated phase.
        if 'phase' not in policy and isinstance(d.get('controller'),dict): policy=d['controller']
        phase=policy.get('phase')
        roll=policy.get('loaded_roll_observation',{})
        if phase in ('dual_hold','dual_position_before_hands','dual_align_hand_span','await_sleeve_geometry') and roll:
            reason='v12 targeted test complete: acquisition, lift, and bounded roll result captured; next immutable v13 will test pitch and current perception. This is not a complete challenge trial.'
            (run/'STOP_REQUESTED').write_text(reason+'\n')
            print(reason, flush=True)
            break
    except (OSError, ValueError):
        pass
    time.sleep(1)
else:
    print('v12 completed before targeted stop',flush=True)
