import json,sys
from pathlib import Path
p=Path(sys.argv[1])/"diagnostics/latest.json"
s=json.loads(p.read_text());d=s["debug"]
out={k:s[k] for k in ("step","simulation_time_s","phase","failure")}
out["phase_steps"]=d.get("phase_steps")
for k in ("route_indices","route_replans","test_lift_visibility_lost_frames"):
 if k in d:out[k]=d[k]
if d.get("approach_base_goals_world"):
 import math
 out["distance_to_approach_goals_m"]=[round(math.dist(b[:2],g),3) for b,g in zip(s["base_pose_world"],d["approach_base_goals_world"])]
for k in ("loaded_roll_observation","loaded_pitch_observation","hypothesis_contact","loaded_wrist_handoff"):
 if d.get(k):
  part=d[k]
  out[k]={a:part[a] for a in ("phase","failure","ineligible_reason","experiment_completed","measured_absolute_roll_degrees","measured_total_absolute_pitch_degrees","pending_failure","contact_travel_m","settle_conditions","fixed_joint_target_lag_lift_arm_yaw_pitch","measured_stable_seconds","frame_count","window_duration_s","last_window_reset_reason","window_reset_count","candidate_controller_bias","linear_joint_window_range_m","wrist_window_range_rad") if a in part}
  wrapper=part.get("equilibrium_wrapper",{})
  for a in ("actual_position_window_seconds","actual_position_window_stable","unresolved_integrated_target_possible"):
   if a in wrapper:out[k][a]=wrapper[a]
print(json.dumps(out,ensure_ascii=False))
