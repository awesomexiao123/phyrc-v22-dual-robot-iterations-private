import json,sys,datetime,math
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads((p/'diagnostics/latest.json').read_text());b=d['debug'];out={k:d[k] for k in ('step','simulation_time_s','phase','failure')};out['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();out['phase_steps']=b.get('phase_steps');out['closed']=d.get('gripper_close_command');out['action']=d.get('action')
if d['phase']=='pair_navigate':
 out['routes']={k:b.get(k) for k in ('route_indices','route_replans')};out['goal_distance_m']=[math.dist(pose[:2],goal) for pose,goal in zip(d['base_pose_world'],b['approach_base_goals_world'])];out['navigation']=[{k:x.get(k) for k in ('reason','body_velocity_xy')} for x in b.get('navigation',[])]
if d['phase'] in ('pair_pregrasp','pair_touch','pair_close','stopped') and b.get('sleeve_side_targets_world'):
 out['grasp_error_mm']=[]
 for base,g,target in zip(d['base_pose_world'],d['grasp_pose_base'],b['sleeve_side_targets_world']):
  w,x,y,z=base[3:];r=[[1-2*(y*y+z*z),2*(x*y-w*z),2*(x*z+w*y)],[2*(x*y+w*z),1-2*(x*x+z*z),2*(y*z-w*x)],[2*(x*z-w*y),2*(y*z+w*x),1-2*(x*x+y*y)]]; delta=[target[i]+((.12 if d['phase']=='pair_pregrasp' else .024) if i==2 else 0)-base[i] for i in range(3)];out['grasp_error_mm'].append([1000*(sum(r[j][i]*delta[j] for j in range(3))-g[i]) for i in range(3)])
 out['descent_paused']=b.get('descent_alignment_paused')
t=b.get('synchronous_transport') or {}
if t:
 out['transport']={k:t.get(k) for k in ('phase','completed_segments','waypoint_index','replans','failure') if k in t}
 s=t.get('segment_debug',t)
 out['transport']['current_segment']={k:s.get(k) for k in ('reference_distance_m','path_length_m','measured_progress_m','lag_to_reference_m','tracking_error_m','relative_grasp_error_m','common_navigation_scale','pause_for_lag','navigation_paused_pair','failure') if k in s}
if b.get('fabric_span_alignment'):out['span_alignment']=b['fabric_span_alignment']
if b.get('loaded_roll_observation'):out['roll']={k:b['loaded_roll_observation'].get(k) for k in ('phase','measured_total_absolute_roll_degrees','ineligible_reason','pending_failure','unresolved_target_lag')}
if any(b.get('fixed_feature_tracks',[])):out['tracks']=[{k:t.get(k) for k in ('reliable','median_displacement_world','reason')} for t in b.get('fixed_feature_tracks',[])]
print(json.dumps(out,ensure_ascii=False,indent=2))
