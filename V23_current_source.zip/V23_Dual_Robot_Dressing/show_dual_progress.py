"""Visible, unscored replay of the frozen, previously verified dual carry policy."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time

OUT = Path(sys.argv[1])
sys.path[:0] = ['/participant', '/project/src/PhyRC_Sim', '/project/scripts']


def write(name, value):
    target = OUT / name
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(target)


def main():
    stop = False
    def request_stop(*_):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    write('process.json', dict(status='loading', windowed=True, recording=False))
    os.environ.update(STRETCH4_HEADLESS='0', STRETCH4_SHOW_COLLIDER='0',
                      STRETCH4_AUTO_EVALUATE='0', STRETCH4_TRAINING_RECORD='0',
                      STRETCH4_FULL_RECORD='0')
    # Load the original backend with a window before DressingEnv forces headless.
    # No official file, physics setting, policy or checkpoint is modified.
    import Env_StandAlone.Teleop_TShirt_Stretch4_Env as M
    from Policy.environment import DressingEnv
    spec = importlib.util.spec_from_file_location('phyrc_submitted_policy', '/participant/policy.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    env = DressingEnv(profile='actor_rgbd', max_episode_steps=12000)
    try:
        obs, _ = env.reset(seed=1401)
        policy = module.load_policy(checkpoint=Path('/participant/frozen_v22/weights/best.pt'),
                                    observation_space=env.observation_space, action_space=env.action_space)
        policy.reset()
        from isaacsim.core.utils.viewports import set_camera_view
        set_camera_view(eye=[3.7, -4.8, 3.2], target=[0., -.25, .8])
        import omni.ui as ui
        panel = ui.Window('V22 + dual robot progress | DEMO', width=480, height=135)
        with panel.frame:
            with ui.VStack():
                ui.Label('Dual pickup / lift / carry to mannequin')
                ui.Label('Frozen verified policy; no training or video recording')
                label = ui.Label('Starting...')
                ui.Label('Full dressing is not achieved. Final scene stays paused.')
        write('process.json', dict(status='running', windowed=True, recording=False))
        print('[DEMO READY] visible Isaac Sim, verified v11 dual carry, no recording', flush=True)
        started = time.monotonic()
        reason = 'demo_horizon'
        debug = {}
        for step in range(1, 12001):
            if stop or (OUT / 'STOP_REQUESTED').exists() or not M.simulation_app.is_running():
                reason = 'requested_stop'
                break
            action = policy(obs)
            obs, _, terminated, truncated, _ = env.step(action)
            debug = policy.actor.debug
            phase = debug.get('phase')
            if step == 1 or step % 20 == 0 or debug.get('failure'):
                progress = dict(status='running', step=step, phase=phase,
                                simulation_time_s=float(obs['simulation_time_s']),
                                wall_seconds=time.monotonic()-started, failure=debug.get('failure'),
                                recording=False, include_in_evaluation_statistics=False)
                write('progress.json', progress)
                label.text = f'{step / 20:.1f}s | {phase}'
            if debug.get('failure'):
                reason = 'controller_stopped: ' + str(debug['failure'])
                break
            if phase in ('await_sleeve_geometry', 'await_sleeve_entry') and debug.get('phase_steps', 0) >= 20:
                reason = 'verified_carry_stage_finished; sleeve entry not implemented'
                break
            if terminated or truncated:
                break
        write('demo_result.json', dict(reason=reason, final_debug=module.plain(debug),
              full_dressing_success=False, include_in_evaluation_statistics=False, recording=False))
        import omni.timeline
        omni.timeline.get_timeline_interface().pause()
        label.text = 'Paused: ' + str(debug.get('phase')) + ' | close window to finish'
        write('process.json', dict(status='paused_for_user_view', reason=reason, recording=False))
        print('[DEMO PAUSED]', reason, flush=True)
        while not stop and not (OUT / 'STOP_REQUESTED').exists() and M.simulation_app.is_running():
            M.simulation_app.update()
            time.sleep(.03)
    except BaseException:
        import traceback
        (OUT / 'error.txt').write_text(traceback.format_exc())
        raise
    finally:
        write('process.json', dict(status='exiting', recording=False))
        env.close()


if __name__ == '__main__':
    main()
