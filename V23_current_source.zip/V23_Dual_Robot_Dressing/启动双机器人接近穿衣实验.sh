#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
# Development branch: predecessors can stop before contact; no success claim.
exec python3 run_experiment.py evaluate --variant calibrated_contact --seeds 1401 --seconds 900 "$@"
