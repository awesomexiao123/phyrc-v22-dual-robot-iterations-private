#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
exec python3 run_experiment.py evaluate --variant contact_hypothesis --seeds 1401 --seconds 600 "$@"
