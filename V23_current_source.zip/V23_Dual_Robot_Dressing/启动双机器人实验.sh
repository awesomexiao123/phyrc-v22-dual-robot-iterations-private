#!/usr/bin/env bash
set -euo pipefail
phyrc_dual_experiment_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 "$phyrc_dual_experiment_dir/run_experiment.py" evaluate "$@"
