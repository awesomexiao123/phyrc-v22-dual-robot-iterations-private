#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
exec python3 run_experiment.py evaluate --variant sleeve_sides --seeds 1401 --seconds 600 "$@"
