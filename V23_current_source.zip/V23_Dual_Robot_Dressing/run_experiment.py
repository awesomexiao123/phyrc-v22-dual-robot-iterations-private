#!/usr/bin/env python3
"""Run an immutable V23 participant snapshot in an isolated official environment."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import shutil
import signal

ROOT = Path(__file__).resolve().parent
IMAGE = 'phyrc-2027:isaac-6.0.1'


def verify():
    provenance = json.loads((ROOT / 'validation/official_provenance.json').read_text())
    official = ROOT / 'official'
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=official, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=official, text=True)
    if head != provenance['tested_commit'] or status:
        raise RuntimeError('The isolated official source checkout has changed.')
    frozen = ROOT / 'participant/frozen_v22'
    manifest = json.loads((frozen / 'source_sha256.json').read_text())
    for name, digest in manifest.items():
        if hashlib.sha256((frozen / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Frozen v22 source mismatch: {name}')
    for name, digest in provenance['prepared_asset_sha256'].items():
        if hashlib.sha256((ROOT / 'runtime' / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Prepared official asset mismatch: {name}')
    for path in (official / 'src/PhyRC_Sim').rglob('*'):
        if path.is_file():
            staged = ROOT / 'runtime/PhyRC_Sim' / path.relative_to(official / 'src/PhyRC_Sim')
            if not staged.is_file() or hashlib.sha256(path.read_bytes()).digest() != hashlib.sha256(staged.read_bytes()).digest():
                raise RuntimeError(f'Official staged source mismatch: {path.name}')
    image_id = subprocess.check_output(['docker', 'image', 'inspect', IMAGE, '--format', '{{.Id}}'], text=True).strip()
    if image_id != provenance['docker_image_id']:
        raise RuntimeError('Docker image differs from the verified image.')
    return provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['check', 'evaluate'])
    parser.add_argument('--seeds', type=int, nargs='+', default=[1701])
    parser.add_argument('--seconds', type=float, default=150)
    parser.add_argument('--variant', choices=['hanging', 'tabletop', 'sleeve_sides', 'sleeve_edges', 'contact_hypothesis', 'contact_sides', 'equilibrium_wrist', 'equilibrium_translation', 'calibrated_contact', 'far_field_roll'], default='hanging')
    parser.add_argument('--stop-at-phase', choices=['dual_hold'], help='End this development experiment when the requested milestone is reached')
    parser.add_argument('--no-diagnostics', action='store_true', help='Disable public-image/debug evidence inside timed policy calls')
    args = parser.parse_args()
    (ROOT / 'cache').mkdir(exist_ok=True)
    lock = (ROOT / 'cache/runtime.lock').open('a')
    try:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('This isolated test area already has an active run.')
    provenance = verify()
    if args.mode == 'check':
        print(json.dumps({'verified': True, 'official_commit': provenance['tested_commit'],
                          'frozen_files': 41, 'simulation_started': False}, indent=2))
        return
    timestamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    run_id = f'{args.mode}_{timestamp}'
    run_dir = ROOT / 'results' / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    participant_snapshot = run_dir / 'participant_snapshot'
    shutil.copytree(ROOT / 'participant', participant_snapshot, ignore=shutil.ignore_patterns('__pycache__'))
    source_hashes = {str(p.relative_to(participant_snapshot)): hashlib.sha256(p.read_bytes()).hexdigest() for p in participant_snapshot.rglob('*') if p.is_file()}
    (run_dir / 'source_sha256.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
    mappings = {'kit': 'kit/cache', 'ov': '.cache/ov', 'pip': '.cache/pip',
                'warp': '.cache/warp', 'glcache': '.cache/nvidia/GLCache',
                'computecache': '.nv/ComputeCache', 'logs': '.nvidia-omniverse/logs',
                'data': '.local/share/ov/data', 'documents': 'Documents', 'mpl': '.cache/matplotlib'}
    for name in mappings:
        folder = ROOT / 'cache' / name
        folder.mkdir(parents=True, exist_ok=True)
        folder.chmod(folder.stat().st_mode | 0o070)
    for folder in [ROOT / 'results', run_dir, ROOT / 'runtime/PhyRC_Sim', ROOT / 'runtime/RCareWorld-2.0']:
        folder.chmod(folder.stat().st_mode | 0o070)
    command = ['docker', 'run', '--rm', '--name', f'v23-dual-{run_id.lower()}',
               '--network=host', '--user', f'1234:{os.getgid()}',
               '--label', 'phyrc.experiment=v23-dual-isolated',
               '-w', '/workspace/PhyRC_Sim']
    env = {'ACCEPT_EULA': 'Y', 'PRIVACY_CONSENT': 'Y', 'OMNI_KIT_ACCEPT_EULA': 'YES',
           'PHYRC_SOURCE_COMMIT': provenance['tested_commit'], 'PHYRC_SOURCE_DIRTY': '0',
           'MPLCONFIGDIR': '/isaac-sim/.cache/matplotlib', 'OPENBLAS_NUM_THREADS': '1',
           'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'OMNICLIENT_HUB_MODE': 'disabled',
           'STRETCH4_HEADLESS': '1', 'STRETCH4_RANDOMIZE': '1', 'V23_VARIANT': args.variant,
           'STRETCH4_TRAINING_RECORD': '0', 'STRETCH4_FULL_RECORD': '0',
           'V22_DIAGNOSTICS_DIR': f'/output/{run_id}/diagnostics',
           'V23_STOP_REQUEST': f'/output/{run_id}/STOP_REQUESTED'}
    if args.mode == 'preflight':
        env['V22_DEVICE'] = 'cpu'
    if args.no_diagnostics:
        env.pop('V22_DIAGNOSTICS_DIR', None)
    if args.stop_at_phase:
        env['V23_STOP_AT_PHASE'] = args.stop_at_phase
    for name, value in env.items():
        command += ['-e', f'{name}={value}']
    mounts = [(ROOT / 'official', '/project', 'ro'), (ROOT / 'official/scripts', '/scripts', 'ro'),
              (participant_snapshot, '/participant', 'ro'), (ROOT / 'results', '/output', 'rw'),
              (ROOT / 'runtime/PhyRC_Sim', '/workspace/PhyRC_Sim', 'rw'),
              (ROOT / 'runtime/RCareWorld-2.0', '/workspace/RCareWorld-2.0', 'rw')]
    mounts += [(ROOT / 'cache' / name, '/isaac-sim/' + target, 'rw') for name, target in mappings.items()]
    for host, target, mode in mounts:
        command += ['-v', f'{host}:{target}:{mode}']
    if args.mode == 'preflight':
        command += ['--entrypoint', '/bin/bash', IMAGE, '-c',
                    'umask 0002; usd=(/isaac-sim/extscache/omni.usd.libs-*/); '
                    'export PYTHONPATH="${usd[0]}:${PYTHONPATH:-}"; '
                    'export LD_LIBRARY_PATH="${usd[0]}/bin:/isaac-sim/kit/lib:${LD_LIBRARY_PATH:-}"; '
                    'exec /isaac-sim/python.sh /participant/preflight.py']
    else:
        command += ['--gpus', 'all', IMAGE, '/participant/development_runner.py',
                    '--policy', '/participant/policy.py', '--checkpoint', '/participant/frozen_v22/weights/best.pt',
                    '--seeds', *map(str, args.seeds), '--seconds', str(args.seconds),
                    '--output', f'/output/{run_id}/official_evaluation']
    record = {'run_id': run_id, 'mode': args.mode, 'variant': args.variant, 'stop_at_phase': args.stop_at_phase, 'started_at': timestamp, 'command': command,
              'official_commit': provenance['tested_commit'], 'recording': False, 'runner_scope': 'development early stopping with unchanged official environment and scorer; not full challenge trial', 'source_snapshot': str(participant_snapshot), 'source_sha256': source_hashes,
              'seeds': args.seeds if args.mode == 'evaluate' else [], 'seconds': args.seconds,
              'timing': 'official budget = simulation time + policy inference wall time',
              'diagnostic_overhead_counted_in_policy_budget': not args.no_diagnostics and args.mode == 'evaluate',
              'policy_sha256': hashlib.sha256((ROOT / 'participant/policy.py').read_bytes()).hexdigest()}
    (run_dir / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
    (ROOT / 'results/latest_run.txt').write_text(str(run_dir) + '\n')
    print(f'Run: {run_dir}', flush=True)
    container_name = f'v23-dual-{run_id.lower()}'
    def stop_requested(signum, frame):
        (run_dir / 'stop_requested.json').write_text(json.dumps({'signal': signum, 'reason': 'requested stop', 'time': datetime.now(timezone.utc).isoformat()}) + '\n')
        subprocess.run(['docker', 'stop', '--timeout', '10', container_name], check=False)
    signal.signal(signal.SIGINT, stop_requested)
    signal.signal(signal.SIGTERM, stop_requested)
    with (run_dir / 'console.log').open('w') as log:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (run_dir / 'pid.json').write_text(json.dumps({'launcher_pid': os.getpid(), 'docker_pid': process.pid}) + '\n')
        for line in process.stdout:
            print(line, end='', flush=True)
            log.write(line)
            log.flush()
        status = process.wait()
    record.update(exit_code=status, finished_at=datetime.now(timezone.utc).isoformat())
    (run_dir / 'completion.json').write_text(json.dumps(record, indent=2) + '\n')
    raise SystemExit(status)


if __name__ == '__main__':
    main()
