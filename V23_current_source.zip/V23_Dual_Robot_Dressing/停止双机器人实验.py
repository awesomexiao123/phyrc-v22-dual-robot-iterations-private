"""Stop this experiment, allowing its runner to save the final measurements."""
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
LABEL = 'phyrc.experiment=v23-dual-isolated'


def running():
    result = subprocess.run(['docker', 'ps', '--filter', f'label={LABEL}',
                             '--format', '{{.Names}}'], check=True,
                            capture_output=True, text=True)
    return set(result.stdout.split())


def request_graceful(name):
    match = re.fullmatch(r'v23-dual-((?:evaluate|demo)_\d{8}t\d{6}_\d{6}z)', name)
    if not match:
        return False
    run_id = match.group(1).replace('t', 'T').replace('z', 'Z')
    directory = ROOT / 'results' / run_id
    if not directory.is_dir() or directory.is_symlink():
        return False
    (directory / 'STOP_REQUESTED').write_text('User requested stop.\n')
    return True


def main():
    names = running()
    graceful = {name for name in names if request_graceful(name)}
    deadline = time.monotonic() + 20
    remaining = names
    while remaining & graceful and time.monotonic() < deadline:
        time.sleep(.5)
        remaining = names & running()
    # Recheck the label and original names before any forced fallback.
    for name in sorted(remaining & running()):
        subprocess.run(['docker', 'stop', '--timeout', '10', name], check=True)
    print('双机器人实验已停止。' if names else '没有正在运行的双机器人实验。')


if __name__ == '__main__':
    main()
