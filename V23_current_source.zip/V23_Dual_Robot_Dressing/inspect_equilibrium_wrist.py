#!/usr/bin/env python3
"""Small offline summary of saved public equilibrium/wrist diagnostics only."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
PHASES = ('pair_settle_before_roll', 'pair_observe_roll',
          'pair_settle_before_pitch', 'pair_observe_pitch')
NOTE = ('仅离线读取已保存公共诊断，不读取仿真或向控制器回传数据。净角度、稀疏采样累计角度、'
        '控制器记录的逐帧实际累计角度分别报告，命令不作运动证据。稀疏日志不能证明连续时间静止、'
        '未记录时刻的最大漂移、完整抓附或穿衣成功。')


def number(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) else None


def array(value, shape):
    try:
        a = np.asarray(value, float)
        return a if a.shape == shape and np.isfinite(a).all() else None
    except (TypeError, ValueError):
        return None


def json_array(value, shape):
    a = array(value, shape)
    return a.tolist() if a is not None else None


def dictionary(value):
    return value if isinstance(value, dict) else {}


def read_records(run):
    """A live write may be incomplete; skip it, preserve warnings, never retry/write."""
    diagnostics = run/'diagnostics'
    paths = sorted(diagnostics.glob('episode_*/progress.jsonl'))
    paths += [diagnostics/'progress.jsonl']
    paths += sorted(diagnostics.glob('episode_*/latest.json'))+[diagnostics/'latest.json']
    records, warnings = {}, []
    for path in paths:
        if not path.exists():
            continue
        try:
            text = path.read_text()
        except OSError as error:
            warnings.append(f'{path.name}: {error}'); continue
        for line, payload in enumerate(text.splitlines() if path.suffix == '.jsonl' else [text], 1):
            try:
                row = json.loads(payload)
                if not isinstance(row, dict): raise ValueError('record is not an object')
            except (ValueError, json.JSONDecodeError) as error:
                warnings.append(f'{path.relative_to(run)}:{line}: {error}'); continue
            stamp = number(row.get('simulation_time_s'))
            if stamp is None:
                warnings.append(f'{path.relative_to(run)}:{line}: missing finite public timestamp'); continue
            episode = row.get('episode_directory') or (path.parent.name if path.parent.name.startswith('episode_') else None)
            episode = Path(str(episode)).name if episode else None
            # The root latest file is an alias of an episode record, not a new
            # motion sample. Reuse its known episode when its clock/step matches.
            matches = [key[0] for key in records if key[1:] == (stamp, row.get('step'))]
            if episode is None and len(set(matches)) == 1:
                episode = matches[0]
            episode = episode or 'episode_unknown'
            row = dict(row, _episode=episode)
            records[(episode, stamp, row.get('step'))] = row
    return sorted(records.values(), key=lambda x:(x['_episode'], x['simulation_time_s'])), warnings


def summarize_base_window(calibration):
    window = dictionary(calibration.get('base_diagnostic_window'))
    try:
        times = np.asarray(window['public_times_s'], float)
        poses = np.asarray(window['base_pose_world'], float)
        if (times.ndim != 1 or len(times) < 2 or poses.shape != (len(times), 2, 7)
                or not np.isfinite(times).all() or not np.isfinite(poses).all()):
            raise ValueError('invalid_saved_base_window')
        dt = np.diff(times)
        if np.any(np.abs(dt-.05) > 1e-4):
            raise ValueError('saved_base_window_not_consecutive_20hz')
        rotations = []
        for frame in poses:
            row = []
            for pose in frame:
                q = pose[3:]; norm = np.linalg.norm(q)
                if abs(norm-1.) > .01: raise ValueError('invalid_base_quaternion')
                w,x,y,z = q/norm
                row.append([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                            [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                            [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
            rotations.append(row)
        rotations = np.asarray(rotations)
        relative = rotations[1:] @ np.swapaxes(rotations[:-1], -1, -2)
        angular = np.arccos(np.clip((np.trace(relative, axis1=-2, axis2=-1)-1.)/2., -1., 1.))/dt[:, None]
        linear = np.linalg.norm(np.diff(poses[:, :, :3], axis=0), axis=2)/dt[:, None]
        def statistics(lin, ang):
            accepted = (lin <= .0002) & (ang <= .0002)
            lengths = np.zeros(3); longest = np.zeros(3)
            for interval, both in zip(dt, accepted):
                masks = np.r_[both, both.all()]
                lengths = np.where(masks, lengths+interval, 0.)
                longest = np.maximum(longest, lengths)
            return dict(linear_speed_median_mps=np.median(lin, axis=0).tolist(),
                linear_speed_peak_mps=np.max(lin, axis=0).tolist(),
                angular_speed_median_radps=np.median(ang, axis=0).tolist(),
                angular_speed_peak_radps=np.max(ang, axis=0).tolist(),
                longest_consecutive_base_rest_candidate_s=longest.tolist(),
                candidate_order=['R0', 'R1', 'both'])
        raw = array(window.get('raw_base_twist_world'), (len(times), 2, 6))
        return dict(status='available', start_time_s=float(times[0]), end_time_s=float(times[-1]),
            interval_count=len(dt), pose_difference=statistics(linear, angular),
            raw_instantaneous_twist=None if raw is None else statistics(np.linalg.norm(raw[1:, :, :3], axis=2), np.linalg.norm(raw[1:, :, 3:], axis=2)),
            base_only_rest_thresholds=dict(linear_mps=.0002, angular_radps=.0002),
            scope='Observed base-only candidates under original contact thresholds; pose differences are interval averages. Does not establish continuous rest, complete governor rest, or physical stopping.')
    except (KeyError, TypeError, ValueError):
        return dict(status='unknown_no_valid_saved_base_window')


def summarize_handoff(stage, calibration, report):
    c = dictionary(calibration); report = dictionary(report)
    q = array(c.get('last_joint_position'), (2, 13))
    t = array(c.get('controller_target_reference'), (2, 9))
    b = array(c.get('controller_bias'), (2, 5))
    offsets = array(c.get('arm_position_offsets'), (2, 4))
    residual = arm_residual = None
    if q is not None and t is not None and b is not None:
        actual = np.column_stack((q[:, 3], q[:, 4:8].sum(1), q[:, 8:11]))
        residual = (t[:, :5]-b-actual).tolist()
        if offsets is not None:
            arm_residual = ((t[:, 1]-b[:, 1])[:, None]/4-(q[:, 4:8]-offsets)).tolist()
    end, start = number(c.get('observed_at_s')), number(c.get('window_start_s'))
    return dict(stage=stage, observed_at_s=end, window_start_s=start,
        window_duration_s=end-start if end is not None and start is not None and end >= start else None,
        frame_count=c.get('frame_count'), controller_bias=json_array(b, (2, 5)),
        bias_coordinate_order=['lift_m', 'total_arm_m', 'yaw_rad', 'pitch_rad', 'roll_rad'],
        arm_position_offsets_m=json_array(offsets, (2, 4)),
        final_effective_target_residual=residual, final_arm_segment_residual_m=arm_residual,
        raw_joint_velocity_median=json_array(c.get('raw_joint_velocity_median'), (2, 13)),
        raw_joint_velocity_peak_deviation=json_array(c.get('raw_joint_velocity_peak_deviation'), (2, 13)),
        base_window=summarize_base_window(c),
        original_target_observed_at_s=number(report.get('original_target_observed_at_s')),
        window_reset_count=report.get('window_reset_count'), last_window_reset_reason=report.get('last_window_reset_reason'),
        method=c.get('method'), residual_basis='Recomputed from saved final actual joints, saved raw targets and the frozen bias; no second bias subtraction.',
        raw_velocity_note='Raw joint_velocity is the native reported value. Position-difference velocity is a separate sampled estimate; neither establishes continuous-time rest.')


def phase_of(row):
    return row.get('phase') or dictionary(row.get('debug')).get('phase')


def summarize_axis(rows, axis):
    key = f'loaded_{axis}_observation'
    available = [(r, dictionary(dictionary(r.get('debug')).get(key))) for r in rows]
    available = [(r, d) for r, d in available if d]
    if not available:
        return dict(status='no_saved_diagnostic', latest=None, sampled_actual_motion=None)
    row, d = available[-1]; wrapper = dictionary(d.get('equilibrium_wrapper'))
    anomalies = [dictionary(item.get('first_raw_velocity_anomaly')) for _, item in available]
    anomalies = [item for item in anomalies if number(item.get('observation_time_s')) is not None]
    first_anomaly = (deepcopy(min(anomalies, key=lambda item:item['observation_time_s']))
                     if anomalies else None)
    phase = d.get('phase')
    actor_failure = row.get('failure') or dictionary(row.get('debug')).get('failure')
    status = ('completed' if d.get('experiment_completed') is True else
              'skipped' if d.get('skipped') is True else
              'failed' if d.get('failure') or (phase_of(row) == 'stopped' and actor_failure) else
              'early_stopped' if d.get('early_stopped') is True else
              'pending_failure' if d.get('pending_failure') else 'not_completed_in_snapshot')
    stamp = number(d.get('report_observed_at_s'))
    samples = []
    for r, item in available:
        now = number(r.get('simulation_time_s')); recorded = number(item.get('report_observed_at_s'))
        # A retained wrist report after transport does not authorize attributing
        # later actual joint changes to this experiment.
        if phase_of(r) != f'pair_observe_{axis}' and (recorded is None or abs(recorded-now) > 1e-6):
            continue
        q = array(r.get('joint_position'), (2, 13))
        if q is not None:
            samples.append((now, q[:, 10 if axis == 'roll' else 9]))
    motion = None
    if samples:
        angles = np.stack([a for _, a in samples])
        motion = dict(first_sample_time_s=samples[0][0], last_sample_time_s=samples[-1][0],
            valid_joint_sample_count=len(samples), first_angles_degrees=np.rad2deg(angles[0]).tolist(),
            last_angles_degrees=np.rad2deg(angles[-1]).tolist(),
            net_degrees=np.rad2deg(angles[-1]-angles[0]).tolist() if len(samples)>1 else None,
            sampled_absolute_degrees_lower_bound=np.rad2deg(np.abs(np.diff(angles, axis=0)).sum(0)).tolist() if len(samples)>1 else None,
            basis='Actual public joint_position during saved phase/fresh report frames only; sparse absolute variation is a lower bound, not the full per-step motion budget.')
    return dict(status=status, latest=dict(phase=phase, report_observed_at_s=stamp,
        retained_at_public_time_s=row['simulation_time_s'],
        report_age_s=row['simulation_time_s']-stamp if stamp is not None else None,
        experiment_completed=d.get('experiment_completed'), skipped=d.get('skipped'),
        early_stopped=d.get('early_stopped'), pending_failure=d.get('pending_failure'),
        ineligible_reason=d.get('ineligible_reason'), actor_failure=actor_failure,
        actor_reported_absolute_degrees=json_array(d.get('wrapper_actual_absolute_angle_degrees'), (2,)),
        kernel_reported_absolute_degrees=json_array(d.get(f'measured_absolute_{axis}_degrees'), (2,)),
        position_difference_velocity=json_array(wrapper.get('position_difference_velocity'), (2, 13)),
        raw_joint_velocity=json_array(wrapper.get('raw_joint_velocity'), (2, 13)),
        velocity_source=wrapper.get('velocity_source')),
        sampled_actual_motion=motion, first_raw_velocity_anomaly=first_anomaly)


def own_poses(row):
    bases = array(row.get('base_pose_world'), (2, 7)); local = array(row.get('grasp_pose_base'), (2, 7))
    if bases is None or local is None: return None
    world = []
    for base, grasp in zip(bases, local):
        q = base[3:]; norm = np.linalg.norm(q)
        if norm < .5: return None
        w, x, y, z = q/norm
        rotation = np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                             [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                             [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
        world.append(base[:3]+rotation@grasp[:3])
    return bases[:, :3], np.array(world)


def drift_summary(rows, handoffs):
    first = next((i for i, r in enumerate(rows) if phase_of(r) in PHASES), None)
    if first is None: return dict(status='unknown_no_saved_wrist_start', maximum_continuous_drift_m=None)
    trial = rows[first:]
    start = next((h['original_target_observed_at_s'] for h in handoffs
                  if h['stage'] == 'pair_settle_before_roll' and h['original_target_observed_at_s'] is not None), None)
    exact = next((r for r in trial if start is not None and abs(r['simulation_time_s']-start) <= 1e-6), None)
    reference = exact or trial[0]; origin = own_poses(reference)
    reference_time = reference['simulation_time_s']
    basis = 'exact_saved_controller_start_frame' if exact is not None else 'first_saved_wrist_phase_frame; exact controller reference unavailable'
    exact_available = exact is not None and origin is not None
    for row in trial:
        original = dictionary(dictionary(row.get('debug')).get('wrist_global_reference'))
        stamp = number(original.get('time'))
        base, grasp = array(original.get('base'), (2, 7)), array(original.get('grasp'), (2, 3))
        if stamp is not None and stamp <= row['simulation_time_s'] and base is not None and grasp is not None:
            origin = (base[:, :3], grasp)
            start = reference_time = stamp
            basis = 'saved_original_controller_reference'
            exact_available = True
            break
    values = [own_poses(r) for r in trial if r['simulation_time_s'] >= reference_time]
    valid = [v for v in values if v is not None]
    known = origin is not None and bool(valid)
    return dict(status='observed_samples_only' if known else 'unknown_missing_reference_poses',
        reference_public_time_s=reference_time, original_controller_start_time_s=start,
        reference_basis=basis, exact_controller_reference_available=exact_available,
        valid_pose_samples=len(valid), missing_pose_samples=len(values)-len(valid),
        observed_max_base_drift_m=np.max([np.linalg.norm(v[0]-origin[0],axis=1) for v in valid],axis=0).tolist() if known else None,
        observed_max_grasp_drift_m=np.max([np.linalg.norm(v[1]-origin[1],axis=1) for v in valid],axis=0).tolist() if known else None,
        maximum_continuous_drift_m=None,
        scope='From the stated saved reference through latest saved run frame, including subsequent phases. Unobserved extrema and missing original reference remain unknown.')


def summarize_episode(rows):
    handoffs = {}
    for row in rows:
        for item in dictionary(row.get('debug')).get('equilibrium_handoffs', []):
            item = dictionary(item); c = dictionary(item.get('calibration'))
            stage, stamp = item.get('stage'), number(c.get('observed_at_s'))
            if isinstance(stage, str) and stamp is not None:
                handoffs[(stage, stamp)] = summarize_handoff(stage, c, item.get('report'))
    handoffs = list(handoffs.values())
    last = rows[-1]
    return dict(episode=last.get('_episode'), record_count=len(rows),
        latest_public_time_s=last['simulation_time_s'], latest_phase=phase_of(last),
        actor_failure=last.get('failure') or dictionary(last.get('debug')).get('failure'),
        equilibrium_handoffs=handoffs, handoff_count=len(handoffs),
        roll=summarize_axis(rows, 'roll'), pitch=summarize_axis(rows, 'pitch'),
        drift_after_wrist_start=drift_summary(rows, handoffs))


def inspect_run(run):
    rows, warnings = read_records(run)
    completion = None
    if (run/'completion.json').exists():
        try: completion = dictionary(json.loads((run/'completion.json').read_text()))
        except (OSError, ValueError) as error: warnings.append(f'completion.json: {error}')
    state = ('running_or_interrupted_no_completion_record' if completion is None else
             'process_finished' if completion.get('exit_code') == 0 else 'process_finished_with_error')
    episodes = [summarize_episode([r for r in rows if r['_episode']==name]) for name in sorted({r['_episode'] for r in rows})]
    return dict(schema='offline-equilibrium-wrist-review-v1', run=run.name,
        generated_at_utc=datetime.now(timezone.utc).isoformat(), snapshot_only=True,
        run_state=state, completion_exit_code=completion.get('exit_code') if completion else None,
        episodes=episodes, warnings=warnings, limitations=NOTE)


def render_chinese(report):
    states = {'running_or_interrupted_no_completion_record':'运行中或中断，暂无完成记录',
              'process_finished':'进程结束', 'process_finished_with_error':'进程异常结束',
              'no_saved_diagnostic':'暂无保存的诊断', 'completed':'已完成', 'skipped':'已跳过',
              'failed':'失败', 'early_stopped':'提前停止', 'pending_failure':'等待停止完成',
              'not_completed_in_snapshot':'此快照尚未完成'}
    lines = [f"腕部校准离线快照：{report['run']}", f"进程状态：{states.get(report['run_state'], report['run_state'])}（进程结束不等于任务成功）"]
    for ep in report['episodes']:
        lines += [f"{ep['episode']}：最后阶段 {ep['latest_phase']}，公共时间 {ep['latest_public_time_s']:.3f}s；校准 {ep['handoff_count']} 次。"]
        for handoff in ep['equilibrium_handoffs']:
            lines += [f"  {handoff['stage']}：原观测时间 {handoff['observed_at_s']}s，窗口 {handoff['window_duration_s']}s / {handoff['frame_count']} 帧；bias和末帧残差见JSON。"]
        for axis, label in (('roll','滚转'),('pitch','俯仰')):
            item=ep[axis]; motion=item.get('sampled_actual_motion') or {}; latest=item.get('latest') or {}
            lines += [f"  {label}：{states.get(item['status'], item['status'])}；实际采样净角度 {motion.get('net_degrees')}°；稀疏绝对变化下界 {motion.get('sampled_absolute_degrees_lower_bound')}°；控制器逐帧实际累计 {latest.get('actor_reported_absolute_degrees')}°。"]
        drift=ep['drift_after_wrist_start']
        lines += [f"  已保存样本的最大底盘/夹点漂移：{drift.get('observed_max_base_drift_m')} / {drift.get('observed_max_grasp_drift_m')} m；参考：{drift.get('reference_basis','unknown')}。",
                  f"  停止原因：{ep['actor_failure'] or '此快照未报告失败'}"]
    lines += ['原生qdot与相邻实际位置差/时间是两种不同观测；偏差校准不能把它们等同。', NOTE,
              'None/unknown表示缺失证据，不表示零。']
    if report['warnings']: lines += ['读取提示：'+'；'.join(report['warnings'])]
    return '\n'.join(lines)+'\n'


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, help='results目录中的运行名称')
    args=parser.parse_args(argv)
    if Path(args.run).name != args.run or args.run in ('.','..'):
        parser.error('--run must be a basename under results/')
    run=ROOT/'results'/args.run
    if not run.is_dir(): parser.error('run directory does not exist')
    report=inspect_run(run)
    for suffix, content in (('.json',json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n'),
                            ('.txt',render_chinese(report))):
        (run/('equilibrium_wrist_review'+suffix)).write_text(content)
    print(json.dumps(dict(run=args.run,run_state=report['run_state'],episodes=len(report['episodes']),
                         report=str(run/'equilibrium_wrist_review.json')),ensure_ascii=False))


if __name__ == '__main__': main()
