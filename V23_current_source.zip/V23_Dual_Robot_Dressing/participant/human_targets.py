"""Observable hand surfaces and unclassified yellow garment trim, not anatomy.

Only public RGB-D and the robots' own poses enter these estimates. Static robot
camera calibration is the frozen V22 calibration. Confidence is a quality
heuristic, not a calibrated probability. No evaluator or simulator imports.
"""
import importlib.util
from pathlib import Path

import cv2
import numpy as np
from camera_geometry import pixel_rays


def _frozen_module(name):
    path = Path(__file__).resolve().parent / 'frozen_v22' / (name + '.py')
    spec = importlib.util.spec_from_file_location('_v23_public_targets_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_DETECTOR = _frozen_module('detector')
_GEOMETRY = _frozen_module('geometry')
_HEAD = np.asarray(_GEOMETRY.CAL['base_from_head_optical'], dtype=float)
_WRIST = np.asarray(_GEOMETRY.CAL['grasp_from_wrist_optical'], dtype=float)
_FOCAL = float(_GEOMETRY.FOCAL)
_CAMERAS = {1: ('robot_0_wrist', 0), 2: ('robot_1_wrist', 1),
            3: ('robot_0_head', 0), 4: ('robot_1_head', 1)}


def _validated(obs, *, wrists=False):
    required = {'rgb': (5, 256, 256, 3), 'depth': (5, 256, 256, 1),
                'depth_valid': (5, 256, 256, 1), 'base_pose_world': (2, 7)}
    if wrists:
        required['grasp_pose_base'] = (2, 7)
    values = {key: np.asarray(obs[key]) for key in required}
    for key, shape in required.items():
        if values[key].shape != shape:
            raise ValueError('Unexpected public observation shape: ' + key)
    if values['rgb'].dtype != np.uint8 or values['depth_valid'].dtype != np.bool_:
        raise ValueError('Expected uint8 RGB and boolean depth validity')
    for key in ('base_pose_world', 'grasp_pose_base'):
        if key in values:
            pose = values[key]
            if not np.isfinite(pose).all() or np.any(np.linalg.norm(pose[:, 3:], axis=1) < .5):
                raise ValueError('Invalid own robot pose: ' + key)
    return values


def _camera_transform(values, camera):
    robot = _CAMERAS[camera][1]
    base = values['base_pose_world'][robot]
    rotation = _GEOMETRY.rotation(base[3:])
    if camera >= 3:
        mount = _HEAD
    else:
        grasp = values['grasp_pose_base'][robot]
        base_from_grasp = np.eye(4)
        base_from_grasp[:3, :3] = _GEOMETRY.rotation(grasp[3:])
        base_from_grasp[:3, 3] = grasp[:3]
        mount = base_from_grasp @ _WRIST
    return rotation @ mount[:3, :3], rotation @ mount[:3, 3] + base[:3]


def _world_pixels(values, camera, u, v, depth):
    optical = pixel_rays(u, v, _FOCAL)*np.asarray(depth)[..., None]
    rotation, translation = _camera_transform(values, camera)
    return optical @ rotation.T + translation


def estimate_hands(obs):
    """Return two visible hand *surface* points; never wrist or anatomical labels.

    Points are sorted by world X/Y/Z for deterministic ordering. A single head
    view is permitted with reduced confidence. Two detected views must agree
    within 12 cm after pair matching, otherwise the estimate abstains. The
    inferred approach vector points horizontally from the reference camera to
    the hand midpoint; it is not an estimate of a forearm axis or safe path.
    """
    values = _validated(obs)
    views = []
    for robot in (0, 1):
        camera = 3 + robot
        detection = _DETECTOR.detect_head(values['rgb'][camera], values['depth'][camera],
                                          values['depth_valid'][camera])
        if not detection['detected']:
            continue
        if not all(12 <= h['u'] <= 244 and 12 <= h['v'] <= 244 for h in detection['hands']):
            continue
        points = _world_pixels(values, camera,
            np.array([h['u'] for h in detection['hands']]),
            np.array([h['v'] for h in detection['hands']]),
            np.array([h['median_depth_m'] for h in detection['hands']]))
        if not np.isfinite(points).all():
            continue
        views.append({'camera_index': camera, 'points': points})
    missing = dict(detected=False, hand_points_world=[], midpoint_world=None, span_m=None,
                   approach_direction_world=None, approach_is_inferred=True,
                   approach_basis='horizontal reference-camera-to-hand-midpoint; not forearm axis',
                   confidence=0.0, cameras=[_CAMERAS[v['camera_index']][0] for v in views],
                   camera=None, reason='no_unambiguous_public_hand_pair',
                   anatomical_labels=False, cross_view_error_m=None)
    if not views:
        return missing
    points = views[0]['points'].copy()
    error = None
    confidence = .55
    if len(views) == 2:
        candidates = [views[1]['points'], views[1]['points'][::-1]]
        other = min(candidates, key=lambda p: np.linalg.norm(points - p, axis=1).sum())
        error = float(np.linalg.norm(points - other, axis=1).max())
        if error > .12:
            return dict(missing, reason='cross_view_hand_surfaces_disagree', cross_view_error_m=error)
        points = (points + other) / 2
        confidence = .85 - .20 * error / .12
    points = np.asarray(sorted(points.tolist(), key=lambda p: tuple(p)))
    span = float(np.linalg.norm(points[1] - points[0]))
    if not .06 <= span <= 1.2:
        return dict(missing, reason='implausible_visible_hand_pair_span', cross_view_error_m=error)
    midpoint = points.mean(axis=0)
    camera = views[0]['camera_index']
    _, origin = _camera_transform(values, camera)
    approach = midpoint - origin
    approach[2] = 0
    length = float(np.linalg.norm(approach))
    approach = (approach / length).tolist() if length >= .10 else None
    return dict(missing, detected=True, hand_points_world=points.tolist(),
                midpoint_world=midpoint.tolist(), span_m=span,
                approach_direction_world=approach, confidence=float(confidence),
                camera=_CAMERAS[camera][0], cross_view_error_m=error,
                point_order='ascending_world_x_then_y_then_z; not anatomical left/right',
                reason='consistent_public_head_rgbd_pair' if len(views) == 2 else 'single_public_head_rgbd_pair')


def garment_edge_candidates(obs):
    """Yellow visible trim adjacent to blue cloth; no sleeve-opening claims.

    Returns separate camera observations without pretending their identities are
    matched across views. The PCA axis is a visible-surface direction with an
    arbitrary sign, not an opening normal. Yellow collar and hem are both possible.
    The human-mounted overview is deliberately excluded: its dynamic transform is
    not a permitted object-localization input.
    """
    values = _validated(obs, wrists=True)
    candidates = []
    for camera in (1, 2, 3, 4):
        color = values['rgb'][camera].astype(float)
        red, green, blue = color.transpose(2, 0, 1)
        cloth = (blue > 100) & (blue > 1.25 * red) & (blue > 1.25 * green)
        near_blue = cv2.dilate(cloth.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)
        yellow = (red > 120) & (green > 100) & (blue < .65 * np.minimum(red, green))
        yellow &= (red > .65 * green) & (green > .55 * red)
        count, labels, stats, _ = cv2.connectedComponentsWithStats(yellow.astype(np.uint8), connectivity=8)
        depth = values['depth'][camera, ..., 0]
        valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < 5)
        for label in range(1, count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < 8:
                continue
            component = labels == label
            blue_adjacency = float(near_blue[component].mean())
            fraction = float(valid[component].mean())
            if blue_adjacency < .1 or fraction < .75:
                continue
            v, u = np.where(component & valid)
            z = depth[v, u]
            points = _world_pixels(values, camera, u, v, z)
            centre = np.median(points, axis=0)
            # Reject mixed foreground/background at a trim boundary.
            distances = np.linalg.norm(points - centre, axis=1)
            points = points[distances <= max(.02, float(np.percentile(distances, 90)))]
            if len(points) < 8:
                continue
            centre = np.median(points, axis=0)
            _, singular, axes = np.linalg.svd(points - centre, full_matrices=False)
            extent = float(np.percentile((points-centre) @ axes[0], 95)
                           - np.percentile((points-centre) @ axes[0], 5))
            if not .005 <= extent <= 1.2:
                continue
            axis = axes[0]
            if axis[np.argmax(np.abs(axis))] < 0:
                axis = -axis
            elongation = float(singular[0] / max(singular[1], 1e-9))
            candidates.append(dict(kind='unclassified_trim', camera=_CAMERAS[camera][0],
                camera_index=camera, centroid_world=centre.tolist(), principal_axis_world=axis.tolist(),
                axis_is_unsigned=True, extent_m=extent, pixel_area=area,
                depth_valid_fraction=fraction, blue_adjacency_fraction=blue_adjacency,
                elongation=elongation, confidence=float(min(.7, .35 + .2 * fraction + .15 * blue_adjacency)),
                opening_verified=False, reason='visible_yellow_trim_adjacent_to_blue_cloth'))
    candidates.sort(key=lambda p: (p['camera_index'], -p['pixel_area']))
    return dict(yellow_trim_candidates=candidates, detected=bool(candidates),
                reason='public_rgbd_trim_candidates' if candidates else 'no_usable_visible_yellow_trim',
                sleeve_opening_verified=False, observations_are_not_cross_view_matched=True)
