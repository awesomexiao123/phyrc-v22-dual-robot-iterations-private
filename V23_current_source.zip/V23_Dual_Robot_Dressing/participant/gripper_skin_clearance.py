"""Static OWN robot boxes against public observed skin points, CPU only.

This is a conservative *geometric approximation of the selected authored
collider meshes*, not a collision certificate. Each box encloses all vertices
of one collider in its own rigid link frame. Different wrist joints and both
measured jaws are articulated separately, anchored by the public grasp pose.
The empty portions of boxes can produce false obstacles. Unobserved skin,
arm/base geometry, PhysX cooking/contact offsets and compliance are unbounded.

No human/cloth asset, simulator state or evaluator is read by this module.
Source extraction used only the published static own Stretch USD. Static-own-
asset use in local experiments is not a competition eligibility guarantee.
"""
import math
import numpy as np


ASSET_RELATIVE_PATH = 'runtime/RCareWorld-2.0/assets/robots/stretch_4/stretch_4.usd'
ASSET_SHA256 = 'a7a7be5bc14354caaeb4461c9b733e10d8f18a0d047dec58814904e8317deb37'
# Generated once from the own USD. Bounds rounded OUTWARD to one micrometre;
# joints retain authored float precision. Runtime requires no USD/Isaac import.
_OWN_GEOMETRY_DATA = {
    'colliders': [
        {'link': 'wrist_link', 'source_prim': '/stretch/wrist_link/collisions/wrist_collision_link/mesh', 'vertex_count': 570, 'lower_m': [-0.053001, -0.027858, -0.001001], 'upper_m': [0.027858, 0.027981, 0.067683]},
        {'link': 'wrist_aruco_link', 'source_prim': '/stretch/wrist_aruco_link/collisions/wrist_aruco_collision_link/mesh', 'vertex_count': 36, 'lower_m': [-0.015001, -0.015001, -5.1e-05], 'upper_m': [0.015001, 0.015001, 0.000551]},
        {'link': 'wrist_reflector_link', 'source_prim': '/stretch/wrist_reflector_link/collisions/wrist_reflector_collision_link/mesh', 'vertex_count': 36, 'lower_m': [-0.007001, -0.015501, -0.008195], 'upper_m': [1e-06, 0.015501, 0.002001]},
        {'link': 'wrist_yaw_link', 'source_prim': '/stretch/wrist_yaw_link/collisions/wrist_yaw_collision_link/mesh', 'vertex_count': 618, 'lower_m': [-0.027799, -0.04322, -0.073201], 'upper_m': [0.027799, 0.027788, 1e-06]},
        {'link': 'wrist_pitch_link', 'source_prim': '/stretch/wrist_pitch_link/collisions/wrist_pitch_collision_link/mesh', 'vertex_count': 618, 'lower_m': [-0.027788, -0.0732, -0.027799], 'upper_m': [0.043221, 1e-06, 0.027799]},
        {'link': 'wrist_roll_link', 'source_prim': '/stretch/wrist_roll_link/collisions/wrist_roll_collision_link/mesh', 'vertex_count': 1074, 'lower_m': [-0.00805, -0.031129, -0.027568], 'upper_m': [0.023101, 0.034368, 0.080385]},
        {'link': 'gripper_camera_link', 'source_prim': '/stretch/gripper_camera_link/collisions/gripper_camera_link_collision/mesh', 'vertex_count': 36, 'lower_m': [-0.016601, -0.002001, -0.029001], 'upper_m': [0.021401, 0.025351, 0.029001]},
        {'link': 'tool_attachment_site_link', 'source_prim': '/stretch/tool_attachment_site_link/collisions/tool_attachment_site_collision_link/mesh', 'vertex_count': 1074, 'lower_m': [-0.026651, -0.031129, -0.027856], 'upper_m': [0.0045, 0.034368, 0.080385]},
        {'link': 'quick_connect_interface_link', 'source_prim': '/stretch/quick_connect_interface_link/collisions/quick_connect_interface_collision_link/mesh', 'vertex_count': 12198, 'lower_m': [-0.0317, -0.114563, -0.047], 'upper_m': [0.031661, 1e-06, 0.027887]},
        {'link': 'gripper_finger_left_link', 'source_prim': '/stretch/gripper_finger_left_link/collisions/gripper_finger_left_collision_link/mesh', 'vertex_count': 306, 'lower_m': [0.0, -0.007001, -0.196776], 'upper_m': [0.066769, 0.007001, 0.00011]},
        {'link': 'gripper_fingertip_left_link', 'source_prim': '/stretch/gripper_fingertip_left_link/collisions/gripper_fingertip_left_collision_link/mesh', 'vertex_count': 2454, 'lower_m': [-0.009568, -0.04052, -0.017846], 'upper_m': [0.019183, 0.021201, 0.017846]},
        {'link': 'gripper_finger_right_link', 'source_prim': '/stretch/gripper_finger_right_link/collisions/gripper_finger_right_collision_link/mesh', 'vertex_count': 306, 'lower_m': [-0.066769, -0.007001, -0.196776], 'upper_m': [-0.0, 0.007001, 0.00011]},
        {'link': 'gripper_fingertip_right_link', 'source_prim': '/stretch/gripper_fingertip_right_link/collisions/gripper_fingertip_right_collision_link/mesh', 'vertex_count': 2454, 'lower_m': [-0.009568, -0.021201, -0.017846], 'upper_m': [0.019183, 0.040508, 0.017846]},
    ],
    'joints': [
        {'name': 'wrist_aruco_joint', 'parent': 'wrist_link', 'child': 'wrist_aruco_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [-0.008670000359416008, 0.0, 0.068060502409935], 'rotation0': [-0.7071067690849304, 0.0, 0.7071067690849304, 1.7926441842064378e-06], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'wrist_reflector_joint', 'parent': 'wrist_link', 'child': 'wrist_reflector_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.006649999879300594, 0.0, 0.06776049733161926], 'rotation0': [-0.7071067690849304, 0.0, 0.7071067690849304, 1.7926441842064378e-06], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'wrist_yaw_joint', 'parent': 'wrist_link', 'child': 'wrist_yaw_link', 'public_index': 8, 'axis': 'Z', 'limits_rad': [-1.1349999749656927, 4.275999675738779], 'position0': [0.0, 0.0, 0.0], 'rotation0': [1.0, 0.0, 0.0, 0.0], 'position1': [0.0, 0.0, 0.0], 'rotation1': [1.0, 0.0, 0.0, 0.0]},
        {'name': 'wrist_pitch_joint', 'parent': 'wrist_yaw_link', 'child': 'wrist_pitch_link', 'public_index': 9, 'axis': 'Y', 'limits_rad': [-4.275999675738779, 1.1349999749656927], 'position0': [0.0, -0.04222000017762184, -0.04520000144839287], 'rotation0': [1.0, 0.0, 0.0, 0.0], 'position1': [0.0, 0.0, 0.0], 'rotation1': [1.0, 0.0, 0.0, 0.0]},
        {'name': 'wrist_roll_joint', 'parent': 'wrist_pitch_link', 'child': 'wrist_roll_link', 'public_index': 10, 'axis': 'X', 'limits_rad': [-1.1349999749656927, 4.275999675738779], 'position0': [0.04222000017762184, -0.04520000144839287, 0.0], 'rotation0': [1.0, 0.0, 0.0, 0.0], 'position1': [0.0, 0.0, 0.0], 'rotation1': [1.0, 0.0, 0.0, 0.0]},
        {'name': 'gripper_camera_joint', 'parent': 'wrist_roll_link', 'child': 'gripper_camera_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.019200000911951065, 0.0, 0.05700000002980232], 'rotation0': [0.7071055173873901, -1.3113021850585938e-06, -1.2516975402832031e-06, 0.7071080803871155], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'tool_attachment_site_joint', 'parent': 'wrist_roll_link', 'child': 'tool_attachment_site_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.01860000006854534, 0.0, 0.0], 'rotation0': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'tool_connection_joint', 'parent': 'tool_attachment_site_link', 'child': 'quick_connect_interface_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.0, 0.0, 0.0], 'rotation0': [0.49999910593032837, -0.5000008940696716, 0.49999910593032837, 0.5000008940696716], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'grasp_center_joint', 'parent': 'quick_connect_interface_link', 'child': 'grasp_center_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.0, -0.2345380038022995, 0.0], 'rotation0': [0.49999910593032837, 0.5000008940696716, 0.49999910593032837, -0.5000008940696716], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'gripper_finger_left_joint', 'parent': 'quick_connect_interface_link', 'child': 'gripper_finger_left_link', 'public_index': 11, 'axis': 'Y', 'limits_rad': [0.0, 0.4999999725468887], 'position0': [0.022260699421167374, -0.037390898913145065, 0.0], 'rotation0': [8.963205004874908e-07, 8.963237405623659e-07, 0.7071080803871155, 0.7071055173873901], 'position1': [0.0, 0.0, 0.0], 'rotation1': [1.0, 0.0, 0.0, 0.0]},
        {'name': 'gripper_fingertip_left_joint', 'parent': 'gripper_finger_left_link', 'child': 'gripper_fingertip_left_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [0.022167999297380447, 0.0, -0.19100800156593323], 'rotation0': [0.49999845027923584, -0.5000015497207642, 0.4999997615814209, -0.5000002384185791], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
        {'name': 'gripper_finger_right_joint', 'parent': 'quick_connect_interface_link', 'child': 'gripper_finger_right_link', 'public_index': 12, 'axis': 'Y', 'limits_rad': [0.0, 0.4999999725468887], 'position0': [-0.022260699421167374, -0.037390898913145065, 0.0], 'rotation0': [-8.963237405623659e-07, 8.963205004874908e-07, 0.7071055173873901, -0.7071080803871155], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.0, 1.0, 0.0, 0.0]},
        {'name': 'gripper_fingertip_right_joint', 'parent': 'gripper_finger_right_link', 'child': 'gripper_fingertip_right_link', 'public_index': None, 'axis': None, 'limits_rad': None, 'position0': [-0.022167999297380447, 0.0, -0.19100800156593323], 'rotation0': [-0.5000008940696716, -0.4999977946281433, 0.5000008940696716, 0.5000004172325134], 'position1': [0.0, 0.0, 0.0], 'rotation1': [0.7071067690849304, 0.0, 0.7071067690849304, 0.0]},
    ],
}


def _rotation(q):
    q = np.asarray(q, dtype=float)
    if q.shape != (4,) or not np.isfinite(q).all() or abs(np.linalg.norm(q)-1) > .01:
        raise ValueError('invalid_public_wxyz_quaternion')
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def _pose(position, quaternion):
    result = np.eye(4)
    result[:3, :3] = _rotation(quaternion)
    result[:3, 3] = position
    return result


def _relative_link_poses(joints):
    """Own joint FK from wrist_link, with separate pre-/post-pitch shells."""
    transforms = {'wrist_link': np.eye(4)}
    remaining = list(_OWN_GEOMETRY_DATA['joints'])
    while remaining:
        progressed = False
        for item in list(remaining):
            if item['parent'] not in transforms:
                continue
            rotation = np.eye(4)
            index = item['public_index']
            if index is not None:
                axis = {'X': 0, 'Y': 1, 'Z': 2}[item['axis']]
                quat = np.zeros(4)
                quat[0] = np.cos(joints[index]/2)
                quat[axis+1] = np.sin(joints[index]/2)
                rotation[:3, :3] = _rotation(quat)
            transforms[item['child']] = (transforms[item['parent']] @
                _pose(item['position0'], item['rotation0']) @ rotation @
                np.linalg.inv(_pose(item['position1'], item['rotation1'])))
            remaining.remove(item)
            progressed = True
        if not progressed:
            raise ValueError('invalid_static_own_joint_tree')
    return transforms


def _public_geometry(obs, robot):
    if isinstance(robot, bool) or robot not in (0, 1):
        raise ValueError('robot_index_must_be_zero_or_one')
    values = {}
    for key, shape in (('base_pose_world', (2, 7)), ('grasp_pose_base', (2, 7)),
                       ('joint_position', (2, 13)), ('fingertip_position_base', (2, 2, 3))):
        value = np.asarray(obs[key], dtype=float)
        if value.shape != shape or not np.isfinite(value).all():
            raise ValueError('invalid_public_'+key)
        values[key] = value
    q = values['joint_position'][robot]
    for item in _OWN_GEOMETRY_DATA['joints']:
        index = item['public_index']
        if index is not None and not item['limits_rad'][0]-.001 <= q[index] <= item['limits_rad'][1]+.001:
            raise ValueError('measured_joint_outside_own_limit:'+item['name'])
    base = values['base_pose_world'][robot]
    grasp = values['grasp_pose_base'][robot]
    world_from_base = _pose(base[:3], base[3:])
    base_from_grasp = _pose(grasp[:3], grasp[3:])
    relative = _relative_link_poses(q)
    base_from_wrist = base_from_grasp @ np.linalg.inv(relative['grasp_center_link'])
    tip_errors = []
    for index, side in enumerate(('left', 'right')):
        predicted = (base_from_wrist @ relative['gripper_fingertip_'+side+'_link'])[:3, 3]
        tip_errors.append(float(np.linalg.norm(predicted-values['fingertip_position_base'][robot, index])))
    # Explicit engineering consistency gate, not a specified sensor guarantee.
    if max(tip_errors) > .003:
        raise ValueError('public_fingertips_disagree_with_own_fk')
    world_from_wrist = world_from_base @ base_from_wrist
    models = []
    for collider in _OWN_GEOMETRY_DATA['colliders']:
        models.append((collider, world_from_wrist @ relative[collider['link']]))
    return models, tip_errors, q[11:13].copy()


def _unknown(reason):
    return dict(valid=False, reason=reason, observed_minimum_clearance_m=None,
                closest_primitive=None, fullbody_clearance=False,
                collision_free=False,
                insertion_allowed=False, unobserved_skin_clearance_known=False)


def observed_gripper_skin_clearance(obs, robot, skin_points_world, *, skin_observed_at,
                                    stationary_skin=False, max_skin_age_s=.25,
                                    proposed_translation_world=None, model_margin_m=.002):
    """Distance to a bounded articulated own-gripper model and OBSERVED points.

    ``skin_observed_at`` must be the original observation timestamp. Cached
    points require explicit ``stationary_skin=True`` and an explicit larger
    ``max_skin_age_s`` (bounded to 600 s here). The caller owns segmentation,
    point uncertainty, and evidence for the stationary-human assumption.
    ``model_margin_m`` (default 2 mm) is an engineering allowance, not a measured
    sensor-error/contact-offset bound; observed fingertip FK error is added.

    A supplied translation must be <=5 mm and is sampled every <=1 mm with all
    articulation fixed. This is a hypothetical gripper-only rigid translation,
    not a validated robot command or continuous whole-body sweep. No action is
    emitted. Zero distance means a point is inside an enclosing/expanded box,
    not that physical skin contact was measured. Positive distance gives no
    guarantee about unseen skin between samples or any unmodeled geometry.
    """
    try:
        now = np.asarray(obs['simulation_time_s'], dtype=float)
        if now.size != 1 or not np.isfinite(now).all():
            raise ValueError('invalid_public_simulation_time')
        stamp = float(skin_observed_at)
        maximum_age = float(max_skin_age_s)
        margin = float(model_margin_m)
        if not np.isfinite([stamp, maximum_age, margin]).all():
            raise ValueError('invalid_skin_stamp_or_model_margin')
        if not 0 < maximum_age <= 600 or not 0 <= margin <= .02:
            raise ValueError('invalid_skin_age_or_model_margin_bound')
        if not isinstance(stationary_skin, (bool, np.bool_)):
            raise ValueError('stationary_skin_assumption_must_be_explicit_boolean')
        age = float(now.reshape(-1)[0])-stamp
        if age < -1e-6 or age > maximum_age or (age > .25 and not stationary_skin):
            raise ValueError('skin_observation_stale_or_future')
        points = np.asarray(skin_points_world, dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or not len(points) or not np.isfinite(points).all():
            raise ValueError('missing_or_invalid_observed_skin_points')
        delta = np.zeros(3) if proposed_translation_world is None else np.asarray(proposed_translation_world, dtype=float)
        if delta.shape != (3,) or not np.isfinite(delta).all() or np.linalg.norm(delta) > .005+1e-12:
            raise ValueError('translation_must_be_finite_and_at_most_5mm')
        models, tip_errors, jaws = _public_geometry(obs, robot)
    except (KeyError, ValueError, TypeError, IndexError) as error:
        return _unknown(str(error))

    total_margin = margin+max(tip_errors)
    fractions = np.linspace(0., 1., max(1, int(math.ceil(np.linalg.norm(delta)/.001)))+1) if np.any(delta) else np.array([0.])
    best, initial = None, float('inf')
    for fraction in fractions:
        for model, transform in models:
            origin = transform[:3, 3]+fraction*delta
            rotation = transform[:3, :3]
            local = (points-origin) @ rotation
            lo, hi = np.asarray(model['lower_m']), np.asarray(model['upper_m'])
            nearest = np.clip(local, lo, hi)
            distance = np.linalg.norm(local-nearest, axis=1)
            index = int(np.argmin(distance))
            clearance = max(0., float(distance[index])-total_margin)
            if fraction == 0.:
                initial = min(initial, clearance)
            if best is None or clearance < best['clearance']:
                best = dict(clearance=clearance, unexpanded=float(distance[index]),
                            primitive=model['link'], source=model['source_prim'],
                            point_index=index, fraction=float(fraction),
                            closest_world=(nearest[index] @ rotation.T+origin).tolist())
    provenance = dict(asset_relative_path=ASSET_RELATIVE_PATH, asset_sha256=ASSET_SHA256,
                      length_unit='m', extraction='All authored collider vertices enclosed by link-local axis-aligned boxes; outward rounding 1 micrometre.',
                      transforms='Own USD joint frames, measured joints 8..12, measured world-base and base-grasp wxyz poses.',
                      contact_offsets_bounded=False, collision_cooking_bounded=False,
                      static_own_asset_permission_certified=False)
    return dict(valid=True, reason='observed_skin_points_only_model_distance', robot=int(robot),
                observed_minimum_clearance_m=best['clearance'],
                current_observed_minimum_clearance_m=initial,
                unexpanded_box_distance_m=best['unexpanded'],
                closest_primitive=best['primitive'], closest_primitive_source=best['source'],
                closest_model_point_world=best['closest_world'],
                closest_skin_point_index=best['point_index'], closest_skin_point_world=points[best['point_index']].tolist(),
                closest_translation_fraction=best['fraction'], skin_point_count=len(points),
                skin_observed_at=stamp, skin_age_s=age, stationary_skin_assumed=bool(stationary_skin),
                public_fingertip_fk_error_m=tip_errors, measured_jaw_angles_rad=jaws.tolist(),
                model_margin_m=margin, effective_model_margin_m=total_margin,
                translation_world_m=delta.tolist(), translation_sample_count=len(fractions),
                sampled_translation_only=bool(np.any(delta)),
                entire_continuous_sweep_checked=False, fullbody_clearance=False,
                collision_free=False, insertion_allowed=False,
                unobserved_skin_clearance_known=False,
                model_bounds=_OWN_GEOMETRY_DATA['colliders'], model_provenance=provenance)
