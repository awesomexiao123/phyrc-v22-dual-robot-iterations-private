"""Alternate experiment: pause V22 before lifting, then lift two grasps together.

This inherits the existing helper navigation heuristic; it does not establish
table-edge collision clearance. Relative-height filtering is not a verified
tabletop plane. Public cloth co-motion is a candidate grasp check, not success.
"""
import numpy as np

import cooperative_policy as cooperative


class Policy(cooperative.Policy):
    VERSION = 'v23_03_tabletop'
    SINGLE_HELPER_LIFT = False
    METHOD = 'frozen V22 close-wait handoff; helper second patch; bounded synchronous public-pose lift'

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.tabletop_handoff_done = False
        self.tabletop_lift_done = False
        self.tabletop_lift_started = None
        self.tabletop_initial_bases = None
        self.tabletop_initial_patches = None
        self.tabletop_lift_diagnostics = {}
        self.tabletop_survey_started = None
        self.tabletop_survey_reference = None
        self.tabletop_survey_hand_streak = 0

    def _cache_hands(self, obs, *, force=False):
        if not force and self.step % 20:
            return False
        observation = cooperative.estimate_hands(obs)
        if observation.get('detected'):
            points = np.asarray(observation['hand_points_world'])
            previous = np.asarray(self.hands.get('hand_points_world', []))
            agrees = not self.hands.get('detected') or min(
                np.max(np.linalg.norm(points - previous, axis=1)),
                np.max(np.linalg.norm(points[::-1] - previous, axis=1))) <= .12
            if agrees:
                self.hands = observation
                self.hand_observation_time = float(np.asarray(obs['simulation_time_s']).item())
                return True
        return False

    def _decorate(self):
        self.debug.update(version=self.VERSION, method=self.METHOD, step=self.step,
            phase=self.phase, phase_steps=self.phase_steps, failure=self.failure,
            active_robot=self.active, helper_robot=self.helper, idle_mode=self.phase,
            tabletop_handoff_done=self.tabletop_handoff_done,
            tabletop_lift_done=self.tabletop_lift_done,
            tabletop_survey_hand_streak=self.tabletop_survey_hand_streak,
            tabletop_observer_mode=getattr(self.baseline, 'mode', None),
            tabletop_lift_diagnostics=self.tabletop_lift_diagnostics,
            tabletop_geometry_status='relative-height filter merely geometric heuristic; tabletop plane and table-edge navigation not verified',
            visual_dual_grasp_candidate=self.visual_dual_grasp_candidate,
            human_hand_estimate=self.hands, hand_observation_time_s=self.hand_observation_time,
            checkpoint_is_frozen=True, new_network_training=False, complete_dressing_claimed=False)

    def _finish(self, action):
        action = np.asarray(action, dtype=np.float32)
        if self.failure:
            action = np.zeros((2, 9), np.float32)
        if action.shape != (2, 9) or not np.isfinite(action).all() or np.max(np.abs(action)) > 1:
            self.fail('invalid tabletop action')
            action = np.zeros((2, 9), np.float32)
        self.previous_action = action.copy()
        self._decorate()
        return action

    def _handoff(self, obs):
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        try:
            self._cache_hands(obs)
            action = self.baseline(obs)
            self.debug = dict(parent_debug=self.baseline.debug)
            if self.baseline.failure:
                raise ValueError('baseline: ' + self.baseline.failure)
            pickup = self.baseline.parent.pickup
            if pickup.phase == 'neural_lift':
                robot = int(pickup.robot)
                exact_boundary = (pickup.debug.get('executed_phase') == 'close_wait'
                                  and pickup.debug.get('lift_specialist_action') is None
                                  and np.all(np.abs(action[robot, :8]) < 1e-8))
                if not exact_boundary:
                    raise ValueError('missed pre-lift handoff; single-robot lift not allowed')
                if not bool(np.asarray(obs['gripper_close_command']).reshape(2)[robot]):
                    raise ValueError('primary not closed at tabletop handoff')
                self.active, self.helper = robot, 1 - robot
                if self.baseline.active != self.active or self.baseline.idle != self.helper:
                    raise ValueError('tabletop observer roles do not match pickup roles')
                self.active_hold = cooperative.grasp_world(obs, robot).copy()
                self.tabletop_handoff_done = True
                now = float(np.asarray(obs['simulation_time_s']).item())
                recent_hands = (self.hands.get('detected') and self.hand_observation_time is not None
                                and 0 <= now - self.hand_observation_time <= 90.)
                self.tabletop_survey_started = now
                self.tabletop_survey_reference = np.asarray(obs['base_pose_world']).copy()
                self.change('helper_locate' if recent_hands else 'helper_survey')
                # Drop the idle robot's old view-search yaw immediately too.
                action = np.zeros((2, 9), np.float32)
                action[robot, 8] = 1
                action[self.helper, 8] = -1
                action = self.execution.apply(obs, action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail(str(error))
        return self._finish(action)

    def _survey(self, obs):
        """Resume only V22's idle observer, keeping the primary immobile."""
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        try:
            if self.baseline.active != self.active or self.baseline.idle != self.helper:
                raise ValueError('tabletop survey observer roles changed')
            now = float(np.asarray(obs['simulation_time_s']).item())
            elapsed = now - self.tabletop_survey_started
            if not np.isfinite(elapsed) or elapsed < 0 or elapsed > 30 or self.phase_steps > 600:
                raise ValueError('tabletop hand survey timed out or public clock invalid')
            poses = np.asarray(obs['base_pose_world'])
            _, tilt = cooperative.yaw_tilt(poses)
            if np.max(tilt) > .025:
                raise ValueError('tabletop survey base tilt')
            if np.max(np.linalg.norm(poses[:, :2] - self.tabletop_survey_reference[:, :2], axis=1)) > .05:
                raise ValueError('tabletop survey base drift exceeds 5cm')
            if np.linalg.norm(poses[0, :2] - poses[1, :2]) < .48:
                raise ValueError('tabletop survey robot bases too close')
            closed = np.asarray(obs['gripper_close_command']).reshape(2)
            if not closed[self.active] or np.asarray(obs['fingertip_origin_distance']).reshape(2)[self.active] > .08:
                raise ValueError('tabletop survey primary gripper not closed')
            if np.linalg.norm(cooperative.grasp_world(obs, self.active) - self.active_hold) > .04:
                raise ValueError('tabletop survey primary grasp drift')
            # Do not call baseline.__call__, its parent, or the pickup policy:
            # those would issue the first single-robot neural lift now.
            proposal = np.asarray(self.baseline._observe_idle(obs), dtype=float)
            if proposal.shape != (3,) or not np.isfinite(proposal).all() or np.max(np.abs(proposal)) > 1:
                raise ValueError('invalid tabletop idle observer proposal')
            action[self.helper, :3] = proposal
            action[self.active, 8] = 1
            action[self.helper, 8] = -1
            # Observe independently from the original observer's internal label.
            if self.phase_steps % 4 == 0:
                accepted = self._cache_hands(obs, force=True)
                self.tabletop_survey_hand_streak = self.tabletop_survey_hand_streak + 1 if accepted else 0
            if self.tabletop_survey_hand_streak >= 3 and self.baseline.mode == 'view_hold':
                self.change('helper_locate')
                action[:, :8] = 0
            action = self.execution.apply(obs, action)
            # The observer is limited to helper base motion; assert the route.
            action[self.active, :8] = 0
            action[self.helper, 3:8] = 0
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail('tabletop observer: ' + str(error))
        return self._finish(action)

    def _begin_pair_lift(self, obs):
        if self.tabletop_lift_done or self.tabletop_lift_started is not None:
            raise ValueError('tabletop paired lift cannot restart')
        if not np.asarray(obs['gripper_close_command']).reshape(2).all():
            raise ValueError('both grippers must be closed before paired lift')
        self.grasp_references = np.stack([cooperative.grasp_world(obs, r) for r in (0, 1)])
        self.tabletop_initial_bases = np.asarray(obs['base_pose_world'])[:, :3].copy()
        points = np.asarray(cooperative.cloth_cloud(obs)['world_points'])
        patches = []
        for point in self.grasp_references:
            patch = points[np.linalg.norm(points - point, axis=1) < .08]
            if len(patch) < 12:
                raise ValueError('insufficient public cloth evidence at one paired grasp')
            patches.append(np.median(patch, axis=0))
        self.tabletop_initial_patches = np.asarray(patches)
        self.tabletop_lift_started = float(np.asarray(obs['simulation_time_s']).item())
        self.change('tabletop_dual_lift')

    def _paired_lift(self, obs):
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        try:
            self._cache_hands(obs)
            poses = np.asarray(obs['base_pose_world'])
            _, tilt = cooperative.yaw_tilt(poses)
            closed = np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
            if not closed.all():
                raise ValueError('paired lift gripper opened')
            if np.max(np.asarray(obs['fingertip_origin_distance'])) > .08:
                raise ValueError('paired lift gripper gap exceeds closed-state bound')
            if np.max(tilt) > .065:
                raise ValueError('paired lift base tilt')
            if np.linalg.norm(poses[0, :2] - poses[1, :2]) < .48:
                raise ValueError('paired lift robot bases too close')
            if np.max(np.linalg.norm(poses[:, :2] - self.tabletop_initial_bases[:, :2], axis=1)) > .05:
                raise ValueError('paired lift base drift')
            now = float(np.asarray(obs['simulation_time_s']).item())
            elapsed = now - self.tabletop_lift_started
            if not np.isfinite(elapsed) or elapsed < 0:
                raise ValueError('invalid paired lift public clock')
            if elapsed > 35 or self.phase_steps > 900:
                raise ValueError('paired lift timed out')
            current = np.stack([cooperative.grasp_world(obs, r) for r in (0, 1)])
            displacement = current - self.grasp_references
            rise = displacement[:, 2]
            if np.max(np.linalg.norm(displacement[:, :2], axis=1)) > .06:
                raise ValueError('paired lift horizontal grasp drift')
            if abs(float(rise[0] - rise[1])) > .06:
                raise ValueError('paired lift height mismatch')
            if np.min(rise) < -.03 or np.max(rise) > .40:
                raise ValueError('paired lift vertical excursion')
            # A shared ramp advances only a little ahead of the slower robot.
            requested_rise = max(0., min(.35, elapsed * .025, float(rise.min()) + .03))
            targets = self.grasp_references.copy()
            targets[:, 2] += requested_rise
            for robot in (0, 1):
                target = cooperative.world_to_base(obs, robot, targets[robot])
                error = target - np.asarray(obs['grasp_pose_base'])[robot, :3]
                if abs(float(error[1])) > .04:
                    raise ValueError('paired lift unactuated lateral error')
                rates = cooperative.bounded(1.8 * np.array([error[0], error[2]]), .03)
                action[robot, 4], action[robot, 3] = rates / np.array([1.21, 1.54])
                action[robot, 8] = 1
            action[:, :8] = self.previous_action[:, :8] + np.clip(
                action[:, :8] - self.previous_action[:, :8], -.012, .012)
            # Explicitly clamp physical x/z speed after smoothing as well.
            for robot in (0, 1):
                rates = cooperative.bounded(action[robot, [4, 3]] * np.array([1.21, 1.54]), .03)
                action[robot, 4], action[robot, 3] = rates / np.array([1.21, 1.54])
            action[:, [0, 1, 2, 5, 6, 7]] = 0
            action = self.execution.apply(obs, action)
            if np.any(self.execution.pending):
                # One unresolved gripper must not let only the other side rise.
                action[:, :8] = 0
            at_goal = bool(np.max(np.abs(rise - .35)) < .015)
            cloth_followed = False
            if at_goal:
                points = np.asarray(cooperative.cloth_cloud(obs)['world_points'])
                checks = []
                for robot in (0, 1):
                    expected = self.tabletop_initial_patches[robot] + [0., 0., .35]
                    patch = points[np.linalg.norm(points - expected, axis=1) < .07]
                    moved = len(patch) >= 12 and np.linalg.norm(np.median(patch, axis=0) - expected) < .05
                    near = len(points) > 0 and np.min(np.linalg.norm(points-current[robot], axis=1)) < .055
                    checks.append(bool(moved and near))
                cloth_followed = all(checks)
            self.stable = self.stable + 1 if at_goal and cloth_followed and not np.any(self.execution.pending) else 0
            self.tabletop_lift_diagnostics = dict(rise_m=rise.tolist(), common_requested_rise_m=requested_rise,
                goal_rise_m=.35, elapsed_s=elapsed, physical_xz_speed_limit_m_s=.03,
                public_cloth_followed_both_grasps=cloth_followed, stable_steps=self.stable,
                evidence='public pose and visible cloth co-motion; no attachment or score input')
            if self.stable >= 20:
                self.tabletop_lift_done = True
                self.visual_dual_grasp_candidate = True
                self.dual_targets = current.copy()
                self.active_hold = current[self.active].copy()
                self.change('dual_hold')
                action[:, :8] = 0
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail(str(error))
        return self._finish(action)

    def __call__(self, obs):
        if self.phase == 'v22_pickup' and not self.tabletop_handoff_done:
            return self._handoff(obs)
        if self.phase == 'helper_survey':
            return self._survey(obs)
        if self.phase == 'tabletop_dual_lift':
            return self._paired_lift(obs)
        before = self.phase
        action = super().__call__(obs)
        if before == 'helper_close' and self.phase == 'helper_test_lift' and not self.failure:
            try:
                self._begin_pair_lift(obs)
                # No helper-only test-lift action can be emitted between phases.
                action[:, :8] = 0
                action[:, 8] = 1
            except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
                self.fail(str(error))
        elif self.phase == 'helper_test_lift' and not self.failure:
            self.fail('unexpected helper-only lift in tabletop policy')
        return self._finish(action)
