"""Bounded, explicitly hypothetical cloth/hand contact in the simulator.

This branch does not require or manufacture a verified sleeve opening. It
tests a measured held-edge plus gravity/width hypothesis. All actor geometry
comes from public RGB-D and own robot state; evaluation truth stays offline.
"""
from copy import deepcopy

import numpy as np

from cloth_patch_tracker import ClothPatchTracker
from contact_motion_governor import ContactMotionGovernor
from cooperative_transport import _snapshot
from grasp_pair_alignment import GraspPairAlignment
from gripper_skin_clearance import observed_gripper_skin_clearance
from held_edge_hypotheses import estimate_held_edge_hypotheses
from human_targets import _validated, _world_pixels
from hypothesis_contact_plan import plan_hypothesis_contact
from observed_hand_reacquisition import _skin
from opening_approach_coordinator import OpeningApproachCoordinator
from public_vision import _rotation, _fabric_mask, cloth_cloud
from routed_pair_transport import RoutedPairTransport


class ContactPulseAlignment(GraspPairAlignment):
    GOAL_TOLERANCE_M = .00075


class HypothesisContactExperiment:
    MAX_DURATION_S = 180.
    MAX_TRAVEL_M = .65
    MAX_SKIN_AGE_S = 20.
    MAX_STATIONARY_ANCHOR_AGE_S = 180.
    MIN_OBSERVED_SKIN_CLEARANCE_M = .020
    PULSE_M = .005
    INITIAL_DISTAL_GAP_M = .020
    MAX_CONTACT_TRAVEL_M = .020

    def __init__(self, obs, initial_edge_report, robot_assignment,
                 original_hand_report, original_observed_at):
        _, grasps, _, _, now = _snapshot(obs)
        self.time0 = self.last_time = now
        self.initial_edges = deepcopy(initial_edge_report)
        self.robot_assignment = list(robot_assignment)
        self.hand_observer = OpeningApproachCoordinator(
            original_hand_report=original_hand_report,
            original_observed_at=original_observed_at, stationary_human=True)
        self.governor = self._create_governor(obs)
        self.phase = 'initial_observe'
        self.plan = self.edges = self.motion_debug = self.governor_debug = {}
        self.last_grasps = grasps.copy()
        self.travel = np.zeros(2)
        self.motion = None
        self.pending_stage = None
        self.motion_completed = False
        self.failure = self.pending_failure = None
        self.done = False
        self.trackers = None
        self.tracks = []
        self.track_baseline = self.grasp_baseline = None
        self.skin = None
        self.skin_stamp = None
        self.skin_anchor = None
        self.skin_anchor_stamp = None
        self.last_skin_attempt = -np.inf
        self.skin_debug = {}
        self.clearance = []
        self.initial_goal = self.final_goal = self.axes = self.hands = None
        self.contact_start = None
        self.contact_travel = 0.
        self.pulse_travel = 0.
        self.hand_assignment = None
        self.pulse_results = []
        self.coverage_baseline = None
        self.wait_reason = None

    def _create_governor(self, obs):
        return ContactMotionGovernor(obs)

    @staticmethod
    def hold():
        result = np.zeros((2, 9), np.float32)
        result[:, 8] = 1.
        return result

    def _result(self, action=None):
        return dict(action=self.hold() if action is None else action,
            done=self.done, failure=self.failure,
            debug=dict(phase=self.phase, plan=self.plan, current_edge_hypotheses=self.edges,
                motion=self.motion_debug, governor=self.governor_debug,
                fixed_feature_tracks=self.tracks, measured_endpoint_path_m=self.travel.tolist(),
                skin=self.skin_debug, own_geometry_clearance=self.clearance,
                contact_travel_m=self.contact_travel, pulse_results=self.pulse_results,
                commanded_advance_from_distal_goal_m=self.pulse_travel,
                nominal_advance_beyond_distal_surface_m=self.contact_travel,
                physical_contact_or_entry_verified=False,
                initial_hypothesis_goal_world=None if self.initial_goal is None else self.initial_goal.tolist(),
                pending_failure=self.pending_failure, wait_reason=self.wait_reason,
                physical_openings_verified=False, sleeve_identity_verified=False,
                complete_dressing_claimed=False, automatic_reseed=False,
                scope='simulation contact experiment based on an unverified cuff hypothesis; observed surface clearance only'))

    def _observe_plan(self, obs, now):
        self.hand_observer._observe_hands(obs, now)
        self.edges = estimate_held_edge_hypotheses(obs, self.initial_edges, self.robot_assignment)
        self.plan = plan_hypothesis_contact(obs, self.edges,
            self.hand_observer.fresh_hands, self.hand_observer.fresh_forearms)
        if not self.plan.get('available'):
            raise ValueError('current contact hypothesis unavailable: '+str(self.plan.get('reason')))
        feasibility = self.plan.get('feasibility', {})
        for field in ('lift_reachable_at_current_wrist', 'alignment_then_common_translation_arm_feasible',
                      'span_does_not_exceed_initial_plus_2cm', 'modeled_visible_footprint_fits_nominal_radius'):
            if feasibility.get(field) is not True:
                raise ValueError('current contact hypothesis feasibility: '+field)
        # This branch decomposes span adjustment and common transport. A
        # fixed-base arm test and a direct30cm limit are therefore diagnostics,
        # not rejection of the different actual path used by this executor.
        if any(r.get('observed_housing_conflict') for r in feasibility.get('observed_housing_screen', [])):
            raise ValueError('current proposed goal has an observed housing conflict')
        goals = np.asarray(self.plan['target_grasps_world'], float)
        axes = np.asarray(self.plan['robot_ordered_axis_world'], float)
        hands = np.asarray(self.plan['robot_ordered_hand_points_world'], float)
        if any(a.shape != (2, 3) or not np.isfinite(a).all() for a in (goals, axes, hands)):
            raise ValueError('invalid current contact geometry')
        if np.any(np.abs(np.linalg.norm(axes, axis=1)-1.) > 1e-5):
            raise ValueError('contact directions must be observed signed unit axes')
        assignment = self.plan.get('robot_to_hand_assignment')
        if assignment not in ([0, 1], [1, 0]):
            raise ValueError('explicit robot-hand assignment required')
        if self.hand_assignment is not None and assignment != self.hand_assignment:
            raise ValueError('hand assignment changed during contact experiment')
        self.hand_assignment = list(assignment)
        return goals, axes, hands

    def _refresh_skin(self, obs, now):
        if now-self.last_skin_attempt < 1.:
            return
        self.last_skin_attempt = now
        values = _validated(obs, wrists=True)
        all_points = []
        for camera in (1, 2, 3, 4):
            depth = values['depth'][camera, ..., 0]
            valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth) &
                (depth > .03) & (depth < (3. if camera < 3 else 5.)) &
                _skin(values['rgb'][camera]) & ~_fabric_mask(values['rgb'][camera]))
            v, u = np.where(valid)
            points = _world_pixels(values, camera, u, v, depth[v, u])
            points = points[np.min(np.linalg.norm(points[:, None]-self.hands, axis=2), axis=1) < .35]
            all_points.extend(points)
        points = np.asarray(all_points, float).reshape(-1, 3)
        counts = [int(np.count_nonzero(np.linalg.norm(points-h, axis=1) < .07)) for h in self.hands]
        if min(counts) >= 12:
            # Keep all observed points; do not sparsify away a nearby surface.
            self.skin, self.skin_stamp = points, now
            if self.skin_anchor is None:
                self.skin_anchor, self.skin_anchor_stamp = points.copy(), now
        self.skin_debug = dict(last_attempt_time_s=now, current_hand_support_pixels=counts,
            retained_observation_time_s=self.skin_stamp, retained_point_count=0 if self.skin is None else len(self.skin),
            fixed_stationary_anchor_observation_time_s=self.skin_anchor_stamp,
            fixed_anchor_point_count=0 if self.skin_anchor is None else len(self.skin_anchor),
            occluded_anchor_points_removed=False,
            stationary_episode_assumption=True, full_body_observed=False,
            source='current skin-colour RGB-D within35cm of observed hand points, four robot cameras')

    def _check_clearance(self, obs, action, now):
        if self.skin is None or now-self.skin_stamp > self.MAX_SKIN_AGE_S:
            raise ValueError('observed skin surface unavailable or older than20s')
        if self.skin_anchor is None or now-self.skin_anchor_stamp > self.MAX_STATIONARY_ANCHOR_AGE_S:
            raise ValueError('stationary observed skin anchor missing or older than180s')
        points = np.concatenate((self.skin_anchor, self.skin))
        self.clearance = []
        state = ContactMotionGovernor._read(obs)
        for robot in (0, 1):
            rotation = _rotation(np.asarray(obs['base_pose_world'])[robot, 3:])
            # Include pending linear target lag and one commanded control step.
            q = np.asarray(obs['joint_position'])[robot]
            target = np.asarray(obs['controller_target'])[robot]
            pending = rotation[:, 2]*(target[0]-q[3])+rotation[:, 0]*(target[1]-q[4:8].sum())
            planar = state['planar'][robot]
            base_velocity = np.r_[planar @ (action[robot, :2]*.616), 0.]
            move = .05*(rotation[:, 0]*action[robot, 4]*1.21+
                rotation[:, 2]*action[robot, 3]*1.54+base_velocity)
            reserve = .05*state['endpoint_speed'][robot]
            # Preserve the old pending segment separately: a cancellation
            # command cannot algebraically erase its possible excursion.
            for label, delta in (('existing_pending_target', pending), ('proposed_interval', pending+move)):
                report = observed_gripper_skin_clearance(obs, robot, points,
                    skin_observed_at=min(self.skin_anchor_stamp, self.skin_stamp), stationary_skin=True,
                    max_skin_age_s=self.MAX_STATIONARY_ANCHOR_AGE_S,
                    proposed_translation_world=delta, model_margin_m=.003+reserve)
                self.clearance.append(dict(
                    {k:v for k,v in report.items() if k not in ('model_bounds','model_provenance')},
                    checked_segment=label, one_measured_rate_interval_reserve_m=float(reserve),
                    reserve_is_inertia_bound=False))
                if not report.get('valid') or report['observed_minimum_clearance_m'] < self.MIN_OBSERVED_SKIN_CLEARANCE_M:
                    raise ValueError('modeled gripper/wrist is within20mm of observed skin or geometry unavailable')

    def _track(self, obs, grasps):
        if self.trackers is None:
            self.trackers = [ClothPatchTracker() for _ in (0, 1)]
            self.tracks = [t.reset(obs, grasps[r], radius=.07) for r, t in enumerate(self.trackers)]
            self.grasp_baseline = grasps.copy()
        else:
            self.tracks = [t.update(obs) for t in self.trackers]
        if not all(t.get('reliable') for t in self.tracks):
            raise ValueError('original held-cloth feature evidence unavailable; no reseed')
        moved = np.asarray([t['median_displacement_world'] for t in self.tracks])
        if np.max(np.linalg.norm(moved-(grasps-self.grasp_baseline), axis=1)) > .03:
            raise ValueError('original cloth features differ from grasp motion by over3cm')
        return moved

    def _coverage(self, obs):
        points = np.asarray(cloth_cloud(obs)['world_points'], float)
        counts = []
        for hand, axis in zip(self.hands, self.axes):
            delta = points-hand
            axial = delta @ axis
            radial = np.linalg.norm(delta-axial[:, None]*axis, axis=1)
            chosen = points[(radial < .065) & (axial >= -.01) & (axial <= .10)]
            counts.append(len(np.unique(np.floor(chosen/.005).astype(int), axis=0)))
        return counts

    def _start_motion(self, obs, stage, grasps):
        self.phase, self.pending_stage = stage, None
        if stage == 'span':
            goals = self.initial_goal-self.initial_goal.mean(axis=0)+grasps.mean(axis=0)
            self.motion = GraspPairAlignment(obs, goals, max_speed=.006)
        elif stage == 'translate':
            shift = self.initial_goal.mean(axis=0)-grasps.mean(axis=0)
            # Validate the common height with measured own lift joints before
            # delegating the public-depth base route to the existing controller.
            q = np.asarray(obs['joint_position'])[:, 3]
            rzz = np.array([_rotation(b[3:])[2, 2] for b in obs['base_pose_world']])
            if np.any(q+shift[2]/rzz < .015) or np.any(q+shift[2]/rzz > 1.185):
                raise ValueError('contact staging height exceeds current wrist/lift workspace')
            self.motion = RoutedPairTransport(obs, shift, max_speed=.008)
        elif stage == 'fine':
            goals, axes, hands = self._observe_plan(obs, float(obs['simulation_time_s']))
            if (np.max(np.linalg.norm(goals-self.initial_goal, axis=1)) > .02 or
                    np.max(np.linalg.norm(hands-self.hands, axis=1)) > .02 or
                    np.min(np.sum(axes*self.axes, axis=1)) < .95):
                raise ValueError('current contact hypothesis changed after staging')
            self.final_goal = goals
            self.axes, self.hands = axes, hands
            self.motion = ContactPulseAlignment(obs, goals, max_speed=.003)
        elif stage == 'contact_pulse':
            self.contact_start = grasps.copy()
            self.track_baseline = np.asarray([t['median_displacement_world'] for t in self.tracks])
            self.coverage_baseline = self._coverage(obs)
            self.motion = ContactPulseAlignment(obs, grasps+self.PULSE_M*self.axes, max_speed=.002)
        else:
            raise ValueError('unknown contact motion stage')
        if self.motion.failure:
            raise ValueError(stage+': '+self.motion.failure)
        self.motion_completed = False

    def _completed_motion(self, obs, grasps, moved):
        if self.phase == 'span':
            self.pending_stage = 'translate'
        elif self.phase == 'translate':
            self.pending_stage = 'fine'
        elif self.phase == 'fine':
            self.pending_stage = 'contact_pulse'
        else:
            actual = grasps-self.contact_start
            cloth = moved-self.track_baseline
            axial = np.sum(cloth*self.axes, axis=1)
            error = np.linalg.norm(cloth-actual, axis=1)
            coverage = self._coverage(obs)
            response = dict(measured_grasp_shift_world=actual.tolist(),
                fixed_cloth_shift_world=cloth.tolist(), cloth_proximal_progress_m=axial.tolist(),
                cloth_vs_grasp_error_m=error.tolist(), current_proximal_cloth_voxels=coverage,
                previous_proximal_cloth_voxels=self.coverage_baseline,
                sleeve_entry_verified=False)
            self.pulse_results.append(response)
            if (np.max(np.linalg.norm(actual-self.PULSE_M*self.axes, axis=1)) > .001 or
                    np.min(axial) < .0015 or np.max(error) > .007):
                raise ValueError('contact pulse did not produce consistent two-sided original-cloth response')
            self.pulse_travel += self.PULSE_M
            self.contact_travel = max(0., self.pulse_travel-self.INITIAL_DISTAL_GAP_M)
            if self.contact_travel >= self.MAX_CONTACT_TRAVEL_M-1e-8:
                self.done, self.phase = True, 'bounded_contact_trial_finished'
            elif self.contact_travel >= .01-1e-8 and not all(
                    c >= max(8, b+2) for c, b in zip(coverage, self.coverage_baseline)):
                self.done, self.phase = True, 'initial_contact_trial_finished_without_support_for_extension'
            else:
                self.pending_stage = 'contact_pulse'
        self.motion = None

    @staticmethod
    def _reference_snapshot(motion):
        # Preserve each primitive's fixed origin/goal and original time budget.
        # Only the reference advanced by this one output is reduced if the
        # downstream native-target governor scales the actual velocity.
        refs = []
        if motion is not None:
            for key in ('reference_fraction', 'reference'):
                if hasattr(motion, key):
                    refs.append((motion, key, getattr(motion, key)))
            refs += HypothesisContactExperiment._reference_snapshot(getattr(motion, 'segment', None))
        return refs

    @staticmethod
    def _scale_reference_advance(refs, scale):
        for obj, key, previous in refs:
            current = getattr(obj, key)
            setattr(obj, key, previous+max(0., current-previous)*float(np.clip(scale, 0., 1.)))

    def step(self, obs):
        if self.failure or self.done:
            return self._result()
        action = self.hold()
        gate = None
        try:
            _, grasps, _, _, now = _snapshot(obs)
            if now < self.last_time or now-self.time0 > self.MAX_DURATION_S:
                raise ValueError('contact experiment clock or180s total budget')
            if now == self.last_time and self.phase != 'initial_observe':
                return self._result()
            self.last_time = now
            self.travel += np.linalg.norm(grasps-self.last_grasps, axis=1)
            self.last_grasps = grasps.copy()
            if self.travel.max() > self.MAX_TRAVEL_M:
                raise ValueError('contact experiment total endpoint path exceeds65cm')
            if self.phase == 'initial_observe':
                self.initial_goal, self.axes, self.hands = self._observe_plan(obs, now)
                self.pending_stage = 'span'
                self.phase = 'initial_settle'
            self._refresh_skin(obs, now)
            moved = self._track(obs, grasps)
            if not self.pending_failure:
                refs = self._reference_snapshot(self.motion)
                if self.motion is not None:
                    result = self.motion.step(obs)
                    self.motion_debug = result['debug']
                    if result['failure']:
                        raise ValueError(result['failure'])
                    action = result['action']
                    if result['done']:
                        self.motion_completed = True
                        action = self.hold()
                gate = self.governor.step(obs, action,
                    halt=self.motion is None or self.motion_completed,
                    max_speed_mps=.003 if self.phase in ('fine','contact_pulse') else .01)
                self.governor_debug = gate['debug']
                self._scale_reference_advance(refs, gate['debug'].get('common_command_scale', 0.))
                action = gate['action']
                self._check_clearance(obs, action, now)
                if gate['failure'] or gate.get('pending_failure'):
                    self.pending_failure = 'contact motion governor: '+str(gate['failure'] or gate['pending_failure'])
                    if gate['failure']:
                        self.failure = self.pending_failure
                    return self._result(action)
                if self.motion_completed and gate['settled']:
                    self._completed_motion(obs, grasps, moved)
                    self.motion_completed = False
                elif self.motion is None and self.pending_stage and gate['settled']:
                    self._start_motion(obs, self.pending_stage, grasps)
                    action = self.hold()
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            if self.pending_failure is None:
                self.pending_failure = str(error)
        if self.pending_failure:
            if gate is not None and not gate.get('cancellation_only'):
                # Geometry rejected a proposed exploratory output. Do not
                # apply it, and do not call a stateful governor twice on the
                # same timestamp. Request cancellation on the next frame.
                if gate['failure'] or gate['settled']:
                    self.failure, self.phase = self.pending_failure, 'stopped'
                return self._result(self.hold())
            if gate is None:
                gate = self.governor.step(obs, self.hold(), halt=True, max_speed_mps=.003)
            self.governor_debug = gate['debug']
            action = gate['action']
            if np.any(np.abs(action[:, :8]) > 1e-12):
                try:
                    self._check_clearance(obs, action, float(obs['simulation_time_s']))
                except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
                    self.failure = self.pending_failure+'; cancellation clearance unavailable: '+str(error)
                    self.phase = 'stopped'
                    return self._result(self.hold())
            if gate['failure'] or gate['settled']:
                self.failure = self.pending_failure
                self.phase = 'stopped'
                action = self.hold()
        return self._result(action)
