"""Synthetic capture counterexamples; no simulation and no image approval."""
import copy
from pathlib import Path
import shutil
import tempfile
import numpy as np
from artifacts import read,write,sha,parent_hashes
from test_fixtures import synthetic_obs
from offline_report import assess
from review_contract import combined_success

ROOT=Path(__file__).resolve().parent


def main(variant):
    output=ROOT/f'preflight_capture_{variant}.json'
    if output.exists():raise RuntimeError('Keep completed preflight')
    checks=[]
    with tempfile.TemporaryDirectory(prefix='phyrc-v22-capture-fixture-') as temp:
        run=Path(temp);folder=run/'synthetic_fixture';folder.mkdir();(folder/'public_observations').mkdir()
        names=['policy.py','collect_probe.py','detector.py','geometry.py','static_calibration.json','test_protocol.json','weights/best.pt']
        names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'frozen_pickup').iterdir()) if p.suffix in ('.py','.json')]
        for name in names:
            (run/name).parent.mkdir(exist_ok=True,parents=True);shutil.copy2(ROOT/name,run/name)
        manifest={n:sha(run/n) for n in names};write(run/'source_sha256.json',manifest)
        plan=read(run/'test_protocol.json');model_info=plan['variants'][variant]
        launch=dict(variant=variant,recording_seed=-1,declared_data_source=model_info['data_source'],checkpoint=str(run/'weights/best.pt'),
            checkpoint_sha256=sha(run/'weights/best.pt'),parent_source_sha256=parent_hashes(run),
            frozen_source_sha256=manifest,source_manifest_sha256=sha(run/'source_sha256.json'),
            policy_source_sha256=sha(run/model_info['policy_file']),detector_source_sha256=sha(run/'detector.py'),
            collector_sha256=sha(run/'collect_probe.py'),protocol_sha256=sha(run/'test_protocol.json'),
            runtime_rates=dict(base_linear_rate=.616,base_angular_rate=2.86,lift_rate=1.54))
        write(folder/'launch.json',launch)
        trace=[]
        # Contract-only fixtures: static own poses and manually constructed parent
        # stage/action records, not a physical or full-neural replay.
        for step in range(1,1201):
            obs=synthetic_obs()
            x=.72 if step<640 else max(.52,.72-(step-640)/159*.2)
            obs['grasp_pose_base'][0,0]=x
            parent_phase='neural_approach' if step<100 else 'refine_raise' if step<600 else 'hold'
            stage='pickup:'+parent_phase if step<620 else 'carry_settle' if step<640 else 'carry_retract' if step<800 else 'carry_hold'
            model=dict(robot=0,phase=stage,failure=None,pickup_debug=dict(robot=0,phase=parent_phase,failure=None) if step<620 else None)
            a=np.zeros((2,9));proposal=a.copy()
            debug=dict(phase='pickup' if step<100 else 'concurrent',failure=None,active_robot=None if step<100 else 0,
                idle_robot=None if step<100 else 1,activation_step=None if step<100 else 100,
                parent_proposed_action=proposal.tolist(),idle_mode='view_hold',initial_search_direction=1)
            if variant=='v6':debug=model
            trace.append(dict(step=step,simulation_time_s=(step-1)*.05,action=a.tolist(),base_pose_world=obs['base_pose_world'].tolist(),
                grasp_position_base=obs['grasp_pose_base'][:,:3].tolist(),gripper_close_command=obs['gripper_close_command'].tolist(),
                fingertip_origin_distance=obs['fingertip_origin_distance'].tolist(),model_debug=model,policy_debug=debug))
        originals={}
        for step in range(10,1201,10):
            obs=synthetic_obs()
            obs['grasp_pose_base'][0,0]=trace[step]['grasp_position_base'][0][0] if step<1200 else .52
            obs.update(previous_action=np.zeros((2,9),np.float32),simulation_time_s=np.asarray(step*.05))
            originals[step]=obs;np.savez_compressed(folder/'public_observations'/f'{step:05d}.npz',**obs)
        result=dict(variant=variant,seed=-1,steps=1200,interrupted=False,wall_seconds=0,policy_debug=trace[-1]['policy_debug'],
            evaluation=dict(valid=True,result=dict(raw_points=5,success=False,score_items=dict(pickup=dict(achieved=True,points=5,achieved_at_episode_s=29.)))) )
        write(folder/'trace.json',trace);write(folder/'result.json',result)
        row,_=assess(folder,emit=True)
        assert row['numeric_concurrent_goal_passed'] and row['actual_visual_review'] is None
        assert not combined_success(row,None) and not (folder/'concurrent_review.json').exists()
        checks.append('complete synthetic capture passes numeric QA but never earns overall or visual success without actual review')
        def rejects_trace(bad,label):
            write(folder/'trace.json',bad)
            try:r,_=assess(folder)
            except (AssertionError,ValueError,KeyError):pass
            else:assert not r['numeric_concurrent_goal_passed'],label
            write(folder/'trace.json',trace)
            checks.append(label)
        for label,alter in [
            ('idle arm movement rejected',lambda t:t[350]['action'][1].__setitem__(3,.1)),
            (('active action differs from parent rejected' if variant=='v22' else 'nonfinite baseline action rejected'),lambda t:t[350]['action'][0].__setitem__(3,.1 if variant=='v22' else float('nan'))),
            ('idle translation speed rejected',lambda t:t[350]['action'][1].__setitem__(0,.03/.616)),
            ('idle yaw slew rejected',lambda t:t[350]['action'][1].__setitem__(2,.1/2.86)),
            ('early activation/movement rejected',lambda t:t[104]['action'][1].__setitem__(2,.001)),
            ('early idle drift rejected',lambda t:t[350]['base_pose_world'][1].__setitem__(0,1.06)),
            ('postcarry active height drift rejected',lambda t:t[900]['grasp_position_base'][0].__setitem__(2,1.05)),
            ('missing carry event rejected',lambda t:[r['model_debug'].__setitem__('phase','carry_retract') for r in t[799:]])]:
            bad=copy.deepcopy(trace);alter(bad);rejects_trace(bad,label)
        bad=copy.deepcopy(result);bad['evaluation']['result']['score_items']['pickup']['points']=0
        write(folder/'result.json',bad);assert not assess(folder)[0]['numeric_concurrent_goal_passed'];write(folder/'result.json',result)
        checks.append('missing original pickup5 rejected')
        for kind in ['final_idle_drift','low_retraction']:
            z=copy.deepcopy(originals[1200])
            if kind=='final_idle_drift':z['base_pose_world'][1,0]+=.06
            else:z['grasp_pose_base'][0,0]=.68
            np.savez_compressed(folder/'public_observations/01200.npz',**z)
            assert not assess(folder)[0]['numeric_concurrent_goal_passed'],kind
            np.savez_compressed(folder/'public_observations/01200.npz',**originals[1200]);checks.append(kind+' rejected independently of debug')
        for step in range(10,811,10):
            z=copy.deepcopy(originals[step]);z['rgb'][:]=0
            np.savez_compressed(folder/'public_observations'/f'{step:05d}.npz',**z)
        late,_=assess(folder)
        assert late['independent_final_centered_samples']==21 and not late['numeric_concurrent_goal_passed'] and late['independent_acquisition_time_s']>late['carry_hold_time_s']
        checks.append('acquisition after carry fails even with perfect final detections and successful debug')
        for step,z in originals.items():np.savez_compressed(folder/'public_observations'/f'{step:05d}.npz',**z)
        for step in range(1000,1201,10):
            z=copy.deepcopy(originals[step]);z['rgb'][:]=0
            np.savez_compressed(folder/'public_observations'/f'{step:05d}.npz',**z)
        assert not assess(folder)[0]['numeric_concurrent_goal_passed'];checks.append('blank final actual images defeat view_hold debug')
        f=folder/'public_observations/00600.npz';f.rename(f.with_suffix('.missing'))
        try:assess(folder)
        except AssertionError:pass
        else:raise AssertionError('missing file accepted')
        checks.append('missing public observation rejected')
    report=dict(passed=True,synthetic_only=True,simulation_runs=0,training_performed=False,checks=checks,
        limitations='Fictional rectangle RGB-D, hand-written phase/proposal trace and public states. No live simulation, full neural replay, image approval or physical proof.',
        offline_report_sha256=sha(ROOT/'offline_report.py'),review_contract_sha256=sha(ROOT/'review_contract.py'))
    write(output,report);print(report)


if __name__=='__main__':
    import sys
    main(sys.argv[1])
