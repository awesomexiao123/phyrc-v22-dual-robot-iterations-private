"""Recompute original evidence and validate pre-existing actual image reviews."""
import fcntl
from datetime import datetime,timezone
from pathlib import Path
from release_checks import ROOT,read,sha,verify_release
from artifacts import write
from review_records import reviewed_row
from comparison import compare


def main():
    assert not (ROOT/'completion_record.json').exists(),'Already archived'
    plan=verify_release();state=read(ROOT/'pipeline_status.json')
    assert state['status']=='completed_pending_visual_review'
    for pid in [state.get('pipeline_pid'),state.get('evaluation_pid'),state.get('child_pid')]:
        assert not pid or not Path('/proc',str(pid)).exists(),'A recorded parent/child is present'
    expected=[(a['seed'],a['variant']) for a in plan['sequence']]
    assert [(a['seed'],a['variant']) for a in state['attempts']]==expected
    rows=[]
    for attempt in state['attempts']:
        folder=Path(attempt['output']);run=folder.parent
        assert sha(run/'source_sha256.json')==sha(ROOT/'source_sha256.json')
        process=read(run/'process.json')
        assert not Path('/proc',str(process['pid'])).exists(),'Simulation child remains present'
        row=reviewed_row(folder,recompute=True)
        assert row is not None,'Missing actual image review: '+str(folder)
        assert (row['seed'],row['variant'])==(attempt['seed'],attempt['variant'])
        rows.append(row)
    result=compare(rows,plan);now=datetime.now(timezone.utc).isoformat()
    result.update(status='completed_reviewed',completed_at_utc=now,protocol_sha256=sha(ROOT/'test_protocol.json'),
        source_manifest_sha256=sha(ROOT/'source_sha256.json'),rows=rows)
    write(ROOT/'final_comparison.json',result)
    write(ROOT/'paired_results.json',dict(result,completed_attempts=12,reviewed_attempts=12,total_attempts=12))
    lines=['取衣并行寻视 v6/v22 独立配对报告',f'完成UTC：{now}',
        '6组新场景两版各首次一次，共12条原60秒1200步，按场景交替先后；全部结果保留，无新训练。',
        '两版共同重新检测所有保存公开RGBD；实际逐条复核取得3幅闲置head和末段6组overview/active wrist/idle head，共252幅。',
        'v6直接执行原取衣/收臂策略；v22从refine_raise后只给闲置侧寻视。共享原父、实际权重、环境、评分和reset。']
    for variant,s in result['variants'].items():
        lines.append(f"{variant}：取衣/收臂/真实稳定持衣{s['pickup_preservation_successes']}/6；并行取得并稳定持视{s['concurrent_successes']}/6；内部失败{s['internal_failures']}；原分{s['original_raw_points']}；完整穿衣{s['dressing_successes']}/6。")
    lines.append(f"预定提升通过={result['predeclared_improvement_passed']}；逐项={result['predeclared_checks']}。")
    for row in rows:
        lines.append(f"{row['variant']}/{row['seed']}：取得{row['acquisition_time_s']}s；carry_hold={row['carry_time_s']}s；末段合格{row['final_qualified_samples']}/21；实际早期={row['early_visual_pass']}，持衣={row['held_visual_pass']}，末段手视角={row['final_hand_visual_pass']}；内部失败={row['controller_failure']}。")
    lines += [f"次指标：惩罚取得时间配对减少中位数{result['secondary_median_paired_penalized_time_reduction_s']:.3f}s。未取得或实际取得图像不通过记60s，不删失败；不作为追加成功条件。",
        f"累计仿真墙钟{result['total_simulation_wall_seconds']/3600:.3f}小时，两版CPUperformance；不与旧powersave墙钟作因果比较。",
        '六对仅描述性结果，不保证总体成功率，不证明持衣侧导航、后退避碰、套袖或完整穿衣；原比赛评分单列。',
        '技术检查、数值和实际图像分开，哈希绑定全部源/权重/协议/原数据/复核。1501–1506不进入训练、标签或后续调参。']
    (ROOT/'本轮对照报告.txt').write_text('\n'.join(lines)+'\n')
    write(ROOT/'pipeline_status.json',dict(state,status='completed_reviewed',reviewed_at_utc=now))
    write(ROOT/'completion_record.json',dict(status='completed_reviewed',completed_at_utc=now,
        protocol_sha256=sha(ROOT/'test_protocol.json'),source_manifest_sha256=sha(ROOT/'source_sha256.json'),
        report_sha256=sha(ROOT/'本轮对照报告.txt'),results_sha256=sha(ROOT/'final_comparison.json'),
        reviews={str(Path(r['output'])/'evaluation_review.json'):r['review_sha256'] for r in rows}))
    print('completed_reviewed',result['predeclared_improvement_passed'])


if __name__=='__main__':
    with (ROOT/'pipeline.lock').open('a') as parent,(ROOT.parent/'PhyRC2027本机模拟/runtime.lock').open('a') as runtime,(ROOT/'offline_report.lock').open('a') as report:
        for lock in [parent,runtime,report]:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        main()
