"""Independent saved public-image and own-state checks; never approves images."""
import argparse
import itertools
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from artifacts import read,write,sha,verify_sources,parent_hashes
from detector import detect_head
from geometry import project_hands,yaw_tilt


def initial_sign(poses, robot):
    # Independent recomputation, intentionally not imported from actor.
    delta=poses[1-robot,:2]-poses[robot,:2]
    yaw,_=yaw_tilt(poses)
    e=(np.arctan2(delta[1],delta[0])-yaw[robot]+np.pi)%(2*np.pi)-np.pi
    return 1 if abs(e)<=1e-6 or abs(abs(e)-np.pi)<=1e-6 or e>0 else -1


def assess(folder, emit=False):
    folder=Path(folder);run=folder.parent
    launch,result,trace=[read(folder/n) for n in ('launch.json','result.json','trace.json')]
    assert result['steps']==len(trace)==1200 and result['evaluation']['valid'] and not result['interrupted']
    assert [x['step'] for x in trace]==list(range(1,1201))
    variant=launch['variant'];plan=read(run/'test_protocol.json');model=plan['variants'][variant]
    assert launch['recording_seed']==result['seed'] and result['variant']==variant
    assert variant in ('v6','v22') and launch['declared_data_source']==model['data_source']
    assert launch['policy_source_sha256']==sha(run/model['policy_file'])==model['policy_sha256']
    assert launch['protocol_sha256']==sha(run/'test_protocol.json')
    assert launch['checkpoint'] and launch['checkpoint_sha256']==sha(run/'weights/best.pt')
    assert launch['parent_source_sha256']==parent_hashes(run)
    assert launch['frozen_source_sha256']==verify_sources(run)
    assert launch['source_manifest_sha256']==sha(run/'source_sha256.json')
    for key,name in [('detector_source_sha256','detector.py'),('collector_sha256','collect_probe.py')]:assert launch[key]==sha(run/name)
    assert launch['runtime_rates']==dict(base_linear_rate=.616,base_angular_rate=2.86,lift_rate=1.54)
    actions=np.asarray([r['action'] for r in trace]);bases=np.asarray([r['base_pose_world'] for r in trace])
    grasps=np.asarray([r['grasp_position_base'] for r in trace]);clocks=np.asarray([r['simulation_time_s'] for r in trace])
    assert actions.shape==(1200,2,9) and np.isfinite(actions).all() and np.max(np.abs(actions))<=1
    assert bases.shape==(1200,2,7) and np.isfinite(bases).all() and np.min(np.linalg.norm(bases[:,:,3:],axis=2))>.5
    assert grasps.shape==(1200,2,3) and np.isfinite(grasps).all()
    assert np.allclose(np.diff(clocks),.05,atol=1e-6)
    first=next((r for r in trace if ((r['model_debug'] or {}).get('pickup_debug') or {}).get('phase')=='refine_raise'),None)
    active=None if first is None else (first['model_debug'] or {}).get('robot')
    assert active in (None,0,1)
    idle=None if active is None else 1-active
    activation=None if first is None else first['step']
    failed=False
    for row,a in zip(trace,actions):
        d=row['policy_debug'];failure=d.get('failure')
        if variant=='v6':
            # Direct original actor output. No fabricated candidate-only debug or added control.
            assert d==row['model_debug']
            if activation is not None and row['step']>=activation and not failure:
                assert d['robot']==active and not np.any(a[idle]),'Baseline idle output changed'
            continue
        if failed:assert failure and not np.any(a),'Failure must latch'
        failed=failed or bool(failure)
        proposal=d.get('parent_proposed_action')
        if failure:assert not np.any(a);continue
        assert proposal is not None and np.asarray(proposal).shape==(2,9)
        if activation is None or row['step']<activation:
            assert np.array_equal(a,np.asarray(proposal)) and d['active_robot'] is None
        else:
            assert d['activation_step']==activation and d['active_robot']==active and d['idle_robot']==idle
            assert (row['model_debug'] or {})['robot']==active
            assert not np.any(np.asarray(proposal)[idle]) and np.array_equal(a[active],np.asarray(proposal)[active])
            assert not np.any(a[idle,3:])
            assert np.linalg.norm(a[idle,:2]*.616)<=.010001 and abs(a[idle,2]*2.86)<=.2/3.146*2.86+1e-6
            if row['step']<activation+20:assert not np.any(a[idle])
            if row['step']>=activation+20:
                ref=bases[activation+19]
                assert d['initial_search_direction']==initial_sign(ref,idle)
                if d['idle_mode']=='search':assert a[idle,2]*d['initial_search_direction']>=-1e-6
                prev=np.zeros(9) if row['step']==activation+20 else actions[row['step']-2,idle]
                assert np.linalg.norm((a[idle,:2]-prev[:2])*.616)<=.001001
                assert abs((a[idle,2]-prev[2])*2.86)<=.01/3.146*2.86+1e-6
    files=sorted((folder/'public_observations').glob('*.npz'))
    assert [int(p.stem) for p in files]==list(range(10,1201,10))
    samples=[];first_triple=None;streak=[];final_obs=None
    for p in files:
        step=int(p.stem)
        with np.load(p,allow_pickle=False) as z:
            obs={k:z[k] for k in z.files}
            assert obs['rgb'].shape==(5,256,256,3) and obs['rgb'].dtype==np.uint8
            assert obs['depth'].shape==obs['depth_valid'].shape==(5,256,256,1)
            assert obs['depth'].dtype==np.float32 and obs['depth_valid'].dtype==bool
            assert np.isfinite(obs['depth'][obs['depth_valid']]).all()
            for name,shape in [('base_pose_world',(2,7)),('grasp_pose_base',(2,7)),('joint_position',(2,13)),('joint_velocity',(2,13))]:
                assert obs[name].shape==shape and np.isfinite(obs[name]).all()
            assert obs['previous_action'].shape==(2,9)
            assert np.allclose(obs['previous_action'],actions[step-1],atol=1e-7)
            assert np.allclose(obs['simulation_time_s'],clocks[step-1]+.05,atol=1e-6)
            if step<1200:
                assert np.allclose(obs['base_pose_world'],bases[step],atol=1e-6)
                assert np.allclose(obs['grasp_pose_base'][:,:3],grasps[step],atol=1e-6)
                for name in ('gripper_close_command','fingertip_origin_distance'):
                    assert np.allclose(obs[name],trace[step][name],atol=1e-7)
            assert not any(k in obs for k in ['seed','score','anchors','cloth_world_positions','human_world_positions','camera_world_transform'])
            d=None if idle is None else detect_head(obs['rgb'][3+idle],obs['depth'][3+idle],obs['depth_valid'][3+idle])
            qualified=bool(d and d['detected'] and abs(np.mean([h['u'] for h in d['hands']])-128)<=20 and all(20<=h['u']<=236 and 20<=h['v']<=236 for h in d['hands']))
            world=project_hands(d,obs['base_pose_world'][idle]).tolist() if qualified else None
            samples.append(dict(step=step,qualified=qualified,detection=d,hand_surfaces_world=world))
            streak=streak+[step] if qualified else []
            if first_triple is None and len(streak)>=3:first_triple=streak[-3:]
            if step==1200:final_obs=obs
    carry=next((r for r in trace if (r['model_debug'] or {}).get('phase')=='carry_hold' and not (r['model_debug'] or {}).get('failure')),None)
    pickup=next((r for r in trace if ((r['model_debug'] or {}).get('pickup_debug') or {}).get('phase')=='hold' and not ((r['model_debug'] or {}).get('pickup_debug') or {}).get('failure')),None)
    retraction=ex=ez=None
    if pickup is not None and active is not None:
        start=np.asarray(pickup['grasp_position_base'])[active];end=final_obs['grasp_pose_base'][active,:3]
        retraction=float(start[0]-end[0]);ex=float(end[0]-.52);ez=float(end[2]-start[2])
    carry_ok=bool(retraction is not None and retraction>=.12 and abs(ex)<=.006 and abs(ez)<=.015)
    all_bases=np.concatenate([bases,final_obs['base_pose_world'][None]])
    all_grasps=np.concatenate([grasps,final_obs['grasp_pose_base'][None,:,:3]])
    idle_drift=idle_tilt=None;idle_guard=False
    if activation is not None and activation+19<1200:
        post=all_bases[activation+19:,idle]
        idle_drift=float(np.linalg.norm(post[:,:2]-post[0,:2],axis=1).max())
        _,tilts=yaw_tilt(post);idle_tilt=float(tilts.max())
        idle_guard=idle_drift<=.05 and idle_tilt<=.025
    active_guard=False;active_guard_details=None
    if carry is not None and active is not None:
        i=carry['step']-1;b=all_bases[i:,active];g=all_grasps[i:,active]
        _,tilts=yaw_tilt(b)
        opened=[]
        for r in trace[i:]:
            opened.append(not bool(np.asarray(r['gripper_close_command']).reshape(2)[active]) or np.asarray(r['fingertip_origin_distance']).reshape(2)[active]>.08)
        opened.append(not bool(final_obs['gripper_close_command'].reshape(2)[active]) or final_obs['fingertip_origin_distance'].reshape(2)[active]>.08)
        max_open=run_open=0
        for value in opened:run_open=run_open+1 if value else 0;max_open=max(max_open,run_open)
        active_guard_details=dict(max_xy_m=float(np.linalg.norm(b[:,:2]-b[0,:2],axis=1).max()),max_tilt_rad=float(tilts.max()),
            max_grasp_x_m=float(np.abs(g[:,0]-g[0,0]).max()),max_grasp_height_m=float(np.abs(g[:,2]-g[0,2]).max()),max_open_streak=max_open)
        v=active_guard_details
        active_guard=bool(v['max_xy_m']<=.05 and v['max_tilt_rad']<=.025 and v['max_grasp_x_m']<=.025 and v['max_grasp_height_m']<=.04 and max_open<5)
    final=[s for s in samples if s['step']>=1000];count=sum(s['qualified'] for s in final)
    pairs=[np.asarray(s['hand_surfaces_world']) for s in final if s['qualified']];matched=[]
    for pair in pairs:
        order=min(itertools.permutations([0,1]),key=lambda ids:np.linalg.norm(pair[list(ids)]-pairs[0],axis=1).sum());matched.append(pair[list(order)])
    radius=None if not matched else float(np.linalg.norm(np.asarray(matched)-np.median(matched,axis=0),axis=2).max())
    acquired=None if first_triple is None else first_triple[-1]*.05
    carry_time=None if carry is None else (carry['step']-1)*.05
    score=result['evaluation']['result'];item=score['score_items']['pickup']
    failures=sorted({str(r['policy_debug']['failure']) for r in trace if r['policy_debug'].get('failure')})
    assert result['policy_debug']==trace[-1]['policy_debug']
    row=dict(variant=variant,seed=result['seed'],output=str(folder),steps=1200,valid=True,technical_pass=True,wall_seconds=result['wall_seconds'],
        active_robot=active,idle_robot=idle,activation_step=activation,carry_hold_step=None if carry is None else carry['step'],
        carry_hold_time_s=carry_time,independent_acquisition_time_s=acquired,independent_first_three_centered_steps=first_triple,
        acquisition_before_or_at_carry=bool(acquired is not None and carry_time is not None and acquired<=carry_time),
        independent_final_centered_samples=count,independent_final_surface_radius_m=radius,independent_2hz_samples=samples,
        idle_entire_execution_xy_max_m=idle_drift,idle_entire_execution_tilt_max_rad=idle_tilt,
        idle_guard_passed=bool(idle_guard),active_postcarry_guard_passed=active_guard,active_postcarry_details=active_guard_details,
        pickup_reference_step=None if pickup is None else pickup['step'],retraction_m=retraction,carry_final_x_error_m=ex,carry_final_height_error_m=ez,
        public_numeric_carry_goal_passed=carry_ok,pickup_awarded=bool(item['achieved']),pickup_points=item['points'],
        pickup_awarded_at_seconds=item['achieved_at_episode_s'],raw_points=score['raw_points'],whole_dressing_success=score['success'],
        original_score_result=score,controller_failure=failures or None,actual_visual_review=None,training_demonstration_approval=False)
    row['numeric_pickup_preservation_passed']=bool(not failures and item['achieved'] and item['points']==5 and carry_ok and active_guard)
    row['numeric_concurrent_goal_passed']=bool(not failures and item['achieved'] and item['points']==5 and carry_ok and idle_guard and active_guard and count>=19 and radius is not None and radius<=.08 and row['acquisition_before_or_at_carry'])
    early=first_triple or [100,200,300]
    row['acquisition_review_image']=dict(file='acquisition_review.png',steps=early,fallback_examples=first_triple is None)
    row['final_review_image']=dict(file='final_concurrent_review.png',steps=[1000,1040,1080,1120,1160,1200],roles_known=active is not None)
    qa=dict(technical_pass=True,steps=1200,launch_sha256=sha(folder/'launch.json'),trace_sha256=sha(folder/'trace.json'),result_sha256=sha(folder/'result.json'),
        checkpoint_sha256=launch['checkpoint_sha256'],parent_source_sha256=launch['parent_source_sha256'],
        public_files_sha256={p.name:sha(p) for p in files},active_action_check=('Recorded frozen-parent active proposal equality; not independent20Hz neural replay' if variant=='v22' else 'Direct unchanged frozen v6 entrypoint and run source binding; not independent20Hz neural replay'),
        training_demonstration_approval=False,visual_approval=False)
    if emit:
        make_sheets(folder,row)
        write(folder/'evaluation_technical_checks.json',qa);write(folder/'concurrent_metrics.json',row)
    return row,qa


def make_sheets(folder,row):
    active=row['active_robot'] if row['active_robot'] is not None else 0
    idle=1-active
    final=Image.new('RGB',(768,1680),'#121820');draw=ImageDraw.Draw(final)
    for i,step in enumerate(row['final_review_image']['steps']):
        with np.load(folder/'public_observations'/f'{step:05d}.npz',allow_pickle=False) as obs:
            for col,(camera,name) in enumerate([(0,'overview'),(1+active,f'active wrist{active}'),(3+idle,f'idle head{idle}')]):
                draw.text((col*256+4,i*280+3),f'{name} step{step} roles known={row["active_robot"] is not None}',fill='white')
                final.paste(Image.fromarray(obs['rgb'][camera]),(col*256,i*280+24))
    final.save(folder/'final_concurrent_review.png')
    early=Image.new('RGB',(768,280),'#121820');draw=ImageDraw.Draw(early)
    for i,step in enumerate(row['acquisition_review_image']['steps']):
        with np.load(folder/'public_observations'/f'{step:05d}.npz',allow_pickle=False) as obs:
            draw.text((i*256+4,3),f'idle{idle} step{step} fallback={row["acquisition_review_image"]["fallback_examples"]}',fill='white')
            early.paste(Image.fromarray(obs['rgb'][3+idle]),(i*256,24))
    early.save(folder/'acquisition_review.png')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('folder');args=parser.parse_args()
    row,_=assess(args.folder,emit=True)
    print({k:row[k] for k in ['seed','numeric_concurrent_goal_passed','controller_failure','independent_acquisition_time_s','carry_hold_time_s']})
