"""Read-only release validation; never initializes Isaac or rewrites prechecks."""
import os
from pathlib import Path
from artifacts import read,sha,verify_sources,verify_environment

ROOT=Path(__file__).resolve().parent


def verify_release():
    verify_sources(ROOT);verify_environment(ROOT)
    plan=read(ROOT/'test_protocol.json')
    assert plan['data_split']['new_test_seeds']==list(range(1501,1507))
    assert plan['budget']['attempts']==12 and plan['budget']['retries']==0
    for path,digest in plan['source_bindings'].items():assert sha(path)==digest,path
    for name,item in read(ROOT/'dependency_provenance.json').items():
        assert sha(ROOT/name)==item['sha256']==sha(item['source']),name
    for v,model in plan['variants'].items():assert sha(ROOT/model['policy_file'])==model['policy_sha256'],v
    assert sha(ROOT/plan['checkpoint'])==plan['checkpoint_sha256']
    for name in ['preflight_results.json','preflight_release_results.json']:
        check=read(ROOT/name);assert check['passed']
        for file,digest in check['tested_sources_sha256'].items():assert sha(ROOT/file)==digest,file
    for key in ['STRETCH4_BASE_LINEAR_RATE','STRETCH4_BASE_ANGULAR_RATE','STRETCH4_LIFT_RATE']:
        assert not os.environ.get(key),'Unexpected rate override '+key
    dev=ROOT.parent/'取衣并行寻视-v22'
    completion=read(dev/'completion_record.json');result=read(dev/'development_results.json')
    assert completion['status']=='completed_reviewed' and result['successes']==3 and result['development_gate_passed']
    assert sha(dev/'development_results.json')==completion['results_sha256']
    for path,digest in completion['review_sha256'].items():assert sha(path)==digest
    return plan
