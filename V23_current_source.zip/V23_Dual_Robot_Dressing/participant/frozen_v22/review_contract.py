"""Bind a pre-existing actual Codex image review; never generate approval."""
from artifacts import sha,parent_hashes,read

FINAL_STEPS=[1000,1040,1080,1120,1160,1200]
IMAGES=['acquisition_review.png','final_concurrent_review.png']


def visual_success(review):
    return bool(review and review.get('stable_final_hold_confirmed') is True
                and review.get('idle_final_person_and_both_hands_confirmed') is True
                and review.get('idle_acquisition_person_and_both_hands_confirmed') is True)


def combined_success(row,review):
    return bool(row['numeric_concurrent_goal_passed'] and visual_success(review))


def validate_review(folder,row,review):
    run=folder.parent
    model=read(run/'test_protocol.json')['variants'][row['variant']]
    expected=dict(policy_source_sha256=sha(run/model['policy_file']),checkpoint_sha256=sha(run/'weights/best.pt'),
        parent_source_sha256=parent_hashes(run),detector_source_sha256=sha(run/'detector.py'),
        geometry_source_sha256=sha(run/'geometry.py'),protocol_sha256=sha(run/'test_protocol.json'),
        evidence_sha256={n:sha(folder/n) for n in IMAGES},
        technical_checks_sha256=sha(folder/'evaluation_technical_checks.json'),metrics_sha256=sha(folder/'concurrent_metrics.json'))
    for key,value in expected.items():assert review[key]==value,key
    assert review['reviewer'] and review['reason'] and review['reviewed_at_utc']
    assert review['training_demonstration_approval'] is False
    assert review['actual_images_reviewed']==IMAGES and review['all21_views_actually_reviewed'] is True
    for key,allowed in [('stable_clothing_held_steps',FINAL_STEPS),('idle_final_visible_person_and_both_hands_steps',FINAL_STEPS),('idle_acquisition_visible_person_and_both_hands_steps',row['acquisition_review_image']['steps'])]:
        assert isinstance(review[key],list) and len(set(review[key]))==len(review[key]) and set(review[key])<=set(allowed)
    expected_flags=dict(stable_final_hold_confirmed=len(review['stable_clothing_held_steps'])==6,
        idle_final_person_and_both_hands_confirmed=len(review['idle_final_visible_person_and_both_hands_steps'])>=5,
        idle_acquisition_person_and_both_hands_confirmed=not row['acquisition_review_image']['fallback_examples'] and len(review['idle_acquisition_visible_person_and_both_hands_steps'])==3)
    for key,value in expected_flags.items():assert type(review[key]) is bool and review[key]==value,key
    assert not (folder/'selection_review.json').exists()
    return visual_success(review)
