"""CPU actual actor loading, isolated late phases and paired aggregation counterexamples."""
import copy
import inspect
from pathlib import Path
import numpy as np
import torch
from actor_loader import load_actor,model_debug
from frozen_pickup.policy import Policy as OriginalV6
from artifacts import read,write,sha
from comparison import compare
from preflight_capture import main as capture_checks

ROOT=Path(__file__).resolve().parent


def main():
    assert not (ROOT/'preflight_results.json').exists(),'Preserve completed checks'
    torch.set_num_threads(1)
    plan=read(ROOT/'test_protocol.json');checks=[]
    assert Path(inspect.getfile(OriginalV6)).resolve()==ROOT/'frozen_pickup/policy.py'
    # Public development observations only. Stage/target injection is explicitly
    # an isolated interface fixture, not physical replay or a new evaluation.
    sources=read(ROOT.parent/'取衣并行寻视-v22/parent_interface_preflight.json')
    npzs=[Path(p) for p in sources['input_sha256'] if p.endswith('.npz')]
    actual_inputs={};cases=0
    for npz in npzs:
        assert sha(npz)==sources['input_sha256'][str(npz)]
        actual_inputs[str(npz)]=sha(npz)
        with np.load(npz,allow_pickle=False) as z:obs={k:z[k].copy() for k in z.files}
        trace=read(npz.parent.parent/'trace.json')
        r=next(x for x in trace if (x['model_debug'].get('pickup_debug') or {}).get('phase')=='refine_raise')
        d=r['model_debug']['pickup_debug'];robot=d['robot']
        for stage,phase in [('pickup',x) for x in ['refine_raise','refine_align','refine_extend','refine_descend','close_wait','neural_lift','hold']]+[(s,'hold') for s in ['carry_settle','carry_retract','carry_hold']]:
            baseline=load_actor(ROOT,'v6',device='cpu');candidate=load_actor(ROOT,'v22',device='cpu')
            assert type(baseline) is OriginalV6 and type(candidate.parent) is OriginalV6
            for parent in [baseline,candidate.parent]:
                parent.stage=stage;parent.robot=robot;parent.pickup.robot=robot;parent.pickup.phase=phase
                parent.pickup.target_world=np.asarray(d['target_world_from_rgbd'])
                parent.start_grasp=obs['grasp_pose_base'][robot,:3].copy();parent.start_grasp[0]+=.2
            # Starting a late wrapper phase is an explicit latch fixture only.
            candidate.active=robot;candidate.idle=1-robot;candidate.activation_step=1;candidate.local_step=20
            original=copy.deepcopy(baseline)
            a=baseline(obs);expected=original(obs);b=candidate(obs)
            assert np.array_equal(a,expected) and model_debug(baseline,'v6')==baseline.debug
            assert candidate.failure is None and np.array_equal(b[robot],a[robot])
            assert not np.any(a[1-robot]) and not np.any(b[1-robot,3:])
            assert model_debug(candidate,'v22')==candidate.debug['parent_debug']
            cases+=1
    assert cases==20
    checks.append('20 actual CPU-loaded parent-network late-phase interface fixtures: both role identities; baseline exact class, candidate active row equal')
    for variant in ['v6','v22']:
        capture_checks(variant)
        assert read(ROOT/f'preflight_capture_{variant}.json')['passed']
    checks.append('both collectors/metrics reject synthetic missing images, false debug success, score/carry loss, late acquisition, illegal action and drift')
    rows=[]
    for item in plan['sequence']:
        candidate=item['variant']=='v22'
        rows.append(dict(item,technical_pass=True,concurrent_success=candidate,pickup_preservation_success=True,
            controller_failure=None,penalized_acquisition_time_s=30. if candidate else 60.,raw_points=5.,dressing_complete=False,wall_seconds=0.))
    assert compare(rows,plan)['predeclared_improvement_passed']
    def fails(bad):
        try:result=compare(bad,plan)
        except AssertionError:return
        assert not result['predeclared_improvement_passed']
    bad=copy.deepcopy(rows)
    for r in [r for r in bad if r['variant']=='v22'][:2]:r['concurrent_success']=False
    fails(bad);checks.append('candidate4/6 fails predeclared minimum')
    bad=copy.deepcopy(rows)
    for r in bad:r['concurrent_success']=True
    fails(bad);checks.append('tie with baseline is not improvement')
    for key,value in [('pickup_preservation_success',False),('controller_failure',['synthetic_failure'])]:
        bad=copy.deepcopy(rows);next(r for r in bad if r['variant']=='v22')[key]=value
        fails(bad);checks.append(key+' regression rejected')
    fails(rows[:-1]);bad=copy.deepcopy(rows);bad[0],bad[1]=bad[1],bad[0];fails(bad)
    checks.append('missing attempt and wrong alternation rejected')
    bad=copy.deepcopy(rows);bad[0]['penalized_acquisition_time_s']=60.
    assert compare(bad,plan)['variants']['v6']['mean_penalized_acquisition_time_s']==60.
    checks.append('no acquisition is retained with60s penalty in all-attempt statistics')
    names=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix in ('.py','.pt')]
    names += [ROOT/'test_protocol.json',ROOT/'dependency_provenance.json',ROOT/'preflight_capture_v6.json',ROOT/'preflight_capture_v22.json']
    report=dict(passed=True,simulation_runs=0,new_training=0,real_parent_interface_cases=cases,checks=checks,
        input_sha256=actual_inputs,tested_sources_sha256={str(p.relative_to(ROOT)):sha(p) for p in names},
        limitations='Late-phase public-development fixtures inject stage/target/latch; capture uses fictional rectangles and handwritten trace. No new physical simulation, full20Hz replay, actual image approval or independent-test evidence.')
    write(ROOT/'preflight_results.json',report)
    print('paired CPU preflight passed',len(checks),'groups')


if __name__=='__main__':main()
