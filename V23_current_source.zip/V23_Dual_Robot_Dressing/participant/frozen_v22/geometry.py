"""Projection using only fixed robot camera mounting and public own pose."""
import json
from pathlib import Path
import numpy as np

CAL = json.loads((Path(__file__).resolve().parent/'static_calibration.json').read_text())
HEAD = np.asarray(CAL['base_from_head_optical'])
FOCAL = 256/(2*np.tan(np.deg2rad(CAL['fov_degrees']/2)))


def rotation(q):
    w, x, y, z = np.asarray(q)/np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def yaw_tilt(poses):
    q = np.asarray(poses, dtype=float)[:, 3:7].copy()
    q /= np.linalg.norm(q, axis=1, keepdims=True)
    w, x, y, z = q.T
    return np.arctan2(2*(w*z+x*y), 1-2*(y*y+z*z)), np.arccos(np.clip(1-2*(x*x+y*y), -1, 1))


def project_hands(detection, pose):
    points = []
    for h in detection['hands']:
        u, v, z = h['u'], h['v'], h['median_depth_m']
        optical = np.array([(u-128)*z/FOCAL, (v-128)*z/FOCAL, z])
        base = HEAD[:3, :3]@optical+HEAD[:3, 3]
        points.append(rotation(pose[3:])@base+pose[:3])
    return np.asarray(points)
