"""One GPU, predeclared alternating sequence, no retries or visual approvals."""
import fcntl
import os
import subprocess
import sys
import time
from datetime import datetime,timezone
from pathlib import Path
from release_checks import ROOT,read,sha,verify_release
from review_records import reviewed_row

def atomic(p,v):
    import json
    temp=p.with_suffix('.tmp');temp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');temp.replace(p)

def _refresh_unlocked():
    state=read(ROOT/'pipeline_status.json');rows=[];pending=[]
    for a in state['attempts']:
        r=reviewed_row(Path(a['output']))
        (pending if r is None else rows).append(a if r is None else r)
    report=dict(status='pending_completion_or_actual_reviews',completed_attempts=len(state['attempts']),
                reviewed_attempts=len(rows),total_attempts=12,reviewed_rows=rows,pending_visual_review=pending,
                protocol_sha256=sha(ROOT/'test_protocol.json'))
    atomic(ROOT/'paired_results.json',report)
    return report

def refresh_report():
    with (ROOT/'offline_report.lock').open('a') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return _refresh_unlocked()

def main():
    status=ROOT/'pipeline_status.json'
    assert not status.exists(),'Already attempted; inspect current child and locks; no automatic restart'
    plan=verify_release()
    for seed in plan['data_split']['new_test_seeds']:
        assert not list(ROOT.parent.rglob(f'seed-{seed}')),'Scene already used'
    with (ROOT.parent/'PhyRC2027本机模拟/runtime.lock').open('a') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=dict(status='starting',pipeline_pid=os.getpid(),started_at_utc=datetime.now(timezone.utc).isoformat(),
               protocol_sha256=sha(ROOT/'test_protocol.json'),source_manifest_sha256=sha(ROOT/'source_sha256.json'),
               attempts=[],checkpoint=str(ROOT/'weights/best.pt'),checkpoint_sha256=sha(ROOT/'weights/best.pt'),no_new_training=True)
    def save(**values):state.update(values);atomic(status,state)
    env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1')
    env.pop('CUDA_VISIBLE_DEVICES',None);cpu=dict(env,CUDA_VISIBLE_DEVICES='');child=None
    try:
        save()
        for item in plan['sequence']:
            verify_release();seed,variant=item['seed'],item['variant']
            prior=[a for a in state['attempts'] if a['seed']==seed]
            assert not any(a['variant']==variant for a in prior)
            actual_dirs=list(ROOT.parent.rglob(f'seed-{seed}'))
            assert sorted(str(p.resolve()) for p in actual_dirs)==sorted(a['output'] for a in prior),'Unexpected duplicate scene'
            with (ROOT/f'{variant}-{seed}.log').open('x') as log:
                child=subprocess.Popen([sys.executable,str(ROOT/'collect_probe.py'),'--seed',str(seed),'--variant',variant],
                                       cwd=ROOT.parent.parent,env=env,stdout=log,stderr=subprocess.STDOUT)
            save(status='paired_evaluation',current_seed=seed,current_variant=variant,evaluation_pid=child.pid)
            run=None
            for _ in range(120):
                for p in sorted((ROOT.parent/'视觉抓取MVP/runs').glob('*/process.json'),reverse=True):
                    try:m=read(p)
                    except (ValueError,FileNotFoundError):continue
                    if m['pid']==child.pid:run=p.parent;break
                if run is not None or child.poll() is not None:break
                time.sleep(1)
            if run is None:raise RuntimeError('Missing run; inspect live child before any further action')
            save(current_run=str(run));code=child.wait();folder=run/f'seed-{seed}'
            if code or not (folder/'result.json').exists():
                save(failed_attempt=dict(seed=seed,variant=variant,output=str(folder),exit_code=code))
                raise RuntimeError('Incomplete first attempt preserved; no automatic retry')
            with (ROOT/'offline_report.lock').open('a') as offline:
                for retry in range(25):
                    try:fcntl.flock(offline,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                    except BlockingIOError:
                        if retry==24:raise
                        time.sleep(.2)
                save(status='offline_reporting',evaluation_pid=None)
                with (ROOT/f'{variant}-{seed}-report.log').open('x') as log:
                    subprocess.run([sys.executable,str(ROOT/'offline_report.py'),str(folder)],cwd=ROOT.parent.parent,
                                   env=cpu,stdout=log,stderr=subprocess.STDOUT,check=True)
                metric=read(folder/'concurrent_metrics.json')
                state['attempts'].append({k:metric[k] for k in ['seed','variant','output','technical_pass','wall_seconds',
                       'controller_failure','independent_acquisition_time_s','numeric_concurrent_goal_passed']})
                save();_refresh_unlocked()
        save(status='completed_pending_visual_review',finished_at_utc=datetime.now(timezone.utc).isoformat(),
             current_seed=None,current_variant=None,current_run=None,evaluation_pid=None)
    except BaseException as error:
        save(status='failed_needs_attention',error=repr(error),child_pid=None if child is None else child.pid,
             child_still_running=bool(child and child.poll() is None))
        raise

if __name__=='__main__':
    with (ROOT/'pipeline.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        main()
