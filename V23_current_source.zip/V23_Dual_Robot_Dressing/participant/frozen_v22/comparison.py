"""Common finite paired endpoint; every first attempt is retained."""
from statistics import mean,median


def compare(rows,plan):
    expected=[(r['seed'],r['variant']) for r in plan['sequence']]
    assert [(r['seed'],r['variant']) for r in rows]==expected,'Incomplete or wrong sequence'
    assert len(rows)==12 and len(set(expected))==12
    stats={}
    for variant in ['v6','v22']:
        group=[r for r in rows if r['variant']==variant]
        assert len(group)==6 and all(r['technical_pass'] for r in group)
        stats[variant]=dict(attempts=6,concurrent_successes=sum(r['concurrent_success'] for r in group),
            pickup_preservation_successes=sum(r['pickup_preservation_success'] for r in group),
            internal_failures=sum(bool(r['controller_failure']) for r in group),
            mean_penalized_acquisition_time_s=mean(r['penalized_acquisition_time_s'] for r in group),
            original_raw_points=[r['raw_points'] for r in group],dressing_successes=sum(r['dressing_complete'] for r in group))
    pairs=[]
    for seed in plan['data_split']['new_test_seeds']:
        pair={r['variant']:r for r in rows if r['seed']==seed};b,c=pair['v6'],pair['v22']
        pairs.append(dict(seed=seed,baseline_concurrent_success=b['concurrent_success'],candidate_concurrent_success=c['concurrent_success'],
            baseline_penalized_time_s=b['penalized_acquisition_time_s'],candidate_penalized_time_s=c['penalized_acquisition_time_s'],
            acquisition_time_reduction_s=b['penalized_acquisition_time_s']-c['penalized_acquisition_time_s']))
    b,c=stats['v6'],stats['v22'];rules=plan['predeclared_improvement']
    checks=dict(candidate_combined_min=c['concurrent_successes']>=rules['candidate_combined_min'],
        candidate_combined_strictly_more=c['concurrent_successes']>b['concurrent_successes'],
        candidate_pickup_preservation_not_lower=c['pickup_preservation_successes']>=b['pickup_preservation_successes'],
        candidate_internal_failures_not_more=c['internal_failures']<=b['internal_failures'])
    return dict(variants=stats,pairs=pairs,predeclared_checks=checks,predeclared_improvement_passed=all(checks.values()),
        secondary_median_paired_penalized_time_reduction_s=median(p['acquisition_time_reduction_s'] for p in pairs),
        total_simulation_wall_seconds=sum(r['wall_seconds'] for r in rows),
        limitation='Six matched scenes, descriptive only; no new training, sleeve insertion or full-dressing claim.')
