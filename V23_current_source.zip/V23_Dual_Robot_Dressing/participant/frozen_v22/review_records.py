"""Read already performed actual reviews, never approve an image."""
from pathlib import Path
from artifacts import read,sha
from offline_report import assess
from review_contract import validate_review,combined_success


def reviewed_row(folder,recompute=False):
    folder=Path(folder)
    path=folder/'evaluation_review.json'
    if not path.exists():return None
    row=read(folder/'concurrent_metrics.json');qa=read(folder/'evaluation_technical_checks.json')
    if recompute:
        fresh,fresh_qa=assess(folder)
        assert fresh==row and fresh_qa==qa,'Independent recomputation changed saved evidence'
    review=read(path);validate_review(folder,row,review)
    early=review['idle_acquisition_person_and_both_hands_confirmed']
    return dict(seed=row['seed'],variant=row['variant'],output=str(folder),technical_pass=row['technical_pass'],
        pickup_preservation_success=bool(row['numeric_pickup_preservation_passed'] and review['stable_final_hold_confirmed']),
        concurrent_success=combined_success(row,review),
        early_visual_pass=early,held_visual_pass=review['stable_final_hold_confirmed'],
        final_hand_visual_pass=review['idle_final_person_and_both_hands_confirmed'],
        acquisition_time_s=row['independent_acquisition_time_s'],carry_time_s=row['carry_hold_time_s'],
        penalized_acquisition_time_s=row['independent_acquisition_time_s'] if early and row['independent_acquisition_time_s'] is not None else 60.,
        final_qualified_samples=row['independent_final_centered_samples'],
        controller_failure=row['controller_failure'],raw_points=row['raw_points'],dressing_complete=row['whole_dressing_success'],
        wall_seconds=row['wall_seconds'],review_sha256=sha(path),
        metrics_sha256=sha(folder/'concurrent_metrics.json'),technical_checks_sha256=sha(folder/'evaluation_technical_checks.json'))
