"""CPU snapshot/lock/archive guards; exec and process launch explicitly mocked."""
import ast
import fcntl
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch
from artifacts import read,write,sha,verify_environment
import collect_probe
import run_paired_test
import finalize_report

ROOT=Path(__file__).resolve().parent


def main():
    output=ROOT/'preflight_release_results.json'
    if output.exists():raise RuntimeError('Do not overwrite completed release checks')
    verify_environment(ROOT)
    for name,item in read(ROOT/'dependency_provenance.json').items():assert sha(ROOT/name)==item['sha256']==sha(item['source'])
    sources=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.txt','.pt') and not p.name.endswith('_status.json')]
    for p in sources:
        if p.suffix=='.py':ast.parse(p.read_text())
    with tempfile.TemporaryDirectory(prefix='phyrc-v22-release-fixture-') as temp:
        out=Path(temp)/'outputs';package=out/'candidate';package.mkdir(parents=True)
        sim=out/'PhyRC2027本机模拟';sim.mkdir();(out/'视觉抓取MVP/runs').mkdir(parents=True)
        for p in sources:
            q=package/p.relative_to(ROOT);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
        write(package/'preflight_release_results.json',dict(passed=True,fixture_only=True))
        names=[str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()]
        write(package/'source_sha256.json',{n:sha(package/n) for n in names})
        plan=read(package/'test_protocol.json')
        write(package/'pipeline_status.json',dict(pipeline_pid=os.getpid(),attempts=[]))
        captured={}
        class ExecIntercept(Exception):pass
        def intercept(executable,args,env):
            captured.update(executable=executable,args=args,env=env)
            fd=int(env['PHYRC_CONCURRENT_PAIR_LOCK_FD']);assert os.get_inheritable(fd)
            with (sim/'runtime.lock').open('a') as other:
                try:fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:pass
                else:raise AssertionError('runtime lock not held across requested exec')
            raise ExecIntercept()
        with patch.object(collect_probe,'ROOT',package),patch.object(collect_probe.os,'execve',intercept):
            try:collect_probe.bootstrap(1501,'v6')
            except ExecIntercept:pass
            else:raise AssertionError('snapshot exec not reached')
        run=Path(captured['args'][1]).parent
        assert captured['args'][1]==str(run/'collect_probe.py') and captured['args'][-1]=='--snapshot'
        assert sha(run/'collect_probe.py')==sha(package/'collect_probe.py')
        manifest=read(run/'source_sha256.json')
        assert all(sha(run/n)==digest for n,digest in manifest.items())
        # A separate CPU interpreter imports only the copied actor and dependencies.
        code="from pathlib import Path;from actor_loader import load_actor;from artifacts import verify_sources;import torch;torch.set_num_threads(1);verify_sources(Path.cwd());actors=[load_actor(Path.cwd(),v,device='cpu') for v in ['v6','v22']];assert actors[1].parent.__class__ is actors[0].__class__;print('copied CPU actors loaded')"
        p=subprocess.run([sys.executable,'-c',code],cwd=run,env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1'),capture_output=True,text=True,check=True)
        assert 'copied CPU actors loaded' in p.stdout
        # The parent must refuse busy GPU and existing state before any Popen.
        (package/'pipeline_status.json').unlink()
        with patch.object(run_paired_test,'ROOT',package),patch.object(run_paired_test,'verify_release',lambda:plan),patch.object(run_paired_test.subprocess,'Popen',side_effect=AssertionError('must not spawn')):
            with (sim/'runtime.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                try:run_paired_test.main()
                except BlockingIOError:pass
                else:raise AssertionError('busy shared lock accepted')
            assert not (package/'pipeline_status.json').exists()
            write(package/'pipeline_status.json',dict(status='existing'))
            try:run_paired_test.main()
            except AssertionError as exc:assert 'Already attempted' in str(exc)
            else:raise AssertionError('duplicate pipeline accepted')
        write(package/'pipeline_status.json',dict(status='completed_pending_visual_review',attempts=[]))
        with patch.object(finalize_report,'ROOT',package),patch.object(finalize_report,'verify_release',lambda:plan):
            try:finalize_report.main()
            except AssertionError:pass
            else:raise AssertionError('missing attempts finalized')
        assert not (package/'completion_record.json').exists()
    report=dict(passed=True,simulation_runs=0,training_performed=False,
        checks=['86 original environment files plus interface snapshots unchanged','all declared parent/detector/static dependencies byte identical',
            'collector bootstrap copies source/weight manifest and requests exec of copied collector with held inherited lock',
            'separate CPU process loads both original baseline and candidate/parent networks from exact snapshot directory',
            'busy runtime lock refuses parent before state creation or process launch',
            'existing pipeline state refuses launch','incomplete attempts cannot finalize'],
        limitations='Exec/Popen and parent release verification explicitly mocked for temporary lock tests; real snapshot CPU model import only. No Isaac initialization, GPU run or actual image review.',
        tested_sources_sha256={str(p.relative_to(ROOT)):sha(p) for p in sources})
    write(output,report);print({k:v for k,v in report.items() if k!='tested_sources_sha256'})


if __name__=='__main__':main()
