"""Fictional rectangle RGB-D used only for offline counterexamples."""
import numpy as np

def synthetic_obs(yaws=(0., 0.), visible=True, pixel_errors=(0., 0.)):
    images = np.zeros((5, 256, 256, 3), np.uint8)
    if visible:
        for r in (0, 1):
            center = int(round(128+pixel_errors[r]))
            for x,y,w,h in [(center-85,108,20,28),(center-13,84,8,8),(center+5,108,8,8)]:
                if 0 <= x and x+w <= 256: images[3+r,y:y+h,x:x+w] = [220,205,206]
    poses = np.zeros((2,7)); poses[:,0] = [-1,1]
    poses[:,3] = np.cos(np.asarray(yaws)/2); poses[:,6] = np.sin(np.asarray(yaws)/2)
    grip = np.zeros((2,7)); grip[:,0]=.72; grip[:,2]=1.; grip[:,3]=1.
    return dict(rgb=images, depth=np.ones((5,256,256,1),np.float32),
        depth_valid=np.ones((5,256,256,1),bool),base_pose_world=poses,grasp_pose_base=grip,
        joint_position=np.zeros((2,13)),joint_velocity=np.zeros((2,13)),
        gripper_close_command=np.ones((2,1),bool),fingertip_origin_distance=np.ones((2,1))*.04,
        simulation_time_s=np.asarray(0.))

