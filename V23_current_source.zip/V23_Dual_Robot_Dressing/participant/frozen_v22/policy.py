"""Frozen v6 pickup/carry with one explicitly latched idle head observer.

No observation fabrication, learned updates, score or scene-state inputs.
"""
import numpy as np
from frozen_pickup.policy import Policy as CarryPolicy
from detector import detect_head
from geometry import yaw_tilt, FOCAL


def limited(v, maximum):
    return v * min(1., maximum / max(float(np.linalg.norm(v)), 1e-12))


def world_to_body(v, yaw):
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([c*v[0]+s*v[1], -s*v[0]+c*v[1]])


def search_sign(poses, robot):
    delta = poses[1-robot, :2]-poses[robot, :2]
    if np.linalg.norm(delta) < .25:
        raise ValueError('invalid_public_pair_search_geometry')
    yaw, _ = yaw_tilt(poses)
    error = float((np.arctan2(delta[1], delta[0])-yaw[robot]+np.pi) % (2*np.pi)-np.pi)
    tie = abs(error) <= 1e-6 or abs(abs(error)-np.pi) <= 1e-6
    return (1 if tie or error > 0 else -1), error


def validate_observation(obs):
    shapes = {'base_pose_world': (2, 7), 'grasp_pose_base': (2, 7),
              'joint_position': (2, 13), 'joint_velocity': (2, 13)}
    for key, shape in shapes.items():
        a = np.asarray(obs[key])
        if a.shape != shape or not np.isfinite(a).all(): raise ValueError(key)
    for key, count in [('fingertip_origin_distance', 2), ('gripper_close_command', 2), ('simulation_time_s', 1)]:
        a = np.asarray(obs[key])
        if a.size != count or not np.isfinite(a).all(): raise ValueError(key)
    if np.min(np.linalg.norm(obs['base_pose_world'][:, 3:], axis=1)) < .5: raise ValueError('base quaternion')
    if obs['rgb'].shape != (5, 256, 256, 3) or obs['rgb'].dtype != np.uint8: raise ValueError('rgb')
    if obs['depth'].shape != (5, 256, 256, 1) or obs['depth_valid'].shape != obs['depth'].shape: raise ValueError('depth')
    if obs['depth_valid'].dtype != bool or not np.isfinite(obs['depth'][obs['depth_valid']]).all(): raise ValueError('valid depth')


class Policy:
    DATA_SOURCE = 'hybrid-frozen-pickup-concurrent-public-hand-view'
    METHOD = 'Frozen v6 learned pickup/carry; idle-only public RGB-D short scan after actual refine_raise; no new training'

    def __init__(self, checkpoint, device=None):
        self.parent = CarryPolicy(checkpoint, device=device)
        self.step = 0
        self.active = self.idle = self.activation_step = None
        self.local_step = 0
        self.reference = None
        self.sign = self.heading_error = None
        self.yaw_speed = 0.
        self.xy_speed = np.zeros(2)
        self.mode = 'inactive'
        self.detected = self.centered = self.lost = 0
        self.carry_reference = None
        self.carry_step = None
        self.open_streak = 0
        self.failure = None
        self.phase = 'pickup'
        self.debug = {}
        self.parent_action = np.zeros((2, 9), np.float32)

    def _observe_idle(self, obs):
        self.local_step += 1
        r = self.idle
        poses = np.asarray(obs['base_pose_world'])
        yaw, tilt = yaw_tilt(poses)
        if self.local_step <= 20:
            self.mode = 'settle'
            return np.zeros(3)
        if self.reference is None:
            self.reference = poses[r].copy()
            self.sign, self.heading_error = search_sign(poses, r)
            self.mode = 'search'
        if tilt[r] > .025: raise ValueError('idle_public_base_tilt')
        if np.linalg.norm(poses[r, :2]-self.reference[:2]) > .05: raise ValueError('idle_public_base_drift')
        d = detect_head(obs['rgb'][3+r], obs['depth'][3+r], obs['depth_valid'][3+r])
        usable = d['detected'] and all(20 <= h['u'] <= 236 and 20 <= h['v'] <= 236 for h in d['hands'])
        if usable:
            self.detected += 1
            self.lost = 0
            error = float(np.mean([h['u'] for h in d['hands']])-128)
        else:
            self.detected = self.centered = 0
            self.lost += 1
            error = None
        requested = .20*self.sign
        if self.mode == 'search' and self.detected >= 3: self.mode = 'center'
        if self.mode in ('center', 'view_hold'):
            requested = float(np.clip(-.6*np.arctan(error/FOCAL), -.12, .12)) if usable else 0.
            if usable:
                self.centered = self.centered+1 if abs(error) <= 20 else 0
                if self.centered >= 10: self.mode = 'view_hold'
            if self.lost >= 10: raise ValueError('idle_lost_target')
        if self.local_step > 920 and self.mode != 'view_hold': raise ValueError('idle_search_timeout')
        self.yaw_speed += float(np.clip(requested-self.yaw_speed, -.01, .01))
        target_xy = limited(world_to_body(self.reference[:2]-poses[r, :2], yaw[r]), .01)
        self.xy_speed += limited(target_xy-self.xy_speed, .001)
        return np.r_[self.xy_speed/.616, self.yaw_speed/3.146]

    def _guard_carry(self, obs):
        if self.parent.debug.get('phase') != 'carry_hold' and self.carry_reference is None: return
        r = self.active
        pose = np.asarray(obs['base_pose_world'])[r]
        grasp = np.asarray(obs['grasp_pose_base'])[r, :3]
        if self.carry_reference is None:
            self.carry_reference = (pose.copy(), grasp.copy())
            self.carry_step = self.step
        base0, grasp0 = self.carry_reference
        _, tilt = yaw_tilt(np.asarray(obs['base_pose_world']))
        if tilt[r] > .025: raise ValueError('active_postcarry_tilt')
        if np.linalg.norm(pose[:2]-base0[:2]) > .05: raise ValueError('active_postcarry_drift')
        if abs(grasp[0]-grasp0[0]) > .025: raise ValueError('active_postcarry_grasp_x')
        if abs(grasp[2]-grasp0[2]) > .04: raise ValueError('active_postcarry_height')
        opened = not bool(np.asarray(obs['gripper_close_command']).reshape(2)[r]) or np.asarray(obs['fingertip_origin_distance']).reshape(2)[r] > .08
        self.open_streak = self.open_streak+1 if opened else 0
        if self.open_streak >= 5: raise ValueError('active_postcarry_gripper_open')

    def __call__(self, obs):
        self.step += 1
        action = np.zeros((2, 9), np.float32)
        parent_debug = None
        parent_action = None
        try:
            validate_observation(obs)
            parent_action = self.parent(obs)
            parent_debug = self.parent.debug
            if parent_action.shape != (2, 9) or not np.isfinite(parent_action).all() or np.max(np.abs(parent_action)) > 1:
                raise ValueError('invalid_parent_action')
            self.parent_action = parent_action.copy()
            if self.parent.failure: raise ValueError('parent_failure: '+str(self.parent.failure))
            pickup = parent_debug.get('pickup_debug') or {}
            if self.active is None and pickup.get('phase') == 'refine_raise':
                robot = parent_debug.get('robot')
                if robot not in (0, 1): raise ValueError('invalid_parent_robot')
                self.active, self.idle = int(robot), 1-int(robot)
                self.activation_step = self.step
            action = parent_action.copy()
            if self.active is not None:
                if parent_debug.get('robot') != self.active: raise ValueError('parent_role_changed')
                if np.any(parent_action[self.idle]): raise ValueError('parent_idle_command_conflict')
                if not self.failure:
                    action[self.idle, :3] = self._observe_idle(obs)
                    self._guard_carry(obs)
            self.phase = 'concurrent' if self.active is not None else 'pickup'
        except (KeyError, ValueError, AssertionError, TypeError, IndexError, AttributeError) as exc:
            self.failure = self.failure or str(exc)
        if self.failure:
            action[:] = 0
            self.xy_speed[:] = 0
            self.yaw_speed = 0.
            self.phase = 'stopped'
        self.debug = dict(step=self.step, phase=self.phase, failure=self.failure,
            active_robot=self.active, idle_robot=self.idle, activation_step=self.activation_step,
            local_step=self.local_step, idle_mode=self.mode, idle_reference=None if self.reference is None else self.reference.tolist(),
            initial_search_direction=self.sign, initial_heading_error=self.heading_error,
            idle_yaw_requested_rad_s=self.yaw_speed, idle_xy_body_m_s=self.xy_speed.tolist(),
            carry_hold_step=self.carry_step, parent_debug=parent_debug,
            parent_proposed_action=None if parent_action is None else parent_action.tolist(),
            detected_streak=self.detected, centered_streak=self.centered, lost_streak=self.lost,
            postcarry_open_streak=self.open_streak, checkpoint_is_frozen=True, new_network_training=False)
        return action.astype(np.float32)
