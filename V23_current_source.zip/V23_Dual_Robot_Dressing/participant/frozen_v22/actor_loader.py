"""Select a byte-identical actor, with no observation or action adapter."""
from pathlib import Path
import inspect


def load_actor(root, variant, device=None):
    root=Path(root).resolve()
    from frozen_pickup import policy as parent
    assert Path(inspect.getfile(parent)).resolve()==root/'frozen_pickup/policy.py'
    if variant=='v6':
        cls=parent.Policy
    elif variant=='v22':
        import policy, detector, geometry
        for module,name in [(policy,'policy.py'),(detector,'detector.py'),(geometry,'geometry.py')]:
            assert Path(inspect.getfile(module)).resolve()==root/name
        cls=policy.Policy
    else:
        raise ValueError(variant)
    return cls(root/'weights/best.pt',device=device)


def model_debug(actor, variant):
    return actor.debug if variant=='v6' else actor.debug['parent_debug']
