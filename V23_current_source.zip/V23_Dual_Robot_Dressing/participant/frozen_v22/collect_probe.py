"""Snapshot then exec this collector copy; original environment and score unchanged."""
import argparse
import fcntl
import os
from pathlib import Path
import shutil
import signal
import sys
import time
from datetime import datetime
from artifacts import read,write,sha,verify_sources,verify_environment,parent_hashes

ROOT=Path(__file__).resolve().parent


def bootstrap(seed, variant):
    plan=read(ROOT/'test_protocol.json')
    assert seed in plan['data_split']['new_test_seeds'] and variant in plan['variants']
    manifest=verify_sources(ROOT);verify_environment(ROOT)
    sim=ROOT.parent/'PhyRC2027本机模拟'
    lock=(sim/'runtime.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=read(ROOT/'pipeline_status.json')
    assert plan['sequence'][len(state['attempts'])]==dict(seed=seed,variant=variant)
    assert Path('/proc',str(state['pipeline_pid'])).exists()
    prior=[a['output'] for a in state['attempts'] if a['seed']==seed]
    assert sorted(str(p.resolve()) for p in ROOT.parent.rglob(f'seed-{seed}'))==sorted(prior),'Unexpected prior scene use'
    assert not any(a['seed']==seed and a['variant']==variant for a in state['attempts'])
    run=ROOT.parent/'视觉抓取MVP/runs'/datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    run.mkdir()
    for name in list(manifest)+['source_sha256.json']:
        dest=run/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,dest)
    write(run/'run_context.json',dict(sim_root=str(sim),release_root=str(ROOT),run_root=str(run)))
    write(run/'process.json',dict(pid=os.getpid(),seeds=[seed],variant=variant,record=False,declared_data_source=plan['variants'][variant]['data_source']))
    os.set_inheritable(lock.fileno(),True)
    env=dict(os.environ,PHYRC_CONCURRENT_PAIR_LOCK_FD=str(lock.fileno()),PYTHONDONTWRITEBYTECODE='1')
    os.execve(sys.executable,[sys.executable,str(run/'collect_probe.py'),'--seed',str(seed),'--variant',variant,'--snapshot'],env)


def execute(seed, variant):
    context=read(ROOT/'run_context.json');sim=Path(context['sim_root'])
    assert ROOT==Path(context['run_root']) and ROOT!=Path(context['release_root'])
    lock=os.fdopen(int(os.environ.pop('PHYRC_CONCURRENT_PAIR_LOCK_FD')),'a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    manifest=verify_sources(ROOT);verify_environment(ROOT)
    plan=read(ROOT/'test_protocol.json');assert seed in plan['data_split']['new_test_seeds']
    model=plan['variants'][variant]
    os.environ.update(PHYRC_PROJECT_ROOT=str(sim),PHYRC_RUNTIME_ROOT=str(sim/'.runtime/DexGarmentLab'),
        PHYRC_OUTPUT_ROOT=str(ROOT),OMNI_KIT_ACCEPT_EULA='YES',ACCEPT_EULA='Y',
        STRETCH4_HEADLESS='1',STRETCH4_SHOW_COLLIDER='0',STRETCH4_RANDOMIZE='1',
        STRETCH4_AUTO_EVALUATE='0',STRETCH4_TRAINING_RECORD='0',STRETCH4_FULL_RECORD='0',
        PHYRC_SOURCE_COMMIT='5ebf2b9b5b391c6e7571d16951bc9f96aa412e7d',PHYRC_SOURCE_DIRTY='1')
    sys.path[:0]=[str(sim/'sitecustomize'),str(sim/'scripts'),str(sim/'.runtime/DexGarmentLab')]
    import sitecustomize
    os.chdir(sim/'.runtime/DexGarmentLab')
    import numpy as np
    from Policy.environment import DressingEnv
    from Policy.evaluation_live import EvaluationSession
    # Environment paths are needed for Isaac imports; actor imports must resolve
    # back to this exact immutable run snapshot, including generic module names.
    sys.path.insert(0,str(ROOT))
    from actor_loader import load_actor,model_debug
    assert Path(sys.modules['actor_loader'].__file__).resolve()==ROOT/'actor_loader.py'
    env=DressingEnv(profile='actor_rgbd',max_episode_steps=1200)
    rates=dict(base_linear_rate=float(env.M.BASE_LINEAR_RATE),base_angular_rate=float(env.M.BASE_ANGULAR_RATE),lift_rate=float(env.M.LIFT_RATE))
    assert rates==dict(base_linear_rate=.616,base_angular_rate=2.86,lift_rate=1.54),rates
    actor=load_actor(ROOT,variant)
    session=EvaluationSession.for_policy(env,ROOT/'evaluation')
    folder=ROOT/f'seed-{seed}';folder.mkdir();(folder/'public_observations').mkdir()
    launch=dict(mode='independent_paired_concurrent_pickup_view',recording_seed=seed,variant=variant,
        declared_data_source=actor.DATA_SOURCE,method=actor.METHOD,checkpoint=str(ROOT/'weights/best.pt'),
        checkpoint_sha256=sha(ROOT/'weights/best.pt'),parent_source_sha256=parent_hashes(ROOT),
        policy_source_sha256=sha(ROOT/model['policy_file']),detector_source_sha256=sha(ROOT/'detector.py'),
        protocol_sha256=sha(ROOT/'test_protocol.json'),collector_sha256=sha(ROOT/'collect_probe.py'),
        source_manifest_sha256=sha(ROOT/'source_sha256.json'),frozen_source_sha256=manifest,
        runtime_rates=rates,actor_inputs='public RGB-D/valid and controlled robot own state only',
        training_demonstration_approval=False,no_new_network_training=True)
    write(folder/'launch.json',launch)
    stopped={'requested':False}
    def request_stop(*_):stopped['requested']=True
    signal.signal(signal.SIGINT,request_stop);signal.signal(signal.SIGTERM,request_stop)
    trace=[];start=time.monotonic()
    try:
        obs,info=env.reset(seed=seed);session.start(dict(launch,seed=seed))
        for step in range(1,1201):
            action=actor(obs)
            row=dict(step=step,simulation_time_s=float(obs['simulation_time_s']),
                base_pose_world=obs['base_pose_world'].tolist(),grasp_position_base=obs['grasp_pose_base'][:,:3].tolist(),
                gripper_close_command=obs['gripper_close_command'].tolist(),fingertip_origin_distance=obs['fingertip_origin_distance'].tolist(),
                action=action.tolist(),policy_debug=actor.debug,model_debug=model_debug(actor,variant))
            obs,_,terminated,truncated,info=env.step(action);trace.append(row)
            if not session.active:raise RuntimeError('Original scoring measurement unexpectedly stopped')
            if step%10==0:
                np.savez_compressed(folder/'public_observations'/f'{step:05d}.npz',**obs)
                write(folder/'progress.json',dict(pid=os.getpid(),step=step,variant=variant,phase=actor.debug.get('phase'),active=actor.debug.get('active_robot',actor.debug.get('robot')),idle=actor.debug.get('idle_robot'),idle_mode=actor.debug.get('idle_mode'),failure=actor.debug.get('failure')))
                print('[Paired pickup/view]',variant,seed,step,actor.debug.get('phase'),actor.debug.get('failure'),flush=True)
            if terminated or truncated or stopped['requested'] or (ROOT/'STOP').exists():break
        interrupted=stopped['requested'] or (ROOT/'STOP').exists()
        evaluation=session.finish(reason='operator_stop' if interrupted else 'policy_horizon')
        write(folder/'trace.json',trace)
        result=dict(variant=variant,seed=seed,steps=len(trace),wall_seconds=time.monotonic()-start,policy_debug=actor.debug,evaluation=evaluation,interrupted=bool(interrupted))
        write(folder/'result.json',result);write(ROOT/'summary.json',[result])
    except BaseException:
        import traceback
        write(folder/'partial_trace.json',trace)
        (ROOT/'error.txt').write_text(traceback.format_exc())
        env.M.simulation_app.close(exit_code=1)
        raise
    finally:
        env.close();lock.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int,required=True);parser.add_argument('--variant',choices=['v6','v22'],required=True);parser.add_argument('--snapshot',action='store_true');args=parser.parse_args()
    execute(args.seed,args.variant) if args.snapshot else bootstrap(args.seed,args.variant)
