"""Non-actor snapshot identity and atomic report helpers."""
import hashlib
import json
from pathlib import Path


def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, value):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)


def verify_sources(root):
    root=Path(root)
    manifest=read(root/'source_sha256.json')
    for name,digest in manifest.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha(root/name)==digest,name
    return manifest


def verify_environment(root):
    audit=read(Path(root)/'environment_audit.json')
    assert len(audit['files_sha256'])==86
    for name,digest in audit['files_sha256'].items():assert sha(name)==digest,name
    sim=Path(audit['sim_root'])
    assert sha(sim/'config/policy_interface.json')==sha(Path(root)/'policy_interface_snapshot.json')
    assert sha(sim/'src/DexGarmentLab/Policy/contract.py')==sha(Path(root)/'contract_snapshot.py')


def parent_hashes(root):
    return {str(p.relative_to(root)):sha(p) for p in sorted((Path(root)/'frozen_pickup').rglob('*')) if p.is_file() and p.suffix in ('.py','.json')}
