"""Identical HDF5/live preprocessing. No simulator imports or hidden labels."""
import cv2
import json
from pathlib import Path
import numpy as np

CAMERAS=('overview','robot_0_wrist','robot_1_wrist','robot_0_head','robot_1_head')
DEPTH_MAX=np.array([10.,3.,3.,5.,5.],dtype=np.float32)
RAW_PROPRIO={'joint_position':26,'base_pose_world':14,'grasp_pose_base':14,
             'fingertip_origin_distance':2,'gripper_close_command':2,'simulation_time_s':1}
# V3 does not expose absolute base pose, virtual base joints, action history or
# post-start clock to the neural network. Base poses only transform measured
# RGB-D points between the robots' frames. There is no scene-state lookup.
PROPRIO={'joint_position':20,'grasp_pose_base':14,
         'fingertip_origin_distance':2,'gripper_close_command':2,'simulation_time_s':1}
ROBOT_DIM=sum(PROPRIO.values())
GEOMETRY_DIM=61
STATE_DIM=ROBOT_DIM+GEOMETRY_DIM
CALIBRATION=json.loads(Path(__file__).with_name('calibration.json').read_text())
HEAD=np.asarray(CALIBRATION['base_from_head_optical'])

def rotation(q):
    q=np.asarray(q,dtype=float);norm=np.linalg.norm(q)
    if norm<1e-8:return np.eye(3)  # synthetic interface fixtures only
    w,x,y,z=q/norm
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                     [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                     [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])

def geometry(rgb,depth,valid,obs):
    """61 explicit visual features, all from public images and static optics.

    Five camera color/depth summaries (20), two head point clouds (24), and a
    shared, currently visible edge estimate in both robot frames (17).
    No temporal target memory, hand-coded action, phase or teacher fallback.
    """
    camera=[];heads=[];candidates=[]
    for i in range(5):
        color=rgb[i].astype(np.float32);z=depth[i,...,0]
        mask=(color[...,2]>1.25*color[...,0])&(color[...,2]>1.25*color[...,1])&(color[...,2]>100)
        mask &= valid[i,...,0]&np.isfinite(z)&(z>.03)
        n,labels,stats,_=cv2.connectedComponentsWithStats(mask.astype(np.uint8),connectivity=8)
        if n>1:
            best=1+int(np.argmax(stats[1:,cv2.CC_STAT_AREA]));v,u=np.where(labels==best)
        else:v,u=np.array([],int),np.array([],int)
        h,w=z.shape
        if len(v)>=30:
            camera.extend([len(v)/(h*w),float(np.median(u))/w,float(np.median(v))/h,float(np.median(z[v,u]))])
        else:camera.extend([0.]*4)
        if i<3:continue
        record=np.zeros(12,np.float32)
        if len(v)>=60:
            f=w/(2*np.tan(np.deg2rad(CALIBRATION['fov_degrees']/2)))
            cloud=np.c_[(u-w/2)*z[v,u]/f,(v-h/2)*z[v,u]/f,z[v,u]]
            cloud=cloud@HEAD[:3,:3].T+HEAD[:3,3]
            cloud=cloud[np.isfinite(cloud).all(1)&(cloud[:,0]>.2)]
            if len(cloud)>=60:
                center=np.median(cloud,axis=0);front=np.percentile(cloud[:,0],8)
                band=cloud[(cloud[:,0]>=front)&(cloud[:,0]<=front+.07)]
                if len(band)>=10:
                    edge=np.median(band,axis=0)
                    record=np.r_[1.,len(cloud)/(h*w),edge,center,
                                 np.percentile(cloud,90,axis=0)-np.percentile(cloud,10,axis=0),
                                 np.arctan2(edge[1],edge[0])]
                    candidates.append((np.linalg.norm(center[:2]),i-3,edge))
        heads.extend(record)
    shared=np.zeros(17,np.float32)
    if candidates:
        _,r,edge=min(candidates,key=lambda x:x[0]);poses=np.asarray(obs['base_pose_world']).reshape(2,7)
        world=rotation(poses[r,3:])@edge+poses[r,:3]
        local=np.stack([rotation(pose[3:]).T@(world-pose[:3]) for pose in poses])
        error=local-np.asarray(obs['grasp_pose_base']).reshape(2,7)[:,:3]
        distances=np.linalg.norm(local[:,:2],axis=1);nearest=np.eye(2)[int(np.argmin(distances))]
        shared=np.r_[1.,local.reshape(-1),error.reshape(-1),distances,nearest]
    out=np.r_[camera,heads,shared].astype(np.float32)
    if len(out)!=GEOMETRY_DIM or not np.isfinite(out).all():raise ValueError('Invalid public visual geometry')
    return out

def pack(obs,size=128):
    if 'rgb' in obs:
        rgb,depth,valid=obs['rgb'],obs['depth'],obs['depth_valid']
    else:
        rgb=np.stack([obs[c+'_rgb'] for c in CAMERAS])
        depth=np.stack([obs[c+'_depth'] for c in CAMERAS])
        valid=np.stack([obs[c+'_depth_valid'] for c in CAMERAS])
    if rgb.ndim!=4 or rgb.shape[0]!=5 or rgb.shape[-1]!=3 or rgb.dtype!=np.uint8:
        raise ValueError('Expected five uint8 RGB camera images')
    if depth.shape!=(*rgb.shape[:3],1) or valid.shape!=depth.shape or valid.dtype!=bool:
        raise ValueError('Expected matching metric depth and boolean validity masks')
    images=[]
    for i in range(5):
        ok=valid[i,...,0] & np.isfinite(depth[i,...,0]) & (depth[i,...,0]>0)
        z=np.where(ok,depth[i,...,0],0).clip(0,DEPTH_MAX[i])/DEPTH_MAX[i]
        color=cv2.resize(rgb[i],(size,size),interpolation=cv2.INTER_AREA).astype(np.float32)/255.
        z=cv2.resize(z,(size,size),interpolation=cv2.INTER_NEAREST)
        mask=cv2.resize(ok.astype(np.float32),(size,size),interpolation=cv2.INTER_NEAREST)
        images.append(np.concatenate((color,z[...,None],mask[...,None]),axis=-1).transpose(2,0,1))
    state=[]
    for key,count in RAW_PROPRIO.items():
        value=np.asarray(obs[key],np.float32).reshape(-1)
        if len(value)!=count or not np.isfinite(value).all():
            raise ValueError('Invalid public robot state: '+key)
        if key=='base_pose_world':continue
        if key=='joint_position':value=value.reshape(2,13)[:,3:].reshape(-1)
        if key=='simulation_time_s':value=np.minimum(value,3.)
        state.append(value)
    state.append(geometry(rgb,depth,valid,obs))
    return np.stack(images).astype(np.float32),np.concatenate(state)

def selected_keys():
    return list(RAW_PROPRIO)+[c+'_'+k for c in CAMERAS for k in ('rgb','depth','depth_valid')]
