"""Learned goal-conditioned lift. Goals come from the wrapper's public RGB-D.

This specialist predicts only lift and extension commands after gripper settling.
It has no simulator, score, seed, cloth truth, or phase-to-action lookup.
"""
import numpy as np
import torch
from torch import nn


class LiftNet(nn.Module):
    def __init__(self, width=64):
        super().__init__()
        # Factor the physically separate axes so correlated expert trajectories
        # cannot make horizontal position a shortcut for lift progress.
        self.extension = nn.Linear(1, 1, bias=False)
        self.vertical = nn.Sequential(nn.Linear(1, width), nn.Tanh(),
                                      nn.Linear(width, width), nn.Tanh(), nn.Linear(width, 1))
        self.register_buffer('input_scale', torch.tensor([.025, .55]))
        # Output order: arm extension, vertical lift; original action units.
        self.register_buffer('output_scale', torch.tensor([.16 / 1.21, .16 / 1.54]))

    def forward(self, error_xz):
        inputs = (error_xz / self.input_scale).clamp(-5, 5)
        raw = torch.cat((self.extension(inputs[..., :1]), self.vertical(inputs[..., 1:])), dim=-1)
        return torch.tanh(raw) * self.output_scale


def public_error(obs, local_surface, robot):
    grasp = np.asarray(obs['grasp_pose_base']).reshape(2, 7)[robot, :3]
    target = np.asarray(local_surface)
    value = np.array([target[0] - grasp[0], target[2] + .55 - grasp[2]], np.float32)
    if not np.isfinite(value).all():
        raise ValueError('Nonfinite public visual goal error')
    return value


class LiftPolicy:
    def __init__(self, saved):
        if saved['format'] != 'phyrc-hybrid-lift-v5' or saved.get('lift_training_steps', 0) < 1:
            raise ValueError('A trained v5 lift specialist is required')
        self.model = LiftNet(saved['lift_config']['width'])
        self.model.load_state_dict(saved['lift_model'])
        self.model.eval()  # Tiny specialist stays on CPU; visual network uses its normal device.

    @torch.inference_mode()
    def __call__(self, obs, local_surface, robot):
        error = public_error(obs, local_surface, robot)
        prediction = self.model(torch.from_numpy(error)[None])[0].numpy()
        if not np.isfinite(prediction).all():
            raise ValueError('Nonfinite lift prediction')
        return prediction, error
