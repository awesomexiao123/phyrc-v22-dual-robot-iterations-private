import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch
from .features import pack,selected_keys,PROPRIO,STATE_DIM

SIM=Path(__file__).resolve().parents[2]/'PhyRC2027本机模拟'
sys.path.insert(0,str(SIM/'src/DexGarmentLab'))
from Policy.dataset_reader import PolicyDataset

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

class Chunks(torch.utils.data.Dataset):
    def __init__(self,manifest,cfg,split,cache_dir=None):
        self.cfg=cfg;self.readers=[];self.windows=[];self.episode_arrays=[];self.prepared=[]
        data=json.loads(Path(manifest).read_text());self.manifest=data
        if data['purpose'] not in ('human-demonstration-training','visual-controller-demonstration-training','synthetic-interface-test'):
            raise ValueError('Declare supported demonstration data provenance')
        identities={};sources=set()
        for entry in data['datasets']:
            path=Path(entry['path']);path=path if path.is_absolute() else Path(manifest).parent/path
            if entry['split'] not in ('train','validation'):raise ValueError('Invalid split')
            identity=digest(path)
            if identity!=entry['sha256']:raise ValueError('Dataset changed after indexing')
            if identity in identities:raise ValueError('Duplicate capture: do not leak episodes across splits')
            identities[identity]=entry['split'];sources.add(entry['split'])
            if entry['split']!=split:continue
            reader=PolicyDataset(path,observation_keys=selected_keys());rid=len(self.readers);self.readers.append(reader)
            self.prepared.append(self.prepare(reader,identity,cache_dir,self.cfg) if cache_dir else None)
            episodes={}
            for index,(name,t) in enumerate(reader.index):episodes.setdefault(name,[]).append(index)
            for name,indices in episodes.items():
                self.episode_arrays.append((rid,indices))
                self.windows.extend((rid,indices,t) for t in range(len(indices)))
        if sources!={'train','validation'} or not self.windows:raise ValueError('Both independent train and validation captures are required')

    def __len__(self):return len(self.windows)

    @staticmethod
    def prepare(reader,identity,cache_dir,cfg):
        # Cache exactly the live preprocessing, retaining float32 precision.
        # Only the public reader is used; no audit labels or simulator state.
        import inspect
        from . import features
        version=hashlib.sha256((inspect.getsource(features)+json.dumps(features.CALIBRATION,sort_keys=True)).encode()).hexdigest()[:16]
        folder=Path(cache_dir)/f'{identity}-{cfg["image_size"]}-{version}'
        folder.mkdir(parents=True,exist_ok=True);ready=folder/'ready.json'
        shapes={'images':(len(reader),5,5,cfg['image_size'],cfg['image_size']),
                'state':(len(reader),STATE_DIM),'actions':(len(reader),2,9)}
        if not ready.exists():
            arrays={k:np.lib.format.open_memmap(folder/(k+'.npy'),mode='w+',dtype=np.float32,shape=s)
                    for k,s in shapes.items()}
            for i in range(len(reader)):
                obs,action=reader[i];images,state=pack(obs,cfg['image_size'])
                arrays['images'][i]=images;arrays['state'][i]=state;arrays['actions'][i]=action.reshape(2,9)
                if i%200==0:print('Preparing public observations',Path(reader.path).parent,i,'/',len(reader),flush=True)
            for array in arrays.values():array.flush()
            del arrays
            ready.write_text(json.dumps(dict(dataset_sha256=identity,frames=len(reader),preprocessor=version)))
        result={k:np.load(folder/(k+'.npy'),mmap_mode='r') for k in shapes}
        if any(result[k].shape!=s or result[k].dtype!=np.float32 for k,s in shapes.items()):
            raise ValueError('Prepared observation cache is incomplete or has the wrong shape')
        return result

    def __getitem__(self,index):
        rid,indices,t=self.windows[index];reader=self.readers[rid];cfg=self.cfg
        prepared=self.prepared[rid]
        if prepared is not None:
            history=[indices[max(0,t-back*cfg['history_stride'])] for back in reversed(range(cfg['history']))]
            future=[indices[min(t+ahead,len(indices)-1)] for ahead in range(cfg['chunk'])]
            return (torch.from_numpy(prepared['images'][history].copy()),
                    torch.from_numpy(prepared['state'][history].copy()),
                    torch.from_numpy(prepared['actions'][future].copy()),
                    torch.tensor([float(t+k<len(indices)) for k in range(cfg['chunk'])],dtype=torch.float32))
        frames=[]
        for back in reversed(range(cfg['history'])):
            obs,_=reader[indices[max(0,t-back*cfg['history_stride'])]]
            frames.append(pack(obs,cfg['image_size']))
        actions=[];mask=[]
        for ahead in range(cfg['chunk']):
            _,act=reader[indices[min(t+ahead,len(indices)-1)]]
            actions.append(act.reshape(2,9));mask.append(float(t+ahead<len(indices)))
        return (torch.from_numpy(np.stack([x[0] for x in frames])),
                torch.from_numpy(np.stack([x[1] for x in frames])),
                torch.from_numpy(np.stack(actions)),torch.tensor(mask,dtype=torch.float32))

    def statistics(self):
        # Read low-dimensional arrays only. No camera decoding or audit access.
        import h5py
        total=None;square=None;n=0;classes=np.ones(3,dtype=np.float64);motion_max=np.zeros((2,8),np.float32)
        for rid,reader in enumerate(self.readers):
            prepared=self.prepared[rid]
            states=(np.asarray(prepared['state'],dtype=np.float64) if prepared is not None
                    else np.stack([pack(reader[i][0],self.cfg['image_size'])[1] for i in range(len(reader))]).astype(np.float64))
            if not np.isfinite(states).all():raise ValueError('Nonfinite training state')
            total=states.sum(0) if total is None else total+states.sum(0)
            square=(states**2).sum(0) if square is None else square+(states**2).sum(0);n+=len(states)
            with h5py.File(reader.path,'r') as f:
                for demo in f['data'].values():
                    for start in range(0,len(demo['actions']),4096):
                        action=np.asarray(demo['actions'][start:start+4096]).reshape(-1,2,9)
                        motion_max=np.maximum(motion_max,np.abs(action[...,:8]).max(0))
                        grip=action[...,8]
                        labels=np.where(grip<-.5,0,np.where(grip>.5,2,1))
                        classes+=np.bincount(labels.reshape(-1),minlength=3)
        mean=total/n;std=np.sqrt(np.maximum(square/n-mean**2,0)).clip(.01)
        weights=np.sqrt(classes.sum()/classes);weights/=weights.mean()
        self.motion_active=(motion_max>1e-6).astype(np.float32)
        self.motion_scale=np.where(self.motion_active>0,np.maximum(motion_max,.01),1.).astype(np.float32)
        return mean.astype('float32'),std.astype('float32'),weights.astype('float32')

    def sampling_weights(self,transition_weight=6.):
        # Give decision boundaries weight using recorded public action changes,
        # never teacher phase metadata, scores, or hidden simulator labels.
        import h5py
        weights=np.ones(len(self.windows),np.float64);offset=0
        for rid,indices in self.episode_arrays:
            reader=self.readers[rid];name=reader.index[indices[0]][0]
            with h5py.File(reader.path,'r') as f:
                actions=np.asarray(f['data'][name]['actions']).reshape(-1,2,9)
            delta=np.abs(np.diff(actions[...,:8]/self.motion_scale,axis=0)).max(axis=(1,2))
            grip=np.any(np.diff(actions[...,8],axis=0)!=0,axis=1)
            boundaries=np.flatnonzero((delta>.2)|grip)+1
            important=np.zeros(len(indices),bool);important[:40]=True
            for i in boundaries:important[max(0,i-5):min(len(indices),i+6)]=True
            weights[offset:offset+len(indices)]=np.where(important,transition_weight,1.)
            offset+=len(indices)
        assert offset==len(weights)
        return weights

    def close(self):
        for reader in self.readers:reader.close()
        self.prepared.clear()
