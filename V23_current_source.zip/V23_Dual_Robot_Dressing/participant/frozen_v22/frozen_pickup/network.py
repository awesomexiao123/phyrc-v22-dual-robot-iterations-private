"""Deterministic chunked BC transformer; not a full ACT/CVAE implementation."""
import torch
from torch import nn
from .features import STATE_DIM,ROBOT_DIM

class ChunkPolicy(nn.Module):
    def __init__(self,cfg):
        super().__init__();self.cfg=dict(cfg);d=cfg['width'];h=cfg['history'];k=cfg['chunk']
        self.cnn=nn.Sequential(nn.Conv2d(5,24,5,2,2),nn.GroupNorm(4,24),nn.SiLU(),
            nn.Conv2d(24,48,3,2,1),nn.GroupNorm(8,48),nn.SiLU(),
            nn.Conv2d(48,64,3,2,1),nn.GroupNorm(8,64),nn.SiLU(),
            nn.AdaptiveAvgPool2d((2,2)))
        self.visual=nn.Linear(64,d);self.state=nn.Linear(STATE_DIM,d)
        self.position=nn.Parameter(torch.randn(1,h*21,d)*.02)
        enc=nn.TransformerEncoderLayer(d,cfg['heads'],d*4,cfg['dropout'],batch_first=True)
        dec=nn.TransformerDecoderLayer(d,cfg['heads'],d*4,cfg['dropout'],batch_first=True)
        self.encoder=nn.TransformerEncoder(enc,cfg['layers'],enable_nested_tensor=False)
        self.decoder=nn.TransformerDecoder(dec,cfg['layers'])
        self.queries=nn.Parameter(torch.randn(1,k,d)*.02)
        self.motion=nn.Linear(d,16);self.grip=nn.Linear(d,6)
        self.register_buffer('state_mean',torch.zeros(STATE_DIM))
        self.register_buffer('state_std',torch.ones(STATE_DIM))
        self.register_buffer('motion_active',torch.ones(2,8))
        self.register_buffer('motion_scale',torch.ones(2,8))

    def forward(self,images,state):
        b,h,c,channels,height,width=images.shape
        tokens=self.cnn(images.reshape(b*h*c,channels,height,width))
        tokens=self.visual(tokens.flatten(2).transpose(1,2)).reshape(b,h,20,-1)
        normalized=((state-self.state_mean)/self.state_std).clamp(-10,10)
        if self.training:
            # Robot-only noise weakens tiny state differences as a replacement
            # for looking at the garment. Actual action labels stay untouched.
            normalized=normalized.clone()
            normalized[:,:,:ROBOT_DIM-1]+=torch.randn_like(normalized[:,:,:ROBOT_DIM-1])*self.cfg.get('robot_state_noise',.05)
        proprio=self.state(normalized)[:,:,None,:]
        memory=self.encoder(torch.cat((tokens,proprio),dim=2).reshape(b,h*21,-1)+self.position)
        prediction=self.decoder(self.queries.expand(b,-1,-1),memory)
        return self.motion(prediction).tanh().reshape(b,-1,2,8)*self.motion_scale*self.motion_active,self.grip(prediction).reshape(b,-1,2,3)

def loss(prediction,actions,mask,grip_weight=.5,class_weights=None,motion_scale=None,motion_active=None):
    motion,grip=prediction
    scale=torch.ones_like(motion[0,0]) if motion_scale is None else motion_scale
    active=torch.ones_like(scale) if motion_active is None else motion_active
    continuous=(((motion-actions[...,:8])/scale.clamp_min(.01)).abs()*active).sum(dim=(-1,-2))/active.sum().clamp_min(1)
    labels=torch.where(actions[...,8]<-.5,0,torch.where(actions[...,8]>.5,2,1)).long()
    ce=nn.functional.cross_entropy(grip.reshape(-1,3),labels.reshape(-1),
                                  weight=class_weights,reduction='none').reshape(*mask.shape,2).mean(-1)
    denom=mask.sum().clamp_min(1)
    return ((continuous+grip_weight*ce)*mask).sum()/denom
