"""Declared hybrid: visual approach and newly trained goal-conditioned lift.

V3 visual weights remain fixed; a separate lift network is trained. Public RGB-D and own state only. No score,
seed, object truth, dynamic camera transform, or hidden attachment feedback.
"""
import numpy as np
import cv2
import torch
from .features import CALIBRATION,HEAD,CAMERAS,rotation
from .neural_policy import Policy as NeuralPolicy
from .execution import GripperExecution
from .lift import LiftPolicy

class Policy:
    DATA_SOURCE='hybrid-learned-policy'
    METHOD='frozen v3 visual approach + trained goal-conditioned lift specialist + declared public RGB-D contact/search and gripper rules'

    def __init__(self,checkpoint,device=None,*,allow_test=False):
        self.neural=NeuralPolicy(checkpoint,device=device,allow_test=allow_test)
        self.lift=LiftPolicy(torch.load(checkpoint,map_location='cpu',weights_only=True))
        self.reset()

    def reset(self):
        self.neural.reset();self.execution=GripperExecution(30)
        self.phase='startup';self.tick=0;self.phase_steps=0;self.robot=None
        self.target_world=None;self.stable=0;self.debug={};self.failure=None

    def change(self,phase):
        self.phase=phase;self.phase_steps=0;self.stable=0
        if phase in ('neural_approach','neural_lift'):self.neural.reset()

    @staticmethod
    def cloud(obs,r):
        i=3+r
        color=np.asarray(obs['rgb'][i] if 'rgb' in obs else obs[CAMERAS[i]+'_rgb'],np.float32)
        depth=np.asarray(obs['depth'][i] if 'depth' in obs else obs[CAMERAS[i]+'_depth'])[...,0]
        valid=np.asarray(obs['depth_valid'][i] if 'depth_valid' in obs else obs[CAMERAS[i]+'_depth_valid'])[...,0]
        mask=(color[...,2]>1.25*color[...,0])&(color[...,2]>1.25*color[...,1])&(color[...,2]>100)
        mask &= valid&np.isfinite(depth)&(depth>.03)
        n,labels,stats,_=cv2.connectedComponentsWithStats(mask.astype(np.uint8),connectivity=8)
        if n<2:return np.empty((0,3))
        v,u=np.where(labels==1+int(np.argmax(stats[1:,cv2.CC_STAT_AREA])))
        if len(v)<30:return np.empty((0,3))
        h,w=depth.shape;f=w/(2*np.tan(np.deg2rad(CALIBRATION['fov_degrees']/2)))
        pts=np.c_[(u-w/2)*depth[v,u]/f,(v-h/2)*depth[v,u]/f,depth[v,u]]
        pts=pts@HEAD[:3,:3].T+HEAD[:3,3]
        return pts[np.isfinite(pts).all(1)&(pts[:,0]>.2)]

    @staticmethod
    def world(obs,p,r):
        pose=np.asarray(obs['base_pose_world']).reshape(2,7)[r]
        return rotation(pose[3:])@p+pose[:3]

    def local(self,obs):
        pose=np.asarray(obs['base_pose_world']).reshape(2,7)[self.robot]
        return rotation(pose[3:]).T@(self.target_world-pose[:3])

    def locate(self,obs):
        candidates=[]
        for r in range(2):
            pts=self.cloud(obs,r)
            if len(pts)<60:continue
            front=np.percentile(pts[:,0],8);band=pts[(pts[:,0]>=front)&(pts[:,0]<=front+.07)]
            if len(band)<10:continue
            candidates.append((np.linalg.norm(np.median(pts,axis=0)[:2]),r,np.median(band,axis=0)))
        if not candidates:return False
        _,observer,edge=min(candidates,key=lambda item:item[0])
        self.target_world=self.world(obs,edge,observer)
        poses=np.asarray(obs['base_pose_world']).reshape(2,7)
        distances=np.linalg.norm(poses[:,:2]-self.target_world[:2],axis=1);nearest=int(np.argmin(distances))
        self.robot=nearest if distances[nearest]+.25<distances[observer] else observer
        return True

    def __call__(self,obs):
        self.tick+=1;self.phase_steps+=1
        executed_phase=self.phase;lift_prediction=None;lift_error=None
        # Raw neural proposals cannot arm a guard on a suppressed close.
        proposed=self.neural(obs)
        action=np.zeros((2,9),np.float32)
        grip=np.asarray(obs['grasp_pose_base']).reshape(2,7)
        closed=np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
        if self.phase=='startup':
            action[:,8]=-1
            if self.phase_steps>=24:self.change('search')
        elif self.phase=='search':
            if self.locate(obs):
                target=self.local(obs)
                self.change('view_align' if abs(np.arctan2(target[1],target[0]))>.22 else 'neural_approach')
            else:action[:,2]=(-.12,.12)
        elif self.phase=='view_align':
            target=self.local(obs);error=np.arctan2(target[1],target[0])+.08
            action[self.robot,2]=np.clip(1.5*error,-.35,.35)/3.146
            if abs(error)<.03:self.change('search')
        elif self.phase=='neural_approach':
            r=self.robot;action[r]=proposed[r]
            # Tiny regression noise and inactive-robot motion are suppressed.
            action[r,:8]=np.where(np.abs(action[r,:8])<.002,0.,action[r,:8])
            if self.phase=='neural_approach' and action[r,8]>.5 and not closed[r]:
                pts=self.cloud(obs,r)
                if len(pts)>=40:
                    self.target_world[2]=float(np.median([self.world(obs,p,r)[2] for p in pts]))
                    self.change('refine_raise')
                else:
                    self.failure='Cannot visually verify contact surface at requested close';self.change('stopped')
                action[:]=0
        elif self.phase=='neural_lift':
            r=self.robot
            lift_prediction,lift_error=self.lift(obs,self.local(obs),r)
            # Lift-only labels supervise extension and vertical motion. The
            # base and wrist stay fixed, matching the teacher's lift phase.
            action[r,4],action[r,3]=lift_prediction
            if grip[r,2]>=self.local(obs)[2]+.55-.012:
                action[:]=0;self.change('hold')
        elif self.phase.startswith('refine_'):
            r=self.robot;target=self.local(obs);error=target-grip[r,:3]
            tilt=np.arccos(np.clip(rotation(np.asarray(obs['base_pose_world']).reshape(2,7)[r,3:])[2,2],-1,1))
            if tilt>.025:
                self.failure='Public base tilt during contact refinement';self.change('stopped')
            elif self.phase=='refine_raise':
                action[r,3]=np.clip(2.5*(error[2]+.12),-.08,.08)/1.54
                if abs(error[2]+.12)<.006:self.change('refine_align')
            elif self.phase=='refine_align':
                # Correct lateral error at a safe height, and forward error
                # only if the target is outside comfortable arm reach.
                action[r,3]=np.clip(2.5*(error[2]+.12),-.06,.06)/1.54
                action[r,1]=np.clip(1.5*error[1],-.03,.03)/.616
                forward=target[0]-.78 if not .60<target[0]<.90 else 0.
                action[r,0]=np.clip(1.5*forward,-.06,.06)/.616
                if abs(error[1])<.008 and abs(forward)<.012:
                    action[r,:2]=0;self.change('refine_extend')
            elif self.phase=='refine_extend':
                action[r,3]=np.clip(2.5*(error[2]+.12),-.08,.08)/1.54
                action[r,4]=np.clip(2.5*error[0],-.08,.08)/1.21
                if abs(error[0])<.003 and abs(error[2]+.12)<.006:self.change('refine_descend')
            elif self.phase=='refine_descend':
                ez=error[2]+.024;speed=.012 if abs(ez)<.03 else .045
                action[r,3]=np.clip(2.5*ez,-speed,speed)/1.54
                action[r,4]=np.clip(2.5*error[0],-.045,.045)/1.21
                self.stable=self.stable+1 if max(abs(error[0]),abs(ez))<.003 and abs(error[1])<.02 else 0
                if self.stable>=5:action[:]=0;self.change('close_wait')
        elif self.phase=='close_wait':
            action[self.robot,8]=1
        # The guard reads the final action sent to the unmodified environment.
        action=self.execution.apply(obs,action)
        if self.phase=='close_wait' and closed[self.robot] and self.execution.stable[self.robot]>=30:
            self.change('neural_lift')
        limit=700 if self.phase=='neural_approach' else 400
        if self.phase not in ('startup','hold','stopped') and self.phase_steps>limit:
            self.failure='Public feedback phase exceeded its finite step limit';self.change('stopped');action[:]=0
        self.debug=dict(method=self.METHOD,phase=self.phase,phase_steps=self.phase_steps,robot=self.robot,
                        executed_phase=executed_phase,
                        lift_specialist_action=None if lift_prediction is None else lift_prediction.tolist(),
                        lift_goal_error_xz=None if lift_error is None else lift_error.tolist(),
                        target_world_from_rgbd=None if self.target_world is None else self.target_world.tolist(),
                        target_base_from_rgbd=None if self.target_world is None else self.local(obs).tolist(),
                        failure=self.failure,raw_neural_action=proposed.tolist())
        if not np.isfinite(action).all():raise ValueError('Nonfinite hybrid action')
        return np.clip(action,-1,1).astype(np.float32)

def load_policy(checkpoint,observation_space,action_space):
    if tuple(action_space.shape)!=(2,9):raise ValueError('Expected two robots with nine actions each')
    return Policy(checkpoint)
