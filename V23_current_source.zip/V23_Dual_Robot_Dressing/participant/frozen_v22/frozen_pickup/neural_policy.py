from collections import deque
from pathlib import Path
import numpy as np
import torch
from .features import pack
from .network import ChunkPolicy
from .execution import GripperExecution

class Policy:
    def __init__(self,checkpoint,device=None,*,allow_test=False):
        if not checkpoint or not Path(checkpoint).is_file():
            raise ValueError('A trained checkpoint is required; no random-motion fallback')
        self.device=torch.device(device or ('cuda' if torch.cuda.is_available() else 'cpu'))
        saved=torch.load(checkpoint,map_location='cpu',weights_only=True)
        if saved.get('format')!='phyrc-hybrid-lift-v5':raise ValueError('Wrong checkpoint format; use its frozen implementation')
        if saved.get('purpose') not in ('human-demonstration-training','visual-controller-demonstration-training') and not allow_test:
            raise ValueError('Synthetic/interface-test weights cannot be used as a competition policy')
        if saved.get('training_steps',0)<1:raise ValueError('Checkpoint has not been trained')
        self.cfg=saved['config'];self.model=ChunkPolicy(self.cfg)
        self.model.load_state_dict(saved['model']);self.model.to(self.device).eval();self.reset()

    def reset(self):
        count=1+(self.cfg['history']-1)*self.cfg['history_stride']
        self.frames=deque(maxlen=count);self.predictions=deque(maxlen=self.cfg['chunk']);self.tick=0
        self.execution=GripperExecution(self.cfg.get('gripper_settle_steps',30))

    @torch.inference_mode()
    def __call__(self,obs):
        frame=pack(obs,self.cfg['image_size'])
        if not self.frames:self.frames.extend([frame]*self.frames.maxlen)
        else:self.frames.append(frame)
        frames=list(self.frames)[::self.cfg['history_stride']]
        images=torch.from_numpy(np.stack([x[0] for x in frames])[None]).to(self.device)
        state=torch.from_numpy(np.stack([x[1] for x in frames])[None]).to(self.device)
        motion,logits=self.model(images,state)
        self.predictions.append((self.tick,motion[0].cpu().numpy(),logits[0].softmax(-1).cpu().numpy()))
        # Only predictions for the CURRENT time are combined. Newer predictions
        # have more weight, and future chunks are never played back blindly.
        votes=[];weights=[];grips=[]
        for start,m,p in self.predictions:
            age=self.tick-start
            if age<len(m):
                votes.append(m[age]);grips.append(p[age]);weights.append(np.exp(-self.cfg['temporal_decay']*age))
        w=np.asarray(weights);w/=w.sum()
        action=np.zeros((2,9),np.float32)
        action[:,:8]=np.sum(np.stack(votes)*w[:,None,None],axis=0)
        action[:,8]=np.argmax(np.sum(np.stack(grips)*w[:,None,None],axis=0),axis=-1)-1
        self.tick+=1
        if not np.isfinite(action).all():raise ValueError('Nonfinite model output')
        # The hybrid wrapper applies its guard only to the actual final action.
        return np.clip(action,-1,1).astype(np.float32)

def load_policy(checkpoint,observation_space,action_space):
    if tuple(action_space.shape)!=(2,9):raise ValueError('Expected two robots with nine actions each')
    for key in ('rgb','depth','depth_valid','previous_action'):
        if key not in observation_space.spaces:raise ValueError('Requires actor_rgbd public observations')
    return Policy(checkpoint)
