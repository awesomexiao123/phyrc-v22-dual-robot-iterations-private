"""Public-state actuator timing guard; no simulator or task-success feedback."""
import numpy as np

class GripperExecution:
    def __init__(self,settle_steps=30):
        self.settle_steps=int(settle_steps)
        self.pending=np.zeros(2,bool);self.stable=np.zeros(2,int)
        self.previous_closed=np.zeros(2,bool)

    def apply(self,obs,proposed):
        action=np.array(proposed,copy=True)
        closed=np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
        gap=np.asarray(obs['fingertip_origin_distance']).reshape(2)
        velocity=np.asarray(obs['joint_velocity']).reshape(2,13)
        for r in range(2):
            if action[r,8]<-.5:
                self.pending[r]=False;self.stable[r]=0
            elif ((action[r,8]>.5 and not closed[r]) or (closed[r] and not self.previous_closed[r])):
                self.pending[r]=True;self.stable[r]=0
            if self.pending[r]:
                quiet=closed[r] and gap[r]<.06 and np.max(np.abs(velocity[r,11:13]))<.05
                self.stable[r]=self.stable[r]+1 if quiet else 0
                if self.stable[r]<self.settle_steps:action[r,:8]=0
                else:self.pending[r]=False
        self.previous_closed=closed.copy()
        return action
