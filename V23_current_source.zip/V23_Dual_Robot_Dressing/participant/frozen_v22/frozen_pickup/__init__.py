"""Public-observation-only action-chunk imitation learning baseline."""
