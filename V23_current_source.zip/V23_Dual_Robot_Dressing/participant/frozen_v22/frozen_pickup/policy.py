"""Frozen v5 pickup followed by a declared, public-state carry preparation rule.

No new network fitting, anatomy/cloth truth, score, scene identifier or reset
changes. The pilot asks whether the garment stays held during slow retraction.
"""
import numpy as np
from .pickup_policy import Policy as PickupPolicy
from .features import rotation


class Policy:
    DATA_SOURCE = 'hybrid-learned-policy'
    METHOD = 'frozen v5 hybrid pickup + declared own-state low-speed loaded-arm retraction and height hold; no new training'

    def __init__(self, checkpoint, device=None, *, allow_test=False):
        self.pickup = PickupPolicy(checkpoint, device=device, allow_test=allow_test)
        self.reset()

    def reset(self):
        self.pickup.reset()
        self.execution = self.pickup.execution
        self.stage = 'pickup'
        self.phase_steps = 0
        self.robot = None
        self.start_grasp = None
        self.goal_x = .52
        self.goal_stable = 0
        self.open_frames = 0
        self.failure = None
        self.debug = {}

    def change(self, phase):
        self.stage = phase
        self.phase_steps = 0
        self.goal_stable = 0

    def __call__(self, obs):
        executed = self.stage
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        grip = np.asarray(obs['grasp_pose_base']).reshape(2, 7)
        pickup_debug = None
        if self.stage == 'pickup':
            action = self.pickup(obs)
            self.robot = self.pickup.robot
            pickup_debug = dict(self.pickup.debug)
            executed = 'pickup:' + pickup_debug.get('executed_phase', self.pickup.phase)
            if self.pickup.failure:
                self.failure = self.pickup.failure
                self.change('stopped')
            elif self.pickup.phase == 'hold':
                self.start_grasp = grip[self.robot, :3].copy()
                self.change('carry_settle')
        elif self.stage not in ('stopped', 'carry_hold'):
            r = self.robot
            closed = bool(np.asarray(obs['gripper_close_command']).reshape(2)[r])
            gap = float(np.asarray(obs['fingertip_origin_distance']).reshape(2)[r])
            pose = np.asarray(obs['base_pose_world']).reshape(2, 7)[r]
            tilt = float(np.arccos(np.clip(rotation(pose[3:])[2, 2], -1, 1)))
            self.open_frames = self.open_frames + 1 if not closed or gap > .08 else 0
            if tilt > .025:
                self.failure = 'Public base tilt during loaded retraction'
            elif self.open_frames >= 5:
                self.failure = 'Public gripper state no longer closed during loaded retraction'
            elif abs(grip[r, 2] - self.start_grasp[2]) > .06:
                self.failure = 'Public grasp height drift during loaded retraction'
            if self.failure:
                self.change('stopped')
            elif self.stage == 'carry_settle':
                if self.phase_steps >= 20:
                    self.change('carry_retract')
            elif self.stage == 'carry_retract':
                ex = self.goal_x - grip[r, 0]
                ez = self.start_grasp[2] - grip[r, 2]
                action[r, 4] = np.clip(1.5 * ex, -.04, 0.) / 1.21
                action[r, 3] = np.clip(2. * ez, -.03, .03) / 1.54
                self.goal_stable = self.goal_stable + 1 if abs(ex) < .006 and abs(ez) < .006 else 0
                if self.goal_stable >= 10:
                    action[:] = 0
                    self.change('carry_hold')
            if self.stage not in ('stopped', 'carry_hold') and self.phase_steps > 260:
                self.failure = 'Public carry preparation exceeded its finite step limit'
                self.change('stopped')
                action[:] = 0
            action = self.execution.apply(obs, action)
        elif self.stage == 'carry_hold':
            action = self.execution.apply(obs, action)
        self.debug = dict(method=self.METHOD,
            phase=('pickup:' + self.pickup.phase) if self.stage == 'pickup' else self.stage,
            executed_phase=executed, phase_steps=self.phase_steps, robot=self.robot,
            failure=self.failure, pickup_debug=pickup_debug,
            carry_start_grasp_base=None if self.start_grasp is None else self.start_grasp.tolist(),
            carry_goal_x_m=self.goal_x,
            carry_retraction_m=None if self.start_grasp is None else float(self.start_grasp[0] - grip[self.robot, 0]),
            carry_height_error_m=None if self.start_grasp is None else float(self.start_grasp[2] - grip[self.robot, 2]),
            new_network_training=False)
        if not np.isfinite(action).all():
            raise ValueError('Nonfinite carry action')
        return np.clip(action, -1, 1).astype(np.float32)


def load_policy(checkpoint, observation_space, action_space):
    if tuple(action_space.shape) != (2, 9):
        raise ValueError('Expected two robots with nine actions each')
    return Policy(checkpoint)
