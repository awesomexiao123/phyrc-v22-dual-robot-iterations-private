"""Public RGB-D hand candidates for this synthetic avatar, with explicit rules.

No model training, seed/scene coordinates, manual pixel injection or anatomical
left/right inference. The detector abstains when the component layout is ambiguous.
"""
import cv2
import numpy as np

CONFIG = dict(red_min=120, red_minus_green_min=4, red_minus_blue_min=7,
              green_minus_blue_range=[-12, 12], hand_area_range=[24, 200],
              face_area_range=[250, 1800], face_hand_vertical_range=[-65, 20],
              hand_pair_distance_range=[12, 100], max_depth_iqr_m=.08,
              min_depth_valid_fraction=.8)


def detect_head(rgb, depth, valid):
    color = np.asarray(rgb).astype(np.int16)
    z = np.asarray(depth).reshape(256, 256)
    validity = np.asarray(valid).reshape(256, 256).astype(bool)
    if color.shape != (256, 256, 3): raise ValueError('Expected public256x256RGB')
    r, g, b = color.transpose(2, 0, 1)
    mask = ((r > CONFIG['red_min']) & (r-g > CONFIG['red_minus_green_min']) &
            (r-b > CONFIG['red_minus_blue_min']) & (g-b < 12) & (g-b > -12))
    n, labels, stats, centers = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    hands, faces = [], []
    for label in range(1, n):
        x, y, w, h, area = [int(v) for v in stats[label]]
        u, v = [float(q) for q in centers[label]]
        item = dict(label=label, u=u, v=v, bbox=[x, y, w, h], area=area)
        if 250 <= area <= 1800 and h >= 20 and w >= 12 and .4 <= w/h <= 1.4:
            faces.append(item)
        if not (24 <= area <= 200 and w >= 5 and h >= 5 and .5 <= w/h <= 2.0): continue
        iu, iv = int(round(u)), int(round(v))
        patch = z[max(0, iv-1):iv+2, max(0, iu-1):iu+2]
        ok = validity[max(0, iv-1):iv+2, max(0, iu-1):iu+2] & np.isfinite(patch) & (patch > .2) & (patch < 4.5)
        if not ok.any() or ok.mean() < .8: continue
        iqr = float(np.percentile(patch[ok], 75)-np.percentile(patch[ok], 25))
        if iqr > .08: continue
        hands.append(dict(item, median_depth_m=float(np.median(patch[ok])), depth_iqr_m=iqr))
    solutions = []
    for face in faces:
        for i, a in enumerate(hands):
            for b in hands[i+1:]:
                delta_a, delta_b = a['u']-face['u'], b['u']-face['u']
                if delta_a*delta_b <= 0 or min(abs(delta_a), abs(delta_b)) < 20: continue
                if max(abs(delta_a), abs(delta_b)) > 170: continue
                dv = (a['v']+b['v'])/2-face['v']
                distance = np.hypot(a['u']-b['u'], a['v']-b['v'])
                if not (-65 <= dv <= 20 and 12 <= distance <= 100): continue
                if max(a['v'], b['v']) > face['bbox'][1]+face['bbox'][3]+12: continue
                solutions.append(dict(face=face, hands=sorted([a, b], key=lambda h: h['v'])))
    # Duplicate face candidates or several pairs are ambiguous; never select using scene truth.
    if len(solutions) != 1:
        return dict(detected=False, reason='no_unique_face_hand_layout', candidate_pairs=len(solutions))
    return dict(detected=True, **solutions[0], candidate_pairs=1,
                reason='unique_color_components_with_relative_face_layout_and_valid_depth')
