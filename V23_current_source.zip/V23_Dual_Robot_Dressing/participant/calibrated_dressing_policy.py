"""Development sequence: far-field trials, carry, fresh staging, contact pulses.

This is a separate experimental controller, not a retrained V22 network or a
claim of full dressing. Every predecessor stage must complete before contact.
"""
from copy import deepcopy

import numpy as np

from calibrated_hypothesis_contact import CalibratedHypothesisContactExperiment
from equilibrium_translation_policy import Policy as TranslationPolicy
from opening_approach_coordinator import OpeningApproachCoordinator
from staging_equilibrium_calibration import StagingEquilibriumCalibration


class Policy(TranslationPolicy):
    VERSION = 'v23_21_calibrated_contact'
    METHOD = ('frozen V22; measured dual pickup and wrist/translation trials; '
              'carry; current RGB-D staging calibration; bounded cloth/hand hypothesis pulses')

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.staging_handoff = None
        self.staging_calibration = None
        self.staging_debug = {}
        self.staging_hand_observer = None
        self.calibrated_contact = None
        self.last_dispatched_time = None
        self.last_dispatched_state = None

    def _create_staging_handoff(self, obs):
        if self.translation_calibration is None:
            raise ValueError('completed_far_field_translation_calibration_required')
        observer = OpeningApproachCoordinator(original_hand_report=self.hands,
            original_observed_at=self.hand_observation_time, stationary_human=True)
        now = float(obs['simulation_time_s'])
        observer._observe_hands(obs, now)
        hands = observer.fresh_hands
        if not hands.get('detected') or hands.get('observation_time_s') != now:
            raise ValueError('current_staging_hand_pair_required')
        self.staging_hand_observer = observer
        return StagingEquilibriumCalibration(obs, hands, now,
            prior_calibration=self.translation_calibration,
            stationary_human=True, max_hand_age_s=180.)

    def __call__(self, obs):
        # A stage transition never permits a second controller to act on the
        # same public frame, even if an external caller repeats that frame.
        hold = np.zeros((2, 9), np.float32)
        closed = np.asarray(obs.get('gripper_close_command', [False, False])).reshape(2)
        hold[:, 8] = np.where(closed, 1., -1.)
        try:
            now = float(obs['simulation_time_s'])
            state = {key:np.asarray(obs[key]).copy() for key in
                ('joint_position', 'joint_velocity', 'controller_target',
                 'base_pose_world', 'grasp_pose_base', 'base_twist_world') if key in obs}
            if not np.isfinite(now):
                raise ValueError('finite_public_clock_required')
            if self.last_dispatched_time is not None:
                dt = now-self.last_dispatched_time
                if dt < -1e-8 or dt > .075:
                    raise ValueError('nonconsecutive_dressing_policy_public_clock')
                if dt <= 1e-8:
                    if (state.keys() != self.last_dispatched_state.keys() or
                            any(not np.array_equal(value, self.last_dispatched_state[key])
                                for key, value in state.items())):
                        raise ValueError('same_dressing_timestamp_has_changed_robot_state')
                    self.debug['repeated_frame_no_action'] = True
                    return hold
            self.last_dispatched_time = now
            self.last_dispatched_state = state
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.fail(str(error))
            self.debug.update(phase=self.phase, failure=self.failure)
            return hold
        # Intercept a direct/recovered legacy entry before its parent can
        # construct the uncalibrated contact controller.
        if self.phase == 'hypothesis_contact':
            self.change('staging_calibrate')
            self.debug.update(phase=self.phase, phase_steps=0)
            return hold
        custom = ('staging_calibrate', 'calibrated_contact', 'contact_trial_complete')
        if self.phase not in custom:
            action = super().__call__(obs)
            if not self.failure and self.phase == 'translation_trial_complete':
                self.change('dual_hold')
            elif not self.failure and self.phase == 'hypothesis_contact':
                self.change('staging_calibrate')
            self.debug.update(phase=self.phase, phase_steps=self.phase_steps,
                              contact_staging_calibration=self.staging_debug)
            return action
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        action[:, 8] = 1.
        try:
            if self.phase == 'staging_calibrate':
                if self.staging_handoff is None:
                    self.staging_handoff = self._create_staging_handoff(obs)
                result = self.staging_handoff.step(obs)
                self.staging_debug = deepcopy(result['debug'])
                self.staging_debug['actor_connected'] = True
                if result['failure']:
                    raise ValueError('staging calibration: '+result['failure'])
                if result['done']:
                    self.staging_calibration = deepcopy(result['calibration'])
                    self.change('calibrated_contact')
            elif self.phase == 'calibrated_contact':
                if self.calibrated_contact is None:
                    if self.staging_handoff is None or self.staging_calibration is None:
                        raise ValueError('completed_staging_handoff_required')
                    self.calibrated_contact = CalibratedHypothesisContactExperiment(obs,
                        self.initial_edge_report, self.pair_candidate_indices,
                        self.hands, self.hand_observation_time,
                        calibration=self.staging_calibration,
                        skin_anchor=self.staging_handoff.skin_anchor,
                        skin_anchor_observed_at=self.staging_handoff.skin_anchor_stamp)
                result = self.calibrated_contact.step(obs)
                action = np.asarray(result['action'], np.float32)
                self.debug['hypothesis_contact'] = deepcopy(result['debug'])
                if result['failure']:
                    raise ValueError('calibrated contact: '+result['failure'])
                if result['done']:
                    self.change('contact_trial_complete')
            executed = self.execution.apply(obs, action)
            if np.max(np.abs(executed[:, :8]-action[:, :8])) > 1e-8:
                raise ValueError('execution modified calibrated contact motion')
            action = executed
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail(str(error))
        contact_debug = self.debug.get('hypothesis_contact')
        action = self._finish_pair(obs, action)
        self.debug.update(contact_staging_calibration=self.staging_debug,
            frozen_contact_calibration=self.staging_calibration,
            hypothesis_contact=contact_debug,
            complete_dressing_claimed=False, new_network_training=False,
            physical_validation_status='unvalidated_development_branch')
        return action
