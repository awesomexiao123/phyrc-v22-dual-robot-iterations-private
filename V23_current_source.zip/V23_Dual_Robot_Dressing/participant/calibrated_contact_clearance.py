"""Independent observed-point geometry check for calibrated contact proposals.

This module does not integrate an actor or change controller state. It binds a
governor's current motion evidence to the same raw observation and output action,
then checks raw/excess pending translations and each pending-plus-action segment
separately. A cancellation cannot erase the earlier segment from this union.

Own boxes/FK always receive raw observations, including both actual jaws. The
wrist and independent jaw envelopes bound their declared finite angle ranges,
and both are added to the original 3 mm margin, the supplied raw-rate reserve
and sampled bias deviations. The original translation checker samples fixed-pose
translations. None of these conditional geometric checks prove continuous
motion, inertia/braking, unseen-skin clearance, contact, or sleeve identity.
"""
import numpy as np

from calibrated_contact_governor import CalibratedContactGovernor
from contact_motion_governor import ContactMotionGovernor
from gripper_skin_clearance import observed_gripper_skin_clearance
from wrist_sweep_envelope import jaw_sweep_envelope, wrist_sweep_envelope


def _array(container, name, shape, *, nonnegative=False):
    value = np.asarray(container[name], dtype=float)
    if value.shape != shape or not np.isfinite(value).all():
        raise ValueError('invalid_motion_evidence_'+name)
    if nonnegative and np.any(value < 0):
        raise ValueError('negative_motion_evidence_'+name)
    return value


def _matches(actual, expected, label, tolerance=1e-8):
    if np.max(np.abs(actual-expected)) > tolerance:
        raise ValueError('motion_evidence_disagrees_with_'+label)


def _result(valid, reason, reports, now=None):
    return dict(valid=valid, reason=reason, observation_time_s=now, reports=reports,
        minimum_observed_skin_clearance_m=(min(r['clearance']['observed_minimum_clearance_m']
                                              for r in reports) if valid else None),
        original_model_margin_m=.003, required_observed_skin_clearance_m=.020,
        geometry_checked=bool(reports), all_required_segments_checked=bool(valid),
        original_observation_modified=False, evidence_modified=False,
        fullbody_clearance=False, collision_free=False, insertion_allowed=False,
        sleeve_identity_verified=False, contact_verified=False,
        physical_stopping_certified=False, physical_safety_proven=False,
        native_target_cancelled=False, inertia_or_dynamics_bounded=False,
        entire_continuous_sweep_checked=False, near_human_contact_authorized=False,
        unobserved_skin_clearance_known=False, jaw_motion_bounded=False,
        declared_jaw_angle_envelope_checked=bool(valid),
        root_rotation_bounded=False)


def calibrated_contact_clearance(raw_obs, motion_evidence, action,
                                 current_skin_points_world, original_skin_points_world, *,
                                 current_skin_observed_at, original_skin_observed_at,
                                 stationary_skin=False):
    """Check both robots against retained original and current observed skin.

    Both skin timestamps must be their actual acquisition times. The existing
    20 s current-cache and 180 s original-anchor bounds are fixed, and the caller
    must explicitly declare stationary_skin=True. This function does not detect
    whether pixels are currently visible; callers retain that admission check.

    Evidence must be the governor result for this exact raw frame AND returned
    action. Position, velocity, raw targets, base twist, reconstructed pending
    segments, predicted targets, and proposed translation must agree. Original
    raw limits are checked even when the effective target would pass. Only
    base XY/lift/arm output is supported; wrist/yaw actions are rejected. Raw
    wrist/jaw rates each expand their target intervals by one 50 ms interval,
    which is a finite engineering reserve, not a future-velocity/inertia bound.

    valid=True means all eight conditional model/observed-point checks passed
    the unchanged 20 mm distance gate. It is neither motion authorization nor
    an assertion that any target was cancelled or a robot physically stopped.
    """
    reports = []
    now = None
    try:
        if stationary_skin is not True:
            raise ValueError('explicit_stationary_skin_assumption_required')
        s = ContactMotionGovernor._read(raw_obs)
        now = s['time']
        if not isinstance(motion_evidence, dict) or motion_evidence.get('valid') is not True:
            raise ValueError('valid_current_motion_evidence_required')
        stamp = float(motion_evidence['observation_time_s'])
        calibration_stamp = float(motion_evidence['calibration_observed_at_s'])
        if not np.isfinite([stamp, calibration_stamp]).all() or abs(stamp-now) > 1e-8:
            raise ValueError('motion_evidence_not_from_current_raw_frame')
        if calibration_stamp > now+1e-8:
            raise ValueError('motion_evidence_calibration_from_future')
        a = np.asarray(action, dtype=float)
        if (a.shape != (2, 9) or not np.isfinite(a).all() or np.max(np.abs(a)) > 1. or
                np.max(np.abs(a[:, [2, 5, 6, 7]])) > 1e-12 or not np.all(a[:, 8] == 1.)):
            raise ValueError('finite_translation_only_closed_gripper_action_required')
        if np.max(np.abs(s['target'][:, 8])) > 1e-5:
            raise ValueError('unresolved_base_yaw_target_not_covered')
        CalibratedContactGovernor._raw_limits(s, s['target'])
        e = motion_evidence
        for name, source, shape in (
                ('raw_joint_position', 'q', (2, 13)),
                ('raw_joint_velocity', 'qd', (2, 13)),
                ('raw_controller_target', 'target', (2, 9)),
                ('raw_base_twist_world', 'twist', (2, 6))):
            _matches(_array(e, name, shape), s[source], name)
        bias = _array(e, 'frozen_controller_bias', (2, 5))
        peak = _array(e, 'sampled_bias_peak_deviation', (2, 5), nonnegative=True)
        if np.any(np.abs(bias) > CalibratedContactGovernor.BIAS_LIMITS):
            raise ValueError('frozen_bias_outside_original_limits')
        rate_reserve = _array(e, 'conservative_geometry_rate_reserve_m', (2,), nonnegative=True)
        measured_speed = _array(e, 'measured_grasp_difference_speed_m_s', (2,), nonnegative=True)
        _array(e, 'position_difference_joint_velocity', (2, 13))
        # A supplied rate reserve may be more conservative, never smaller than
        # the raw-state and measured-grasp values that the governor reports.
        if np.any(rate_reserve+1e-12 < .05*np.maximum(s['endpoint_speed'], measured_speed)):
            raise ValueError('motion_evidence_rate_reserve_understates_raw_or_measured_speed')
        raw_lag = s['lag']
        excess_lag = raw_lag-bias[:, :2]
        _matches(_array(e, 'excess_aggregate_target_lead_m', (2, 2)), excess_lag, 'excess_linear_lag')
        _matches(_array(e, 'raw_wrist_target_lag_rad', (2, 3)), s['wrist_lag'], 'raw_wrist_lag')
        _matches(_array(e, 'excess_wrist_target_lag_rad', (2, 3)),
                 s['wrist_lag']-bias[:, 2:5], 'excess_wrist_lag')
        rotations = s['rotations']
        raw_pending = rotations[:, :, 2]*raw_lag[:, :1]+rotations[:, :, 0]*raw_lag[:, 1:2]
        excess_pending = rotations[:, :, 2]*excess_lag[:, :1]+rotations[:, :, 0]*excess_lag[:, 1:2]
        world_base = np.einsum('nij,nj->ni', s['planar'], a[:, :2]*.616)
        move = .05*(np.pad(world_base, ((0, 0), (0, 1)))+
                    rotations[:, :, 2]*(a[:, 3:4]*1.54)+rotations[:, :, 0]*(a[:, 4:5]*1.21))
        predicted = s['target'].copy()
        predicted[:, :2] += a[:, 3:5]*[1.54, 1.21]*.05
        CalibratedContactGovernor._raw_limits(s, predicted)
        _matches(_array(e, 'predicted_next_raw_controller_target', (2, 9)), predicted, 'predicted_raw_target')
        for field, value in (
                ('raw_pending_translation_world', raw_pending),
                ('excess_pending_translation_world', excess_pending),
                ('proposed_interval_translation_world', move),
                ('raw_pending_plus_proposed_world', raw_pending+move),
                ('excess_pending_plus_proposed_world', excess_pending+move)):
            _matches(_array(e, field, (2, 3)), value, field)

        current_stamp, original_stamp = float(current_skin_observed_at), float(original_skin_observed_at)
        if (not np.isfinite([current_stamp, original_stamp]).all() or
                not -1e-8 <= now-current_stamp <= 20. or
                not -1e-8 <= now-original_stamp <= 180. or original_stamp > current_stamp+1e-8):
            raise ValueError('invalid_stale_or_future_skin_acquisition_time')
        clouds = []
        for label, values in (('current', current_skin_points_world), ('original', original_skin_points_world)):
            points = np.asarray(values, dtype=float)
            if points.ndim != 2 or points.shape[1:] != (3,) or not len(points) or not np.isfinite(points).all():
                raise ValueError('missing_or_invalid_'+label+'_skin_points')
            clouds.append(points)
        points = np.concatenate(clouds, axis=0)
        segments = (
            ('raw_pending_target', raw_pending),
            ('raw_pending_plus_proposed', raw_pending+move),
            ('prior_excess_pending_target', excess_pending),
            ('excess_pending_plus_proposed', excess_pending+move))
        for robot in (0, 1):
            wrist = s['target'][robot, 2:5]
            current_wrist = s['q'][robot, 8:11]
            wrist_rate = np.abs(s['qd'][robot, 8:11])*.05
            raw_range = np.column_stack((np.minimum(current_wrist, wrist)-wrist_rate,
                                        np.maximum(current_wrist, wrist)+wrist_rate))
            effective = wrist-bias[robot, 2:5]
            excess_range = np.column_stack((np.minimum(current_wrist, effective-peak[robot, 2:5])-wrist_rate,
                                           np.maximum(current_wrist, effective+peak[robot, 2:5])+wrist_rate))
            angular = wrist_sweep_envelope(s['q'][robot], raw_range, excess_range)
            if not angular.get('valid'):
                raise ValueError('invalid_wrist_sweep_envelope:'+str(angular.get('reason')))
            angular_reserve = float(angular['max_displacement_reserve_m'])
            jaw = jaw_sweep_envelope(s['q'][robot], s['target'][robot, 5], s['qd'][robot, 11:13])
            if not jaw.get('valid'):
                raise ValueError('invalid_jaw_sweep_envelope:'+str(jaw.get('reason')))
            jaw_reserve = float(jaw['max_displacement_reserve_m'])
            bias_reserve = float(peak[robot, :2].sum())
            margin = .003+float(rate_reserve[robot])+bias_reserve+angular_reserve+jaw_reserve
            if not np.isfinite(margin) or margin > .020:
                raise ValueError('required_model_margin_exceeds_original20mm_cap')
            for label, translations in segments:
                delta = translations[robot]
                if np.linalg.norm(delta) > .005+1e-12:
                    raise ValueError('pending_segment_exceeds_original5mm_translation_cap')
                clearance = observed_gripper_skin_clearance(raw_obs, robot, points,
                    skin_observed_at=min(original_stamp, current_stamp), stationary_skin=True,
                    max_skin_age_s=180., proposed_translation_world=delta, model_margin_m=margin)
                reports.append(dict(robot=robot, checked_segment=label,
                    translation_world_m=delta.tolist(), model_margin_m=margin,
                    additional_angular_reserve_m=angular_reserve,
                    additional_jaw_reserve_m=jaw_reserve,
                    jaw_target_ranges_rad=jaw['jaw_target_ranges_rad'],
                    wrist_raw_rate_angle_reserve_rad=wrist_rate.tolist(),
                    rate_reserve_m=float(rate_reserve[robot]), sampled_bias_reserve_m=bias_reserve,
                    current_skin_original_observed_at_s=current_stamp,
                    original_skin_anchor_observed_at_s=original_stamp,
                    actual_jaw_angles_rad=s['q'][robot, 11:13].tolist(),
                    clearance={k:v for k,v in clearance.items() if k not in ('model_bounds', 'model_provenance')}))
                if not clearance.get('valid'):
                    raise ValueError('own_geometry_clearance_unavailable:'+str(clearance.get('reason')))
                if clearance['observed_minimum_clearance_m'] < .020:
                    raise ValueError('expanded_own_geometry_within20mm_of_observed_skin')
    except (KeyError, TypeError, ValueError, IndexError, AttributeError, OverflowError) as error:
        return _result(False, str(error), reports, now)
    return _result(True, 'all_raw_and_excess_model_segments_clear_of_observed_points', reports, now)


def check_calibrated_contact_clearance(obs, motion_evidence, action, *,
                                       skin, skin_observed_at,
                                       skin_anchor, skin_anchor_observed_at):
    """Public entry point for the caller's declared stationary-mannequin scene.

    ``skin`` and ``skin_anchor`` retain their separate original acquisition
    timestamps. This interface inherits the caller's stationary-skin assumption;
    it does not infer stationarity or refresh either cache. ``checks`` contains
    eight reports on success, or only the reports reached before a rejection.
    """
    result = calibrated_contact_clearance(
        obs, motion_evidence, action, skin, skin_anchor,
        current_skin_observed_at=skin_observed_at,
        original_skin_observed_at=skin_anchor_observed_at,
        stationary_skin=True)
    result['checks'] = result.pop('reports')
    result['stationary_skin_assumed_by_caller'] = True
    return result
