"""Separate finite +1 degree loaded roll trial, ending before pitch or carry.

Only the calibration's sampled base/grasp position diameter is 1 mm. Original
joint, sampled net-speed, elapsed-time and total drift guards remain. This is
an unvalidated simulator experiment, not proof of physical rest or dressing.
"""
import numpy as np

from equilibrium_contact_policy import Policy as WristPolicy
from equilibrium_wrist_experiments import CalibratedLoadedRoll
from loaded_equilibrium_calibration import LongLoadedEquilibriumCalibration
from loaded_roll_observation import LoadedRollObservation


class FarFieldEquilibriumCalibration(LongLoadedEquilibriumCalibration):
    POSE_RANGE = .001

    def _freeze(self):
        super()._freeze()
        if self.done:
            self.calibration['method'] = (
                'Frozen median target-minus-actual bias from at least 41 consecutive '
                '20Hz zero-input public samples spanning 2s. Base/grasp sampled pose '
                'diameter is limited to 1mm; individual/aggregate linear joint range '
                'remains 250um, linear net speed 0.5mm/s, original total drift 3mm '
                'and total calibration budget 6s. Original wrist, bias and terminal '
                'residual gates remain. This allows bounded pose creep and does not '
                'certify physical or continuous-time rest; the baseline is not refreshed.')

    def _result(self):
        result = super()._result()
        details = dict(calibration_variant='far_field_1mm_pose_window',
            sampled_pose_diameter_limit_m=self.POSE_RANGE,
            linear_joint_range_limit_m=self.LINEAR_RANGE,
            sampled_linear_net_speed_limit_mps=self.LINEAR_NET_SPEED,
            allows_bounded_sampled_pose_creep=True,
            physical_stationary_verified=False)
        self.debug.update(details); result['debug'].update(details)
        return result


class OneDegreeLoadedRoll(LoadedRollObservation):
    NOMINAL_RAD = np.deg2rad(1.)
    PER_WRIST_RAD = np.deg2rad(1.25)
    TOTAL_RAD = np.deg2rad(2.5)

    def _result(self, action=None):
        result = super()._result(action)
        details = dict(nominal_positive_roll_degrees_per_robot=1.,
            per_robot_absolute_ceiling_degrees=1.25,
            total_absolute_roll_budget_degrees=2.5)
        self.debug.update(details); result['debug'].update(details)
        return result


class CalibratedOneDegreeLoadedRoll(CalibratedLoadedRoll):
    CORE = OneDegreeLoadedRoll


class Policy(WristPolicy):
    VERSION = 'v23_22_far_field_roll'
    METHOD = ('frozen V22; measured dual pickup and raise; bounded sampled 1mm pose '
              'calibration; one-degree loaded roll per wrist; stop before pitch or carry')
    CALIBRATION_CLASS = FarFieldEquilibriumCalibration
    ENABLE_FAR_CLOTH_PITCH_PILOT = False

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.last_far_roll_dispatch_time = None

    def _create_loaded_roll(self, obs):
        return CalibratedOneDegreeLoadedRoll(obs, self.hands, self.hand_observation_time,
            calibration=self.wrist_calibration, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def __call__(self, obs):
        hold = np.zeros((2, 9), np.float32)
        hold[:, 8] = np.where(np.asarray(obs['gripper_close_command']).reshape(2), 1., -1.)
        try:
            now = float(obs['simulation_time_s'])
            if not np.isfinite(now):
                raise ValueError('finite_far_roll_public_clock_required')
            if self.last_far_roll_dispatch_time is not None:
                dt = now-self.last_far_roll_dispatch_time
                if dt < -1e-8:
                    raise ValueError('far_roll_public_clock_moved_backwards')
                if dt <= 1e-8:
                    self.debug['repeated_frame_no_action'] = True
                    return hold
            self.last_far_roll_dispatch_time = now
            if self.phase == 'far_roll_trial_complete':
                return hold
            if self.phase in ('pair_settle_before_pitch', 'pair_observe_pitch', 'dual_hold',
                              'carry', 'hypothesis_contact', 'calibrated_contact'):
                raise ValueError('phase_not_allowed_in_far_roll_only_trial')
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.fail(str(error))
            self.debug.update(phase=self.phase, failure=self.failure)
            return np.zeros((2, 9), np.float32)
        previous_phase = self.phase
        action = super().__call__(obs)
        if not self.failure and previous_phase == 'pair_observe_roll' and self.phase == 'dual_hold':
            self.change('far_roll_trial_complete')
            self.debug.update(phase=self.phase, phase_steps=0, idle_mode=self.phase,
                far_roll_trial_completed=True, pitch_or_contact_started=False,
                physical_validation_status='unvalidated_development_branch',
                complete_dressing_claimed=False)
        return action
