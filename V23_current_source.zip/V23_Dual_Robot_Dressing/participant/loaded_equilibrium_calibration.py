"""Finite sampled-equilibrium calibration for loaded simulation experiments.

Only consecutive public own-state and current RGB-D observations are used.
The recorded target offset and raw velocity distribution are empirical: they
do not prove continuous-time rest, attachment, force balance or collision safety.
This module never changes an integrated target or issues a motion command.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from loaded_roll_observation import _cloth_evidence, _state
from public_vision import _rotation


class LoadedEquilibriumCalibration:
    """Acquire one immutable baseline; construct a new instance after loading changes.

    ``step`` returns ``action, done, failure, debug, calibration``. Only success
    sets done=True and supplies calibration. A non-null failure is terminal and
    requires the caller to stop; zero output does not cancel native target lead.
    The constructor does not count a frame. The first step may use that same
    observation, but subsequent repeats of its clock never count again.
    """

    MAX_SECONDS = 3.
    WINDOW_SECONDS = .5
    MIN_FRAMES = 11
    ACTION_DT = .05
    CLOCK_TOLERANCE = 1e-4
    TARGET_TOLERANCE = 1e-6
    ZERO_TOLERANCE = 1e-8
    POSE_RANGE = .00025
    LINEAR_RANGE = .00025
    LINEAR_NET_SPEED = .0005
    WRIST_RANGE = np.deg2rad(.05)
    WRIST_NET_SPEED = np.deg2rad(.1)
    BIAS_LIMITS = np.array([.003, .003, *([np.deg2rad(.3)]*3)])
    # Actual downstream thresholds, without enlarging its settle tolerances:
    # pitch SETTLED_LAG for lift/arm/pitch; roll TARGET_TRACK_TOL for roll;
    # pitch's initial fixed-yaw target check; individual arm segment settle.
    TERMINAL_RESIDUAL_LIMITS = np.array([.0001, .0001, np.deg2rad(.05),
                                       np.deg2rad(.01), np.deg2rad(.01)])
    TERMINAL_ARM_SEGMENT_LIMIT = .0001

    def __init__(self, obs, hands, observed_at, *, stationary_human=True,
                 max_hand_age_s=300):
        self.done = False
        self.failure = None
        self.calibration = None
        self.debug = {}
        self.window = []
        self.window_resets = 0
        self.last_time = None
        self.time0 = None
        self.stationary_human = stationary_human is True
        try:
            if not self.stationary_human:
                raise ValueError('explicit_stationary_human_assumption_required')
            self.observed_at = float(observed_at)
            self.max_hand_age_s = float(max_hand_age_s)
            if (not np.isfinite([self.observed_at, self.max_hand_age_s]).all()
                    or not 0 < self.max_hand_age_s <= 300):
                raise ValueError('invalid_original_hand_time_or_cache_bound')
            if (hands.get('observation_time_s') is not None
                    and abs(float(hands['observation_time_s'])-self.observed_at) > 1e-7):
                raise ValueError('hand_observation_timestamp_sources_disagree')
            self.hands = np.asarray(hands.get('hand_points_world'), float).copy()
            if (not hands.get('detected') or self.hands.shape != (2, 3)
                    or not np.isfinite(self.hands).all()
                    or not .06 <= np.linalg.norm(self.hands[1]-self.hands[0]) <= 1.2):
                raise ValueError('two_separated_observed_hand_points_required')
            bases, grasps, _, _, now = _snapshot(obs)
            _, _, targets = _state(obs)
            self.base0, self.grasp0 = bases.copy(), grasps.copy()
            self.target0 = targets.copy()
            self.last_targets = targets.copy()
            self.time0 = now
            self.debug['cached_hand_observed_at_s'] = self.observed_at
            self.debug['original_target_observed_at_s'] = now
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = str(error)

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32)
        action[:, 8] = 1.
        return action

    def _result(self):
        self.debug.update(
            phase='failed' if self.failure else ('calibrated' if self.done else 'acquiring_zero_input_window'),
            frame_count=len(self.window), window_reset_count=self.window_resets,
            stationary_human_assumption_declared=self.stationary_human,
            motion_commanded=False, sampled_equilibrium_only=True,
            continuous_time_stationary_verified=False, attachment_verified=False,
            full_human_or_wrist_sweep_clearance_verified=False,
            native_target_cancelled=False)
        return dict(action=self._hold(), done=self.done, failure=self.failure,
                    debug=deepcopy(self.debug), calibration=deepcopy(self.calibration))

    def _reset_window(self, reason):
        if self.window:
            self.window_resets += 1
        self.window = []
        self.debug['last_window_reset_reason'] = reason

    def _cloth_report(self, obs, grasps):
        """Default far-field evidence; subclasses may replace this scene gate."""
        return _cloth_evidence(obs, grasps, self.hands)

    def _guards(self, obs, bases, grasps, tilt, now):
        q, qd, targets = _state(obs)
        previous = np.asarray(obs['previous_action'], float)
        if previous.shape != (2, 9) or not np.isfinite(previous).all():
            raise ValueError('finite_public_previous_action_required')
        age = now-self.observed_at
        if not -1e-7 <= age <= self.max_hand_age_s:
            raise ValueError('stationary_hand_cache_stale_or_from_future')
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('closed_gripper_intent_lost')
        gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isfinite(gap).all() or np.any(gap < 0) or gap.max() > .08:
            raise ValueError('closed_gripper_gap_guard')
        if np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60 or tilt.max() > .065:
            raise ValueError('base_separation_or_tilt_guard')
        base_drift = np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1)
        grasp_drift = np.linalg.norm(grasps-self.grasp0, axis=1)
        self.debug.update(base_drift_from_start_m=base_drift.tolist(),
                          grasp_drift_from_start_m=grasp_drift.tolist())
        if max(base_drift.max(), grasp_drift.max()) > .003:
            raise ValueError('initial_base_or_grasp_3mm_budget_exceeded')
        for r in (0, 1):
            relative = _rotation(bases[r, 3:]) @ _rotation(self.base0[r, 3:]).T
            if np.arccos(np.clip((np.trace(relative)-1)/2, -1., 1.)) > np.deg2rad(.25):
                raise ValueError('uncommanded_base_rotation')
        self.debug.update(self._cloth_report(obs, grasps))
        self.debug['hand_observation_age_s'] = age
        zero = (np.max(np.abs(previous[:, :8])) <= self.ZERO_TOLERANCE
                and np.max(np.abs(targets[:, 6:9])) <= self.ZERO_TOLERANCE)
        self.debug['previous_motion_action_and_base_targets_zero'] = bool(zero)
        return q, qd, targets, zero

    def _window_metrics(self):
        duration = self.window[-1]['time']-self.window[0]['time']
        q = np.stack([x['q'] for x in self.window])
        bases = np.stack([x['bases'][:, :3] for x in self.window])
        grasps = np.stack([x['grasps'] for x in self.window])
        linear = np.concatenate((q[:, :, 3:8], q[:, :, 4:8].sum(2, keepdims=True)), axis=2)
        wrist = q[:, :, 8:11]
        diameter = lambda p: float(np.linalg.norm(p[:, None]-p[None, :], axis=-1).max())
        net = lambda p: float(np.linalg.norm(p[-1]-p[0], axis=-1).max()/duration) if duration > 0 else 0.
        linear_net = float(np.max(np.abs(linear[-1]-linear[0]))/duration) if duration > 0 else 0.
        wrist_net = float(np.max(np.abs(wrist[-1]-wrist[0]))/duration) if duration > 0 else 0.
        return dict(window_duration_s=float(duration), base_window_diameter_m=diameter(bases),
                    grasp_window_diameter_m=diameter(grasps),
                    linear_joint_window_range_m=float(np.ptp(linear, axis=0).max()),
                    wrist_window_range_rad=float(np.ptp(wrist, axis=0).max()),
                    base_net_speed_mps=net(bases), grasp_net_speed_mps=net(grasps),
                    linear_joint_net_speed_mps=linear_net, wrist_net_speed_radps=wrist_net)

    def _freeze(self):
        q = np.stack([x['q'] for x in self.window])
        qd = np.stack([x['qd'] for x in self.window])
        targets = np.stack([x['targets'] for x in self.window])
        actual = np.concatenate((q[:, :, 3:4], q[:, :, 4:8].sum(2, keepdims=True), q[:, :, 8:11]), axis=2)
        bias = np.median(targets[:, :, :5]-actual, axis=0)
        self.debug['candidate_controller_bias'] = bias.tolist()
        self.debug['controller_bias_limits_m_m_rad_rad_rad'] = self.BIAS_LIMITS.tolist()
        if not np.isfinite(bias).all() or np.any(np.abs(bias) > self.BIAS_LIMITS):
            raise ValueError('sampled_equilibrium_controller_bias_exceeds_bound')
        offsets = np.median(q[:, :, 4:8]-q[:, :, 4:8].mean(2, keepdims=True), axis=0)
        # Componentwise medians need not sum exactly to zero. Project onto the
        # zero-sum subspace, preserving the aggregate arm coordinate separately.
        offsets -= offsets.mean(1, keepdims=True)
        last = self.window[-1]
        effective = last['targets'][:, :5]-bias
        terminal_residual = effective-actual[-1]
        terminal_arm_residual = effective[:, 1, None]/4-(last['q'][:, 4:8]-offsets)
        self.debug.update(
            terminal_candidate_effective_target_residual=terminal_residual.tolist(),
            terminal_candidate_arm_segment_residual_m=terminal_arm_residual.tolist(),
            terminal_residual_limits_m_m_rad_rad_rad=self.TERMINAL_RESIDUAL_LIMITS.tolist(),
            terminal_arm_segment_limit_m=self.TERMINAL_ARM_SEGMENT_LIMIT)
        if (np.any(np.abs(terminal_residual) > self.TERMINAL_RESIDUAL_LIMITS)
                or np.any(np.abs(terminal_arm_residual) > self.TERMINAL_ARM_SEGMENT_LIMIT)):
            # A slow drift can satisfy a .5s range/net-speed window while its
            # final pose differs too much from the median. Freezing that bias
            # would strand the downstream zero-command settle indefinitely.
            # Start a new observed window here; never reset original budgets.
            self._reset_window('terminal_frame_not_settled_against_candidate_median')
            self.window.append(last)
            self.debug['window_target_reference_observed_at_s'] = last['time']
            return
        velocity_median = np.median(qd, axis=0)
        self.calibration = dict(
            observed_at_s=last['time'], window_start_s=self.window[0]['time'],
            frame_count=len(self.window), controller_bias=bias.tolist(),
            controller_bias_peak_deviation=np.max(np.abs(targets[:, :, :5]-actual-bias), axis=0).tolist(),
            arm_position_offsets=offsets.tolist(),
            arm_position_offsets_peak_deviation=np.max(np.abs(
                q[:, :, 4:8]-q[:, :, 4:8].mean(2, keepdims=True)-offsets), axis=0).tolist(),
            deviation_scope='Maximum deviations within the saved sampled window only; not a bound on future or between-sample motion.',
            raw_joint_velocity_median=velocity_median.tolist(),
            raw_joint_velocity_peak_deviation=np.max(np.abs(qd-velocity_median), axis=0).tolist(),
            last_joint_position=last['q'].tolist(), last_base_pose=last['bases'].tolist(),
            controller_target_reference=last['targets'].tolist(),
            method='Frozen median target-minus-actual bias from at least 11 consecutive 20Hz zero-input public samples spanning 0.5s, with final-frame effective target residuals within the downstream roll/pitch settle thresholds; individual arm shape offsets are centered to zero sum. Raw velocity median and peak deviations describe sampled values, not true continuous-time rest or a physical stopping certificate.')
        # Selected public own-base diagnostics retain their original clocks.
        # No control threshold is changed by this additional evidence.
        self.calibration['base_diagnostic_window'] = dict(
            public_times_s=[x['time'] for x in self.window],
            base_pose_world=[x['bases'].tolist() for x in self.window],
            raw_base_twist_world=[None if x['base_twist'] is None else x['base_twist'].tolist() for x in self.window],
            grasp_position_world=[x['grasps'].tolist() for x in self.window],
            raw_joint_position=[x['q'].tolist() for x in self.window],
            raw_joint_velocity=[x['qd'].tolist() for x in self.window],
            raw_controller_target=[x['targets'].tolist() for x in self.window],
            previous_action=[x['previous_action'].tolist() for x in self.window],
            scope='Selected public own-control diagnostics from the same counted samples; missing twist stays null. No continuous-time rest inference.')
        self.done = True

    def step(self, obs):
        if self.done or self.failure:
            return self._result()
        try:
            bases, grasps, _, tilt, now = _snapshot(obs)
            q, qd, targets, zero = self._guards(obs, bases, grasps, tilt, now)
            elapsed = now-self.time0
            self.debug['elapsed_since_original_start_s'] = elapsed
            if elapsed < -1e-8:
                raise ValueError('public_clock_precedes_calibration_start')
            if elapsed > self.MAX_SECONDS+1e-8:
                raise ValueError('sampled_equilibrium_calibration_timed_out')
            if self.last_time is not None:
                dt = now-self.last_time
                if dt < -1e-8:
                    raise ValueError('public_clock_moved_backwards')
                if dt <= 1e-8:
                    return self._result()
                if abs(dt-self.ACTION_DT) > self.CLOCK_TOLERANCE:
                    self._reset_window('not_consecutive_20hz_public_observations')
            self.last_time = now
            reference = self.window[0]['targets'] if self.window else self.last_targets
            target_changed = np.max(np.abs(targets[:, :5]-reference[:, :5])) > self.TARGET_TOLERANCE
            self.last_targets = targets.copy()
            if not zero:
                self._reset_window('waiting_for_observed_zero_input')
                return self._result()
            if target_changed:
                # The native controller can change its submitted target through
                # anti-windup even under zero action. Never average across that
                # change; restart only the candidate window, not global budgets.
                self._reset_window('native_target_changed_under_zero_input')
                self.debug['last_target_change_observed_at_s'] = now
            twist = None
            if 'base_twist_world' in obs:
                twist = np.asarray(obs['base_twist_world'], float)
                if twist.shape != (2, 6) or not np.isfinite(twist).all():
                    raise ValueError('invalid_optional_public_base_twist')
            frame = dict(time=float(now), q=q.copy(), qd=qd.copy(), targets=targets.copy(),
                         bases=bases.copy(), grasps=grasps.copy(), base_twist=None if twist is None else twist.copy(),
                         previous_action=np.asarray(obs['previous_action'], float).copy())
            self.window.append(frame)
            self.debug['window_target_reference_observed_at_s'] = self.window[0]['time']
            metrics = self._window_metrics()
            self.debug.update(metrics)
            stable = (max(metrics['base_window_diameter_m'], metrics['grasp_window_diameter_m']) <= self.POSE_RANGE
                      and metrics['linear_joint_window_range_m'] <= self.LINEAR_RANGE
                      and metrics['wrist_window_range_rad'] <= self.WRIST_RANGE
                      and max(metrics['base_net_speed_mps'], metrics['grasp_net_speed_mps'],
                              metrics['linear_joint_net_speed_mps']) <= self.LINEAR_NET_SPEED
                      and metrics['wrist_net_speed_radps'] <= self.WRIST_NET_SPEED)
            if not stable:
                self._reset_window('observed_pose_or_joint_window_not_stationary')
                self.window.append(frame)
                return self._result()
            if (len(self.window) >= self.MIN_FRAMES
                    and metrics['window_duration_s'] >= self.WINDOW_SECONDS-1e-8):
                self._freeze()
            return self._result()
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = str(error)
            return self._result()


class LongLoadedEquilibriumCalibration(LoadedEquilibriumCalibration):
    """Separate longer sampling variant; all original movement guards remain.

    The extended window records more instantaneous velocity samples. It does
    not enlarge position ranges, bias caps or final-frame residual tolerances,
    and still does not establish continuous-time equilibrium.
    """
    WINDOW_SECONDS = 2.
    MIN_FRAMES = 41
    MAX_SECONDS = 6.

    def _freeze(self):
        super()._freeze()
        if self.done:
            self.calibration['method'] = (
                f'Frozen median target-minus-actual bias from at least {self.MIN_FRAMES} '
                f'consecutive 20Hz zero-input public samples spanning {self.WINDOW_SECONDS:g}s, '
                'with original position-range, net-speed, bias-cap and final-frame '
                'roll/pitch residual gates unchanged; individual arm shape offsets '
                'are centered to zero sum. Raw velocity median and peak deviations '
                'cover this sampled window only, not continuous-time rest or future motion.')

    def _result(self):
        self.debug.update(calibration_variant='long_loaded_equilibrium',
                          required_window_seconds=self.WINDOW_SECONDS,
                          required_frame_count=self.MIN_FRAMES,
                          original_total_time_budget_s=self.MAX_SECONDS)
        return super()._result()
