"""Separate ten-degree far-field posture hypothesis for cloth contact trials.

This changes the experimental angle budget explicitly, not the original 2deg
pilot. One persistent owner retains all measured travel, references and the
original hand timestamp. It does not execute contact or identify a sleeve.
"""
import numpy as np

from loaded_pitch_observation import LoadedPitchObservation


class LoadedContactPitch(LoadedPitchObservation):
    NOMINAL_RAD = np.deg2rad(10.)
    PER_WRIST_RAD = np.deg2rad(10.5)
    TOTAL_RAD = np.deg2rad(21.)
    MAX_SECONDS = 45.
    MAX_CALLS = 950
    # Maximum 0.295358m lever displacement over10deg is51.55mm,
    # plus the existing3mm measured grasp-center guard, rounded upward.
    LINEAR_ENVELOPE_M = .055
