"""Finite far-field servo trial; never an insertion or dressing controller.

One fresh loaded calibration is frozen for a pair of 2mm lift and arm
out-and-back moves. Each endpoint requires the governor's measured rest;
no phase reconstructs it or resets the original pose/path/time references.
"""
from copy import deepcopy

import numpy as np

from calibrated_contact_governor import CalibratedContactGovernor
from cooperative_transport import _snapshot
from loaded_roll_observation import _cloth_evidence, _state


class LoadedTranslationTrial:
    STAGES = (('lift_out', 0, .002), ('lift_return', 0, 0.),
              ('arm_out', 1, .002), ('arm_return', 1, 0.))
    MAX_SECONDS = 30.
    SPEED = .001

    def __init__(self, obs, hands, observed_at, *, calibration, max_hand_age_s=300.):
        self.failure = None; self.done = False; self.phase = 'initial_settle'
        self.pending_failure = None; self.cancellation_only = False
        self.index = -1; self.governor = None; self.debug = {}; self.segments = []
        self.path = np.zeros(2); self.processed_time = None; self.last_result = None
        try:
            bases, grasps, _, _, now = _snapshot(obs)
            q, _, _ = _state(obs)
            self.time0 = self.last_time = now
            self.base0, self.grasp0 = bases.copy(), grasps.copy()
            self.previous_grasps = grasps.copy()
            self.coordinates0 = np.column_stack((q[:, 3], q[:, 4:8].sum(1)))
            self.hands = np.asarray(hands['hand_points_world'], float).copy()
            self.hand_stamp = float(observed_at); self.hand_max_age = float(max_hand_age_s)
            if (not hands.get('detected') or self.hands.shape != (2, 3)
                    or not np.isfinite(self.hands).all()
                    or not np.isfinite([self.hand_stamp, self.hand_max_age]).all()
                    or not 0 < self.hand_max_age <= 300.):
                raise ValueError('invalid_original_observed_hands')
            if hands.get('observation_time_s') is not None and abs(float(hands['observation_time_s'])-self.hand_stamp) > 1e-7:
                raise ValueError('original_hand_timestamp_mismatch')
            self.governor = CalibratedContactGovernor(obs, calibration=calibration)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error)

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        return action

    def _result(self, action=None):
        self.debug.update(phase=self.phase, failure=self.failure,
            pending_failure=self.pending_failure,
            cancellation_only=bool(self.cancellation_only and not self.failure and not self.done),
            actual_accumulated_grasp_path_m=self.path.tolist(), completed_segments=deepcopy(self.segments),
            far_field_translation_trial_only=True, contact_or_dressing_attempted=False,
            attachment_verified=False, physical_stopping_certified=False,
            original_references_reset=False)
        return dict(action=self._hold() if action is None or self.failure or self.done else action,
                    done=self.done, failure=self.failure, pending_failure=self.pending_failure,
                    cancellation_only=bool(self.cancellation_only and not self.failure and not self.done),
                    debug=deepcopy(self.debug))

    def step(self, obs):
        if self.failure or self.done:
            return self._result()
        try:
            bases, grasps, _, _, now = _snapshot(obs)
            q, _, _ = _state(obs)
            dt = now-self.last_time
            if dt < -1e-8 or dt > .075:
                raise ValueError('nonconsecutive_public_trial_clock')
            if now-self.time0 > self.MAX_SECONDS:
                raise ValueError('original_30s_translation_trial_budget')
            if not 0 <= now-self.hand_stamp <= self.hand_max_age:
                raise ValueError('original_hand_cache_expired')
            coordinates = np.column_stack((q[:, 3], q[:, 4:8].sum(1)))
            if dt > 1e-8:
                self.path += np.linalg.norm(grasps-self.previous_grasps, axis=1)
            self.previous_grasps = grasps.copy(); self.last_time = now
            if (self.path.max() > .02
                    or np.linalg.norm(grasps-self.grasp0, axis=1).max() > .0045
                    or np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1).max() > .003
                    or np.max(np.abs(coordinates-self.coordinates0)) > .0032):
                raise ValueError('original_far_field_translation_pose_or_path_budget')
            gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
            if not np.isfinite(gap).all() or np.any(gap < 0) or gap.max() > .08:
                raise ValueError('closed_gripper_gap_guard')
            self.debug.update(_cloth_evidence(obs, grasps, self.hands))
            proposal = self._hold()
            repeated = self.processed_time is not None and abs(now-self.processed_time) <= 1e-8
            self.processed_time = now
            halt = (repeated or bool(self.pending_failure) or self.phase == 'initial_settle'
                    or self.phase.endswith('_settle'))
            if not halt:
                name, axis, displacement = self.STAGES[self.index]
                error = self.coordinates0[:, axis]+displacement-coordinates[:, axis]
                self.debug['actual_goal_error_m'] = error.tolist()
                if np.max(np.abs(error)) <= .00005:
                    self.phase = name+'_settle'; halt = True
                else:
                    proposal[:, 3+axis] = np.clip(4.*error, -self.SPEED, self.SPEED)/[1.54, 1.21][axis]
            result = self.governor.step(obs, proposal, halt=halt, max_speed_mps=self.SPEED)
            self.pending_failure = self.pending_failure or result.get('pending_failure')
            self.cancellation_only = bool(result.get('cancellation_only', False))
            self.debug['governor'] = deepcopy(result['debug'])
            self.debug['motion_evidence'] = deepcopy(result.get('motion_evidence'))
            self.debug['actual_lift_arm_change_m'] = (coordinates-self.coordinates0).tolist()
            if result['failure']:
                raise ValueError('calibrated translation governor: '+result['failure'])
            if result['settled'] and halt and not repeated and not self.pending_failure:
                if self.index >= 0:
                    name, axis, displacement = self.STAGES[self.index]
                    error = self.coordinates0[:, axis]+displacement-coordinates[:, axis]
                    if np.max(np.abs(error)) > .0001:
                        raise ValueError('actual_endpoint_drifted_while_settling')
                    self.segments.append(dict(stage=name, observed_at_s=now,
                        actual_lift_arm_change_m=(coordinates-self.coordinates0).tolist(),
                        actual_grasp_change_world_m=(grasps-self.grasp0).tolist()))
                self.index += 1
                if self.index == len(self.STAGES):
                    if np.max(np.abs(coordinates-self.coordinates0)) > .0001:
                        raise ValueError('actual_final_joint_position_did_not_return')
                    if np.linalg.norm(grasps-self.grasp0, axis=1).max() > .0005:
                        raise ValueError('actual_final_grasp_did_not_return_within_half_mm')
                    self.done = True; self.phase = 'translation_trial_complete'
                else:
                    self.phase = self.STAGES[self.index][0]
                return self._result()
            return self._result(result['action'])
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error)
            self.debug['simulation_level_stop_required'] = True
            return self._result()
