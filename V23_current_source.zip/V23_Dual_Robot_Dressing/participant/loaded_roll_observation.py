"""Bounded loaded-cloth ROLL experiment, before approaching observed hands.

No actor integration, cuff identity, attachment sensor or visibility promise.
Public own wrist: joint_position column 10, controller_target column 4,
action column 7; default WRIST_RATE=5.5 rad/s. Native targets are integrated,
so a zero action alone does not cancel target lag. A pending abort can issue
bounded target cancellation before returning failure; see the result contract.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from public_vision import _rotation, cloth_cloud


def _cloth_evidence(obs, grasps, hands):
    cloud = cloth_cloud(obs)
    points = np.asarray(cloud['world_points'], float)
    cameras = np.asarray(cloud['camera_ids'])
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < 48 or not np.isfinite(points).all():
        raise ValueError('insufficient_current_observed_cloth')
    support = []
    for grasp in grasps:
        near = np.linalg.norm(points-grasp, axis=1) <= .12
        counts = {int(c): int(np.count_nonzero(near & (cameras == c))) for c in np.unique(cameras[near])}
        if not counts or max(counts.values()) < 24:
            raise ValueError('insufficient_current_cloth_support_near_both_grasps')
        support.append(counts)
    cloth_distance = float(np.linalg.norm(points[:, None]-hands[None], axis=2).min())
    grasp_distance = float(np.linalg.norm(grasps[:, None]-hands[None], axis=2).min())
    if min(cloth_distance, grasp_distance) <= .50:
        raise ValueError('observed_cloth_or_grasp_not_over_50cm_from_cached_hand_points')
    return dict(observed_cloth_point_count=len(points), support_by_camera_per_grasp=support,
                minimum_observed_cloth_to_hand_point_m=cloth_distance,
                minimum_grasp_to_hand_point_m=grasp_distance)


def _state(obs):
    q = np.asarray(obs['joint_position'], float)
    qd = np.asarray(obs['joint_velocity'], float)
    targets = np.asarray(obs['controller_target'], float)
    if (q.shape != (2, 13) or qd.shape != (2, 13) or targets.shape != (2, 9)
            or not all(np.isfinite(a).all() for a in (q, qd, targets))):
        raise ValueError('finite_public_joints_velocities_and_controller_targets_required')
    return q, qd, targets


class LoadedRollObservation:
    """One instance per experiment; no reset or automatic exploratory reversal.

    Constructor requires an explicit stationary_human=True and an earlier
    detected hand report plus its original observed_at timestamp. step(obs,
    stop_for_openings=False) returns an action and state. The optional bool is
    a caller stop request, not a claim that this module detected openings.

    Before any command or measured wrist motion, ineligibility returns
    done=True, skipped=True, failure=None. After motion, aborts latch. While
    cancellation_only=True, failure remains None and pending_failure explains
    the abort: the caller MUST apply that action until cancellation finishes.
    If cancellation cannot be bounded, failure is immediate and
    unresolved_target_lag=True; zero action must not be described as freezing
    the robot. A simulation-level stop may then be required by the caller.
    """
    NOMINAL_RAD = np.deg2rad(4.5)  # Reserve 1 degree inside the pair's 10 degree budget.
    PER_WRIST_RAD = np.deg2rad(5.)
    TOTAL_RAD = np.deg2rad(10.)
    RATE = np.deg2rad(1.)
    ROLL_LIMITS = (-1.1349999749656927+np.deg2rad(1.), 4.275999675738779-np.deg2rad(1.))
    TARGET_LEAD = np.deg2rad(.15)
    TARGET_TRACK_TOL = np.deg2rad(.01)
    MAX_CANCEL_LAG = np.deg2rad(.50)
    ACTION_DT = .05  # Official 20 Hz action, three 1/60 s control ticks.
    MAX_SECONDS = 25.

    def __init__(self, obs, hands, observed_at, *, stationary_human=False, max_hand_age_s=300., wrist_rate=5.5):
        self.eligible = False; self.done = False; self.skipped = False; self.failure = None
        self.pending_failure = None; self.early_stopped = False; self.experiment_completed = False
        self.motion_started = False; self.phase = 'initial_settle'; self.active_robot = 0
        self.calls = 0; self.stable_s = 0.; self.cancel_start = None; self.cancel_stable_s = 0.
        self.cancel_calls = 0
        self.absolute_roll = np.zeros(2); self.debug = {}; self.ineligible_reason = None
        self.last_time = self.time0 = None; self.last_roll = None
        self.stationary_human = stationary_human is True
        self.observed_at = None
        try:
            self.wrist_rate = float(wrist_rate)
            self.observed_at = float(observed_at); self.max_hand_age_s = float(max_hand_age_s)
            if stationary_human is not True:
                raise ValueError('explicit_verified_stationary_human_assumption_required')
            if (not np.isfinite([self.wrist_rate, self.observed_at, self.max_hand_age_s]).all()
                    or self.wrist_rate < self.RATE or not 0 < self.max_hand_age_s <= 300):
                raise ValueError('invalid_runtime_rate_or_stationary_hand_cache_bound')
            if hands.get('observation_time_s') is not None and abs(float(hands['observation_time_s'])-self.observed_at) > 1e-7:
                raise ValueError('hand_observation_timestamp_sources_disagree')
            self.hands = np.asarray(hands.get('hand_points_world'), float).copy()
            if (not hands.get('detected') or self.hands.shape != (2, 3)
                    or not np.isfinite(self.hands).all() or not .06 <= np.linalg.norm(self.hands[1]-self.hands[0]) <= 1.2):
                raise ValueError('two_separated_observed_hand_points_required')
            bases, grasps, _, _, now = _snapshot(obs)
            self.base0, self.grasp0 = bases.copy(), grasps.copy()
            self.q0, _, self.targets0 = [a.copy() for a in _state(obs)]
            self.goals = self.q0[:, 10]+self.NOMINAL_RAD
            self.last_roll = self.q0[:, 10].copy(); self.last_time = self.time0 = now
            if (np.any(self.q0[:, 10] < self.ROLL_LIMITS[0]) or np.any(self.goals > self.ROLL_LIMITS[1])):
                raise ValueError('positive_roll_goal_exceeds_own_joint_margin')
            if np.max(np.abs(self.targets0[:, 4]-self.q0[:, 10])) > self.TARGET_LEAD:
                raise ValueError('initial_roll_integrated_target_is_not_settled')
            self._guards(obs, bases, grasps, now, initial=True)
            self.eligible = True
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self._skip(str(error))

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        return action

    def _skip(self, reason):
        self.done = self.skipped = True; self.eligible = False
        self.ineligible_reason = reason; self.phase = 'ineligible_before_motion'

    def _result(self, action=None):
        if action is None or self.done or self.failure:
            action = self._hold()
        self.debug.update(phase=self.phase, active_robot=self.active_robot,
            nominal_positive_roll_degrees_per_robot=4.5, per_robot_absolute_ceiling_degrees=5.,
            total_absolute_roll_budget_degrees=10.,
            measured_absolute_roll_degrees=np.rad2deg(self.absolute_roll).tolist(),
            measured_total_absolute_roll_degrees=float(np.rad2deg(self.absolute_roll.sum())),
            ineligible_reason=self.ineligible_reason, pending_failure=self.pending_failure,
            stationary_human_assumption_declared=self.stationary_human, cached_hand_observed_at_s=self.observed_at,
            current_cloth_required_every_frame=True, observed_point_clearance_only=True,
            full_human_or_wrist_sweep_clearance_verified=False, attachment_verified=False,
            opening_visibility_improved=None, cuff_identity_verified=False, insertion_allowed=False,
            scope='finite far-from-observed-hands loaded cloth roll experiment; not pure camera motion or dressing success')
        return dict(action=np.asarray(action, np.float32), done=self.done, eligible=self.eligible,
            skipped=self.skipped, failure=self.failure, pending_failure=self.pending_failure,
            cancellation_only=self.phase == 'cancelling_target', motion_started=self.motion_started,
            early_stopped=self.early_stopped, experiment_completed=self.experiment_completed,
            debug=deepcopy(self.debug))

    def _guards(self, obs, bases, grasps, now, *, initial=False):
        q, qd, targets = _state(obs)
        age = now-self.observed_at
        if not -1e-7 <= age <= self.max_hand_age_s:
            raise ValueError('stationary_hand_cache_stale_or_from_future')
        self.debug['hand_observation_age_s'] = age
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('closed_gripper_intent_lost')
        gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isfinite(gap).all() or np.any(gap < 0) or gap.max() > .08:
            raise ValueError('closed_gripper_gap_guard')
        if np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
            raise ValueError('base_pair_separation_guard')
        tilt = np.array([np.arccos(np.clip(_rotation(b[3:])[2, 2], -1., 1.)) for b in bases])
        if tilt.max() > .065:
            raise ValueError('base_tilt_guard')
        if (np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1).max() > .003
                or np.linalg.norm(grasps-self.grasp0, axis=1).max() > .003):
            raise ValueError('base_or_grasp_center_drift_over_3mm')
        for r in (0, 1):
            rotation = _rotation(bases[r, 3:]) @ _rotation(self.base0[r, 3:]).T
            if np.arccos(np.clip((np.trace(rotation)-1)/2, -1., 1.)) > np.deg2rad(.25):
                raise ValueError('uncommanded_base_rotation')
        if (np.max(np.abs(q[:, 3:8]-self.q0[:, 3:8])) > .003
                or np.max(np.abs(q[:, 4:8].sum(1)-self.q0[:, 4:8].sum(1))) > .003
                or np.max(np.abs(q[:, 8:10]-self.q0[:, 8:10])) > np.deg2rad(.2)):
            raise ValueError('fixed_lift_arm_yaw_or_pitch_changed')
        # These target columns must remain unchanged under zero fixed-axis action.
        if np.max(np.abs(targets[:, :4]-self.targets0[:, :4])) > 1e-5 or np.max(np.abs(targets[:, 6:9])) > 1e-5:
            raise ValueError('unexpected_nonroll_integrated_controller_target')
        fixed_lag = np.column_stack((targets[:, 0]-q[:, 3], targets[:, 1]-q[:, 4:8].sum(1),
                                    targets[:, 2]-q[:, 8], targets[:, 3]-q[:, 9]))
        self.debug['fixed_joint_target_lag_lift_arm_yaw_pitch'] = fixed_lag.tolist()
        self.debug['fixed_joint_target_lag_limits_m_m_rad_rad'] = [.0015, .003, np.deg2rad(.15), np.deg2rad(.15)]
        if np.any(np.abs(fixed_lag) > np.array([.0015, .003, np.deg2rad(.15), np.deg2rad(.15)])):
            raise ValueError('fixed_joint_integrated_target_lag')
        if (np.any(q[:, 10] < self.ROLL_LIMITS[0]) or np.any(q[:, 10] > self.ROLL_LIMITS[1])
                or np.any(np.abs(q[:, 10]-self.q0[:, 10]) > self.PER_WRIST_RAD+1e-8)
                or np.any(self.absolute_roll > self.PER_WRIST_RAD+1e-8)
                or self.absolute_roll.sum() > self.TOTAL_RAD+1e-8):
            raise ValueError('measured_absolute_roll_or_joint_budget_exceeded')
        if np.any(np.abs(qd[:, 10]) > 2*self.RATE):
            raise ValueError('measured_roll_velocity_exceeds_bounded_response')
        if np.max(np.abs(targets[:, 4]-q[:, 10])) > self.MAX_CANCEL_LAG:
            raise ValueError('excessive_integrated_roll_target_lag')
        if not initial:
            allowed = self.targets0[:, 4].copy()
            if self.phase in ('roll_0', 'settle_0', 'roll_1', 'settle_1'):
                allowed[:self.active_robot+1] = self.goals[:self.active_robot+1]
                other = 1-self.active_robot
                expected = self.goals[other] if other < self.active_robot else self.q0[other, 10]
                if abs(q[other, 10]-expected) > np.deg2rad(.2) or abs(qd[other, 10]) > np.deg2rad(.2):
                    raise ValueError('inactive_robot_roll_drift')
            if np.any(targets[:, 4] > allowed+1e-6) or np.any(targets[:, 4] < self.q0[:, 10]-self.TARGET_LEAD):
                raise ValueError('integrated_roll_target_outside_phase_goal')
        self.debug.update(_cloth_evidence(obs, grasps, self.hands))
        self.debug.update(measured_roll_degrees=np.rad2deg(q[:, 10]).tolist(),
                          integrated_roll_target_degrees=np.rad2deg(targets[:, 4]).tolist(),
                          measured_target_lag_degrees=np.rad2deg(targets[:, 4]-q[:, 10]).tolist())
        return q, qd, targets

    def _abort(self, reason, obs, now):
        if not self.motion_started:
            self._skip(reason); return self._result()
        if self.pending_failure is None:
            self.pending_failure = reason
        if reason in ('unexpected_nonroll_integrated_controller_target', 'fixed_joint_integrated_target_lag'):
            self.failure = reason; self.phase = 'unresolved_nonroll_target_lag'
            self.debug.update(unresolved_target_lag=True, unresolved_nonroll_target=True)
            return self._result()
        if self.phase != 'cancelling_target':
            self.cancel_start = now; self.cancel_stable_s = 0.
        self.phase = 'cancelling_target'
        return self._cancel(obs, now, 0.)

    def _cancel(self, obs, now, dt):
        """Move only integrated roll targets toward *current* measured angles.

        Negative rates here remove target lead; they are not a reverse-shape
        experiment. Any measured reversal still consumes the absolute budget.
        """
        try:
            self.cancel_calls += 1
            q, qd, targets = _state(obs)
            error = q[:, 10]-targets[:, 4]
            reserve = self.TOTAL_RAD-self.absolute_roll.sum()
            if np.max(np.abs(targets[:, :4]-self.targets0[:, :4])) > 1e-5 or np.max(np.abs(targets[:, 6:9])) > 1e-5:
                self.debug['unresolved_nonroll_target'] = True
                raise ValueError('nonroll_target_changed_while_cancelling')
            if (np.max(np.abs(error)) > self.MAX_CANCEL_LAG
                    or reserve < np.abs(error).sum()+np.deg2rad(.05)
                    or np.any(self.absolute_roll+np.abs(error)+np.deg2rad(.025) > self.PER_WRIST_RAD)
                    or now-self.cancel_start > 1.5 or self.cancel_calls > 40
                    or np.any(q[:, 10] < self.ROLL_LIMITS[0]) or np.any(q[:, 10] > self.ROLL_LIMITS[1])):
                raise ValueError('cannot_bound_roll_target_cancellation')
            # Continue recording current scene evidence while cancelling, but
            # never resume the experiment just because lost geometry returns.
            try:
                _, grasps, _, _, _ = _snapshot(obs)
                self.debug.update(_cloth_evidence(obs, grasps, self.hands))
                self.debug['hand_observation_age_s'] = now-self.observed_at
                self.debug['cancellation_scene_evidence_reason'] = (
                    None if 0 <= now-self.observed_at <= self.max_hand_age_s else 'cached_hand_time_invalid_during_cancellation')
            except (KeyError, ValueError, TypeError, IndexError) as evidence_error:
                self.debug['cancellation_scene_evidence_reason'] = str(evidence_error)
            action = self._hold()
            action[:, 7] = np.clip(error/self.ACTION_DT, -self.RATE, self.RATE)/self.wrist_rate
            settled = bool(np.max(np.abs(error)) <= self.TARGET_TRACK_TOL and
                           np.max(np.abs(qd[:, 10])) <= np.deg2rad(.1))
            self.cancel_stable_s = self.cancel_stable_s+dt if settled else 0.
            self.debug['target_cancellation_rate_degrees_s'] = np.rad2deg(action[:, 7]*self.wrist_rate).tolist()
            self.debug['unresolved_target_lag'] = False
            if self.cancel_stable_s >= .15-1e-8:
                if self.pending_failure:
                    self.failure = self.pending_failure; self.phase = 'failed_after_target_cancellation'
                else:
                    self.done = self.early_stopped = True; self.phase = 'early_stop_after_target_cancellation'
                return self._result()
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.failure = (self.pending_failure or 'requested_early_stop')+': '+str(error)
            self.phase = 'unresolved_target_lag'; self.debug['unresolved_target_lag'] = True
            return self._result()

    def step(self, obs, *, stop_for_openings=False):
        if self.done or self.failure:
            return self._result()
        self.calls += 1
        try:
            bases, grasps, _, _, now = _snapshot(obs)
            q, qd, targets = _state(obs)
            change = np.abs(q[:, 10]-self.last_roll)
            self.absolute_roll += change; self.last_roll = q[:, 10].copy()
            self.motion_started |= bool(np.any(change > 1e-7))
            dt = now-self.last_time; self.last_time = now
            if dt < -1e-8 or dt > .075:
                raise ValueError('nonconsecutive_public_observation_clock')
            dt = max(0., dt)
            if self.phase == 'cancelling_target':
                return self._cancel(obs, now, dt)
            q, qd, targets = self._guards(obs, bases, grasps, now)
            if now-self.time0 > self.MAX_SECONDS or self.calls > 600:
                raise ValueError('bounded_roll_experiment_timed_out')
            if not isinstance(stop_for_openings, bool):
                raise ValueError('optional_stop_request_must_be_boolean')
            if stop_for_openings:
                self.debug['early_stop_basis'] = 'caller_requested_inspection; this module did not verify openings'
                if not self.motion_started:
                    self.done = self.early_stopped = True; self.phase = 'early_stop_before_motion'
                    return self._result()
                self.phase = 'cancelling_target'; self.cancel_start = now
                return self._cancel(obs, now, dt)
            if dt <= 0:
                return self._result()
            if self.phase == 'initial_settle':
                stable = (np.max(np.abs(qd[:, 3:8])) <= .003 and
                          np.max(np.abs(qd[:, 8:11])) <= np.deg2rad(.1) and
                          np.max(np.abs(targets[:, 4]-q[:, 10])) <= self.TARGET_TRACK_TOL)
                self.stable_s = self.stable_s+dt if stable else 0.
                if self.stable_s >= .5-1e-8:
                    self.phase = 'roll_0'; self.stable_s = 0.
                return self._result()
            robot = self.active_robot
            # No new target may get more than .15 degrees ahead of measured roll.
            remaining = self.goals[robot]-targets[robot, 4]
            lead_room = q[robot, 10]+self.TARGET_LEAD-targets[robot, 4]
            budget_room = self.TOTAL_RAD-self.absolute_roll.sum()-np.abs(targets[:, 4]-q[:, 10]).sum()-np.deg2rad(.1)
            advance = max(0., min(self.RATE*self.ACTION_DT, remaining, lead_room, budget_room))
            action = self._hold()
            if self.phase.startswith('roll_'):
                action[robot, 7] = advance/self.ACTION_DT/self.wrist_rate
                if advance > 0:
                    self.motion_started = True
                if (remaining <= self.TARGET_TRACK_TOL and abs(q[robot, 10]-self.goals[robot]) <= np.deg2rad(.05)
                        and abs(qd[robot, 10]) <= np.deg2rad(.1)):
                    self.phase = 'settle_'+str(robot); self.stable_s = 0.; action = self._hold()
            else:
                if (abs(targets[robot, 4]-self.goals[robot]) > self.TARGET_TRACK_TOL
                        or abs(q[robot, 10]-self.goals[robot]) > np.deg2rad(.05)):
                    raise ValueError('roll_or_target_drift_during_settle')
                self.stable_s = self.stable_s+dt if abs(qd[robot, 10]) <= np.deg2rad(.1) else 0.
                if self.stable_s >= .5-1e-8:
                    if robot == 0:
                        self.active_robot = 1; self.phase = 'roll_1'; self.stable_s = 0.
                    else:
                        self.done = self.experiment_completed = True; self.phase = 'experiment_completed'
            self.debug['positive_command_rate_degrees_s'] = float(np.rad2deg(action[robot, 7]*self.wrist_rate))
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            return self._abort(str(error), obs, self.last_time if self.last_time is not None else self.time0)
