"""Conservative low-speed base guard using public RGB-D and robot poses only.

This is not a planner, complete collision checker, or proof that a route is free.
It cannot see through occlusions or protect the extended arm.  Robot-base world
Z approximates floor height.  Approximate self masks discard points close to the
controlled robot's base and grasp; they can also hide nearby environmental points.
Published own-robot visual geometry is a local development assumption; this
module does not establish that this use has competition approval.
"""
import numpy as np
import cv2
import base64
import zlib

from public_vision import CALIBRATION, HEAD, WRIST, _rotation, base_to_world, world_to_base, grasp_world
from camera_geometry import pixel_rays


# Static OWN-robot visual geometry, not scene/collision meshes. Provenance:
# stretch_4.usd SHA256 a7a7be5bc14354caaeb4461c9b733e10d8f18a0d047dec58814904e8317deb37.
# quick_connect_interface_link's visual bounds, transformed into grasp_center_link.
# This small rigid housing was visible 19 cm behind the grasp and fell outside
# the old grasp sphere. The 1 mm allowance covers sampled surface numerics;
# it is not a larger near-robot suppression radius.
_HOUSING_LO = np.array([-.234538103, -.031760518, -.047])
_HOUSING_HI = np.array([-.119975051, .031759243, .028])
# /stretch/mast_link/visuals/mast_link/mesh is a fixed vertical extrusion in
# base_footprint coordinates. base_link is +0.028 m above public base_footprint.
# This exact 28-corner visual boundary preserves its
# small front recess; a bounding box or convex hull would erase that recess.
# The mesh has only these two Z levels. No garment/environment mesh is used.
_MAST_Z = (.112, 1.58200007)
_MAST_OUTLINE = np.array([
    [-.131104, -.102982], [-.131007, -.103856], [-.127085, -.112074],
    [-.119977, -.117767], [-.111100, -.119800], [-.074900, -.119800],
    [-.066023, -.117767], [-.058915, -.112074], [-.054993, -.103856],
    [-.054896, -.102982], [-.054896, -.095818], [-.054993, -.094944],
    [-.058915, -.086726], [-.066023, -.081033], [-.074900, -.079000],
    [-.082500, -.079000], [-.083500, -.079268], [-.084232, -.080000],
    [-.084500, -.081000], [-.101500, -.081000], [-.101768, -.080000],
    [-.102500, -.079268], [-.103500, -.079000], [-.111100, -.079000],
    [-.119977, -.081033], [-.127085, -.086726], [-.131007, -.094944],
    [-.131104, -.095818]], dtype=np.float32)
# Rotating wheel visual envelopes in base_footprint. Axis is the fixed revolute
# axle, not a guessed world direction. Radius/axial limits are extrema of each
# published visual mesh; the narrow cylinder includes tread/spoke empty volume.
# It does not describe surrounding space or expand the base footprint.
_WHEEL_CENTERS = np.array([[.15068799, .087, .100], [-.15068799, .087, .100],
                           [0., -.174, .100]])
_WHEEL_AXES = np.array([[-.866023014, -.500004139, -.000003590],
                       [.866023014, -.500004139, -.000003590],
                       [0., 1., -.000003575]])
_WHEEL_AXES /= np.linalg.norm(_WHEEL_AXES, axis=1, keepdims=True)
# Exact base VISUAL triangle subset needed outside the existing 0.20 m mask.
# Extracted from /stretch/base_link/visuals/base_link/mesh, transformed to
# base_footprint; keep triangles whose max vertex XY radius >.198 m and max
# Z >.10 m. 3756 triangles; 10 micrometre signed-int16 coordinates, zlib/base85.
# Maximum quantization is 5 micrometres per coordinate. Data only, not code.
# This retains the actual wheel recesses instead of convexifying the chassis.
_BASE_OUTER_VISUAL_DATA = (
    b'c-my$cbrzm{r>-@2!hg95l}=F*g}V;_p*KO`(D5_jm8oaF={j#BbF$}L}Ow}EYX-mjnP<X?$S|dQlyEB6j4Nq2*NI)h)DVF?DO1y'
    b'PJX|CuE+Iw?KyMi%)IA4bLKwxy)#eEE1GzI#i_R?`<(yxlYd$~F;e8oMp>ye=f7XSZpp+*k?jrsQln2bzolT}`8&?|c}bu1TV&2D'
    b'OA~%(?Nun!sM*>?n)9xxw2X|y|DS6iO)~0?UV8qO3vb>0kMsXE_xBt6od5a4x7SaM6#3<wbKXsJ{*kw?e1Br3NV^69dMC~K7nfbL'
    b'c4DN+NpIc1GR^rmD|fA)7%B4WrFXoY=KPv9YgbN;6xp-'
    b'l*Gp?k>(%s~nv(n6QseI*5IDmBzRyeVPK*?(Gx*_^Y0kgUf6lszks@1%{qvnP=PwzQw{c>m$m1jCznkX#>qGW#o){_e)BMnG2)}&'
    b'T2cJxg6uF~l=ErHy|7ye++b2ef+*UkvYnt<a8rkLZiIF0wmi~8Vn)6LZ-MM#Sq{!^jCw8Yf-'
    b'(u7U`zJ<<)GO;!)#v;HN7s&88byT&$^87Xnh5-4@4tsEJ-'
    b'=#ih%}01@2?(~=KQ|u)itq4k>|hMFe1(QpB)NuPLZD+?mQ~Z`P097=sT}g2u0LT^!8c&)z+owUow07<}~5Ou)l6z_|%T2=U+SPvy'
    b'an+cVx?j6ZS4W|7hh^HSI8Qdc)7tgwI_#@$;pTA`i?MwLQ&w<x^zh%(AU%&b#8{O|~Z=O?}<;$>e3J&ug?>3gI7X@=5ZNNRf3-'
    b'?@k^~BK$*5mL$8TD6**O1<4H&=l{^;$>hl?icD{slYBek{H;yKCyyitwOE`uBeAggJBfcJUTv{4aeLW+n@vcbm)h8Tbn+L;+0BcR'
    b'Ba)?=Rf(1*MVW^Zuau0)JSBNaF-3ARM<(AYLilqtbCL^-ew*1hIj7{K7Oj#`lvQLFCl{4aq-kbuva-xQY7N&_lUXhHC+;p&ABuc0'
    b'vuSc_3Bs!bMfzl3kX%xP@M`5QMr3}Jc;SD}LNYR!B&L=keEjOjb1mj4CPakSdXF{ln>-_VbMq$2!-*H0^+?{4bT3-'
    b'ZJyOK+QIFSp{TTIiEm01_>&IQ0`N`!ai!+~0PAZDGD)N^aof~mpFHq#7%)66|i}Y_ri`?X634KA4A(<VLt0Th4uZ6sm*)N$YMR;{'
    b'nvUA-pMf5(xyI+drwm6(fMXkzfTQ%3G@%uvbKEf-FBBBW4l}`~7i14mXk$%m$C7MM&&g&zJ9BF!HvN9sP9;9i~DY@i39=x&HDRXa'
    b'fL}7;(qf?m$87&5<1{UaF{BVoUlNS{tyq=}V@)m27H$<G*dKCF@i)WL!N1WG^Z#1t;UQ;lo`Mer^zxlM}g9WauCd#MCht1oiE{r&'
    b'@e2OR&;a!m;u7&WAwzxidTOpNI;%6a7H^RG%Ud_%--Iwn!lz(fJD^dgV@gdEUsk<ZZuLwod9O28G-'
    b'JZHCpCVcS;eXcbpQ+*b6w!|ee@n9$QqA(!NBMU(c_P&_Qbd^ue{Yjzsmw?bWg`5an|z+yKAIw~h42qFIh2|<dU1n$%eRewtHGn?Q'
    b'$}ZGEUMAh8`LWw7}d&k@r;a_<)22!QzRqfZ{;oW(<JzX4X*r7k&KL=m-qON1V6t)|L+vZ$mm^j-82baO{kj0&qCZa!pE<UxNC%u-'
    b'vttH4L;o_?lH7LpKl(i)o{#B2WngLKqw#K`+f8CnyXOc&I6&I2tV+fel@kF$UO%_Ya{%SZ|c_E^^FHYO<XH|^`L1It{bmay0$?P*'
    b'G1C)Z{I26x=7mp{5wU|2TA+TN2{yb)QlZ<b}wVA!dSx>Rwq)wkB;$Igd$oA;ipvJp87?ki2FtOzgPbwH6ouP+6v+SQ2pOj^Qb<`A'
    b'5|4bG)0t&@SUo{h^B}#5k8|TjA)9u7Q%nDFO2c7RUw0^gR5-'
    b'X`$ckO;gG!{Z(qMRWM)U=C+`dSllNDIBG2s&xf<d7?OR=wQ7N)=Z^(WKf8oAolfNyb$d<h!b0YjT`$CRYALYmI6j3I^$6E|hCc?*'
    b'C9&s&%*H*3fPDuW|xb@!r<l805y<uH3z50~oqsh~&s}duUk5qk?s7{pZ3v={+Rbl4+{=Tphqljbpq5H$Eicq9r|H$N;i1V&Ok+S_'
    b'^7QVWwZ?aXg!@jUuD5?r87K$9$8`d-'
    b'WMW3pF{e4Rk^GXlwU7onNG+smGgS~4L?IX^+Blq}Z)#k*WM7++(hMF?FMTC!+j9j!YtVj`FP43<sRz$Dv4eOuh_V!55E>=%1to{^'
    b'nJi?1BnkJ!~G!I@}Wmko@U!(nDJs)o|q}Beg;zf8ZOpz}8!-'
    b'`i7Tw2q@UzTcTiY(q6)}II;zZSA^U*F_u5#iNM$<B4Z6w$K??|vz=ZSUd4Gf}JZ+SWMI4zu<iPgE3BL@OcujJ<mjc_kE44#JBNin'
    b't=eiyw-pC&C*M6w&4gZ*)*ZU)*ybJSQ3vw;c%2j}$RpsB`1TAj(1bUmXa~sua=tNE90f!ZR;LL=nPYbs#)Dmwj1XQ}Xw}oR>Tn)s'
    b'{x}to<uRTm|7rf7vdT8!6%{2tVx0!KsTPMO+=>hkiLC_1DyMUoS}gCDrjrM)^ZE`c3M>$Y*2>D1Y!f5){eE=v98fcO>|XjLh<!RQ'
    b'8b%Q#mz$TdHBI%aK>UQzRo}a_U$zO@i-n<mMVxALqvJ3voQc$J+-'
    b'{4#I2O_}#@@BYnT2{s`}iG<|pR`wBjNFYY?D#_p4jryfdue$v-9$1gl3l=k{5p|%MB*-'
    b'4vfN}$N}Q$lSKe%nbe*OW|=S566cf$&>S`c2K<EjlIKmutB?MO-&tt8{IHBCd<1y}JvFxGs|R+rCpoeUP-'
    b'D{9O(06xj<xc=e=+y&#0wN))jdghcy7wXH-EdqfDY-'
    b'8>`Q+GJib{X9jHyk_%~X~KI7JF<4ls0T+?uNgSvrh>n(y>`Uv!UtAm4NVp|UNK|f;?gDWUN!uok_-'
    b'2z%HJ4bWn1@~oi&~!R^v$e*`(Q+H-=a>S-rfmcYf-'
    b'=p%k$yLwHxAh;<{vyW(AY9#1qYGi%(i>!IYFVH7cwrb+Nt0%jaDkrF6k7DITYrSpSaarnF4d&DS1`1rmkVuT|6g$F8=d&(&yQz86'
    b'_y@$)1j-`m~ituL78+ZMtr1>~I!}fj=K3)!D?-'
    b'$|Y^+D|YBE0(l=dC%tCZt|lF}VK)$uY~8_T8SK$j_GT?E67NEX`YUc=)U+qA0R%)jdOx7a_bDqsYUnx(+QVMtCv#+Qu`BPK@lZVN'
    b'=oW!L2^1S5$BC!u8h`H|_t`=KRuCgSM`}xA={I6nXx`t4d$(gYY+Re5|BfZ;ITy@$r&Qy(#j|#`Pt4^`uC>4@*kF>5lL-H?=EW-'
    b'tDd}N6N11_VGu}$|mQm-;`Zi+KnPjKbl-RB;x#+ANH-'
    b'$!=JyDYTM<<yQiea=az3fkr<!L<MsC?%E#wsWK0+{J~#KPlWVlzp)<$4*PSAcLHIvczf|71Cq<No@E!N;Ne$|ik#Y5y2YV{N$JaS'
    b'Eo+8Rb_zhpRtnn04rZHuV$HyRITqFF?zu1@hNq>qM*GPKo-(P;D|M#|iQufL4)}OtT{L_H_Tk{i>2U2AHj(3wk?TzrSeDb}-'
    b'J$V$Fy#05{{H_SEr<9-_97z$agz(O#i2g!&B~#?NEz8P!MVuE8Myo6oAC-vAgYZT%MIPLFO=;Hz!q?kApzy<Sw{PxLkWsd4>(fQ&'
    b'C7XP*s`#8D{=@CV$}$TPifCbkzxw0KlCMWlL<=LlF+~wAjPS+_MYIFL8$lE?MiAckYWDunVf_=o+Bj*%l_~c~k%vA?<!?(Oyt|e+'
    b'ZvSv+LF3|h{y`qv^g!XsQC{NBfE1Bu5dOUPPb=6rj3V-'
    b'nj3@h<F)5<{2p`XNi26r$c8|67jI@^MDTG%~is&hXS5J!QDTJ3xDI%jHygSvx;!QhKL^LA2NTY}tMtG4%5g7xCX7JiEOA#3Z;f-'
    b'IK&L<(0AbdPSA{)Ni{T=6JxnT{5k4b0XV~s+_vjh3xrXfeY+VJBVwP$PJcvNP{W<F=}naiE0hkHqX*6(Q|tPs2#Fh8?)2Csc9fFl'
    b'2G5@uV3_s#%Cypuo?YfglBU5Z#IBfMJqT*+rc>VWV*QSw)xo#9b!Yl%+@k?0e{+FDV>3K`+mO6&O)<H1&;XSJc$^GS-'
    b'9*XDMBDPo<O-Wd+w`t!d{L;r3*J@o!f%|ibod`{!t-~APT^0W{$6w%jd61-'
    b'lfh`J%Xs8D|TS|Oq+BBBufhjp&1@e~nz2yfOFnT~05O1&CS5#=NN*-'
    b'aPLtOO|Ht`Yv^Gs3)fQTs4YO=}zGuW@IE*^MF<tsB>@PxhY|)-dOt7v{1%+lRbO5hbLuLT<_K`d0q0hkukEatK9k?)=-'
    b'rUPBOmc}_<0)dOzp-FD~?iqGox*|5chS9TAXnIefET}ED=kMNVbe?Ib0qkq*Y<T_V;?A(ywDB>yze@cgt-zehh2>;`bVV<H$c6Ps'
    b'#W)b0E?{ui-w>?hn7}j#y<S!kEmCox-'
    b'5iNu8&Z5Zo&k6G*!pE<UG;0^;S%i<@1@da!kS!73T^nCURy=y6vDP}|&nS1*`uHe7a?cEFA%qt*6cHx~FQO<Seh^*+%9iqsQBM(B'
    b'1>tXK6XucD?ZPbctMkHq^!pBBew0IG40lHnB_MpKv%(xi5hWx1!E?f_DyrQ@JmwKCfbe>aB3csR^%_Og4dL}8Mbr)9<1vq@Gr}7q'
    b'6#0F}u!=zVLEXaIV}F;h8cFpD>y``p&F#Otj3UDZ-jMfk)Y@9!@eA`VAN=1E<5xKpF=i1yULPbrmU-isBDZ$EHvgn(T=VjY`P5r^'
    b'@wo|kpjB8WBfOrah**lpl~$sNyN+6~)@!#&Yl+rC_;_m|+7scmo|+sxE3Bhjks@X1UOxKOF$k~y%ZKml@>r^5c-'
    b'^kkk_!g^r`HRKt9rjWtTew%?}}mbM@{HiZ{$lO@9Exq^uA$#?p}BF6C;pcbjdC}(Em4`GmCETe_7`@3cC)zEBl8<LvlK0=M{C%%F'
    b'Mo}xO3<KbbP9$b=I~HT}m&{mgVHJHd*sa4tHys_2ZKDxjZg|$(98<6N>-UPoCuQD|6QsHSX_z-'
    b'FxGH3kS3<li{!HdG(0r^5u4l=zXztaqp9d)h%*7MQ-UmVc6UPgm*4Q{@C;V5d%jfypk{P`b_?P!|&{RJb%Yf^ASbv?b@dxYlypZM'
    b'+36YEJ=3X)9IPwS2}4Wtw9kjhQwR%>@GVBdi8y#^YFrrc>_AHE_^sr<dn`&6?W>4@E7DRFFH4mBFl2$D*RqAgm0KTw5Vkdiu^7oS'
    b'+u5Wt6s;3cOTiKXM>S%4j<mL&d53=X7$Y-)T$_%S3a~j|J*)>LoP13BCp}l2Z}E5^VQ(fi!bQYZ^+U@ik#JN-oUqu5MBus={sO%z'
    b'h9P!zzc`g>G5Jh98zS?pvHLxWeETE!0+{`jucUjINX_ichR3ay9<i+%^6wzN_T{h-#hZdoPQM0?v3!;N}S)`<>bN_2aA7-'
    b'+}L$+!Pr3vKeB7vg6ju}4P!?<P{hbWc+o<UA9wFHx@#0g{PC`1@+$|5F&WHNC?dZhyem>f^dh{`O%ZX9@bUvij1GM&D&moV{4(#-'
    b'p`#<hi<}k%TJ=9(Qqb?Ifte*m{eC;}<r0MNIAB-'
    b'5_GKpxnAq>s#KQi2`p!?hKk$RRQAvta4tzB4k%;h*4nDnCBK5sKuMd8)cu1cKgL{+=?Ux+br<5W&{hAD%5)uB)0dxC3RYnolMfg1'
    b'foAmi4Qp9x;e#+qDUf)KFs1L$t51-'
    b'Ygw0z|7^<569WZ(sZZ|L=SlBS7KfCvBe!2W%%i!@D)0z7yvMiJuz;k7VDj6{UjBNQ>B5ndl@XW3QTQbevscx_7&IUM1&Ek$H|B%1'
    b'YVd!Hg!7YHvNC{i%^(VmM^2><`@k$4XxdI90%k$~t0gpWrQq8AW89+`+%MdB??5$%ugTAL!q7s8wAC}Jccys=CX;}_xM82~XOAiV'
    b'VhMa(7$AI~<3Sq9<dK#G`;5MEZK$oB5P9Cc?zcsbK7Z2q<Oponz~!pG-'
    b'j#0m%D&Ew`B$Czs<qI`rm*HFaT0O8F(G`<!>`1t&eSR)~Pe4T(;xgorD1x3td2w&J`Nx?t+Qp6mG@Y<OoW<!LJ&vA%36yf9RD8&4'
    b'W@YaMBQFDZMzxy`aTimU4n+<mtJ=l50`jN$xyZ>`#!=Vor{byCfVfBjcU3K%Yc?CWpTD)Sy;GQKuC;IsPtp&sT-'
    b'v0jI3WoN3YF(Y8hx%46ZPouo$(p6F_q)2J(UR}?*<VJHQE%1HD~<?1eDQyJy_lfLzZM?s{%S<{ne)TSXVuE<hGysQSWz;hxM0hQ!'
    b'XZD26#2>9g@ZDRkjGcOI;<?;@f3M~RmHG{qY%E?n%ogzj!<)V@uzi}MR)Y4$Vcy;R<I}{{G0E!Ex2I-'
    b'MQ(fVjr`{$!nc3#n*3i4Y`N**#Zx*B*tnzc`3`q(2=R~b+MFUiHe6n`CKuuL2t}S>|AV65T@hY?QRK=GwiLeJ6X835@J8XpUOpE)'
    b'dvkc=II!`el1;f3x%k7duJ-Ah&jmi)IKSlEND-eJ*q?v;y=U_OJUqUukKDAj?&v2+_!QD-lz&}w^@!*5DdKp9pRnfr5ralkL^%lm'
    b'$2IjvzC2Rwi9>t-J}vbL>9A$Bvs<kqK0848L(3NoIJ=A@%0c)I%foC-'
    b'5m!X`MavU4bC8k~OTvt)CKQ>wILx8fEDm!hj}KpbL$4>2r!Q&JXKUi*CH?zcAI15!`C)D2uLvI>DTuQW-pEqIoAblGJa%!Ikr6&!'
    b'T2Q3Rl65s}FoajD9n0qpTv0T4`BMW=D|ul>-yzEiDe}~cFoz=i!z(WxnqMem$R08VMP6MIW@Lodk`$S}Jj~z-'
    b'ubnBfd1+V)Abh;Pkey4zDgxo-'
    b'{f>OQG_02pUT+%jbJtHOemcr*6nS<1<HePI5PsRZ)rF7cQRJod|0tf<d;XfbBkPX1b#3p_Rl}ZN+iP^Up%l66y<_=1Bf{VEUd<FX'
    b'gd$I`d!w-'
    b'1V1&Q_y}<?N526uScck!=fj&jzeU?NKM<RUuvo^#Pk?88RBbp*=j_}4NMcg&Q8@Xl&@nc4yh<HPIS)C%{4dLT+0U{0&Uj8>Cj6{)'
    b'75u*~}jRlH`4TLvRC?bjw-'
    b'q@sw*hBdET#1Nbgx7i$F%}SBOH#y`LU^N<BE}{XjojLHqe!#{s3p8sHI}_kV(e4IEP(LNrHEMo;gw7gvjD=I!6_of5Z?Sw5z&b7L'
    b')ZRw)Tp5pF&+{AoweDcy9}X-'
    b'@rdwde2N&M2p?ZLM5DNNY(}Kk$5$ZnagFe@5JkLugYdEtMZArJ@NyJIyq|;c73=RPp52ooRtN~cY{Qu)W4cqsngQYC>kY(O0^zMs'
    b'tSV*KOV$l5+?+=dITqm$uY0DjZEuRGKf+u8P(=L^KE94Z)F0vFYc@pv5#Ab)B34$FsjW>e$$uy@;FO|*_e%~od$wf9nB3$2I`$m%'
    b'k7HXq-8c5n$A{!l<XHK^V~4utm5)8KC9nIq)fpG|LMT#a-1R5cM}$|x8RLFhw`bo@<KC{bDesJN|E)7MQl$I1GwXEf?HIh-xM%84'
    b'=}VC}$9!EcYY@UeH};eIYX)vh^=Q~)#I0kFpM3l9>M?(4`0`MCXv_@_|2ouPDKc{G)eUloAiUBj@~g2GC!IAI;ay8xX}5UE$d~2!'
    b'HO?D}@M_hi@Mzn`$vaCXv>8|SgOWR1-'
    b'5)7(Q`r?QCzK$3QR3&BiDHW6CGT$0u}C==6uox#s|n|NPPdPj*>CfJL@`C|6d`=Qfs6C*FQbT^ScJEKySmH4(OJ<m;LF|SjA$`}B'
    b'A(FgPTR+x&^f<wYNUwgP=r?|MLdThyz&QRB?=Ek`@nUx_vLTNqlg{vld_&G+}g<#z2hn3=^o*o+oZ!)`P(}=cX)@){GDAX;&_B_*'
    b'm2gV*YhZ%CJ28?rz=Jb7(|haa~>OYZAAE?*||e=M^I!$=P|>7IpW6BE*S#`eN|Rf|Cb{+Bwwy`?I46-'
    b'QMTdO>v<G0`Vjt+#2rU>cBP2XhwyJDvW{-=L=hueOX|mXJ0toI;nkcX`VQgU7ez!4!vCx5z`-'
    b'*MC~~65YeR}6!vD0#HT^o2Qe;l=L;asEd7`9YqnS~@G9D3LOH#ymM0hPp5hESpwIoGkA%vIlXqtpPW^~xsijN({z8S*1JBk?B2=C'
    b'r0Vq7Eq^1d(kuAiicajmUn7+D43<t~cIHXlw}QD<}B?n&e84(z*oQn<U<r+wSBrWaoOL5q`$W><tGDe~LO!j@N-'
    b'ApFZS!WAiU%Zy*NNkoKyVOB*=HdDT9jhqr%oBwvwj=DqpArv`#^3-'
    b'~Z`XhYb$vx^nKY*qt|GWN`1LJ2Qmrg!dzbfMV+0#PrQ)K?+YZ`POg78Ntk8XJW(Dx?&J7Z(dcPDMmxU*Nfwn341C$*~6u6LRQuk}'
    b'_<4bf6>Y8Y`RPabpP{I2gz3FB_yln%%L-r?rSVP-^lM^dD4^4rH(<s!Ut?BRU7F=Q=!H56I4F=Q%)w^w5YVvTWpLm1Z-'
    b'u``44&ZUU`9E4Z0eW%{<hw*O5i6YjV)<}O`7xIQR6-6A0@b<eX;wp9C3FE?=`3LWYaYPa8WQ2DvMXZw%UJVOZh0$aO&s8X5rw-'
    b'v=aqXhQ?u(Q52JIOl{IMlr3{u1sCBpAp9!4ugJW=Y+gPX&g74HjV!R9beA$+_~k#9Z>^Ay7WXMM=k6#4h2Fi#=;{B<E$pHdle<}Y'
    b'SmSub})&TAnzQsjZ@VV**G(N2-'
    b'Rm0_Mj_;`dP*H(mi3gL|iiVUs@GndFW664oGj6Q^q*BLSP5#Bx0D4*1heS{xBBg`)p`Bg=jSrESa?Dv~=D5Xf(86n61^t~{ni7Sz'
    b'V@Y<Oo;uhiK{e_5Igpc<-VoV`?{HX*n9_6>Mrj#_U8WGQjNWW<>HtC*^@a~Qx<^_az?-'
    b'VgFApGFj!&}x*QpCKVt&9#M0^yBBiWn)EbxzDXx!{`4MRQM#Y}BL08()vu*y-k(-'
    b'wwMkr}wOegUdQUFnf2T$QzxH&05&cZ&LkYz|!SS$4(gXy;Xb4{c@Dwm_jJx_o)zG36~e_Uq5WHUzD0W>W=q+SVR$JBK*YR`_}xkm'
    b'?FwV_~V0TtoX2G+wi}y9-'
    b'lk4VDb9#xl;<>TK{;Lu>*I%H9mLp;HAsP=Z+q_{O!g)DdKp9zjQ=m&3oN%>~+Q)y>frh=f(Nsb8qhZw*~oKDY9w6Wi@3!&}+-'
    b'<S9PoI@%g;TIgaP?K0SUuZ%7VBp6&MfobrhC!@5tNJ0xd)=aXmO*Y8(d-'
    b'=96G_vr5Bb6@R4kqKQl%<d3zerdO5bH3<Kk@nq6=gjMY@b`CnVa}3nN_MUuq{xcyf0(yw5W?$mQE_XhOK1Li_-'
    b'!?M<M1hG&7J=J;zeh@KE0&)iS|#<TwO?!h3z`dXkSS0KWEg8-xkD=LH<&sw?>?wd)}%Ue;svAtHSB4ODDH%HS>bxn#}E$n-dh-'
    b'(&UNCTT<#EKGlsP@jCP3nIi5E;V;b_yx^1JnS<Y1cHht|`oFt)&amo!_bmF;fU^cZ{#M&4W_Ay}b;+P!6cHx~|KOm%Ed5D;G4qd+'
    b'bJk`Kj>i~s)3A=K#tcDtXHi5=)JhFc%KPBW$pa~(*AV{t-W6}$lSdITfbe3EB4PvKMWZ@shj<N<vHh-F_|x79|3B?hON<eO*PawH'
    b'b`W0M9_fDW!t;{*a!;DSEqPAoSKr7eGp3vszYD|_5kB4;h?*mOyj2mskMMedB9G^7S(sUf@bMT!GJEWM^PD1tmt!eX*!h>QH!eo_'
    b'WczbxKU5-j$z!Jv_-bjhGK$Ez2tPM({^G6)`AU`(ffSKr5neP>M2<yx(MS<F7U9JSMbsbRwHrm$AK|qdMcfy{Yd2Y9-'
    b'#PEi=^teV5h7Y}`AQy;TcQk8OSCz{$8!{-FA!edGiUkDM(t0L4SAm|X+93&)tn+?8{yp-Mcfg>ix3*!Z|$8Tyn0eZTOqu=P?NRYU'
    b's(KMR3D1W$h~#Jt78ye+b$oot2)2yspGN_UDfTav4_9BCoem7_vb(9|GngOyY3rWSoXthV}|hffz;D`=M4K`Z2xao4ayn!_v5<<&'
    b'l&Udu@fUlmP~E6CV8}Ea*GR+H<oof?X$9?vYtCXEb)txmzSKf^`FHQu@XS|lZxtY{$bJ2%3iK&KF+T``UOaY?@~5$chj*H@k^2j-'
    b'>&rV_C4hk@r#uACV$hgW+bM*X}G$ub1J9F_lut$yQ$ud!~ZaLK>gjr-33K%9CJm(-'
    b';73h=ThXf@~<0DiU_adJ>w>Q`|}>(jw?8JEbpmt#YbN4Ly`I8%1&G~AZy$ghlk{pjywCvker9d-'
    b'FxJv&ibO^*b5Jg&($LoSu?i7p<WT^Gsm5Lcyi9Ui63nrpIcRa$-'
    b'eQq9m?nLY1>79utvJL^vO@&>rRogOR_#rbAEm4Kemp~)f(<MG49uOP8&iIeU0$$f+C^<;p6v?h%toMRuplM2(Nu8;@%Nnd&+xSU~'
    b'BQXk242T#9br22!FRc>)6Q!Z>J_5ZCu=-yx{9|iYW4*WRIg6Wu;|J>s*<-'
    b'G%@MhZApY8naPod&Wku7F9(^I+O|Kl5aCZ9v;Dv)!(APJdd!f+Uyq=OV-WuIu{#e=9!QZ5<uC2~(*T6Ob<CSpKkZGCC8>Yx9@Gor'
    b'MGHk{CLY|;xF^DkE+fdujgK$HNJseiI7J>w+_a}z8NwUa6zP_Huexgj;a8WQ_tl5vqFhniv$6z5^d`c`vkjt`5niomJj)@xT2Vyy'
    b'ljXLQRX6CLkn1QS&mjEx<gTW7MT*E0#;nmD?+ZjWK=^o{BE}2C$72IA?hrm6V~8=1@M4l8vK+!29TahQ2p=CQh*m;)BTE(%Z}F^!'
    b'h(?6hYZMW~2yf1!h_Qh1`jjHZ6vD?N0Wp3NUc^$ws7HA5OcB}RN8=to*17Z6v8#^%x$~rP(~iH=y=&r{%(hWni5xNWRPwH7J)&4L'
    b'o9r0(-0^?)lXd08J>%LPJsjmvpJ4jT@x!tA9(|=#-'
    b'*KOxXxYPOk@o5@FK=_|{82ukv+vy`d920TMfSaY;^vt9#!P7R(nv>A<eD+Xjp{_7@$vD`AAdb|T7!MVeA-BnpNxH=LDz`zK5g{b;'
    b'*qg$)w_N`{Buv_H{<T9d!RqU`<&Eg4L(1;c3f_qha*LnjT>6$_WlUJe%ziD=jLfKv+#rCijJ<&rAW7NC%(Bn8{sp@eQ~69R(j3~?'
    b'W`A+<H&UT2ThY-'
    b'97}dj^WdFDkyFoq_W11H2(M=;^7**^CmQ!h`1mZ0{CeE?>U51}XWp!RVr=93JBD5{?)kbe4(>hfP`#`n6zM*0YrV095Z>p!qR!gp'
    b'v(%HP)-4i&ZzRTL_9=~LHstoirI}MA&WmKdqy6Kb6CwHn;YBG$j0=Pp!xS-'
    b's5I+8?Jz}gOym68KEI!1N2%(5bLwM~*5%G!eT9P7S8{xI{$;qCXnI&hZe%kEx;<2g0&6XBY<m1$)CZi+5k51KXc5wkkZY!@@0Ou!'
    b'58?~-3d!wvw%i|?RE=61g;f-'
    b'{PxC+9{0~B#xgpYq}hNut1%OMmQKjvSJ298E}`Gg|Lv8x+AF#_Rb7>dXz2rvIoL@u&!uQO&|qv!HPHAQ|<e(R}o3lLt+Q{?{C@g@'
    b'&Mgf~VgvNL&Ovlk=68#NT!n;4z>azuC|h$2syb#B?d4B?F_iriQ>u;o(`=Z(1Z3=&Acviz2(CJ;WpZb2R?{a(xY5$8SAQRELLJz7'
    b'5!5q^5nDQ7K8y;j`ttjCl06rXz5x5?Edom-Deim~XejM|u_$VbKd&U_((@O?^Kx4te?M41TRsI)`tPZAVyEoFKS#JLn%P_U}~v?R'
    b'himm(DfAGLohx(nXDP~?e%&Fv4T+;v%T)3XvO_ip@}x#D>hF|Q%KJWLVsiSSR4J*WPC!zm)p5nd!y#CSn?QB4u!4&g;LMdTBN7u6'
    b'Jzmk?f5Q$#*Ncu`Fec`1tjS}&@j$gd^h1mQ(BMZ^ihi)xC99E2Cu6cJGfug57ODiB^gP(-'
    b'xo3;PN2K1DonBYZqIkoerq$LAfyERXQ<`3tc&KzOq%MXWIp-mFRyYZZhyhf>6v2jR`I6tRx_rtQe-rG+cn-'
    b'Z*_%Vcj!lR(@M_!P%!y@0tJGvj<Lpe$@Bd|7H3^BX6#nRdG?`qN<lFJ}P_cz>O7;Cm!8?>hv3n`fdwnZTYm_^nVx3*>u{>=La;{l'
    b'r{5*1L|%%e`Z<#zifGZ`p)6M+p>20b;Gl^{&sra$VIynmD7s;y6cL{jzufK_^M(;$@e?lIb+%2WgVWHarWSEJMEt_XwaIDduQA<u'
    b'&C4NGygN-NT;lsKZ+DN-syWYOZ)#Y=V!C-'
    b'>2+bwm9uW|wYl^DS^w#IUALR(w$3W;{=wYKvwh;@Gnxk73g_&OcHn)IVyEuEZO)v2MhQji<I&cqt*Lw^am#7Nm50iB+~+2r?#`V4'
    b'S=p{H0^e3OvvN(c+sDt&_|53<pHxr3FaN8pjb}_MJhFE1+?P5pTpMaq{NC+zmgV05{x`GRbmrfGuX@hEI?>P9O`Ovu%U>yScwM_W'
    b'Lvj#)$-0@dZ;r~Gu{PYP(kSxRcSAcMysNBy_rf_p?{Vba!a1LJYx({Yvxjs?I<5<?*XjL<vybIb<g|5LX8pG}!k@eDl-'
    b'W1;qsX7vpEm3EJcPe#{f9Gu)3@8Y2D2aTcjNkHGk@N{-'
    b'UriWT{M6q_thLzG!Wr$T;FHbi9r;ZzP`z<mV*(#?S?wDP8)L1rm+9~hfSBwym5HOM};%)7=iFRHkHoYJzQjt*&g~-'
    b'd{RX3AiU_Mh<;Q~?#`{14;DL@A{Xuqk%RDkcHTYxu1JyHpZ#F^O;JQGJL9^_wx#i?L)Nzmr6Ig1efOMD2Ycz!XL+4Yo4InR9r%n6'
    b';eILNNQ6JH{lBN5GnyjGMELe+hr9OaWb~<YPH1h4M4tfG5?)Ox;?qNfS1V)C=cju+Z<+N%q=?U65#DF1-'
    b'MWT|HKJ#Ay?xH|T#6Xo2ycv2#Aj^?F9V$1IgF!0ooCLT(D~uq3ugbcD@A5>Za4ey-'
    b'4XuYoZrpb)$^vD5Ziyw`EcgVeXFu6W)}CAuVgA&E1tXLD};X_XW7gv`%^?7LwMy=<ab&3%pBAY;a&anPJ3oF9nzyiw;Ah(6?7<@k'
    b'vWticeW4tHuIc6PXBfUe|`Iqhfg_lamA~Ne&6I(yqJ{35x#u?zbeL+QAD;!co|zhm)lSIxYLZ6hf-wi=590IABOOUKk7W=uR|#^c'
    b'XOyM!oRXP%mS@8h5I^b(}9|H>%aNw8D|YPo0wT}iv0Y;%`?^vM0jW2zVY6f{i6IMBT+<lif1YrOg@ww<v@y*u4^~@iHP&R`(X6!^'
    b'<C*d*Izs9!d~&SkmuKrpEV)kyv#|FSJz)L>!FDAaw$b_-SG9yO%dVa_k|4G_{_{H5#hCiHi@?|MYKP{7i<cnm?C;jj(ufISPy)>C'
    b'FBr_-2G`-'
    b'Eg<|0pN3V0oa|h)Bt;yL@NzFjl!Nf`jE$6Tf44F>%H+K4O_Ad}W>y}F2rrY1?S@}`QSo_+2&c%wU4tvXEk<~27>dl_@%PHfg$Qqj'
    b'Ly^aJyk0q~0O4QR{#oTE`4@lDs`8Iz{XY+L!Jsd`t~jNPA}u~oR6bl{_2o#lrHJDZUd<_@9E4Z%zg2ClSe3Anx%Z2(+M$Sb4#Jz!'
    b'3J?CGvLa>Wv!klGa$=;2a}j=CRpZL;Ns74c`~weE{4sg_s|zdIr8XaUtzu7-'
    b'BAJJNQ}Mfq^T!VCs2Gxx!5kw~QAC*tuk~a?8B#u^h*d7a%bygn9!B^-'
    b'oVBlVU_M2xoDu$}GnZC2DWJ&JXTDxJIwJhTt;Sb2EixC}oD<eR@i_&N^AX<4nIdKZgztV{-'
    b'i%8lMYO~4CZT2CZV+1X>L#JBD6*~5MHN#c!cS`&W&!!c+FmZDh+K{E)^Ze)s}bJnjv{gq!dv@MM0P@WYeI_1T1Y&DQN)~u@Uj_2J'
    b'h>pe{6?d{){bR_mzOAF)FZsSL=m|H;bkg{7`X^9k5R-'
    b'JM|dkzipVesZ*)^chC%pvmOzXzgg3e=VkE{#eLN>1MmoaBa|<E^AiP{ur*RnjqE~Dq{JusZdr+iflTaGMf6(aP74N4gQm;uU|GDN'
    b'bR(xEx<g~9V8kgPId{)K935xvZw9o<w|BL1uD^^GE*PYco)YJ1LMe>_BuIv$U-jk*$aqswf9;b-s0)+RpP7zNK2*2-'
    b')vYNi8i02N3cP|w2%!2Uljw0%e@a~-=?yj(=oa;(txuLBRm9IsL$bkqy;>-'
    b'}|6p3<a?K<4^LVUH1cy>Ve_^KQ6q=WFXD@8o%AiV5K5l=b@ZyuqDXEB5~k5I(37{a?#ig-pt_;~vu9nXBK^1>p7kGC_@q*cfa2(M'
    b'o#^37>sg@Eufzb8;{nR;@hi1<W!wW5gFMtHTNh`2>~wW5f)MR@h3h`2>~cR>;38sX#fAYxo2yzD^{(T?!42StnmgqK?=A~PVo_i`'
    b'yBt9XX}eV4E=<hhk1d%A?D6@>RBOA$L}2=6(UBKFoiZ{Cyr^~{ZVMju7&!XbS886Qy^!rK#|h*}|h{D~fMcL*Qf89=lQ!rMupNS)'
    b'3{=KQ^b{WQ;RcGW22`3~XZyK{)ALWGa+#UXav5Z<m}q_xCTrxn6=+gi;kD%iQJ)vRYrx^!MJcWWoLeJgjt+(TUle-Kp7*R2bGrHD'
    b'O4Pm7)_*Q{SKcS{~cJd+~4GAW`35MKG7uRV7+`>@rltU(m90`weu`G!`rrbbVr6mdMlTTfC%IZHooHLJx4`wa0N20I4+N)b=82p_'
    b'K@;wc#6-H|re{_&C#t2=~OE6;H&K7XS!Q5=6}L?%_eQF(u~Tf)b8SCIOL-l$xhM0mR~o(s&3ea{G`QAB1&`16~G(kLRQA-'
    b'pxbrvU5!f#-%hqVfGAg#T;X&@%fwh8DBm6+a8{tby>ZV(iNjPi2SRr--bA@UB7;`&|fcPmKC3Abu8N{|({Q(>Rg=j3$cM@k97tIb'
    b'n=YL~cZQ8PXUm{^0sIw|9z<CS+2L?u-'
    b'Z@AC<_E4cEW<dPMj?Y+5k)+CdcAv+4Rb2SkJ~`*^|JUyhi5ZqN(Pz5dPI5w~>;f2ByvPT@#|kKY%vI6IV&@bUIR&d&|?M0nYWBC~'
    b'SC{c01vAHNo&#}PhWXGGs2ynCdGctiMa+b)<pvw$L^7vZmOwP0?CQi`0}DrDM|wuNJ4UD*KPwKGLz1B8$F7b4Ffe7xTgSrOr7Z;H'
    b'sM#-m*YHK&M-'
    b'f$;8&A~FWTA8p=hR{bPJWDM;fN6BUgFDp_+ChR^nypdQqCA_0}*_7}G<C<x$o0Js)XWEogj~CUQ7T!zzbb5F<b#`TVxAUnP;VsaK'
    b'(;I%?=lpe*;eAwpMfeA1jN0Dke2O>=iAtDRwzbC33Gbl(Yi@W$_1jtD9aM^3GJE;vH0Pa5k!xpt_Hml?N-'
    b'ms!$=30?W9Ec+w#Uv1Z!b5RHh$0e+#kHQ_p|Z2B^BX~M~XNe;r}x|ye-*la(Gw#o5|sw(*9GzTcZ?NJ@vFN#^-)HDZEp?Z&G-'
    b'V+VMQTX;OHznj(3V+J0Leael_6@V?yTlfrx5=T5rg_`-g5C;k2Cpx$YH_-'
    b'Loz{z{R?lj<M6t0%&DowWVPH{B`HWzyhpmv>X9BeNzwd%S6XigcbF-eN`g4U@tf>0)5Q)U}Of6^I0iTr~Ahjc$!NKWxf94gNZ6;m'
    b'm1mZb|)Z`VU%ePt>0g-u0!(1Jm<cZjLzraK-'
    b'5@R+oxE*A<5pQ7eT1a!PoQ^wrnGd&Nzsg?CMJriQmqKbjie_|?~griFJ_DWZQ7e&e+8E~~yiXJ&ZYIUXCxoXYS{EW$gBB5I;mYWT'
    b'(E@Xjzrv^K&Io*dpWrii{ncril}eTwj+NFB68yoSg<Q^I@B2p?}BL~J9x_N0iIM|f@fkIL}odGG1r?c9B@g|~B!1!u+Y0&zuzkGB'
    b'S*<_I5eRYdP2yk4M4{<QE$F~Y}V3^_72d|v?J<wlD1n-'
    b'<>9M)+G^3vXr1jdI<!72&OBipY})|K4lit!8;fb`pUUksA?SG*U!vM0n9i5xEiJ#R)~!AK|qdMbsbRwHrm;7s6{dWBlC8@V>gSFH'
    b'TNWcKr6$F`|Vc&s2o>x)J{3*TNg`6j9pxX}L|lUu@3O7Zj155I)|gh^&S1auG#FO}?Yvx5E%#UZThYlU8Olj0i8Ini-'
    b'E)UR9NzF)3oyAiQ>?h;~4Dtx6FsgYe>$B3caL<1L2hDTLR;_q`pyReIy<@O{$1tP0;4z2U9!UDth!!?zm$ydZr4k;nhJEPRvE{<B'
    b'Y@#_bN@Or(fUo$4+Q-+%n&n{&c9+2_}Olf70ED*=Qb_j>r=WzNd*eZ4&^e!aBM`M+KozJZAFe_I;9Z%C1o-nxHfn)82L6uv!5k#-'
    b'CI^-'
    b'iDjE4GC129DnnzUSyIkw@2s?@0Qr6Q_tbPY~W&KELpmixMajz41~@_~<j%+RwGUV>5kS_;xl;zlT%%UQI3GeUjpHaOd`28@>%q5y'
    b'vBZygrC>5MKS2{QBDP?dkZtMu<I-'
    b'mG6Y_?0dV(4vA=ac}4g&05L<62Udq~E+c&Ncfv0N99^(;#rWLC%N}1eK6l5G+HacIW<smDXWk6o)ul-LH~z6U&G}LDFJC=ASDoFj'
    b'dQwF6B7AfgwTh@4!pHZ25Oqd)?I1I&`On@6-yNoi+9JHM^Yps#9osqUYQMYsPWYB9MYgUB-'
    b')}AWu;7g=Q<)!xZ=NC)X|OhYI~C#M<setB4Bs6__-9szZ*99e{`EWIJK7X+48niAGJGGLBF&eFZ;K=Rl;z<&<`g+&N%-'
    b'bF!s}&<yuL8}4gkW73S(1Fh>u)E4ng>M20*@88oon~@G=HP3RZ^iAR~N_wc-1}GLN2>e<-'
    b'3i5k8*B5WS4>YDMGu6XDg0BJ!#%n)yliMsxhLKSTyY`1l)ch#Y0C8I|$AK#XF9kM}8JydZo$HW1?u;o~ue$UF!yCMhDvBD~Q-'
    b'5qF31@sWaPrD*KbdLv8r5O48pgNR0i*J~6J!w7FSq=>PA@cNV@#uUQGBLOjf5njYn#HdGj@k|lf;}28Eom!Uv)YLOiT{!CIDYrCw'
    b'dF0wjTkD-'
    b'a=%mSS)w^N9fJsB^+|hsRq&{^X>ifu~+&Yit9enlK<MVpoKY3b%s$tJgexO0Op{pkys+Th)IVZgBKYUL3UO<PL`_6nZ@#vJ|Ms=g'
    b'#|MBZUe$&ivon=mX@%ZeX`zD3=nctffz9Z&Y*wbsvN$rk)8$IJ#(OHdL{@Pv5dX`YcTIKzUYckI+<2_wE>(|qcH+itg^DITqoc83'
    b'Y^&-'
    b'N1wx!64Df1dVpO5gKb}3?&NH3e*zW$$wTN6^`{z>1f(=A#n@>Yoyv105v`JSUwI%$&|CKVmsluHrqgYa63BAy2kUK{$&w|0|P9)G'
    b'a2-@l^B`IDv{pWGec{T7zr#PeHuVt^ukTMywyh~K;OJ9uJ=B7Q>;;YFHX|2y#7u@)<$-'
    b'vFe@;n#X*o)!^)RAs%ECrZZ83EvkGd#RZX&w3(B5pjs{E2p<^eSM_JYttLG-d~3BmsfUa*}iN=W%$0swbR2l8hXzN-'
    b'(R4}Z8O5R7!ZE?%<wISQ5E4kN58KK-'
    b'zs{bGJLCoBFaSgucvoty){xqnFxRD%<#<!intcS|7Fex?aRuyO$*;2IrFvf&5_e8!goU`qHYN9PAQ^p2p?}TMBNZR-tvgLA-tZVh'
    b'&mhZ_O;{|iX49R-'
    b'^VNaAbdOyk$8^c#Vtj|7{bSY=@Ai)u515I`4l;8(sRe3?uYQor$}m2QJqT$B7A%lAaW+c8#NS>T@hXurHDL?@UkvNWOam>lPMzqB'
    b'fQ^aqllRT;r%8XO_RFKeo~O;!5h~UnKEr~vt@+{Z;Vq!BqO|0PZ5!fL{VLv6DShJb}ixKxdk!m5#Dc#Qbevmc)vJG5p$pU<-'
    b'BQ|n&cOnM=0|0)LT!T7tJrcd4wWQO!-'
    b'%%L8B2qKFc5#lUFx*as<MgYba7@a^w0tha$YWMkL!A7O@mD6Cu2arHFD6Uc^$w6_M!bwb4is^+b5lND=po@FI;O+702;aTpZQ{s='
    b'G9D5CEWUZhdPx&q;4SBhAlAiV4vW!+k0t%C682pV72AiOz(B33)m%u?&kP!zEPkMQO!irBqJcr%ODn)QG+8%3-'
    b'Z5WeN4UmP0~DPoO*@Gnk!_*l0{5$h9#_q(;$6@CTR>VhKHlL#N5K@fFAcry+~)GfX8RR8~5St06%@bMKIqRt3!MMn|8+1umD&8cI'
    b'_jEu=O`u#8GCDV#*Iq5gwasHK4f*)HoFL_PDs_J>k`|?*;w@IZHx#z&V<iLpV_Z+w)H8B6yCP80sP_I1rz$ucE(fd2jr_cRAGUS`'
    b'O-|@5$W!`h(nzAv;oAzH*)-8F@f#HeSks@XLbCPdIB<;s1k3`-v)2mNOJ{l=<b9I-pM-w+xol*8&*^^b96MGT}MNY4-'
    b'N{on(<draUU#qgR()#<BB<7Va*>^_S&5<G(?VF#NP=@fXLXizMM|O*@&b#8Qy~h(3#WVKqN#vE>u`jo*XQapnd)Fq~mm<8HP~^bg'
    b'<%xSE!mHJmy*bH+Mauu_zQ2|2Dx!!o5&n^V#bt+z#KWykLVMoYB(!jv1TS*5cG~}6?;wsu(mwPiMQ&{pe4YJ&D?6>=o&$d?TN%ZG'
    b'I;+(+`>s#kR!EVhHTrEt_`g>Dt?Ziu=ZaNjQbcScyt63MwQ5@O!HDqj>uMQSq)4agdZh~^&c{nep0Ck%5$Dz9&rL&2YKQ4fL)=nC'
    b'E2W7R3vI5gZf){^Ek+SzZA9iN$xDjQ%?vI1uNI;HrI}TUmL>S_TXZRFRYDQRApEs0!reJ5edI@p7a~Q5v^b;ehEjyj$Xt?`8Y%Kz'
    b'ixBw~d9r!Svd1FA4{EVEaYlk73!A@__(y^wOPX~myDB1lzvkN#&5{(E-'
    b'*jZziHP$@nx2`gOj6|GriEoKBEm0f+9|mtYG+=*P{fhiMEeYE5qdnG@j}bzH4BkOkrPcrFC+Yv<{{E3a$WNf6$t-'
    b'+^ALL!aV>;@v_*(ail`OB>wQ=GRnvN<_ZKRSB0p{xq7mVhMv)Jjg&0P7?NHYG&eDRMS*_=n=H!;N&M3Vsn<9TZt95aj@D;5uDVdr'
    b'@kq^%7P&_rOUfT<b3v!T?+HNS$$)$+W5dNQM-BPkKQe;A#>7^TUXMPs0mHaG}-'
    b'+4zU`HJn~m_P0efBkk_D1joypM`S~{@Auq6Mp(<;qDNMxC+AmVtc43MO^*5WY>cmbFWKQR&UI0liYAHC(<-'
    b'IxjN@N9{fv*Grlayp~#@bhJ%-'
    b'7Z!fE?o|?72tn0z4S%VTMS6`M*(<B^|=E1*|c)Kc;6BJQe(_YgSPtEF`xA(27S<m%szWB0iitNuj{8pOq|LytLMFlw&Ijz^2MLD@'
    b'&=RLl7WA1yse!OU7?qz)jyp<Cv;uwU#q|eN^3UVl-'
    b'v~H`z@r_o7()O+noFY%J2qhr=g=<1hD00!7P}|ijL;Vk|4tLjVWhj{<jzRc;uLw1vh|+#o5nAlC*Fsw@sR-@%!-'
    b'~)s{AaI)o}y_Ij!g65|N2_!ahfKfuiI9Jo@!ee`q8;GO+w$LdGKm7tIbP^9oZY(R3@55ql_YAo+4w;d@FH##Q7J`T$Gp=mE+uN+T'
    b'55Z&8CP^jPO5dla+Wriy}rb!e7<qKv{7XMeb^|qU_`>iWup}sahRs`)=7iITTUD``iAy^vO=Lfl)6fTy%Ct>AZ+g<dn1TE^QZaUJ'
    b'0_q&1at|O_xBCtIl3rx+}^yywcRC-q}maZq1437UY7nFDW~kjqvdtg^WLYc-'
    b'iWR^R9U8(@;X=ZJ~U*2;mohdS6+e9E!+A2>-;Vp)`s-_-UuI=dvjx7a{z^pROsblTDFTpFUE0aTZ17D}-'
    b';j?atB$Sri$(?Kh<>J5fYtlRwq@M>|3fQpElKdFO8vS7iTV=lDdgY?<@VJ2#hg%#xqwNrZoVXNV<7It!=BOFR1{=10f#&T=j1_T4'
    b'!(aUz={@;Sm!-4R9yMcfg>yCXSG#_OI}cfmb56v^&;-@<7*^0{oky1cS_S`I}zjp=&uo}8yspHw}cb!+P6>f-'
    b';&;fM_H7<^A^MOA5}h<uLlBgzj{?Z~ExJdf}fmY-bREQcb`mtR?Zdk#g^AK}&i+%ZEB-kPKS?gilwl+QhQG@BykGKAk!zTx2NY>G'
    b'@SKk3WMvMFM|L-?D@&-ijz7DX;8KmE&jSrjp^A$*ha9S7TGQDi~tj)PBjqUo75<l!@Wf4E>}C$pjX&K!5N*R=~S{-'
    b'2o<Y1sRv1q~w3E5Tg$<KFw`KleX#C6d|utOa!<&MQs)oSk=U{;g4TQDjx`-ShiIoOcz9{HFKk^H)c6G4G1s>-'
    b'*lq+jGRE_(b^M_Z_?FL^egt(Ma0QSad};Ma<d=e@oxhi+W{K<ov#0E}EZ35%W93x9HnoadEWvxU|pKMfY{WDRQ_^gT)=A<9TPLXV'
    b'nmyA5IC;NRi%CL#$deSW#?zJG1~r-'
    b'd!2me9qfP7CoO;^>!#TzD_`_A{>L?_4dL=rI8}m3<y8r?Vl~$kxdb63537%?fgZ}awziZ+o4}5qW%c4{@YfDs8E0Rg78<a+ByGdH'
    b'btzL5dKfALWEFc`KqJyFUzKgH5I~txhiYHt}KciTQzXOyex`XJ0bk>RZlEvmqn2ktC}o)vJ*wD%FdlO<>1Or)<yBP*4n8VUtat_Y'
    b'a}FN+J=J-BF-zp>Z{Mxy$7F*N}$M{Q(JynC*r))#Lt!~A)Ce5Y{=m$4;<_haX!BGL(ZKVavH+B;*Y0>EGj0&C&Evidc5jHHbtxw5'
    b'&q<9tE#TZrij%b!k;(o?W$hc6#2ol4OR2AC}Jgv@b^p$bB#6Uo6{<*@9UIac?LxunbxklV{|<4te)+kFS$3npnaW^+p=by^Rv=Ra'
    b'wzirIbRnq>4fl8&$+tviX4i}YFk(^u<egO34Y8cfsg;>_ocT)>nm%mC(a4vo?Xj|SGDV~Yk%>D=k(llSMrV={?X5l7B7nkMan)qR'
    b'J<qR{N9~AiW{}3RtWL45bFnox5l7W6!EhVs|bXju=AwkZ*wSO6=9`kE$2=t5?|L@xy6q`tltpcYR!7yioK{!>zeB#yk`N5%xH5ck'
    b'><Ro1FK(sWED*j{pA>|<#?YWR=EhT2PtAbjPQEAcv~pn-'
    b'6giaS1_n8McnD!Eg`zz*%D$;<WQvalMrtRFRqll^^<jlH=Y}BRpgpa{#caL0pXR<^^2=g6LV&N@p9s&j`4m+{`JKpiMu1+vS)T#v'
    b'kviNkfnR>FMH!Wgnw+$+|ulGEBE}Qcz9b;?XL*`+@1$YD%w%RS#9@Uo!XG~WYw9eXR@;PEl%B)Ly@0Uot%0g;=KA(<fFY;CDZrCy'
    b'B8%#Wq$Q(>f@|PYf0U&o-'
    b'4mQ;{3wHx#gc`QDn=ZmF2&WIA1^Gvhp2S6gem3yfJCc|D@5<8r~vvZp~HdwAhurD(jwRV^XUl{eH6xQtxH?D@C?94Yfsh<xu3>hF'
    b'LW=L3r1_==9L4MnU5A(B>2|f)L&luCuN_J@kSjDKg;nhsqY8hwz6_`>O2L4)mPU-cD@n7(WYHnR!yOZzqJ0-'
    b'zoAyi)qQM=uUa9<atUy5w}K@oVmVT`?3!rMLf?U{Is?`6ZLZ`;<+2)*S5(^*3WhI<}I&E)z6LJ1>zWlmrp37G=!IJN=|Myrhe`#j'
    b'gFPq&yDvW@~5VEe8>5C`yd@NzfPq&uU1NS?l~D3*La#HA@<Td_;<hQU*jnvViEp>Lk(*@MMOTr-'
    b'@HH6ibkWRb_5~(>Mxeo)Q}>^Bf^*LE(mu~tB5>+@E7kKnM`|g4MGv~4#Ine6*IY8Lp+Ejij;2)F@W&#Cwk=I_Lbjp-'
    b'c{<Ae{rZL_l_BI=!%>lmkv2pGhdY7@bzt3Tgsb$eQ&nEQlxlH{-H~95Z<|-Sv;-u@Bhr=nylDs?wcRvyx#NjH*d+Q==JS)>M6-'
    b'zDdMRL;h)WGwxE74MUM9Awy=IKMO+u*&*;~6QT<$ss1L&L9nfq^{alJ1ANcgri4o_Y8FXxE{alKa4$fJASH$^8hQ6|*elA6B9sbh'
    b'lyCcre9&zeB^>Zn5>8L-'
    b'wTR)c~FXX@c!S5r^zgVz$ea%R$RphRcbGOvbrO42dc3aY%Kdbc8PwMAVWJ$@uPtu$}JF#JV{alLdP5kb&-'
    b'$k7Nb#l<I`neS8pDf;WSH$`2Q;qi2&!xzf<v*(WZN&M-<%_D)-tGiK5jzzKfBu*S2kPfi#100+-!`VxS06-'
    b'**x5k%?~OV0&@E9+dPdgQH2pLko{Q5Yc+bU8^j`l~qxS21w_md7ocLMDiQX42Sr&1AXx>LlE<DG%o|@xlA)bX1-'
    b'c{@>*kOo|6vWN|wO0^72C=Jv@WzzACc8;`fg<*l5MGbi$uX|u`#*?QMfmtW5~BT;V;9J|6tVMz@bb@3dbFLtq*G4!ZS!+F$R1OAq'
    b'~5$Y`-~nBym?#J!##iW<|R24aXi95+4F)ougIZ@a-Qnm=B+_(wYIiG_-DJ_v3OuxiZ~15mvwt~!HwrqL_PI>Szgi7Rqf*aj{G}s?'
    b'DFAl5neu_NT+@$uN)b1UOu5n+rdA7H$URM>_L$?2baH>=Db`%k++BcXJbLcdAWijRilfx=0}{DD=1P>^wF+SZS8rAw1-'
    b'P~R9(}KBBBf7?=JbeYFJx}$Q}r<WQxc_2(Kp3z7zWQ=WA;F`rXh|yWa^>G4`DhGyY1EU#<ypg7D7uyzfc>o2gs&-'
    b'jVZ%DIt@*Iwi#O^eKnGOsgFRf2D{W351_CCFCoL9G=o}fBjsFxGusMO?{*$6H-'
    b'Kd5dNZRuh!&PigbVN@aGdF&Ub%p$mhY+KsLX2T1`tL{Pv3VH94Omf1F;i_3nuCZD)K@Grv&eS2KryR6my@pUm#J@%ItuZ=N%wX6B'
    b';EvNx91%zzZx^+x@*Y0f|N=Cf<+=ThW}H#6QzbN<?eFW1bi6ghwKznA|m;{24wYnIi|rO2km$Clj{asHVl57x}}6xp);FN=N~alY'
    b'x>rz}c)J9`L4?D8S}PgaH%3q|byA^b(F!#al|b_EfB^qP=i#H9TteN7R2N(gUH>HC%W`x~|YP37+DJ?F&FLjG3yV)e3!^E)ehS6_'
    b'IJbL}|A&qC}YA-'
    b't>Dk+VA&A1R1kHEN$Nehgwq4&jX{`?Pjq^#Vog$0EEQu?uQk$M;SVt%~sRJy=BhE5{D1b17oi6yfEcV^hQ0IRCZBzRu|&dz?Epte'
    b'l^l8rIdbri3*!MI4XtGp2+&ks`{OJpJ^q2DR1N+6v*HpB`pUiZ~15+f>~5^^NCJL_PKX;OW&>tJ=l;9eIDozxNGqi}2|T6BPMkX6'
    b'rp8BhJew6!~(_Key#aoR>W)a_!uIe46IGTtSgf->CkuAmY4SL6K`0-'
    b'TQui#Cf?Q$|1Gn`^z@28r9b41tM+n%3GFR(~csd3*mpf>c`85wWWycf$&PEh%AKgYLffa$z#UnW@JpL(fCuXr&NEXh$mBoufH!*K'
    b'0Z>!lPSXgc=wdl_}po2Pb9`idk7V+8`ltuc=mU^=T>J?#4{tpmv0MYQpD3GlJ@^szUTe;)e*Y^2!D3dg*El3h&=>^Z*xk$ns%Uwy'
    b'$FOK)^K=@r-<DKgxCHQvD<*~`epxllS_x>oZ7K(jXvL@y!3@^ifrr9rS$Ubi`p+M>y>NwCf(*i(<HQp-'
    b'FW-$=bhKAY;vTC{aA!oCPnNZA-wXPrJk-r5w%5l`~Uyx_*6;jEZ$wv=+lAPBR~Eql>FS5a78;3>D~`_gj2-'
    b's1j5Jna_#gglOpzk5x(h1q2?5^du(s{;txa3&)ytri|~%2$d5ONyNLFpYrQi4^~(=K58@PYjGY0`{*wnUT{b>a#PdGF`ybPuSpDD'
    b'0_>(W<|5W;4v7XTVuSSY^Do1$#w~-'
    b'>A$`M}46!BD!@M@yY{*!ooR|N5Y#t}ZgyMp|nPxwYK!pC=M5PLXU#!iU#p@`iNg!g}SDPlha;k6z`?1vz{mh96bd<WnElK5lyBXe'
    b'KKrilMC<3Fd{gHm&fxC>9Co;Ry|gm3p##8W52E0ZFg91&jm&QecTp@`Zdyysv4L4$V}6mg{gBja}%CaevFB7U8~FBSOJ1*;(6^|o'
    b'roDPpCH@Xn&vMarazXD)<yb&7aW^Bm{@-KampJBA|e2;r5PekKY}J$})PBA#>*-'
    b'f!=?M=cOv^CP|;@0TS!oA`z}MLdrnyl;zB#PbNkE14pmM-'
    b'X03)Y&gA#h(WezrTd=@#jj!FO@~lm9;+pe2RE_)iRy|wGTx+_aVGr;h=~oL4?<O6!9d8@LJOEq51yudy{5<^FlUFlknYezbNJDTg'
    b'@rrF08|?wEYenMXa|GUYQiJW=44BJ4-'
    b'!Xg(7N;@K*l5wavQ=nkL~$|AX8ACAYU`?l8096tVw_@X;=4t=er<CPnPzBfS6mO%eP5J{|C1#{B12gm(-'
    b'@x{V8WktV?_(_hp74K{F!IOe}i$B#PFKj<4n{@e8a^57|wDt}{0PUG}3NBZY9-'
    b'd&#7^tt!flJTP+?CHpy#x2JLPvd6=^20h;MLexYM#k0Oael*B!BeEi*E!$uv~L-'
    b'aBmL9Ihij!33CCQxKYh%R{uk~Kb*AZach{0|*N(h!f4KLw#?K0*?l(Ilo>n9yquH1=;nOYof8^DMAD5>|+J`ciBp*6hmb*Xs_k+*'
    b'XXi;@qmn6qlm*x8FmC3=?S=oP2o?ZQ5_SMO4RXrj_zOC^;%yA4pFnLq;@+^uBO*XH7H_P#>YV>e)7DZ0flyGT8_}o<U>dHuwZmFB'
    b'9UylesHZ``oVJ=OR#WlVvaqQs3HCH)y@P|29*JzLI+|)Y<D|6h@*wjM@8%Fn-E+L$iCVV(Def;9uW7-'
    b'~U_#FveIVY0OAH1~YE*2d;99<E2Ot;k42Vc*@9iu+Z!W|PoQf(1lnM(M3jXoHaLy;?M%FK!gKQ#Hy!FRJLGBA1d!R1*$E&qLWo1D'
    b'ALS5#jdwV3{TE|sW$Buj5nWL>I9^`VIKdXpjz%X?H`91&j6Qlx)*qI!Nrcs)xIbwhYPOA&R}KHB;2@|FiL&Y?dozvy6_|7lgEfBB'
    b';a=Vv3lUZ6<B@@WSzjySK)DY7m#?ckv-gxCHQc`o(n!ABy_Yk!K|lDg>NposH&N58n2bnFF9lW@Pi%DWz%p6$MVRKD*(y+{#9B58'
    b'l1x?au)sl>q}S!#GvdE(#&*%Wbi2=6Ks(Mkv(zoMGE7De<L!uKk#tPUjyMf5(xpH%*6^#ze4q6pzXNIhD8B#R=Vab(T4nnqVVtES'
    b'BP*%WaVgs-Y8;fhERS3&ssHU6YX5!ZFCku|N|^ndO>O+qisuW9*{vbBFzjfQIlMYK7>pH<Vs^CLyHIl?QSBCfSNb-'
    b'4PXsOF1ne3M8K^<SLYb)ZSMTJ5g!7e$Jw3BormfBV4mks@k>@LkIPdSGj$h`J$ZU%o#a6Et1_(0XYSeADtX_J?Z)Mf4QHyGM$+yW'
    b'^?y{a;7rZ%v)Ce{Q6R5)l6Nni6h^6j3I^KVG99B1QgRRrVhwcU|9c97r?hWD**%jJsK7XkhokkICF-'
    b'V>`hPw2l*Q_e?4si6J?fsSyNg3(*eBG}IA?){aCaVwx%y(PS`xl-'
    b'*5&(oBHcJ(SC`hmbm!6z$;N9#*i>bP^(H=)U*y*<|_WHLrQ@XFs3!kDYyg=lfAlg#To3&m(!KpIq~mqk|aefJ7ZWx#rN(Bl-'
    b'J#I+fqit8nZbis%c%AMELtq=>#C{0qJB9!QGl3&M+mBI2=T@M**^_d(XDBSd71@G?RM(Vng<;uK^M?dk3eVu;f}UD`TTS@yNk#;N'
    b'Ztdw6tjW1!z1{aK^3%%?Yw=9~G#4WlnLwiR-'
    b't#~aI&A|D<7Or!Tq(qDsrZuI8nbe<xYkCvLx=B@wi=%bAj>01=pJNm80rbPG$MnBfrmlXNU=#Iw0MEF-mZ)o(MK>CVYQ~YMn|Gae'
    b'd)V>k%KU$hUb#}_gN^20_N{U=pYBdL(x6gy6Yo|7ie7E$KsS|~xrMsrqjo{XNv2^a#!4ce=J*9b1EHC&LZq4vY(IR|`xxd4gN{>!'
    b'$OZ!k{L+Qv=J`w&eOYeB%**rzgEp?}QPa4I0CNm@dTiiK0k?Ny6?<g*5^k!whcN96V*qJ<@IInjUxvcoT$%#aGeWb|s#cxbLo(Qj'
    b'x6cHQ3>mx<PtUl`etJ0&5i4mGzd9smtOI4ATE3axkUO;$VpvZexe!4l4IIrdudDqHsH;?BLUi~TZQt7eg_QZMhr^v3-'
    b'baPeWyzc0WTx3cS`Tj>~adUq`UJsX^Y0OKCSc&kzEgqhnH}ZqhEzQ^SBK%otb#r}zBC<nxr%*(d5PtYXkvoebx`y!ki$9*+U!aKY'
    b'BmAAkmnPRIMf{2o{^P~-8n5Rm;@5bzI5)W{ow%p?i{5uB;uM6xt$1>Bb5g`92*0UVXv|NFIM-QwO0$hcZ^<3eg#)EKoAV3mf4H=v'
    b'xw$|QHAnb%>7rh3DWc{GZ-0t7>#1U?u`xydNby6Bg-H?d-'
    b'&k7HTv!m*?WN0_8<Qd;LHI4DlZ{<T5s@JL+R}96g`|ks5dIHWjPyK3R1e`#6ff%SNmFh6okDmyQbcwau2|c6E$#pFVx@5)DPjkN-'
    b'(TF&*pd{nC&E8a{M*LTq=<SV{GQ^T#*utFz4Xed7?SphI$TuxeDg^Diqb@LD*vaYziBQlP()u4esk&1np=`0`hxHqN*6Z|Bt`TE;'
    b'Zsz7MZ{wbE`GVoZa6|jrU)-1L{!67MVx~0!`(rgzHTO_aCs)4I&N;oa|r#1R!m-'
    b'>?rOz<=B=&xcfGb1^Nu2mS}{Yd!T+Zf|Em=FYAa@<_3K*kPwrb3`EV<y0K&h!6|<NkpK8T4LHIvu#iXXl?pFL`Uq2I1DdJx|6Hgs'
    b'7veFuaw~`|N+KwrJ@b>w@Ow7v9&csyx`b<18;nw`lOw3K(n%S9n2J<c4n&FkAMR<GK;h$$>%G-w`J7?kv0pSnN#FHLH?wE-ujk!Z'
    b'HHO_0r)R3L-{9da+8T-'
    b'AXNas*YD1_HLiX1u=6AIz=ks_@_F|!a}A1NX>gx5!kh*^Eq`J8r4I=ZnP6K%Mv$OG+|VhFDb6#4gdOfiI4bBg?`9WxH$)t@3Sx8u'
    b'nT;nkla&$K5Rs}kpRM_=S3Q;Nv9(vB%9uX*j5cNDP_;mfU<P4~8AVv2BUJ7y?FWQXuhp@=FW{P2k)cNRr-'
    b'4dF*xF)=Bk`w0L0t(d$N@hd|3Rjrud6!B}kwiVOOi7Q$$4JqOjgulEMQ<Wl4LHPH#VmedAxz1YDj#)XJJE9Bsw`1<B{}<YC_GTqT'
    b')EwcjZO2rlh?*n3{VC$CyIL`WM82~XGm9ePU)_$mDXLOCrYc25g79x^$8@HMND%(Xr()VtL~ICOYsJ)~i0UEywpPqXis%%=%aJ0o'
    b'd$JXi)NZ?4G1n+!2ZaAdE9N6b?1}KzR?Jq4s3*cd--'
    b';>h^#6Kl?Wq_jq7ENw$JD;EeP?4Te|<Y<Iz{va;VbQ!+7!_jgnxHC<~T+41>wa&5%E})BJ9U6ci9a`h{zP-WrT=oxT=U#5PrBjh|'
    b'^cq<0j&qdfdgFQ;*vjx~d+x4?f*l@4rv3#~bE*>+#N?BJ=BUk6;b{!+N}1rbx5izZdAQUr~>@*}g@QGwbmt9N~Xbi~9(Q9InM1b%'
    b'cMY7Pl32K;o_SPik>@BmReKaq}Xh!TMM;AbhMGtk3n=Ouc&cDH7g3XV&AsU`0J{7UtLE774fJa4qf*aBJ?Z$IX;);nobV6fMHr(+'
    b')S*<EFzt6xmsiTM~qC*5m$*B0sFhZOeVtcyqqB8gI^Jr#l;K{kwyH?<jI<t$)|hC%oQK<k!`BOONpSNRjDkythYqeWZxk5MCcCB4'
    b'+hb=dIOv+fVPS##{a2sv^_Xc$1Itx<HX%SL01S!mBw&F0I9TeuP(lifpX)@3Z=ZSAUB9eeLtFu1cKO9et6@;I|h#Ad&CW)wn5;*M'
    b'rq~=T8wUk%5o*^Ow}()<A@BRO23jBC<nxr%*(d5PtYXkvoebx`yyiSL4=zBD#<8Z&c&<fg*lI2!BZ}ZZRn0*Z5d9-'
    b'tarITa6n5iZ}(~7uVuufg(;p_^WDhLqQSeI_t4&+!qYzJ|NMBt7>ugq5g|&abG|YHAnbvHEtFtqUH#1e~LKk{93$+7x{Z@@!p;y;'
    b'(u=~?hZtCel2bmC?XPsKU$3&3W|sX;eT9>8wZMr4H@`&^G^ryNA(6I{LyOM5l}>@5MGWHk=<FfxJ|Iz1+{p$PZ2vH{QGKgM?evKB'
    b'K%FYxL=@%dLsPYwYZ6J`dPKOO&HE}K%x$J*W%`4Q%|SzH`U@^gChEZ@b9a|%>_mD1>rBK#a#wP^abI?KoRj+Gx#*(m-`^=(-'
    b'9&vMR*w@gJ@4z6>$nOi1u`M1~J6xvz_f@m1R$K_KkgK*{-'
    b'>X%0TOL#Y$zFPmj(0vYam*o4dHOt#IXw*~;>y$ZK;uD(gn9!JnJkU7pTUWciEFm!HjB|DSW$R8FLCQRKn7zpiXbgnwl2!OFg*$e+'
    b')BrgAV5{u6V1DrYaF$lK>`?fKg~Pmb*y5&yq*7L?CU8Chu!!dpp^GiTpl9&p}1TVH&rd{4?$wEH^$HnwSGZ|CpEP84qH{NvcV5i5'
    b'P`>CVZqgCn>#_0Gbv<ptlutr=b^euTHD9on61#<rz>D00T^d&csK@UL`!bM>=%ij2)(IyRmEe)o>?%*f5%+r}qS#q?|S+_B2`{Gj'
    b'8Z$klU~j~`Eb;G>%qSw6RZd?FEEXDM>B`>FBA6XA81B4R^$ou!DF)kmHGs&h?cVub#2=iEx>EmcJdogbBZ|L1+e>jFjcoqsA%B+j'
    b'cjMXv08qI^7$@aj*ITRI;sZ%>?8e~LWZSzTV0IIlbUA{UubM80=+-'
    b'YoAg$ZL1!%F4W?h?NL`efN*X=Z)Okxxf5+UW9jarpxOK6p<amJB1>ugz&>BiriTg(KUqM-'
    b'MwObe}N*pkMPfRFCJf?6!9xU_*c8Xt-PM6h+pGP-Al$7r4#Gjk=}PH;uM6R?JgeQoD^{i!oSh|@5=n7h;yA)>s(e@^p@NaUAVt<c'
    b'X@t6{lC!JU*24xh?*n(mpU)^YD*C{M|k^F#93eNK400GBL8;xKxJW4MEu7(jq<{Rs9xyImNzCvM1t_Y>~(opQbZ&Ozi@VS<%Oh(*'
    b'bshc_ZK}+5!FNZk91$|?MV@xLU=h+M0TsXla<%f{<n9Zs2oU&*a6{pclTGeBt`6r@Q-'
    b'xAT3MPDQBQ=gb#JH~$*0q2FFX}P(mqj#KbZYu`AGi4*}dhd{DRr9mzNeOqAv)4qI0mkB`KmW2!F=xOXUMe5q&}U6jfgl@mPb4U+%'
    b'ISju4S4!pjH|)o@i2ry%@rcMzwq$;4dVkcsDzD{}E<Lf@5(S?tp@a`B(JA{YOzYjQE~D6%6LGt?UVdrRVfl_HCCF%zx-Kra5teTy'
    b'RFxtIb7e^)MMF-1mmF-;KuFLE)dDe~r$_{UzIiRTvaZ_mVYh>WbX2H~xw$ZMIH0tj!P4`*UlUYv=k`u0pbli=2TE7N~2>T_!*-'
    b'x*IYzJ*&eyi&9XZ%;cc$i$Sl4@DMa;t63u!awuQc=n@6Arns;kL6-&+>?u`Av@jqa;`rs`@N&cWG*HY!s{JHj^tuOA-'
    b'q0P<hfkTEQHrbiii#2^^qcCRv&f#S~eyfy*e8cZMdq)S=pFk2(Jqic_tH64B^$BBHz!%j6?WA{X>yQGV$bw41Cm|B8M}3E2|Rcbw'
    b'^+1B2$XU_quFMNqIexjd@2AD-r&>T+F85&BnwOVIdnclp?Z2c&AWAl@NaTM3Fm-BD#j~TXQinDWdxb|G8XDUW)h?A^gX4F~KR~*S'
    b'Izp)6I#u=3*LB#3=}WTP~(5MVx~0n{qLoDdJpb?a0Qg9L^olh56Z-'
    b'`|6*|#;l}>nj`$0Y)n;(s5!#hKb_kr&blBMGf3nMa{Y<cS48|1*_fN6x+NP^l_DZR`1`Ukohc#`g#T$arY%LphVcKlB&HrkR1e|L'
    b'&&7PCh)yBA94R8ZpDu|>YPU0T{khy%#107mwp`3dir5q3k1gpx5A+pLPlTUd5>wdeKgdp=ih&~Pur?c0`-'
    b'be@m8tydY|M0u=nKMMmyM}S5q&}UyRtFIDWWe3F9wQ;$C?yjKYqE(Za6|jrU)-1L{!67MVx~0!`(rg{{Q&7HBJ'
)
_BASE_OUTER_TRIANGLES = None


def _base_visual_triangles():
    global _BASE_OUTER_TRIANGLES
    if _BASE_OUTER_TRIANGLES is None:
        raw = zlib.decompress(base64.b85decode(_BASE_OUTER_VISUAL_DATA))
        if len(raw) != 3756*3*3*2:
            raise ValueError('Invalid bundled own-base visual data')
        _BASE_OUTER_TRIANGLES = np.frombuffer(raw, dtype='<i2').reshape(-1, 3, 3).astype(float)*1e-5
    return _BASE_OUTER_TRIANGLES


def _model_base_surface_self_mask(local):
    """Within 1 mm of actual outer chassis visual triangles; not its hull."""
    selected = np.zeros(len(local), bool)
    possible = np.flatnonzero(np.isfinite(local).all(axis=1) &
        (np.linalg.norm(local[:, :2], axis=1) >= .198) &
        (np.abs(local[:, 0]) <= .214) & (np.abs(local[:, 1]) <= .208) &
        (local[:, 2] >= .10) & (local[:, 2] <= .219))
    if not len(possible):
        return selected
    tri = _base_visual_triangles()
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    ab, ac = b-a, c-a
    d00, d01, d11 = (ab*ab).sum(1), (ab*ac).sum(1), (ac*ac).sum(1)
    denominator = d00*d11-d01*d01
    for index in possible:
        point = local[index]
        ap = point-a
        d20, d21 = (ap*ab).sum(1), (ap*ac).sum(1)
        u = (d11*d20-d01*d21)/np.maximum(denominator, 1e-30)
        v = (d00*d21-d01*d20)/np.maximum(denominator, 1e-30)
        foot = a+u[:, None]*ab+v[:, None]*ac
        distance2 = np.where((u >= 0) & (v >= 0) & (u+v <= 1) & (denominator > 1e-20),
                            ((point-foot)**2).sum(1), np.inf)
        for start, end in ((a, b), (b, c), (c, a)):
            edge = end-start
            t = np.clip(((point-start)*edge).sum(1)/np.maximum((edge*edge).sum(1), 1e-30), 0, 1)
            distance2 = np.minimum(distance2, ((point-start-t[:, None]*edge)**2).sum(1))
        selected[index] = np.min(distance2) <= .001**2
    return selected


def _model_wheel_self_mask(local):
    selected = np.zeros(len(local), bool)
    for center, axis in zip(_WHEEL_CENTERS, _WHEEL_AXES):
        relative = local-center
        axial = relative @ axis
        radius = np.linalg.norm(relative-axial[:, None]*axis, axis=1)
        selected |= ((axial >= -.026499845-.001) & (axial <= .025551510+.001) & (radius <= .101))
    return selected
# Left finger's NONCONVEX XY visual silhouette relative to its hinge at q=0.
# Derived from the published visual triangles at 0.2 mm grid, simplified by
# <=0.3 mm. Do not convexify: the large space inside the bent finger is not self.
# Its physical half-thickness is 7 mm. The right finger is the Y reflection.
_FINGER_OUTLINE = np.array([
    [-.000110, -.000368], [.000690, .000032], [.008290, -.001368], [.039890, -.001968],
    [.067090, -.003968], [.097090, -.007768], [.127690, -.013568], [.177290, -.024368],
    [.181690, -.023768], [.196290, -.019368], [.196690, -.020568], [.177890, -.025968],
    [.160290, -.034368], [.130290, -.053768], [.117290, -.060568], [.110290, -.063368],
    [.101490, -.065768], [.094490, -.066768], [.085090, -.066768], [.076890, -.065368],
    [.068090, -.062568], [.050890, -.053768], [.040890, -.047968], [.041290, -.047768],
    [.059290, -.057968], [.070890, -.063168], [.079690, -.065568], [.084290, -.066168],
    [.092290, -.066568], [.098890, -.065968], [.110490, -.062968], [.115290, -.061168],
    [.123290, -.057168], [.134090, -.050968], [.156290, -.036368], [.163090, -.032368],
    [.173890, -.026968], [.178890, -.025168], [.175490, -.024768], [.127490, -.014168],
    [.097090, -.008568], [.066890, -.004568], [.039890, -.002568], [.008290, -.001968],
    [-.000110, -.000768]], dtype=np.float32)


def _model_mast_self_mask(obs, robot, world):
    """Fixed own-mast visual envelope with 1 mm surface tolerance.

    Use the complete measured base quaternion, including pitch and roll. Other
    robots' mast points are retained when they lie outside this robot's narrow
    envelope. A contacting point within the 1 mm allowance is indistinguishable
    from self; this is not an expansion of the approximate base cylinder.
    """
    local = world_to_base(obs, robot, np.asarray(world, dtype=float))
    selected = np.zeros(len(local), dtype=bool)
    low, high = _MAST_OUTLINE.min(axis=0)-.001, _MAST_OUTLINE.max(axis=0)+.001
    possible = np.flatnonzero(np.isfinite(local).all(axis=1) &
        (local[:, 2] >= _MAST_Z[0]-.001) & (local[:, 2] <= _MAST_Z[1]+.001) &
        (local[:, :2] >= low).all(axis=1) & (local[:, :2] <= high).all(axis=1))
    for index in possible:
        selected[index] = cv2.pointPolygonTest(
            _MAST_OUTLINE, tuple(map(float, local[index, :2])), True) >= -.001
    return selected


def _model_gripper_self_mask(obs, robot, world):
    """Narrow housing envelope and articulated finger surfaces in own grasp frame.

    Missing/invalid finger angles disable finger masking; they never broaden
    the excluded region. Public joint columns 11/12 are the measured finger
    angles in the documented 13-joint Stretch order. The housing is rigidly
    attached to the measured grasp pose, so wrist rotation is handled directly.
    Housing bounds remain an approximation with possible empty internal volume;
    this filter cannot distinguish a contacting surface within its 1 mm tolerance.
    """
    world = np.asarray(world, dtype=float)
    pose = np.asarray(obs['grasp_pose_base'], dtype=float)[robot]
    local = (world_to_base(obs, robot, world)-pose[:3]) @ _rotation(pose[3:])
    selected = ((local >= _HOUSING_LO-.001) & (local <= _HOUSING_HI+.001)).all(axis=1)
    joints = np.asarray(obs.get('joint_position', []), dtype=float)
    if joints.shape != (2, 13) or not np.isfinite(joints[robot, 11:13]).all():
        return selected
    for side, column in ((1, 11), (-1, 12)):
        angle = float(joints[robot, column])
        if not -.001 <= angle <= .501:
            continue
        c, s = np.cos(side*angle), np.sin(side*angle)
        neutral = (local-[-.1971472, side*.0222607, 0]) @ np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        neutral[:, 1] *= side
        possible = np.flatnonzero((np.abs(neutral[:, 2]) <= .008) &
            (neutral[:, 0] >= -.0012) & (neutral[:, 0] <= .1978) &
            (neutral[:, 1] >= -.0678) & (neutral[:, 1] <= .0011))
        for index in possible:
            if cv2.pointPolygonTest(_FINGER_OUTLINE, tuple(map(float, neutral[index, :2])), True) >= -.001:
                selected[index] = True
    return selected


def own_geometry_mask(obs, robot, world):
    """Reusable own-robot mask in public world coordinates.

    Includes the existing approximate base/grasp neighborhoods plus narrowly
    modeled chassis surface, wheel swept envelopes, fixed mast and gripper.
    Paired rigid-formation planning may apply this to both robots, then enforce
    their relative separation separately. Single-robot navigation must keep the
    other robot as an obstacle. Empty wheel interiors and contacting points can
    be hidden by these documented approximations; no complete self model exists.
    """
    points = np.asarray(world, dtype=float).reshape(-1, 3)
    local = world_to_base(obs, robot, points)
    near_base = (np.linalg.norm(local[:, :2], axis=1) < .20) & (local[:, 2] < .45) & (local[:, 2] >= 0)
    near_grasp = np.linalg.norm(points-grasp_world(obs, robot), axis=1) < .12
    return (near_base | near_grasp | _model_mast_self_mask(obs, robot, points) |
            _model_gripper_self_mask(obs, robot, points) |
            _model_base_surface_self_mask(local) | _model_wheel_self_mask(local))


def _depth_obstacle_points(obs, robot, sample_stride=8):
    """Sparse low geometry from all four public robot-mounted depth cameras."""
    depth, valid = np.asarray(obs['depth']), np.asarray(obs['depth_valid'])
    if depth.ndim != 4 or depth.shape[0] != 5 or depth.shape[-1] != 1 or valid.shape != depth.shape:
        raise ValueError('Expected five matching metric depth/validity camera arrays')
    if valid.dtype != bool:
        raise ValueError('Expected boolean public depth_valid')
    poses = np.asarray(obs['base_pose_world'], dtype=float)
    grasps = np.asarray(obs['grasp_pose_base'], dtype=float)
    if poses.shape != (2, 7) or grasps.shape != (2, 7) or not np.isfinite(poses).all() or not np.isfinite(grasps).all():
        raise ValueError('Invalid public robot poses')
    height, width = depth.shape[1:3]
    focal = width/(2*np.tan(np.deg2rad(CALIBRATION['fov_degrees']/2)))
    row, col = np.mgrid[0:height:sample_stride, 0:width:sample_stride]
    points, camera_ids, pixels, optical_depth = [], [], [], []
    valid_count = 0
    for camera in (3, 4, 1, 2):
        z = depth[camera, row, col, 0]
        good = valid[camera, row, col, 0] & np.isfinite(z) & (z > .05) & (z < (3. if camera < 3 else 5.))
        valid_count += int(np.count_nonzero(good))
        if not np.any(good):
            continue
        optical = pixel_rays(col[good], row[good], focal, width, height)*z[good, None]
        observer = camera-3 if camera >= 3 else camera-1
        if camera >= 3:
            base = optical @ HEAD[:3, :3].T + HEAD[:3, 3]
        else:
            grasp = optical @ WRIST[:3, :3].T + WRIST[:3, 3]
            base = grasp @ _rotation(grasps[observer, 3:]).T + grasps[observer, :3]
        points.append(base_to_world(obs, observer, base))
        camera_ids.append(np.full(int(good.sum()), camera, dtype=np.int8))
        pixels.append(np.column_stack((col[good], row[good])))
        optical_depth.append(z[good])
    if not points:
        return dict(points=np.empty((0, 3)), sampled_valid_count=valid_count,
                    filtered_self_count=0, filtered_model_mast_count=0,
                    source_camera_ids=np.empty(0, dtype=np.int8),
                    source_pixel_uv=np.empty((0, 2), dtype=int), optical_depth_m=np.empty(0))
    world = np.concatenate(points)
    z_above_base = world[:, 2]-poses[robot, 2]
    low = np.isfinite(world).all(axis=1) & (z_above_base >= .12) & (z_above_base <= .70)
    world = world[low]
    sources, pixel_uv, depths = np.concatenate(camera_ids)[low], np.concatenate(pixels)[low], np.concatenate(optical_depth)[low]
    # Deliberately small approximate masks plus measured-pose visual envelopes.
    # The extended arm is not modeled. The OTHER robot is also a base disk.
    local = world_to_base(obs, robot, world)
    near_own_base = (np.linalg.norm(local[:, :2], axis=1) < .20) & (local[:, 2] < .45) & (local[:, 2] >= 0)
    near_own_grasp = np.linalg.norm(world-grasp_world(obs, robot), axis=1) < .12
    model_gripper = _model_gripper_self_mask(obs, robot, world)
    model_mast = _model_mast_self_mask(obs, robot, world)
    model_base = _model_base_surface_self_mask(local)
    model_wheels = _model_wheel_self_mask(local)
    self_mask = near_own_base | near_own_grasp | model_gripper | model_mast | model_base | model_wheels
    return dict(points=world[~self_mask], sampled_valid_count=valid_count,
                source_camera_ids=sources[~self_mask], source_pixel_uv=pixel_uv[~self_mask],
                optical_depth_m=depths[~self_mask],
                filtered_self_count=int(np.count_nonzero(self_mask)),
                filtered_model_base_count=int(np.count_nonzero(model_base & ~near_own_base & ~near_own_grasp)),
                filtered_model_wheel_count=int(np.count_nonzero(model_wheels & ~near_own_base & ~near_own_grasp)),
                filtered_model_mast_count=int(np.count_nonzero(model_mast & ~near_own_base & ~near_own_grasp & ~model_gripper)),
                filtered_model_gripper_count=int(np.count_nonzero(model_gripper & ~near_own_base & ~near_own_grasp)))


def guard_base_velocity(obs, robot, body_velocity_xy, max_speed=.10, footprint_radius=.30):
    """Return a bounded body velocity and evidence about any restriction.

    Prediction: 1.5 seconds of constant planar velocity, with a circular base
    footprint and 4 cm clearance.  Restrict commands approaching observed low
    geometry; permit commands moving away from it.  No directional low-geometry
    support means unknown, capped at 0.03 m/s instead of reported as free space.
    Other-robot radius is conservatively assumed equal to footprint_radius.
    """
    if robot not in (0, 1):
        raise ValueError('Robot index must be 0 or 1')
    velocity = np.array(body_velocity_xy, dtype=float, copy=True)
    if velocity.shape != (2,) or not np.isfinite(velocity).all():
        raise ValueError('Expected finite body velocity [forward, left] in m/s')
    if not np.isfinite(max_speed) or max_speed <= 0 or not np.isfinite(footprint_radius) or footprint_radius <= 0:
        raise ValueError('Positive speed and footprint radius required')
    requested = velocity.copy()
    speed = float(np.linalg.norm(velocity))
    velocity *= min(1., max_speed/max(speed, 1e-12))
    poses = np.asarray(obs['base_pose_world'], dtype=float)
    if poses.shape != (2, 7) or not np.isfinite(poses).all():
        raise ValueError('Invalid public base poses')
    rotation = _rotation(poses[robot, 3:])
    # Extract yaw from a wxyz base orientation. A planar guard cannot certify
    # tilted bases; tell the caller and stop instead of flattening a large tilt.
    tilt = float(np.arccos(np.clip(rotation[2, 2], -1., 1.)))
    yaw = np.arctan2(rotation[1, 0], rotation[0, 0])
    body_to_world = np.array([[np.cos(yaw), -np.sin(yaw)], [np.sin(yaw), np.cos(yaw)]])
    world_velocity = body_to_world @ velocity
    measured = _depth_obstacle_points(obs, robot)
    cloud = measured['points']
    base = poses[robot, :2]
    # The paired base remains an obstacle even if depth is missing or if its
    # low body happens to be outside all camera images.
    centers = np.vstack((cloud[:, :2], poses[1-robot, :2]))
    obstacle_radii = np.r_[np.zeros(len(cloud)), footprint_radius]
    offsets = centers-base
    distances = np.linalg.norm(offsets, axis=1)
    clearances = distances-footprint_radius-obstacle_radii
    nearest_index = int(np.argmin(clearances))
    nearest = dict(kind='other_robot_base' if nearest_index == len(cloud) else 'public_depth_point',
                   world_xy=centers[nearest_index].tolist(), distance_m=float(distances[nearest_index]),
                   approximate_footprint_clearance_m=float(clearances[nearest_index]))
    def source_details(index):
        if index >= len(cloud):
            return {}
        details = dict(world_xyz=cloud[index].tolist(),
                       base_local_xyz=world_to_base(obs, robot, cloud[index]).tolist())
        if 'source_camera_ids' in measured:
            details.update(source_camera_id=int(measured['source_camera_ids'][index]),
                           source_pixel_uv=measured['source_pixel_uv'][index].tolist(),
                           optical_depth_m=float(measured['optical_depth_m'][index]))
        return details
    nearest.update(source_details(nearest_index))
    norm = float(np.linalg.norm(world_velocity))
    toward = offsets @ world_velocity
    heading_support = 0
    if norm > 1e-10 and len(cloud):
        depth_distance = distances[:len(cloud)]
        heading_support = int(np.count_nonzero((depth_distance < 2.) & (depth_distance > .01) &
            (toward[:len(cloud)]/np.maximum(norm*depth_distance, 1e-12) > np.cos(np.pi/4))))
    unknown = heading_support < 3
    scale = 1.
    reason = 'observed_constraints_only_no_free_space_guarantee'
    if norm <= 1e-10:
        scale, reason = 0., 'stationary'
    elif tilt > .065:
        scale, reason = 0., 'base_tilt_outside_planar_guard'
    elif distances[-1] < 1e-4:
        scale, reason = 0., 'coincident_other_base_stop'
    elif unknown:
        scale = min(1., .03/norm)
        reason = 'unknown_direction_limited_speed'
    horizon = 1.5
    segment = world_velocity*horizon
    length_squared = float(segment @ segment)
    projected = np.clip((offsets @ segment)/max(length_squared, 1e-12), 0., 1.)
    closest = base + projected[:, None]*segment
    swept_clearance = np.linalg.norm(centers-closest, axis=1)-footprint_radius-obstacle_radii
    threatening = (toward > 1e-9) & (swept_clearance < .20)
    restricting = None
    if norm > 1e-10 and np.any(threatening) and tilt <= .065:
        candidates = np.where(threatening)[0]
        limiting = int(candidates[np.argmin(swept_clearance[candidates])])
        obstacle_scale = float(np.clip((swept_clearance[limiting]-.04)/.16, 0., 1.))
        restricting = dict(kind='other_robot_base' if limiting == len(cloud) else 'public_depth_point',
                           world_xy=centers[limiting].tolist(),
                           predicted_swept_clearance_m=float(swept_clearance[limiting]))
        restricting.update(source_details(limiting))
        if obstacle_scale <= scale:
            scale = obstacle_scale
            reason = 'approaching_obstacle_stop' if scale == 0 else 'approaching_obstacle_slowdown'
    applied = velocity*scale
    return dict(body_velocity_xy=applied.tolist(), reason=reason, scale=float(scale),
                requested_body_velocity_xy=requested.tolist(),
                speed_bounded_world_velocity_xy=world_velocity.tolist(),
                applied_world_velocity_xy=(body_to_world @ applied).tolist(),
                nearest_obstacle=nearest, restricting_obstacle=restricting,
                observed_point_count=int(len(cloud)), sampled_valid_depth_count=measured['sampled_valid_count'],
                filtered_self_point_count=measured['filtered_self_count'],
                filtered_model_gripper_point_count=measured.get('filtered_model_gripper_count', 0),
                filtered_model_mast_point_count=measured.get('filtered_model_mast_count', 0),
                filtered_model_base_point_count=measured.get('filtered_model_base_count', 0),
                filtered_model_wheel_point_count=measured.get('filtered_model_wheel_count', 0),
                directional_low_geometry_support=heading_support, unknown_direction=unknown,
                space_is_certified_free=False, prediction_horizon_s=horizon,
                self_filter='existing approximate base cylinder 0.20m and grasp sphere 0.12m, plus static visual chassis triangles, wheel swept envelopes, housing, measured-angle nonconvex fingers and fixed nonconvex mast with 1mm tolerance; approximate self filtering can hide contacting points',
                limitation='sparse public depth plus paired-base disk; no route planning, complete visibility, arm protection, or collision-free guarantee')
