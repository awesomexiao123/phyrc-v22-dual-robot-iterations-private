"""One bounded negative-two-degree loaded pitch pilot per robot.

Uses public RGBD/own poses and the reviewed static OWN pitch lever only. This
is a cloth-shape experiment, not an opening detector, attachment test, or sweep
clearance certificate. Targets are integrated: callers must pass through the
``cancellation_only`` action while ``failure`` is None. A terminal unresolved
target lag requires an external simulation stop, not an assertion that zeros
freeze the robot. Never reconstruct this object to reset measured budgets.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from loaded_roll_observation import _cloth_evidence, _state
from public_vision import _rotation


class LoadedPitchObservation:
    """Persistent, sequential pilot with measured grasp-center feedback.

    API mirrors LoadedRollObservation. ``stop_for_openings`` is merely an
    optional caller inspection request; this module never verifies an opening.
    Existing cached hands require an explicit verified stationary assumption.
    Current cloth support near BOTH grasps is required on every normal step.
    """
    LEVER = .29535798728466034  # Own USD pitch-axis to grasp X; validation audit.
    NOMINAL_RAD = np.deg2rad(2.)
    PER_WRIST_RAD = np.deg2rad(2.5)
    TOTAL_RAD = np.deg2rad(5.)
    RATE = np.deg2rad(1.)
    LINEAR_RATE = .01
    ACTION_DT = .05
    MAX_SECONDS = 18.
    MAX_CALLS = 450
    LINEAR_ENVELOPE_M = .016
    PITCH_LIMITS = (-4.275999675738779+np.deg2rad(1.), 1.1349999749656927-np.deg2rad(1.))
    OTHER_WRIST_LIMITS = (-1.1349999749656927+np.deg2rad(1.), 4.275999675738779-np.deg2rad(1.))
    LOWER = np.array([.005, .005, PITCH_LIMITS[0]])
    UPPER = np.array([1.195, .515, PITCH_LIMITS[1]])
    NORMAL_LAG = np.array([.001, .001, np.deg2rad(.10)])
    CANCEL_LAG = np.array([.002, .002, np.deg2rad(.30)])
    SETTLED_LAG = np.array([.0001, .0001, np.deg2rad(.01)])
    MAX_RATES = np.array([LINEAR_RATE, LINEAR_RATE, RATE])
    TARGET_COLUMNS = [0, 1, 3]
    ACTION_COLUMNS = [3, 4, 6]

    def __init__(self, obs, hands, observed_at, *, stationary_human=False,
                 max_hand_age_s=300., wrist_rate=5.5, lift_rate=1.54, arm_rate=1.21):
        self.done = self.skipped = self.eligible = self.motion_started = False
        self.experiment_completed = self.early_stopped = False
        self.failure = self.pending_failure = self.ineligible_reason = None
        self.phase = 'initial_settle'; self.active_robot = 0
        self.debug = {}; self.absolute_pitch = np.zeros(2)
        self.calls = self.cancel_calls = 0; self.stable_s = self.cancel_stable_s = 0.
        self.time0 = self.last_time = self.cancel_start = None
        self.stationary_human = stationary_human is True; self.observed_at = None
        try:
            self.scales = np.array([lift_rate, arm_rate, wrist_rate], float)
            self.observed_at = float(observed_at); self.max_hand_age_s = float(max_hand_age_s)
            if not self.stationary_human:
                raise ValueError('explicit_verified_stationary_human_assumption_required')
            if (not np.isfinite(self.scales).all() or np.any(self.scales < self.MAX_RATES)
                    or not np.isfinite([self.observed_at, self.max_hand_age_s]).all()
                    or not 0 < self.max_hand_age_s <= 300):
                raise ValueError('invalid_rates_or_stationary_hand_cache_bound')
            if hands.get('observation_time_s') is not None and abs(float(hands['observation_time_s'])-self.observed_at) > 1e-7:
                raise ValueError('hand_observation_timestamp_sources_disagree')
            self.hands = np.asarray(hands.get('hand_points_world'), float).copy()
            if (not hands.get('detected') or self.hands.shape != (2, 3) or not np.isfinite(self.hands).all()
                    or not .06 <= np.linalg.norm(self.hands[1]-self.hands[0]) <= 1.2):
                raise ValueError('two_separated_observed_hand_points_required')
            bases, grasps, _, _, now = _snapshot(obs)
            self.base0, self.grasp0 = bases.copy(), grasps.copy()
            self.q0, _, self.targets0 = [a.copy() for a in _state(obs)]
            self.u0 = self._measured(self.q0)
            self.goals = self.u0[:, 2]-self.NOMINAL_RAD
            self.last_u = self.u0.copy(); self.time0 = self.last_time = now
            self.last_targets = self.targets0.copy()
            self.expected_targets = self.targets0.copy()
            self.goal_u = self.u0.copy()
            lateral = []
            for robot in (0, 1):
                delta = self._pitch_delta(robot, self.u0[robot, 2], self.goals[robot])
                self.goal_u[robot] += [-delta[2], -delta[0], -self.NOMINAL_RAD]
                sweep = [abs(self._pitch_delta(robot, self.u0[robot, 2], p)[1])
                         for p in np.linspace(self.u0[robot, 2], self.goals[robot], 17)]
                lateral.append(max(sweep))
            self.debug['predicted_unactuated_lateral_excursion_m'] = lateral
            if max(lateral) >= .001:
                raise ValueError('initial_yaw_makes_pilot_lateral_residual_at_least_1mm')
            if np.any(self.goal_u < self.LOWER) or np.any(self.goal_u > self.UPPER):
                raise ValueError('compensated_pilot_goal_exceeds_own_joint_margin')
            self._guards(obs, bases, grasps, now, initial=True)
            self.eligible = True
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self._skip(str(error))

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        return action

    @staticmethod
    def _measured(q):
        return np.column_stack((q[:, 3], q[:, 4:8].sum(1), q[:, 9]))

    @staticmethod
    def _velocities(qd):
        return np.column_stack((qd[:, 3], qd[:, 4:8].sum(1), qd[:, 9]))

    def _pitch_delta(self, robot, before, after):
        # Pitch moves about local Y after wrist yaw; arm/lift move in base X/Z.
        dx = self.LEVER*(np.cos(after)-np.cos(before))
        yaw = self.q0[robot, 8]
        return np.array([np.cos(yaw)*dx, np.sin(yaw)*dx,
                         -self.LEVER*(np.sin(after)-np.sin(before))])

    def _predicted_center_delta(self, robot, measured, target):
        delta = self._pitch_delta(robot, measured[2], target[2])
        return delta + [target[1]-measured[1], 0., target[0]-measured[0]]

    def _skip(self, reason):
        self.done = self.skipped = True; self.eligible = False
        self.ineligible_reason = reason; self.phase = 'ineligible_before_motion'

    def _result(self, action=None):
        if action is None or self.done or self.failure:
            action = self._hold()
        self.debug.update(phase=self.phase, active_robot=self.active_robot,
            nominal_negative_pitch_degrees_per_robot=float(np.rad2deg(self.NOMINAL_RAD)),
            absolute_ceiling_degrees_per_robot=float(np.rad2deg(self.PER_WRIST_RAD)),
            total_absolute_pitch_budget_degrees=float(np.rad2deg(self.TOTAL_RAD)),
            maximum_linear_compensation_from_start_m=self.LINEAR_ENVELOPE_M,
            measured_absolute_pitch_degrees=np.rad2deg(self.absolute_pitch).tolist(),
            measured_total_absolute_pitch_degrees=float(np.rad2deg(self.absolute_pitch.sum())),
            ineligible_reason=self.ineligible_reason, pending_failure=self.pending_failure,
            cached_hand_observed_at_s=self.observed_at, stationary_human_assumption_declared=self.stationary_human,
            current_cloth_required_every_frame=True, observed_point_clearance_only=True,
            full_human_or_wrist_sweep_clearance_verified=False, attachment_verified=False,
            opening_visibility_improved=None, cuff_identity_verified=False, insertion_allowed=False,
            scope='finite compensated loaded pitch pilot; no opening, attachment or dressing claim')
        return dict(action=np.asarray(action, np.float32), done=self.done, eligible=self.eligible,
            skipped=self.skipped, failure=self.failure, pending_failure=self.pending_failure,
            cancellation_only=self.phase == 'cancelling_target', motion_started=self.motion_started,
            early_stopped=self.early_stopped, experiment_completed=self.experiment_completed,
            debug=deepcopy(self.debug))

    def _guards(self, obs, bases, grasps, now, *, initial=False):
        q, qd, targets = _state(obs); u = self._measured(q)
        t = targets[:, self.TARGET_COLUMNS]; velocities = self._velocities(qd)
        if not 0 <= now-self.observed_at <= self.max_hand_age_s:
            raise ValueError('stationary_hand_cache_stale_or_from_future')
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('closed_gripper_intent_lost')
        gaps = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isfinite(gaps).all() or np.any(gaps < 0) or np.any(gaps > .08):
            raise ValueError('closed_gripper_gap_guard')
        if np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
            raise ValueError('base_pair_separation_guard')
        if (np.any(u < self.LOWER) or np.any(u > self.UPPER) or np.any(t < self.LOWER) or np.any(t > self.UPPER)
                or np.any(q[:, 4:8] < -1e-5) or np.any(q[:, 4:8] > .13001)
                or np.any(q[:, [8, 10]] < self.OTHER_WRIST_LIMITS[0])
                or np.any(q[:, [8, 10]] > self.OTHER_WRIST_LIMITS[1])):
            raise ValueError('own_measured_or_target_joint_limit')
        drift = np.linalg.norm(grasps-self.grasp0, axis=1)
        self.debug['measured_grasp_center_drift_m'] = drift.tolist()
        if drift.max() > .003 or np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1).max() > .003:
            raise ValueError('base_or_grasp_center_drift_over_3mm')
        for robot in (0, 1):
            rb = _rotation(bases[robot, 3:]); relative = rb @ _rotation(self.base0[robot, 3:]).T
            if (np.arccos(np.clip(rb[2, 2], -1, 1)) > .065
                    or np.arccos(np.clip((np.trace(relative)-1)/2, -1, 1)) > np.deg2rad(.25)):
                raise ValueError('base_tilt_or_rotation_guard')
        if (np.max(np.abs(q[:, [8, 10]]-self.q0[:, [8, 10]])) > np.deg2rad(.2)
                or np.max(np.abs(qd[:, [8, 10]])) > np.deg2rad(.2)
                or np.max(np.abs(targets[:, [2, 4]]-q[:, [8, 10]])) > np.deg2rad(.15)
                or np.max(np.abs(targets[:, [2, 4]]-self.targets0[:, [2, 4]])) > 1e-5
                or np.max(np.abs(targets[:, 6:9])) > 1e-5):
            raise ValueError('fixed_base_yaw_or_roll_changed')
        if np.any(np.abs(velocities) > [2*self.LINEAR_RATE, 2*self.LINEAR_RATE, 2*self.RATE]):
            raise ValueError('measured_velocity_exceeds_bounded_response')
        if (np.max(np.abs(q[:, 4:8]-targets[:, 1, None]/4)) > .00075
                or np.max(np.abs(qd[:, 4:8])) > .005):
            raise ValueError('individual_arm_segment_lag_or_velocity')
        if (np.any(self.absolute_pitch > self.PER_WRIST_RAD+1e-8)
                or self.absolute_pitch.sum() > self.TOTAL_RAD+1e-8):
            raise ValueError('measured_absolute_pitch_budget_exceeded')
        if np.any(np.abs(t-u) > self.CANCEL_LAG):
            raise ValueError('excessive_three_axis_integrated_target_lag')
        if np.any(np.abs(t[:, :2]-self.u0[:, :2]) > self.LINEAR_ENVELOPE_M):
            raise ValueError('linear_compensation_exceeds_pilot_envelope')
        if (np.any(t[:, 2] < self.goals-1e-7) or np.any(t[:, 2] > self.u0[:, 2]+np.deg2rad(.01))
                or np.any(u[:, 2] < self.goals-np.deg2rad(.2))
                or np.any(u[:, 2] > self.u0[:, 2]+np.deg2rad(.1))):
            raise ValueError('pitch_outside_negative_pilot_goal')
        if initial and np.any(np.abs(t-u) > self.SETTLED_LAG*3):
            raise ValueError('initial_three_axis_targets_not_settled')
        if initial and np.max(np.abs(q[:, 4:8]-targets[:, 1, None]/4)) > .0001:
            raise ValueError('initial_individual_arm_segments_not_settled')
        if initial and np.max(np.abs(targets[:, [2, 4]]-q[:, [8, 10]])) > np.deg2rad(.05):
            raise ValueError('initial_fixed_yaw_or_roll_target_not_settled')
        if not initial and np.max(np.abs(targets[:, self.TARGET_COLUMNS]-self.expected_targets[:, self.TARGET_COLUMNS])) > 1e-5:
            raise ValueError('unexpected_three_axis_integrated_target_change')
        if self.phase != 'initial_settle':
            other = 1-self.active_robot
            expected_pitch = self.goals[other] if other < self.active_robot else self.u0[other, 2]
            if abs(u[other, 2]-expected_pitch) > np.deg2rad(.1) or abs(velocities[other, 2]) > np.deg2rad(.1):
                raise ValueError('inactive_robot_pitch_drift')
        self.debug.update(_cloth_evidence(obs, grasps, self.hands))
        self.debug.update(hand_observation_age_s=now-self.observed_at,
            measured_lift_arm_pitch=u.tolist(), integrated_lift_arm_pitch_targets=t.tolist(),
            measured_target_lag=(t-u).tolist(), final_compensated_nominal_joint_goals=self.goal_u.tolist())
        return q, qd, targets

    def _emit(self, targets, delta):
        action = self._hold()
        action[:, self.ACTION_COLUMNS] = delta/self.ACTION_DT/self.scales
        self.expected_targets = targets.copy()
        self.expected_targets[:, self.TARGET_COLUMNS] += delta
        if np.max(np.abs(delta)) > 1e-12:
            self.motion_started = True
        return self._result(action)

    def _abort(self, reason, obs, now):
        if not self.motion_started:
            self._skip(reason); return self._result()
        self.pending_failure = self.pending_failure or reason
        if self.phase != 'cancelling_target':
            self.cancel_start = now; self.cancel_stable_s = 0.
        self.phase = 'cancelling_target'
        return self._cancel(obs, now, 0.)

    def _cancel(self, obs, now, dt):
        """Remove all three target leads together, never launch a reverse pilot.

        The common fraction preserves the coupled compensation vector during
        cancellation. Predicted pending center excursion must remain <=1.5mm;
        this is a kinematic bound, not a servo/force guarantee.
        """
        try:
            self.cancel_calls += 1
            q, qd, targets = _state(obs); u = self._measured(q); t = targets[:, self.TARGET_COLUMNS]
            error = u-t
            if (np.any(np.abs(error) > self.CANCEL_LAG) or np.any(u < self.LOWER) or np.any(u > self.UPPER)
                    or np.any(t < self.LOWER) or np.any(t > self.UPPER)
                    or np.any(self.absolute_pitch+np.abs(error[:, 2])+np.deg2rad(.025) > self.PER_WRIST_RAD)
                    or self.absolute_pitch.sum()+np.abs(error[:, 2]).sum()+np.deg2rad(.05) > self.TOTAL_RAD
                    or now-self.cancel_start > 1.5 or self.cancel_calls > 40):
                raise ValueError('cannot_bound_three_axis_target_cancellation')
            if (np.max(np.abs(targets[:, [2, 4]]-self.targets0[:, [2, 4]])) > 1e-5
                    or np.max(np.abs(targets[:, [2, 4]]-q[:, [8, 10]])) > np.deg2rad(.15)
                    or np.max(np.abs(targets[:, 6:9])) > 1e-5):
                raise ValueError('uncontrolled_fixed_axis_target_during_cancellation')
            if (np.any(np.abs(self._velocities(qd)) > 2*self.MAX_RATES)
                    or np.max(np.abs(qd[:, [8, 10]])) > np.deg2rad(.2)):
                raise ValueError('cannot_bound_measured_velocity_during_cancellation')
            if (np.max(np.abs(q[:, 4:8]-targets[:, 1, None]/4)) > .001
                    or np.max(np.abs(qd[:, 4:8])) > .005):
                raise ValueError('cannot_bound_individual_arm_segment_response')
            excursions = [max(np.linalg.norm(self._predicted_center_delta(r, u[r], u[r]+s*(t[r]-u[r])))
                              for s in np.linspace(0., 1., 5)) for r in (0, 1)]
            if max(excursions) > .0015:
                raise ValueError('pending_three_axis_target_predicts_center_excursion_over_1_5mm')
            # Observations continue during cancellation; missing evidence never
            # resumes the experiment or prevents removing already queued lead.
            try:
                _, grasps, _, _, _ = _snapshot(obs)
                self.debug.update(_cloth_evidence(obs, grasps, self.hands))
                self.debug['cancellation_scene_evidence_reason'] = None if 0 <= now-self.observed_at <= self.max_hand_age_s else 'cached_hand_time_invalid'
            except (KeyError, TypeError, ValueError, IndexError) as evidence_error:
                self.debug['cancellation_scene_evidence_reason'] = str(evidence_error)
            self.debug['pending_target_center_excursion_m'] = excursions
            scale = min(1., float(np.min(self.MAX_RATES*self.ACTION_DT/np.maximum(np.abs(error), 1e-15))))
            delta = error*scale
            stable = (np.all(np.abs(error) <= self.SETTLED_LAG)
                      and np.all(np.abs(self._velocities(qd)) <= [.0005, .0005, np.deg2rad(.1)])
                      and np.max(np.abs(q[:, 4:8]-targets[:, 1, None]/4)) <= .0001
                      and np.max(np.abs(qd[:, 4:8])) <= .0002)
            self.cancel_stable_s = self.cancel_stable_s+dt if stable else 0.
            self.debug['unresolved_target_lag'] = False
            if self.cancel_stable_s >= .15-1e-8:
                if self.pending_failure:
                    self.failure = self.pending_failure; self.phase = 'failed_after_target_cancellation'
                else:
                    self.done = self.early_stopped = True; self.phase = 'early_stop_after_target_cancellation'
                return self._result()
            # No repeated integration against an unchanged observation clock.
            return self._emit(targets, delta) if dt > 0 or self.cancel_calls == 1 else self._result()
        except (KeyError, TypeError, ValueError, IndexError) as error:
            self.failure = (self.pending_failure or 'requested_early_stop')+': '+str(error)
            self.phase = 'unresolved_target_lag'; self.debug['unresolved_target_lag'] = True
            return self._result()

    def step(self, obs, *, stop_for_openings=False):
        if self.done or self.failure:
            return self._result()
        self.calls += 1
        try:
            bases, grasps, _, _, now = _snapshot(obs)
            q, qd, targets = _state(obs); u = self._measured(q)
            changes = np.abs(u-self.last_u)
            self.absolute_pitch += changes[:, 2]
            self.motion_started |= bool(np.any(changes > 1e-7))
            self.last_u = u.copy()
            dt = now-self.last_time; self.last_time = now
            if dt < -1e-8 or dt > .075:
                raise ValueError('nonconsecutive_public_observation_clock')
            dt = max(0., dt)
            if self.phase == 'cancelling_target':
                return self._cancel(obs, now, dt)
            q, qd, targets = self._guards(obs, bases, grasps, now)
            if now-self.time0 > self.MAX_SECONDS or self.calls > self.MAX_CALLS:
                raise ValueError('bounded_pitch_experiment_timed_out')
            if not isinstance(stop_for_openings, bool):
                raise ValueError('optional_stop_request_must_be_boolean')
            if stop_for_openings:
                self.debug['early_stop_basis'] = 'caller_requested_inspection; this module did not verify openings'
                if not self.motion_started:
                    self.done = self.early_stopped = True; self.phase = 'early_stop_before_motion'
                    return self._result()
                self.phase = 'cancelling_target'; self.cancel_start = now
                return self._cancel(obs, now, dt)
            if dt <= 0:
                return self._result()
            t = targets[:, self.TARGET_COLUMNS]; velocities = self._velocities(qd)
            settled = (np.all(np.abs(velocities) <= [.0005, .0005, np.deg2rad(.1)])
                       and np.all(np.abs(t-u) <= self.SETTLED_LAG)
                       and np.max(np.abs(q[:, 4:8]-targets[:, 1, None]/4)) <= .0001
                       and np.max(np.abs(qd[:, 4:8])) <= .0002)
            if self.phase == 'initial_settle':
                self.stable_s = self.stable_s+dt if settled else 0.
                if self.stable_s >= .5-1e-8:
                    self.phase = 'pitch_0'; self.stable_s = 0.
                return self._result()
            robot = self.active_robot
            if self.phase.startswith('settle_'):
                reached = (abs(u[robot, 2]-self.goals[robot]) <= np.deg2rad(.03)
                           and np.linalg.norm(grasps-self.grasp0, axis=1).max() <= .001)
                self.stable_s = self.stable_s+dt if settled and reached else 0.
                if self.stable_s >= .5-1e-8:
                    if robot == 0:
                        self.active_robot = 1; self.phase = 'pitch_1'; self.stable_s = 0.
                    else:
                        self.done = self.experiment_completed = True; self.phase = 'experiment_completed'
                    return self._result()
            # Pause angular advance if compensation is lagging, but continue
            # bounded center feedback. Never grow target pitch beyond its goal.
            lead_room = max(0., self.NORMAL_LAG[2]-(u[robot, 2]-t[robot, 2]))
            budget = min(self.PER_WRIST_RAD-self.absolute_pitch[robot], self.TOTAL_RAD-self.absolute_pitch.sum())-np.deg2rad(.1)
            advance = max(0., min(self.RATE*self.ACTION_DT, t[robot, 2]-self.goals[robot], lead_room, budget))
            if np.any(np.abs(t[robot, :2]-u[robot, :2]) > self.NORMAL_LAG[:2]) or self.phase.startswith('settle_'):
                advance = 0.
            desired_pitch = t[robot, 2]-advance
            error_local = _rotation(bases[robot, 3:]).T @ (self.grasp0[robot]-grasps[robot])
            delta_pitch = self._pitch_delta(robot, u[robot, 2], desired_pitch)
            desired = u[robot]+[error_local[2]-delta_pitch[2], error_local[0]-delta_pitch[0], desired_pitch-u[robot, 2]]
            delta = np.zeros((2, 3)); delta[robot] = desired-t[robot]
            # Scale the coupled 3-axis increment rather than independently
            # clipping axes, which would create uncompensated pitch motion.
            scale = min(1., float(np.min(self.MAX_RATES*self.ACTION_DT/np.maximum(np.abs(delta[robot]), 1e-15))))
            delta *= scale
            next_target = t+delta
            if np.any(next_target < self.LOWER) or np.any(next_target > self.UPPER):
                raise ValueError('outgoing_compensated_target_exceeds_own_joint_margin')
            if np.any(np.abs(next_target-u) > self.CANCEL_LAG):
                raise ValueError('outgoing_three_axis_target_lag_unbounded')
            if (self.phase.startswith('pitch_') and abs(t[robot, 2]-self.goals[robot]) <= self.SETTLED_LAG[2]
                    and abs(u[robot, 2]-self.goals[robot]) <= np.deg2rad(.03)
                    and abs(velocities[robot, 2]) <= np.deg2rad(.1)):
                self.phase = 'settle_'+str(robot); self.stable_s = 0.
            self.debug['command_physical_lift_arm_pitch_rates'] = (delta/self.ACTION_DT).tolist()
            self.debug['active_unactuated_center_error_m'] = float(error_local[1])
            return self._emit(targets, delta)
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            return self._abort(str(error), obs, self.last_time if self.last_time is not None else self.time0)
