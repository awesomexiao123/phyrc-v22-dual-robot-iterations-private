"""Bounded local A* around observed low geometry; never a free-space proof.

Public sparse depth and the paired base define inflated obstacles. Unobserved
cells remain unknown, even when a route through them is returned. A caller must
retain the live depth velocity guard and low speed; extended-arm, cloth and
human clearance are outside this base-only local planner.
"""
import heapq
import math

import numpy as np

from navigation import _depth_obstacle_points, own_geometry_mask
from public_vision import world_to_base

RESOLUTION = .05
FOOTPRINT_RADIUS = .30
CLEARANCE = .04
MAX_EXECUTION_CLEARANCE = .20
# A clear exact endpoint can lie inside a conservatively occupied grid cell.
# Connect only to nearby already-free nodes; never erase occupied cells.
MAX_ENDPOINT_CONNECTION = 2*RESOLUTION
MAX_SIDE = 8.
MAX_GOAL_DISTANCE = 6.
MAX_EXPANSIONS = 26000


def _execution_clearance(value):
    """Validate an explicit geometric margin, separate from grid cell padding."""
    if np.ndim(value) != 0:
        raise ValueError('execution_clearance_m must be a finite scalar in [0.04, 0.20] m')
    try:
        margin = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError('execution_clearance_m must be a finite scalar in [0.04, 0.20] m') from error
    if not np.isfinite(margin) or not CLEARANCE <= margin <= MAX_EXECUTION_CLEARANCE:
        raise ValueError('execution_clearance_m must be a finite scalar in [0.04, 0.20] m')
    return margin


def _segment_clear(start, end, centers, radii):
    """Continuous swept-disk test against all supplied point/disk obstacles."""
    start, end = np.asarray(start), np.asarray(end)
    vector = end-start
    squared = float(vector @ vector)
    fraction = np.clip(((centers-start) @ vector)/max(squared, 1e-15), 0., 1.)
    distance = np.linalg.norm(centers-(start+fraction[:, None]*vector), axis=1)
    return bool(np.all(distance > radii + 1e-9))


def _astar(occupied, start, goal, max_expansions=MAX_EXPANSIONS):
    """Eight-neighbor grid search; diagonal motion may not cut blocked corners."""
    height, width = occupied.shape
    if occupied[start] or occupied[goal]:
        return None, 0, 'blocked_grid_endpoint'
    costs = np.full(occupied.shape, np.inf)
    costs[start] = 0.
    parents = np.full((height, width, 2), -1, dtype=np.int32)
    closed = np.zeros_like(occupied, dtype=bool)

    def estimate(node):
        dy, dx = abs(node[0]-goal[0]), abs(node[1]-goal[1])
        return max(dx, dy) + (math.sqrt(2)-1)*min(dx, dy)

    queue = [(estimate(start), 0., start)]
    expanded = 0
    offsets = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if dy or dx]
    while queue and expanded < max_expansions:
        _, cost, current = heapq.heappop(queue)
        if closed[current]:
            continue
        closed[current] = True; expanded += 1
        if current == goal:
            route = [current]
            while route[-1] != start:
                route.append(tuple(int(v) for v in parents[route[-1]]))
            return list(reversed(route)), expanded, 'grid_route_found'
        y, x = current
        for dy, dx in offsets:
            ny, nx = y+dy, x+dx
            if not (0 <= ny < height and 0 <= nx < width) or occupied[ny, nx] or closed[ny, nx]:
                continue
            if dy and dx and (occupied[y, nx] or occupied[ny, x]):
                continue
            candidate = cost + (math.sqrt(2) if dy and dx else 1.)
            if candidate < costs[ny, nx]:
                costs[ny, nx] = candidate; parents[ny, nx] = current
                heapq.heappush(queue, (candidate+estimate((ny, nx)), candidate, (ny, nx)))
    return None, expanded, 'search_budget_exhausted' if queue else 'no_route_in_bounded_region'


def _inflate(origin, shape, centers, radii):
    occupied = np.zeros(shape, bool)
    # A whole cell must fit, rather than only its center being collision-free.
    cell_margin = RESOLUTION/math.sqrt(2)
    for center, radius in zip(centers, radii + cell_margin):
        lower = np.floor((center-radius-origin)/RESOLUTION).astype(int)
        upper = np.ceil((center+radius-origin)/RESOLUTION).astype(int)
        x0, x1 = max(0, lower[0]), min(shape[1]-1, upper[0])
        y0, y1 = max(0, lower[1]), min(shape[0]-1, upper[1])
        if x1 < x0 or y1 < y0:
            continue
        x = origin[0] + np.arange(x0, x1+1)*RESOLUTION
        y = origin[1] + np.arange(y0, y1+1)*RESOLUTION
        occupied[y0:y1+1, x0:x1+1] |= ((x[None, :]-center[0])**2 + (y[:, None]-center[1])**2 <= radius**2)
    return occupied


def _endpoint_grid_connection(point, origin, occupied, centers, radii):
    """Nearest free node within 10 cm with a checked exact-endpoint segment.

    Cell inflation includes discretization padding, while this connector uses
    the same continuous swept footprint as the final path. Occupancy is read
    only. A bounded failure stays a failure even if a farther node is free.
    """
    grid_xy = np.rint((point-origin)/RESOLUTION).astype(int)
    rounded = (int(grid_xy[1]), int(grid_xy[0]))
    height, width = occupied.shape
    in_grid = 0 <= rounded[0] < height and 0 <= rounded[1] < width
    detail = dict(exact_endpoint_world_xy=np.asarray(point).tolist(),
                  rounded_grid_node_yx=list(rounded),
                  rounded_cell_occupied=bool(occupied[rounded]) if in_grid else None,
                  max_connection_distance_m=MAX_ENDPOINT_CONNECTION,
                  free_candidate_segments_checked=0, connected=False)
    radius = int(np.ceil(MAX_ENDPOINT_CONNECTION/RESOLUTION))+1
    candidates = []
    for y in range(max(0, rounded[0]-radius), min(height, rounded[0]+radius+1)):
        for x in range(max(0, rounded[1]-radius), min(width, rounded[1]+radius+1)):
            if occupied[y, x]:
                continue
            target = origin+RESOLUTION*np.array([x, y])
            distance = float(np.linalg.norm(target-point))
            if distance <= MAX_ENDPOINT_CONNECTION+1e-9:
                candidates.append((distance, (y, x) != rounded, y, x, target))
    candidates.sort(key=lambda candidate: candidate[:4])
    for distance, _, y, x, target in candidates:
        detail['free_candidate_segments_checked'] += 1
        if _segment_clear(point, target, centers, radii):
            detail.update(connected=True, grid_node_yx=[y, x],
                          grid_node_world_xy=target.tolist(), connection_length_m=distance)
            return (y, x), detail
    return None, detail


def _connect_grid_endpoints(start, goal, origin, occupied, centers, radii):
    """Return two read-only grid attachments and explicit failure diagnostics."""
    start_node, start_detail = _endpoint_grid_connection(start, origin, occupied, centers, radii)
    goal_node, goal_detail = _endpoint_grid_connection(goal, origin, occupied, centers, radii)
    reason = ('start_endpoint_has_no_clear_grid_connection' if start_node is None else
              'goal_endpoint_has_no_clear_grid_connection' if goal_node is None else None)
    return start_node, goal_node, dict(start=start_detail, goal=goal_detail), reason


def _simplify(points, centers, radii):
    simplified = [np.asarray(points[0])]
    index = 0
    while index < len(points)-1:
        chosen = None
        for candidate in range(len(points)-1, index, -1):
            if _segment_clear(points[index], points[candidate], centers, radii):
                chosen = candidate
                break
        if chosen is None:
            return None
        simplified.append(np.asarray(points[chosen])); index = chosen
    return simplified


def plan_base_route(obs, robot, goal_xy, *, execution_clearance_m=CLEARANCE):
    """Return measured-world XY waypoints including exact start and goal.

    feasible means a route avoids *observed* inflated obstacles in this bounded
    grid. Unknown cells are traversable but explicitly not certified safe. No
    starting/goal obstacle is cleared to force a plan. execution_clearance_m
    is a finite margin in [0.04, 0.20] m outside the base footprint. Choosing
    a wider margin can avoid severe guard slowdown; it does not guarantee
    execution speed or relax the live guard. Exact clear endpoints may connect
    to an already-free grid node within 10 cm after a continuous sweep check;
    occupied grid cells are never cleared for this connection.
    """
    result = dict(waypoints_world_xy=[], feasible=False, reason='not_planned',
        unknown_space=True, space_is_certified_free=False, route_observation_status='unobserved_route',
        execution_requires_depth_guard=True, grid_resolution_m=RESOLUTION,
        footprint_radius_m=FOOTPRINT_RADIUS, obstacle_clearance_m=None,
        execution_clearance_m=None,
        max_region_side_m=MAX_SIDE, expanded_nodes=0,
        feasibility_basis='bounded route around observed inflated low points and other-base disk only',
        limitation='Unknown cells may hide obstacles; no extended-arm, garment, human or global-route guarantee.')
    try:
        margin = _execution_clearance(execution_clearance_m)
        result.update(obstacle_clearance_m=margin, execution_clearance_m=margin)
        if robot not in (0, 1):
            raise ValueError('robot must be 0 or 1')
        bases = np.asarray(obs['base_pose_world'], dtype=float)
        goal = np.asarray(goal_xy, dtype=float)
        if bases.shape != (2, 7) or not np.isfinite(bases).all() or goal.shape != (2,) or not np.isfinite(goal).all():
            raise ValueError('invalid public base positions or goal')
        start = bases[robot, :2].copy()
        delta = goal-start
        if np.linalg.norm(delta) > MAX_GOAL_DISTANCE or np.max(np.abs(delta)) + 2. > MAX_SIDE:
            return dict(result, reason='goal_outside_bounded_local_planning_range')
        side = max(3., float(np.max(np.abs(delta))) + 2.)
        count = int(np.floor(side/RESOLUTION)) + 1
        origin = (start+goal)/2-side/2
        measured = _depth_obstacle_points(obs, robot)
        points = np.asarray(measured['points'], dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
            raise ValueError('invalid public obstacle point cloud')
        centers = np.vstack((points[:, :2], bases[1-robot, :2]))
        radii = np.r_[np.full(len(points), FOOTPRINT_RADIUS+margin),
                      2*FOOTPRINT_RADIUS+margin]
        result.update(observed_low_point_count=int(len(points)),
            sampled_valid_depth_count=int(measured.get('sampled_valid_count', 0)),
            filtered_self_count=int(measured.get('filtered_self_count', 0)),
            nearest_start_observed_points_world=points[np.argsort(np.linalg.norm(points[:, :2]-start, axis=1))[:8]].tolist(),
            grid_shape=[count, count], region_origin_world_xy=origin.tolist(),
            region_side_m=(count-1)*RESOLUTION)
        near = np.argsort(np.linalg.norm(points[:, :2]-start, axis=1))[:8]
        if 'source_camera_ids' in measured:
            local_points = world_to_base(obs, robot, points[near])
            result['nearest_start_observed_sources'] = [dict(
                world_xyz=points[index].tolist(), own_base_xyz=local_points[i].tolist(),
                camera_index=int(measured['source_camera_ids'][index]),
                pixel_uv=np.asarray(measured['source_pixel_uv'][index]).tolist(),
                optical_depth_m=float(measured['optical_depth_m'][index])) for i, index in enumerate(near)]
        if np.any(np.linalg.norm(centers-start, axis=1) <= radii):
            return dict(result, reason='start_in_observed_collision_rejected')
        if np.any(np.linalg.norm(centers-goal, axis=1) <= radii):
            return dict(result, reason='goal_in_observed_collision_rejected')
        if np.linalg.norm(delta) < 1e-9:
            return dict(result, feasible=True, reason='already_at_goal_unobserved_space',
                        waypoints_world_xy=[start.tolist()], path_length_m=0.)
        occupied = _inflate(origin, (count, count), centers, radii)
        start_node, goal_node, connections, reason = _connect_grid_endpoints(
            start, goal, origin, occupied, centers, radii)
        result['grid_endpoint_connections'] = connections
        if reason is not None:
            return dict(result, reason=reason)
        route, expanded, reason = _astar(occupied, start_node, goal_node)
        result['expanded_nodes'] = expanded
        if route is None:
            return dict(result, reason=reason)
        raw = [start]
        for y, x in route:
            point = origin + RESOLUTION*np.array([x, y])
            if np.linalg.norm(point-raw[-1]) > 1e-8:
                raw.append(point)
        if np.linalg.norm(goal-raw[-1]) > 1e-8:
            raw.append(goal)
        simplified = _simplify(raw, centers, radii)
        if simplified is None or not all(_segment_clear(a, b, centers, radii) for a, b in zip(simplified, simplified[1:])):
            return dict(result, reason='continuous_swept_clearance_check_failed')
        length = sum(float(np.linalg.norm(b-a)) for a, b in zip(simplified, simplified[1:]))
        return dict(result, feasible=True, reason='unobserved_route_avoiding_observed_obstacles',
                    waypoints_world_xy=[p.tolist() for p in simplified], path_length_m=length,
                    raw_grid_path_nodes=len(route), swept_segments_checked=len(simplified)-1)
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason='invalid_planning_input: '+str(error))


def plan_pair_route(obs, desired_shift_xy, *, execution_clearance_m=CLEARANCE):
    """Plan one shared translation of two bases with their offsets held fixed.

    Search takes place in the pair-center configuration space. For base offset
    ``offset[r]``, a measured obstacle at ``point`` forbids pair centers within
    the footprint radius of ``point - offset[r]``. The union of both sets must
    be avoided; independently feasible base routes cannot be combined here.

    This returns candidate waypoints only. It does not move either robot,
    change yaw, widen the grasp pair, protect arms/cloth, or certify visibility.
    The executor must keep the formation and use live public-depth guards.
    execution_clearance_m is a finite margin in [0.04, 0.20] m, applied to
    both observed base sweeps and the required initial pair separation.
    Endpoint-to-grid connections use the same bounded continuous check in
    pair configuration space, so both bases must clear every connection.
    """
    result = dict(pair_center_waypoints_world_xy=[], feasible=False, reason='not_planned',
        unknown_space=True, space_is_certified_free=False, route_observation_status='unobserved_route',
        execution_requires_depth_guard=True, execution_requires_fixed_pair_offsets=True,
        grid_resolution_m=RESOLUTION, footprint_radius_m=FOOTPRINT_RADIUS,
        obstacle_clearance_m=None, execution_clearance_m=None,
        max_region_side_m=MAX_SIDE, expanded_nodes=0,
        feasibility_basis='single shared-translation configuration space for both observed base footprints',
        other_robot_is_fixed_obstacle=False, pair_yaw_changes_allowed=False,
        planning_only=True, self_body_exclusion_radius_m=.20,
        self_body_exclusion_height_m=[.12, .45],
        self_body_exclusion_scope='both robots at measured initial public poses; static visual surfaces and existing narrow neighborhoods; never translated along the route',
        limitation=('Unknown cells may hide obstacles. The depth extractor uses approximate own-robot masks; '
                    'the additional 0.20m low-base neighborhoods can also hide contacting environment points. '
                    'No extended-arm, garment, human, tension, yaw-change or global-route guarantee.'))
    try:
        margin = _execution_clearance(execution_clearance_m)
        result.update(obstacle_clearance_m=margin, execution_clearance_m=margin)
        bases = np.asarray(obs['base_pose_world'], dtype=float)
        shift = np.asarray(desired_shift_xy, dtype=float)
        if bases.shape != (2, 7) or not np.isfinite(bases).all() or shift.shape != (2,) or not np.isfinite(shift).all():
            raise ValueError('invalid public base positions or desired pair shift')
        start = bases[:, :2].mean(axis=0)
        goal = start + shift
        offsets = bases[:, :2] - start
        result.update(initial_pair_center_world_xy=start.tolist(), goal_pair_center_world_xy=goal.tolist(),
                      base_offsets_from_pair_center_world_xy=offsets.tolist(),
                      desired_shift_world_xy=shift.tolist())
        if np.linalg.norm(shift) > MAX_GOAL_DISTANCE or np.max(np.abs(shift)) + 2. > MAX_SIDE:
            return dict(result, reason='goal_outside_bounded_local_planning_range')
        if np.linalg.norm(bases[1, :2]-bases[0, :2]) <= 2*FOOTPRINT_RADIUS+margin:
            return dict(result, reason='initial_pair_footprints_overlap_or_lack_clearance')

        # Each query already uses all four public robot-mounted depth cameras,
        # with the queried robot's existing own-geometry mask. Retain that
        # cloud for its own base sweep. Remove both observed own geometries
        # because the translating companion is not a stationary obstacle.
        # This is specific to fixed-formation transport, not independent routes.
        world_clouds, configuration_points = [], []
        raw_counts, excluded_counts, sampled_counts = [], [], []
        for robot in (0, 1):
            measured = _depth_obstacle_points(obs, robot)
            points = np.asarray(measured['points'], dtype=float)
            if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
                raise ValueError('invalid public obstacle point cloud')
            raw_counts.append(int(len(points)))
            sampled_counts.append(int(measured.get('sampled_valid_count', 0)))
            near_body = np.zeros(len(points), bool)
            for body in (0, 1):
                near_body |= own_geometry_mask(obs, body, points)
            excluded_counts.append(int(np.count_nonzero(near_body)))
            points = points[~near_body]
            world_clouds.append(points[:, :2])
            configuration_points.append(points[:, :2] - offsets[robot])
        centers = np.unique(np.vstack(configuration_points), axis=0)
        radii = np.full(len(centers), FOOTPRINT_RADIUS+margin)
        side = max(3., float(np.max(np.abs(shift))) + 2.)
        count = int(np.floor(side/RESOLUTION)) + 1
        origin = (start+goal)/2-side/2
        result.update(observed_low_point_count_by_robot=raw_counts,
                      retained_obstacle_point_count_by_robot=[len(p) for p in world_clouds],
                      planning_self_body_excluded_count_by_robot=excluded_counts,
                      sampled_valid_depth_count_by_robot=sampled_counts,
                      configuration_obstacle_count=len(centers), grid_shape=[count, count],
                      region_origin_world_xy=origin.tolist(), region_side_m=(count-1)*RESOLUTION)
        # These are genuine configuration-space endpoint checks. Do not clear
        # either footprint or a goal neighborhood to force an A* solution.
        if np.any(np.linalg.norm(centers-start, axis=1) <= radii):
            return dict(result, reason='start_in_observed_collision_rejected')
        if np.any(np.linalg.norm(centers-goal, axis=1) <= radii):
            return dict(result, reason='goal_in_observed_collision_rejected')
        if np.linalg.norm(shift) < 1e-9:
            return dict(result, feasible=True, reason='already_at_goal_unobserved_space',
                        pair_center_waypoints_world_xy=[start.tolist()], path_length_m=0.,
                        swept_base_segments_checked=0)
        occupied = _inflate(origin, (count, count), centers, radii)
        start_node, goal_node, connections, reason = _connect_grid_endpoints(
            start, goal, origin, occupied, centers, radii)
        result['grid_endpoint_connections'] = connections
        if reason is not None:
            return dict(result, reason=reason)
        route, expanded, reason = _astar(occupied, start_node, goal_node)
        result['expanded_nodes'] = expanded
        if route is None:
            return dict(result, reason=reason)
        raw = [start]
        for y, x in route:
            point = origin + RESOLUTION*np.array([x, y])
            if np.linalg.norm(point-raw[-1]) > 1e-8:
                raw.append(point)
        if np.linalg.norm(goal-raw[-1]) > 1e-8:
            raw.append(goal)
        simplified = _simplify(raw, centers, radii)
        if simplified is None:
            return dict(result, reason='continuous_swept_clearance_check_failed')
        # Independently verify the actual two swept base paths after every
        # simplification. No base may take a shortcut across a table corner.
        for robot in (0, 1):
            points = world_clouds[robot]
            clearance = np.full(len(points), FOOTPRINT_RADIUS+margin)
            if not all(_segment_clear(a+offsets[robot], b+offsets[robot], points, clearance)
                       for a, b in zip(simplified, simplified[1:])):
                return dict(result, reason='continuous_pair_base_sweep_check_failed')
        length = sum(float(np.linalg.norm(b-a)) for a, b in zip(simplified, simplified[1:]))
        return dict(result, feasible=True, reason='unobserved_pair_route_avoiding_observed_obstacles',
                    pair_center_waypoints_world_xy=[p.tolist() for p in simplified],
                    path_length_m=length, raw_grid_path_nodes=len(route),
                    swept_base_segments_checked=2*(len(simplified)-1))
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason='invalid_planning_input: '+str(error))


def validate_base_route_segment(obs, robot, start_xy, end_xy, clearance_m=CLEARANCE):
    """Check a proposed shortcut against current observed inflated obstacles.

    Useful before advancing a waypoint while still short of its exact position:
    the new segment may cut a corner even though the original route was clear.
    A feasible result is only a continuous geometric check of this segment,
    not permission to move through unseen space or to disable the live guard.
    This does not validate paired formation motion.
    """
    result = dict(feasible=False, reason='not_checked', unknown_space=True,
        space_is_certified_free=False, execution_requires_depth_guard=True,
        footprint_radius_m=FOOTPRINT_RADIUS, obstacle_clearance_m=None,
        execution_clearance_m=None)
    try:
        margin = _execution_clearance(clearance_m)
        result.update(obstacle_clearance_m=margin, execution_clearance_m=margin)
        if robot not in (0, 1):
            raise ValueError('robot must be 0 or 1')
        bases = np.asarray(obs['base_pose_world'], dtype=float)
        start, end = np.asarray(start_xy, dtype=float), np.asarray(end_xy, dtype=float)
        if (bases.shape != (2, 7) or not np.isfinite(bases).all()
                or start.shape != (2,) or end.shape != (2,)
                or not np.isfinite(start).all() or not np.isfinite(end).all()):
            raise ValueError('invalid public base positions or segment endpoints')
        measured = _depth_obstacle_points(obs, robot)
        points = np.asarray(measured['points'], dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
            raise ValueError('invalid public obstacle point cloud')
        centers = np.vstack((points[:, :2], bases[1-robot, :2]))
        radii = np.r_[np.full(len(points), FOOTPRINT_RADIUS+margin),
                      2*FOOTPRINT_RADIUS+margin]
        clear = _segment_clear(start, end, centers, radii)
        return dict(result, feasible=clear, observed_low_point_count=len(points),
                    reason='segment_avoids_observed_obstacles_unknown_space' if clear
                    else 'segment_in_observed_collision_rejected')
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason='invalid_planning_input: '+str(error))


def validate_pair_route_segment(obs, start_center_xy, end_center_xy, clearance_m=.12):
    """Check one shared translation using the pair's currently measured offsets.

    Each base follows center + its current offset, with no yaw or separation
    change. The measured robot geometries are removed from both public clouds
    exactly as in plan_pair_route, because both travel with the formation.
    A feasible result means only that both continuous swept disks avoid those
    observed obstacles at the requested margin. It neither certifies unseen
    space nor validates arms, cloth, humans, or formation tracking accuracy.
    """
    result = dict(feasible=False, reason='not_checked', unknown_space=True,
        space_is_certified_free=False, execution_requires_depth_guard=True,
        execution_requires_fixed_pair_offsets=True, pair_yaw_changes_allowed=False,
        other_robot_is_fixed_obstacle=False, footprint_radius_m=FOOTPRINT_RADIUS,
        obstacle_clearance_m=None, execution_clearance_m=None,
        limitation='Observed base sweeps only; approximate own-model exclusions can hide contacting points; no arm, cloth, human or free-space guarantee.')
    try:
        margin = _execution_clearance(clearance_m)
        result.update(obstacle_clearance_m=margin, execution_clearance_m=margin)
        bases = np.asarray(obs['base_pose_world'], dtype=float)
        start = np.asarray(start_center_xy, dtype=float)
        end = np.asarray(end_center_xy, dtype=float)
        if (bases.shape != (2, 7) or not np.isfinite(bases).all()
                or start.shape != (2,) or end.shape != (2,)
                or not np.isfinite(start).all() or not np.isfinite(end).all()):
            raise ValueError('invalid public base positions or pair segment endpoints')
        center = bases[:, :2].mean(axis=0)
        offsets = bases[:, :2]-center
        result.update(current_pair_center_world_xy=center.tolist(),
                      base_offsets_from_pair_center_world_xy=offsets.tolist(),
                      segment_start_center_world_xy=start.tolist(),
                      segment_end_center_world_xy=end.tolist())
        if np.linalg.norm(bases[1, :2]-bases[0, :2]) <= 2*FOOTPRINT_RADIUS+margin:
            return dict(result, reason='initial_pair_footprints_overlap_or_lack_clearance')
        raw_counts, retained_counts, excluded_counts, sweeps = [], [], [], []
        for robot in (0, 1):
            measured = _depth_obstacle_points(obs, robot)
            points = np.asarray(measured['points'], dtype=float)
            if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
                raise ValueError('invalid public obstacle point cloud')
            raw_counts.append(int(len(points)))
            near_body = np.zeros(len(points), bool)
            for body in (0, 1):
                near_body |= own_geometry_mask(obs, body, points)
            excluded_counts.append(int(np.count_nonzero(near_body)))
            points = points[~near_body]
            retained_counts.append(int(len(points)))
            sweeps.append(_segment_clear(start+offsets[robot], end+offsets[robot],
                                         points[:, :2], np.full(len(points), FOOTPRINT_RADIUS+margin)))
        clear = all(sweeps)
        return dict(result, feasible=clear, base_sweeps_clear=sweeps,
                    observed_low_point_count_by_robot=raw_counts,
                    retained_obstacle_point_count_by_robot=retained_counts,
                    planning_self_body_excluded_count_by_robot=excluded_counts,
                    swept_base_segments_checked=2,
                    reason='pair_segment_avoids_observed_obstacles_unknown_space' if clear
                    else 'pair_segment_in_observed_collision_rejected')
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason='invalid_planning_input: '+str(error))
