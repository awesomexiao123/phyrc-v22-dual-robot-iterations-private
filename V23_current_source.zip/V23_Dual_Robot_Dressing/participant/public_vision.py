"""Measured RGB-D geometry for the two-robot extension.

Only public observations and fixed robot camera calibration are read.  Blue
fabric and yellow trim are synthetic-scene appearance assumptions, not a trained
garment/sleeve detector. Targets are visible fabric patches, not verified edges
or sleeve openings.
Reachability below is a conservative approach heuristic, not collision checking.
"""
from pathlib import Path
import json

import cv2
import numpy as np
from camera_geometry import pixel_rays


CALIBRATION = json.loads((Path(__file__).parent / "frozen_v22" /
                          "static_calibration.json").read_text())
HEAD = np.asarray(CALIBRATION["base_from_head_optical"], dtype=float)
WRIST = np.asarray(CALIBRATION["grasp_from_wrist_optical"], dtype=float)
CAMERA_NAMES = ("overview", "robot_0_wrist", "robot_1_wrist",
                "robot_0_head", "robot_1_head")


def _rotation(quaternion):
    q = np.asarray(quaternion, dtype=float)
    if q.shape != (4,) or not np.isfinite(q).all() or np.linalg.norm(q) < .5:
        raise ValueError("Invalid public wxyz quaternion")
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def _robot_pose(obs, robot, key="base_pose_world"):
    if robot not in (0, 1):
        raise ValueError("Robot index must be 0 or 1")
    poses = np.asarray(obs[key], dtype=float)
    if poses.shape != (2, 7) or not np.isfinite(poses).all():
        raise ValueError("Invalid public " + key)
    return poses[robot]


def base_to_world(obs, robot, point):
    """Transform one point (3,) or an array (...,3), with wxyz pose ordering."""
    pose = _robot_pose(obs, robot)
    return np.asarray(point, dtype=float) @ _rotation(pose[3:]).T + pose[:3]


def world_to_base(obs, robot, point):
    pose = _robot_pose(obs, robot)
    return (np.asarray(point, dtype=float) - pose[:3]) @ _rotation(pose[3:])


def grasp_world(obs, robot):
    return base_to_world(obs, robot, _robot_pose(obs, robot, "grasp_pose_base")[:3])


def _fabric_mask(rgb):
    color = np.asarray(rgb, dtype=np.float32)
    red, green, blue = color.transpose(2, 0, 1)
    cloth = (blue > 1.25*red) & (blue > 1.25*green) & (blue > 100)
    trim = ((red > 110) & (green > 90) &
            (blue < .70*np.minimum(red, green)) &
            (np.maximum(red, green) < 2.2*np.maximum(np.minimum(red, green), 1)))
    # Yellow is accepted only where a local blue fabric component supports it;
    # unrelated yellow furniture/markers do not become candidate fabric.
    near_blue = cv2.dilate(cloth.astype(np.uint8), np.ones((7, 7), np.uint8)) > 0
    combined = cloth | (trim & near_blue)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        combined.astype(np.uint8), connectivity=8)
    keep = np.zeros(combined.shape, dtype=bool)
    for component in range(1, count):
        if stats[component, cv2.CC_STAT_AREA] < 12:
            continue
        region = labels == component
        if np.count_nonzero(region & cloth) >= 8:
            keep |= region
    return keep


def cloth_cloud(obs, cameras=None):
    """Return fabric world_points (N,3), camera_ids (N,), and rgb (N,3).

    Default cameras are both heads and wrists.  The overview camera has a
    randomized scene-relative mount and is intentionally unsupported: its world
    transform cannot be recovered from the public robot state alone.
    """
    rgb = np.asarray(obs["rgb"])
    depth = np.asarray(obs["depth"])
    valid = np.asarray(obs["depth_valid"])
    if rgb.ndim != 4 or rgb.shape[0] != 5 or rgb.shape[-1] != 3:
        raise ValueError("Expected five public RGB camera images")
    if depth.shape != (*rgb.shape[:3], 1) or valid.shape != depth.shape:
        raise ValueError("Expected matching depth and depth_valid images")
    if rgb.dtype != np.uint8 or valid.dtype != bool:
        raise ValueError("Expected uint8 RGB and boolean depth validity")
    selected = (3, 4, 1, 2) if cameras is None else tuple(cameras)
    points, camera_ids, colors = [], [], []
    height, width = rgb.shape[1:3]
    focal = width / (2*np.tan(np.deg2rad(CALIBRATION["fov_degrees"]/2)))
    for camera in selected:
        if isinstance(camera, str):
            if camera not in CAMERA_NAMES:
                raise ValueError("Unknown public camera: " + camera)
            camera = CAMERA_NAMES.index(camera)
        if camera not in (1, 2, 3, 4):
            raise ValueError("Only robot-mounted cameras have known static extrinsics")
        z = depth[camera, ..., 0]
        mask = (_fabric_mask(rgb[camera]) & valid[camera, ..., 0] &
                np.isfinite(z) & (z > .03) & (z < (3. if camera < 3 else 5.)))
        v, u = np.where(mask)
        if len(v) == 0:
            continue
        optical = pixel_rays(u, v, focal, width, height)*z[v, u, None]
        robot = camera-3 if camera >= 3 else camera-1
        if camera >= 3:
            base = optical @ HEAD[:3, :3].T + HEAD[:3, 3]
        else:
            grasp = optical @ WRIST[:3, :3].T + WRIST[:3, 3]
            pose = _robot_pose(obs, robot, "grasp_pose_base")
            base = grasp @ _rotation(pose[3:]).T + pose[:3]
        world = base_to_world(obs, robot, base)
        finite = np.isfinite(world).all(axis=1)
        points.append(world[finite])
        camera_ids.append(np.full(np.count_nonzero(finite), camera, dtype=np.int8))
        colors.append(rgb[camera, v[finite], u[finite]])
    if not points:
        return dict(world_points=np.empty((0, 3), dtype=float),
                    camera_ids=np.empty(0, dtype=np.int8),
                    rgb=np.empty((0, 3), dtype=np.uint8))
    return dict(world_points=np.concatenate(points), camera_ids=np.concatenate(camera_ids),
                rgb=np.concatenate(colors))


def _supported_patch(points, ids, seed, active, helper, *, recenter=True):
    """Require dense pixels in one external view or agreeing separate views."""
    target = np.asarray(seed)
    accepted = None
    # Recompute support after centring: a seed at an isolated extremity must
    # not borrow a distant patch then report its original unsupported point.
    for _ in range(2):
        near = np.linalg.norm(points-target, axis=1) < .045
        if np.count_nonzero(near) < 24:
            return None
        counts = {int(camera): int(np.count_nonzero(near & (ids == camera)))
                  for camera in np.unique(ids[near])}
        helper_head = 3+helper
        if counts.get(helper_head, 0) >= 24:
            used, priority, basis = [helper_head], 0, 'dense_helper_head_view'
        else:
            # Several pixels in one camera are not independent views. Require
            # at least 12 measured pixels per camera and agreement of the local
            # 3D medians, rather than merely adding two unrelated counts.
            views = [camera for camera, count in counts.items() if count >= 12]
            medians = {camera: np.median(points[near & (ids == camera)], axis=0) for camera in views}
            pairs = [(a, b) for i, a in enumerate(views) for b in views[i+1:]
                     if np.linalg.norm(medians[a]-medians[b]) <= .035]
            if pairs:
                used = list(max(pairs, key=lambda pair: counts[pair[0]]+counts[pair[1]]))
                priority, basis = 1, 'agreeing_multiple_camera_patches'
            elif counts.get(3+active, 0) >= 48:
                used, priority, basis = [3+active], 2, 'dense_active_head_fallback'
            else:
                return None
        supported = near & np.isin(ids, used)
        measured = points[supported]
        if recenter:
            center = np.median(measured, axis=0)
            # New proposals may use robust centring. Tracked patches must NOT:
            # repeated centring acts as mean-shift up a pixel-density gradient,
            # even when the cloth and cameras are perfectly stationary.
            target = measured[np.argmin(np.linalg.norm(measured-center, axis=1))]
        accepted = dict(target=target, priority=priority, support_basis=basis,
                        source_cameras=sorted(used), local_support_count=int(len(measured)),
                        support_by_camera={str(camera): counts[camera] for camera in used},
                        total_nearby_pixels=int(np.count_nonzero(near)))
    # The accepted coordinate is the final snapped measured point. Audit the
    # counts around that exact coordinate, not around its previous median.
    near = np.linalg.norm(points-target, axis=1) < .045
    used = accepted['source_cameras']
    counts = {camera: int(np.count_nonzero(near & (ids == camera))) for camera in used}
    required = 24 if accepted['priority'] == 0 else 12 if accepted['priority'] == 1 else 48
    if min(counts.values()) < required:
        return None
    if len(used) > 1:
        centers = [np.median(points[near & (ids == camera)], axis=0) for camera in used]
        if np.linalg.norm(centers[0]-centers[1]) > .035:
            return None
    accepted.update(local_support_count=sum(counts.values()),
                    support_by_camera={str(camera): count for camera, count in counts.items()},
                    total_nearby_pixels=int(np.count_nonzero(near)))
    return accepted


def _patch_seeds(points, ids, helper, active_point):
    """Nominate dense spatial cells, with a bounded cost per policy call."""
    _, inverse, counts = np.unique(np.floor(points/.025).astype(np.int32), axis=0,
                                   return_inverse=True, return_counts=True)
    centers = np.zeros((len(counts), 3))
    np.add.at(centers, inverse, points)
    centers /= counts[:, None]
    if len(centers) <= 72:
        return centers
    helper_counts = np.bincount(inverse[ids == 3+helper], minlength=len(counts))
    geometry = np.minimum(np.linalg.norm(centers-active_point, axis=1), .5)
    # Spatial cells are only proposals. Full pixel-level support around each
    # proposal is checked separately; no isolated maximum is accepted directly.
    selected = np.unique(np.r_[np.argsort(helper_counts)[-24:],
                               np.argsort(counts)[-24:], np.argsort(geometry)[-24:]])
    return centers[selected]


def helper_grasp_target(obs, active, helper, previous=None):
    """Choose a supported fabric point separated from the active held point.

    The helper may rotate/translate to approach: requiring current arm reach
    would reject the scene before navigation starts.  The filter admits public
    base-frame height .20--1.45 m and <=3 m horizontal approach distance.
    Physical assumption: this function is called after the active robot has
    settled a lifted garment under gravity. Fabric more than 5 cm ABOVE the
    active grasp is excluded as an implausible hanging patch. This is relative
    to measured grasp height, never a fixed scene coordinate.

    Each point is one valid source image pixel. Require >=24 local pixels from
    the helper head, or two agreeing views with >=12 pixels each. A single active
    head fallback needs >=48. These are support heuristics for the public
    256x256 observations, not calibrated probabilities or mesh-node counts.
    A previous target must retain the same support; loss does not silently jump.
    Tracking uses the nearest measured point, without median re-centring, with
    at most 1.5 cm correction per observation. Pass the previous FULL RESULT
    dict to preserve tracking_anchor_world and bound total displacement to 3 cm.
    A bare previous point is supported for compatibility but cannot encode an
    earlier anchor; it must not be used to claim a cumulative displacement bound.
    """
    if active not in (0, 1) or helper != 1-active:
        raise ValueError("Active/helper must be different fixed robot indices")
    previous_point = anchor = None
    if isinstance(previous, dict):
        previous_point = previous.get('target_world')
        if previous_point is None:
            previous_point = previous.get('last_valid_target_world')
        anchor = previous.get('tracking_anchor_world')
        if previous_point is None:
            previous_point = anchor
    elif previous is not None:
        previous_point = previous
    if previous_point is not None:
        previous_point = np.asarray(previous_point, dtype=float)
        anchor = previous_point.copy() if anchor is None else np.asarray(anchor, dtype=float)
        if previous_point.shape != (3,) or anchor.shape != (3,) or not np.isfinite(np.r_[previous_point, anchor]).all():
            raise ValueError('Invalid previous public vision target or anchor')
    cloud = cloth_cloud(obs)
    points = cloud["world_points"]
    result = dict(target_world=None, confidence=0., visible_count=int(len(points)),
                  source_cameras=[], reason="no_visible_fabric")
    if previous_point is not None:
        # Retain the anchor even on abstention. A subsequent call with this
        # result may reacquire this patch, but cannot silently select a new one.
        result.update(tracking_anchor_world=anchor.tolist(), last_valid_target_world=previous_point.tolist())
    if len(points) < 24:
        return result
    active_point = grasp_world(obs, active)
    local = world_to_base(obs, helper, points)
    separation = np.linalg.norm(points-active_point, axis=1)
    distance = np.linalg.norm(local[:, :2], axis=1)
    eligible = ((separation >= .18) & (separation <= 1.15) &
                (local[:, 2] >= .20) & (local[:, 2] <= 1.45) & (distance <= 3.) &
                (points[:, 2] <= active_point[2]+.05))
    result['excluded_above_held_grasp_pixels'] = int(np.count_nonzero(points[:, 2] > active_point[2]+.05))
    if np.count_nonzero(eligible) < 24:
        result["reason"] = "no_separated_approach_candidate"
        return result
    candidate = points[eligible]
    ids = cloud["camera_ids"][eligible]
    selected_patch = None
    if previous_point is not None:
        difference = np.linalg.norm(candidate-previous_point, axis=1)
        within_anchor = np.linalg.norm(candidate-anchor, axis=1) <= .03+1e-9
        allowed = np.flatnonzero(within_anchor & (difference <= .015+1e-9))
        if not len(allowed):
            result['reason'] = 'previous_fabric_patch_not_visible'
            return result
        nearest = int(allowed[np.argmin(difference[allowed])])
        selected_patch = _supported_patch(candidate, ids, candidate[nearest], active, helper, recenter=False)
        if selected_patch is None:
            result['reason'] = 'insufficient_local_fabric_support'
            return result
    if selected_patch is None:
        possibilities = []
        for seed in _patch_seeds(candidate, ids, helper, active_point):
            supported = _supported_patch(candidate, ids, seed, active, helper)
            if supported is None:
                continue
            p = supported['target']
            p_local = world_to_base(obs, helper, p)
            score = (.35*min(float(np.linalg.norm(p-active_point)), .50)
                     -.15*np.linalg.norm(p_local[:2]) + .10*p_local[2]
                     +.05*min(supported['local_support_count']/100., 1.))
            possibilities.append((supported['priority'], -float(score), supported))
        if possibilities:
            selected_patch = min(possibilities, key=lambda item: item[:2])[2]
    if selected_patch is None:
        result["reason"] = "insufficient_local_fabric_support"
        return result
    target = selected_patch['target']
    if anchor is None:
        anchor = target.copy()
    source = selected_patch['source_cameras']
    confidence = ((.72, .80, .48)[selected_patch['priority']]
                  +.10*min(selected_patch['local_support_count']/100., 1.))
    result.update(target_world=target.tolist(), confidence=float(confidence),
                  source_cameras=source, reason="visible_fabric_surface_patch",
                  helper_local=world_to_base(obs, helper, target).tolist(),
                  active_separation_m=float(np.linalg.norm(target-active_point)),
                  local_support_count=selected_patch['local_support_count'],
                  support_by_camera=selected_patch['support_by_camera'],
                  support_basis=selected_patch['support_basis'],
                  confidence_is_heuristic=True, is_verified_edge=False,
                  tracking_anchor_world=anchor.tolist(), last_valid_target_world=target.tolist(),
                  tracking_anchor_displacement_m=float(np.linalg.norm(target-anchor)),
                  tracking_observation_correction_m=0. if previous_point is None else float(np.linalg.norm(target-previous_point)),
                  tracking_limits_m={'per_observation': .015, 'from_preserved_anchor': .03},
                  hanging_height_assumption='settled garment under gravity; no patch >5cm above active grasp',
                  reachability="bounded_approach_candidate_not_collision_checked")
    return result
