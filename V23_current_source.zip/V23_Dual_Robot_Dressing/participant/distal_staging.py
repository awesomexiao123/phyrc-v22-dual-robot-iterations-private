"""Infer a 3D waiting midpoint distal to observed hand surface directions.

This is a public-observation staging hypothesis, not an insertion axis, sleeve
target, whole-body clearance check or motion executor. A unique single-view
surface axis may support the hypothesis, but remains explicitly weak evidence.
"""
import numpy as np


def _point(value, name):
    point = np.asarray(value, dtype=float)
    if point.shape != (3,) or not np.isfinite(point).all():
        raise ValueError('invalid_'+name)
    return point


def _unit(value, name):
    vector = _point(value, name)
    norm = float(np.linalg.norm(vector))
    if norm < .5:
        raise ValueError('invalid_'+name)
    return vector/norm


def _hand_axis(report, hand, index):
    if report.get('hand_index') != index:
        raise ValueError('forearm_hand_index_mismatch')
    if np.linalg.norm(_point(report.get('hand_surface_world'), 'forearm_hand_point')-hand) > .02:
        raise ValueError('forearm_surface_is_not_bound_to_current_hand_point')
    if report.get('conflicting_pairs'):
        raise ValueError('conflicting_views_for_hand_surface_axis')
    if report.get('axis_sign') != 'hand_surface_toward_visible_proximal_surface':
        raise ValueError('surface_axis_has_no_observed_proximal_sign')
    views = report.get('candidate_views', [])
    status = report.get('status')
    if status == 'single_view_candidate' and len(views) == 1:
        axis = _unit(views[0].get('axis_world'), 'single_view_surface_axis')
        weak = True
    elif status == 'multi_view_consistent_candidate' and len(views) >= 2 and report.get('supporting_parallax_pairs'):
        axis = _unit(report.get('axis_world'), 'multi_view_surface_axis')
        weak = False
    else:
        raise ValueError('no_unique_single_view_or_consistent_multi_view_surface_axis')
    cameras = []
    for view in views:
        camera = view.get('camera_index')
        if camera not in (1, 2, 3, 4) or view.get('hand_index') != index:
            raise ValueError('surface_view_is_not_from_matching_public_robot_camera')
        if view.get('axis_sign') != 'measured_hand_toward_one_sided_visible_proximal_surface':
            raise ValueError('surface_view_axis_sign_is_unknown')
        view_axis = _unit(view.get('axis_world'), 'view_surface_axis')
        if float(axis @ view_axis) < np.cos(np.deg2rad(15.)):
            raise ValueError('surface_view_axes_disagree_with_reported_direction')
        # The sign must also point toward an actual reported visible surface
        # support point. Never choose the sign from the robot/camera position.
        proximal = _point(view.get('proximal_observed_surface_point_world'), 'proximal_surface_support')
        if float((proximal-hand) @ view_axis) <= .025:
            raise ValueError('axis_sign_is_not_supported_by_proximal_surface_point')
        cameras.append(camera)
    if len(set(cameras)) != len(cameras):
        raise ValueError('duplicate_camera_views_do_not_establish_independent_support')
    return axis, dict(hand_index=index, status=status, weak_single_view=weak,
        camera_indices=cameras, signed_axis_world=axis.tolist(),
        evidence_scope='visible surface elongation only; not verified anatomy')


def plan_distal_staging(obs, hand_report, forearm_report, *, hand_observation_time_s=None,
                       distance_m=.30, max_age_s=5., stationary_human=False):
    """Return an inferred target midpoint or unknown, without action commands.

    The timestamp on hand_report is used when present; otherwise pass the
    parent's separate public hand-cache timestamp. The forearm report needs its
    own observation_time_s. Both must be within 0.1 s of one another. The default
    age is 5 s and ordinary mode is bounded to 30 s. Explicit stationary_human
    mode permits a caller-requested age up to 300 s, under the caller's assumption
    that the human has remained stationary before approach/contact. It does not
    verify that assumption or refresh either timestamp.
    The exact .30 m default offset is applied in full 3D to the hands' midpoint.
    If that midpoint is less than the requested distance from either observed
    hand point, abstain rather than silently lengthen or flatten the offset.
    This point clearance does not cover actual grip spacing, hidden hand/body
    surfaces, held cloth, arms or the route to the waiting position.
    """
    result = dict(status='unknown', available=False, reason=None,
        target_grasp_midpoint_world=None, hand_midpoint_world=None,
        common_proximal_surface_axis_world=None, common_distal_direction_world=None,
        distal_offset_world=None, axis_disagreement_degrees=None,
        contains_weak_single_view_evidence=False, per_hand_axis_evidence=[],
        target_midpoint_distances_to_observed_hands_m=None,
        stationary_human_assumption_declared=stationary_human is True,
        stationary_human_assumption=('caller declares human unchanged before approach/contact; not verified by this planner'
                                     if stationary_human is True else None),
        stationary_human_cache_used=False, maximum_observation_age_s=float(max_age_s),
        nominal_distal_offset_m=float(distance_m), observed_hand_point_clearance_only=True,
        insertion_allowed=False, sleeve_openings_verified=False, motion_executor_included=False,
        full_body_or_garment_swept_clearance_verified=False,
        scope='inferred distal waiting midpoint; not an insertion or sleeve target')
    try:
        if not isinstance(stationary_human, bool):
            raise ValueError('stationary_human_requires_explicit_boolean_declaration')
        if not np.isfinite([distance_m, max_age_s]).all() or not .30 <= distance_m <= .40 or not 0 < max_age_s <= 300.:
            raise ValueError('invalid_bounded_staging_distance_or_observation_age')
        if max_age_s > 30. and not stationary_human:
            raise ValueError('extended_cache_requires_explicit_stationary_human_assumption')
        now = float(np.asarray(obs['simulation_time_s']).item())
        recorded_hand_time = hand_report.get('observation_time_s')
        if recorded_hand_time is not None and hand_observation_time_s is not None:
            if abs(float(recorded_hand_time)-float(hand_observation_time_s)) > 1e-7:
                raise ValueError('hand_timestamp_sources_disagree')
        hand_time = recorded_hand_time if recorded_hand_time is not None else hand_observation_time_s
        axis_time = forearm_report.get('observation_time_s')
        if hand_time is None or axis_time is None:
            raise ValueError('public_hand_and_surface_observation_times_required')
        hand_time, axis_time = float(hand_time), float(axis_time)
        if not np.isfinite([now, hand_time, axis_time]).all():
            raise ValueError('invalid_public_observation_time')
        ages = np.array([now-hand_time, now-axis_time])
        result['observation_age_s'] = dict(hands=float(ages[0]), surfaces=float(ages[1]))
        result['source_observation_time_s'] = dict(hands=hand_time, surfaces=axis_time)
        result['stationary_human_cache_used'] = bool(stationary_human and np.max(ages) > 30.)
        if np.any(ages < -1e-7) or np.any(ages > max_age_s):
            raise ValueError('hand_or_surface_report_is_stale_or_from_future')
        if abs(hand_time-axis_time) > .1+1e-7:
            raise ValueError('hand_and_surface_reports_are_not_from_matching_observation')
        hands = np.asarray(hand_report.get('hand_points_world'), dtype=float)
        if not hand_report.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all():
            raise ValueError('two_public_hand_surface_points_required')
        if not .06 <= np.linalg.norm(hands[1]-hands[0]) <= 1.2:
            raise ValueError('ambiguous_or_implausible_observed_hand_pair')
        reports = forearm_report.get('hand_surfaces', [])
        if len(reports) != 2:
            raise ValueError('two_hand_bound_surface_reports_required')
        axes, evidence = zip(*[_hand_axis(reports[i], hands[i], i) for i in (0, 1)])
        dot = float(np.clip(axes[0] @ axes[1], -1., 1.))
        angle = float(np.rad2deg(np.arccos(dot)))
        result['axis_disagreement_degrees'] = angle
        result['per_hand_axis_evidence'] = list(evidence)
        weak = any(item['weak_single_view'] for item in evidence)
        result['contains_weak_single_view_evidence'] = weak
        if angle > 20.:
            raise ValueError('two_signed_proximal_surface_axes_disagree')
        mean_axis = _unit(axes[0]+axes[1], 'common_signed_surface_axis')
        midpoint = hands.mean(axis=0)
        offset = -float(distance_m)*mean_axis
        target = midpoint+offset
        clearances = np.linalg.norm(hands-target, axis=1)
        result['target_midpoint_distances_to_observed_hands_m'] = clearances.tolist()
        if np.min(clearances) < distance_m-1e-8:
            raise ValueError('nominal_distal_midpoint_would_reduce_observed_hand_clearance')
        return dict(result, status='inferred_distal_staging_target', available=True,
            reason=('agreed_signed_surface_axes_with_explicit_single_view_hypothesis' if weak else
                    'agreed_signed_multi_view_surface_candidates'),
            hand_midpoint_world=midpoint.tolist(), target_grasp_midpoint_world=target.tolist(),
            common_proximal_surface_axis_world=mean_axis.tolist(),
            common_distal_direction_world=(-mean_axis).tolist(), distal_offset_world=offset.tolist(),
            evidence_strength='includes_unique_single_view_hypothesis' if weak else 'multi_view_candidates_for_both_hands')
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason=str(error))


def constrain_staging_to_lift_reach(obs, proposal, hands, margin_m=.015):
    """Adjust a waiting midpoint to the common lift range, without moving robots.

    ``hands`` is the original public hand report or its two world points. The
    input proposal must have passed plan_distal_staging. Lift limits are static
    own-robot joint limits, not human/garment state. The calculation holds wrist,
    arm, base height and attitude fixed and preserves the two grasps' initial
    height difference. It constrains vertical reach only; planar reach, route,
    cloth clearance and continued grasp attachment still need separate checks.

    If Z is clamped, extend the existing horizontal distal bearing to retain the
    proposal's nominal distance from the measured hand midpoint. This changes
    the inferred distal-axis direction and is ONLY a reachable-height waiting
    hypothesis, never an insertion-aligned target. No missing bearing is invented.
    """
    result = dict(proposal) if isinstance(proposal, dict) else {}
    result.update(available=False, status='unknown', reason=None,
        target_grasp_midpoint_world=None, original_target_grasp_midpoint_world=None,
        reach_adjusted=False, inferred_axis_deviation_degrees=None,
        reachable_midpoint_z_interval_m=None, per_robot_lift_reach=[],
        lift_joint_limits_m=[0., 1.2], lift_joint_position_index=3,
        own_joint_limit_source='static own Stretch USD /stretch/joints/lift_joint; validation/wrist_contact_review.json wrist_dependent_reach_audit',
        lift_reach_assumptions=[
            'fixed wrist, arm, base height and base attitude during lift',
            'both grasps receive the same world-Z shift; initial height difference is preserved',
            'own lift joint nominal range is 0 to 1.2 m; margin is in joint metres',
            'only vertical joint reach is checked; planar motion needs its own guarded route'],
        insertion_aligned=False, insertion_allowed=False,
        full_body_or_garment_swept_clearance_verified=False,
        scope='reachable-height waiting midpoint hypothesis; not insertion alignment or clearance certification')
    try:
        from public_vision import _rotation, grasp_world
        if not isinstance(proposal, dict) or proposal.get('available') is not True:
            raise ValueError('an_available_public_distal_staging_proposal_is_required')
        margin = float(margin_m)
        if not np.isfinite(margin) or not 0. <= margin < .60:
            raise ValueError('invalid_lift_joint_margin')
        result['lift_joint_margin_m'] = margin
        safe_limits = np.array([margin, 1.2-margin])
        result['safe_lift_joint_interval_m'] = safe_limits.tolist()
        original = _point(proposal.get('target_grasp_midpoint_world'), 'proposed_midpoint')
        result['original_target_grasp_midpoint_world'] = original.tolist()
        hand_points = np.asarray(hands.get('hand_points_world') if isinstance(hands, dict) else hands, dtype=float)
        if (isinstance(hands, dict) and not hands.get('detected')) or hand_points.shape != (2, 3) or not np.isfinite(hand_points).all():
            raise ValueError('two_public_hand_surface_points_required_for_reach_adjustment')
        if not .06 <= np.linalg.norm(hand_points[1]-hand_points[0]) <= 1.2:
            raise ValueError('ambiguous_or_implausible_observed_hand_pair')
        hand_mid = hand_points.mean(axis=0)
        if np.linalg.norm(hand_mid-_point(proposal.get('hand_midpoint_world'), 'proposal_hand_midpoint')) > 1e-4:
            raise ValueError('reach_adjustment_hands_do_not_match_proposal_midpoint')
        distance = float(proposal.get('nominal_distal_offset_m'))
        if not np.isfinite(distance) or not .30 <= distance <= .40:
            raise ValueError('invalid_nominal_distal_offset')
        original_offset = original-hand_mid
        if abs(np.linalg.norm(original_offset)-distance) > 1e-5:
            raise ValueError('proposal_does_not_preserve_its_nominal_distal_offset')
        horizontal_length = float(np.linalg.norm(original_offset[:2]))
        if horizontal_length < 1e-6:
            raise ValueError('no_observed_horizontal_distal_bearing_for_reach_adjustment')
        base = np.asarray(obs['base_pose_world'], dtype=float)
        joints = np.asarray(obs['joint_position'], dtype=float)
        if base.shape != (2, 7) or joints.shape != (2, 13) or not np.isfinite(base).all() or not np.isfinite(joints).all():
            raise ValueError('invalid_public_own_base_or_joint_positions')
        rotations = np.asarray([_rotation(pose[3:]) for pose in base])
        rzz = rotations[:, 2, 2]
        if np.any(rzz < np.cos(.065)):
            raise ValueError('base_tilt_outside_local_transport_assumption')
        q = joints[:, 3]
        if np.any(q < -1e-6) or np.any(q > 1.2+1e-6):
            raise ValueError('current_lift_joint_outside_verified_nominal_range')
        grasps = np.asarray([grasp_world(obs, robot) for robot in (0, 1)])
        current_mid = grasps.mean(axis=0)
        shifts = rzz[:, None]*(safe_limits[None, :]-q[:, None])
        lower, upper = float(shifts[:, 0].max()), float(shifts[:, 1].min())
        for robot in (0, 1):
            result['per_robot_lift_reach'].append(dict(robot_index=robot,
                current_joint_lift_m=float(q[robot]), base_rotation_zz=float(rzz[robot]),
                current_grasp_world=grasps[robot].tolist(),
                allowable_common_world_z_shift_m=shifts[robot].tolist(),
                reachable_grasp_z_interval_m=(grasps[robot, 2]+shifts[robot]).tolist()))
        if lower > upper+1e-9:
            raise ValueError('no_common_vertical_shift_with_both_lift_joint_margins')
        z_interval = current_mid[2]+np.array([lower, upper])
        result['reachable_midpoint_z_interval_m'] = z_interval.tolist()
        adjusted = original.copy()
        adjusted[2] = np.clip(original[2], *z_interval)
        changed = abs(adjusted[2]-original[2]) > 1e-10
        dz = float(adjusted[2]-hand_mid[2])
        if abs(dz) > distance+1e-9:
            raise ValueError('reachable_height_cannot_preserve_nominal_hand_midpoint_offset')
        if changed:
            adjusted[:2] = hand_mid[:2]+original_offset[:2]/horizontal_length*np.sqrt(max(0., distance**2-dz**2))
        offset = adjusted-hand_mid
        clearances = np.linalg.norm(hand_points-adjusted, axis=1)
        result['target_midpoint_distances_to_observed_hands_m'] = clearances.tolist()
        if np.min(clearances) < .30-1e-8:
            raise ValueError('reachable_waiting_midpoint_has_less_than_30cm_observed_hand_clearance')
        shift_z = float(adjusted[2]-current_mid[2])
        predicted_lifts = q+shift_z/rzz
        deviation = float(np.rad2deg(np.arccos(np.clip(original_offset @ offset/distance**2, -1., 1.))))
        result.update(available=True, status='inferred_lift_reachable_waiting_target',
            reason='height_clamped_with_existing_distal_bearing' if changed else 'original_waiting_height_within_both_lift_limits',
            target_grasp_midpoint_world=adjusted.tolist(), distal_offset_world=offset.tolist(),
            surface_inferred_distal_direction_world=(original_offset/distance).tolist(),
            common_distal_direction_world=(offset/distance).tolist(),
            waiting_direction_world=(offset/distance).tolist(), reach_adjusted=changed,
            inferred_axis_deviation_degrees=deviation,
            selected_common_world_z_shift_m=shift_z, predicted_lift_joint_positions_m=predicted_lifts.tolist(),
            reach_observation_time_s=float(np.asarray(obs['simulation_time_s']).item()))
        if not np.isfinite(result['reach_observation_time_s']):
            raise ValueError('invalid_public_reach_observation_time')
        return result
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, available=False, status='unknown', target_grasp_midpoint_world=None, reason=str(error))
