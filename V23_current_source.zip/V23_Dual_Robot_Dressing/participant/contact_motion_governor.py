"""Public-state rate/target-lag gate for an experimental contact coordinator.

Only base XY, lift and telescoping arm translation are admitted. This module
does not plan motion or check skin, cloth, environment, full-body geometry or
path budgets. The caller must check those for both proposed and cancellation
actions, preserve one instance, and pause its upstream reference on holds.
An integrated position target is not cancelled by a zero velocity action.

Physical scales are the published local default profile: base .616 m/s, lift
1.54 m/s, arm 1.21 m/s; 20 Hz public actions. Runtime overrides are unsupported.
All tolerance/rate/rest gates below are engineering limits, not guarantees of
actuator braking or person-contact safety. Failure with unresolved_target_lag
requires the caller to end the simulation; returning zeros is not a stop proof.
"""
import numpy as np

from public_vision import _rotation


class ContactMotionGovernor:
    DT = .05
    SCALES = np.array([.616, .616, 1.54, 1.21])
    COLUMNS = [0, 1, 3, 4]
    TARGET_LEAD = .0003
    MAX_CANCEL_EXCURSION = .00075
    MAX_BASE_REFERENCE_LEAD = .00075
    SETTLED_LAG = .000025
    SETTLED_SPEED = .0002
    SETTLE_SECONDS = .20
    CANCEL_SECONDS = 1.5
    STALL_SECONDS = 3.
    LIFT_LIMITS = (.005, 1.195)
    ARM_LIMITS = (.005, .515)
    WRIST_LIMITS = np.deg2rad([[-65.03070831298828, 244.99673461914062],
                              [-244.99673461914062, 65.03070831298828],
                              [-65.03070831298828, 244.99673461914062]])

    def __init__(self, obs):
        self.failure = None; self.pending_failure = None
        self.mode = 'handoff'; self.stable = 0.; self.calls = 0
        self.debug = {}; self.base_reference = None
        self.time0 = self.last_time = None; self.cancel_since = None
        self.last_progress = None; self.progress_reference = None
        self.progress_base_reference = None
        self.fixed_q = self.fixed_targets = self.base_rotations0 = None
        self.last_grasps = None
        try:
            state = self._read(obs)
            self.time0 = self.last_time = self.cancel_since = state['time']
            self.last_progress = np.full(2, state['time'])
            self.fixed_q = state['q'][:, 8:11].copy()
            self.fixed_targets = state['target'][:, 2:5].copy()
            self.base_rotations0 = state['rotations'].copy()
            self.base_reference = state['base'][:, :2].copy()
            self.last_grasps = self.progress_reference = state['grasps'].copy()
            self.progress_base_reference = state['base'][:, :2].copy()
            self._validate(state, .01, handoff=True)
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.failure = 'invalid_governor_initial_state: '+str(error)
            self.debug['unresolved_target_lag'] = True

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), dtype=np.float32); action[:, 8] = 1.
        return action

    @staticmethod
    def _read(obs):
        values = {}
        for name, shape in (('joint_position', (2, 13)), ('joint_velocity', (2, 13)),
                            ('controller_target', (2, 9)), ('base_pose_world', (2, 7)),
                            ('grasp_pose_base', (2, 7)), ('base_twist_world', (2, 6))):
            value = np.asarray(obs[name], float)
            if value.shape != shape or not np.isfinite(value).all():
                raise ValueError('finite_public_'+name+'_required')
            values[name] = value
        clock = np.asarray(obs['simulation_time_s'], float)
        if clock.size != 1 or not np.isfinite(clock).all():
            raise ValueError('finite_public_clock_required')
        closed = np.asarray(obs['gripper_close_command'])
        if closed.shape not in ((2,), (2, 1)) or closed.dtype != np.bool_ or not closed.all():
            raise ValueError('both_public_closed_gripper_intents_required')
        q, qd, t = (values[k] for k in ('joint_position', 'joint_velocity', 'controller_target'))
        base = values['base_pose_world']; grasp = values['grasp_pose_base']
        if any(np.max(np.abs(np.linalg.norm(value[:, 3:], axis=1)-1.)) > .01 for value in (base, grasp)):
            raise ValueError('invalid_public_pose_quaternion_norm')
        rotations = np.array([_rotation(x[3:]) for x in base])
        grasps = np.array([rotations[r] @ grasp[r, :3]+base[r, :3] for r in (0, 1)])
        # Official drive projects forward onto the floor; left is perpendicular
        # to that projected heading (action column1 reverses backend strafe).
        forward = rotations[:, :2, 0].copy()
        forward /= np.maximum(np.linalg.norm(forward, axis=1), 1e-12)[:, None]
        planar = np.stack((forward, np.column_stack((-forward[:, 1], forward[:, 0]))), axis=2)
        twist = values['base_twist_world']
        linear_velocity = np.column_stack((qd[:, 3], qd[:, 4:8].sum(1)))
        endpoint_velocity = (twist[:, :3]+np.cross(twist[:, 3:], grasps-base[:, :3])
            + rotations[:, :, 2]*linear_velocity[:, :1]
            + rotations[:, :, 0]*linear_velocity[:, 1:2])
        wrist_lag = t[:, 2:5]-q[:, 8:11]
        arm_stage_lag = t[:, 1, None]/4-q[:, 4:8]
        lag = np.column_stack((t[:, 0]-q[:, 3], t[:, 1]-q[:, 4:8].sum(1)))
        pending = np.abs(lag[:, 0])+np.abs(arm_stage_lag).sum(1)
        speed = np.linalg.norm(endpoint_velocity, axis=1)+.35*np.abs(qd[:, 8:11]).sum(1)
        return dict(time=float(clock.reshape(-1)[0]), q=q, qd=qd, target=t, base=base,
                    rotations=rotations, planar=planar, grasps=grasps, twist=twist,
                    linear_velocity=linear_velocity, endpoint_speed=speed,
                    lag=lag, arm_stage_lag=arm_stage_lag, wrist_lag=wrist_lag, pending=pending)

    def _validate(self, s, speed, *, handoff=False):
        q, qd, target = s['q'], s['qd'], s['target']
        if (np.any(q[:, 3] < self.LIFT_LIMITS[0]) or np.any(q[:, 3] > self.LIFT_LIMITS[1])
                or np.any(target[:, 0] < self.LIFT_LIMITS[0]) or np.any(target[:, 0] > self.LIFT_LIMITS[1])
                or np.any(q[:, 4:8] < -1e-6) or np.any(q[:, 4:8] > .130001)
                or np.any(target[:, 1] < self.ARM_LIMITS[0]) or np.any(target[:, 1] > self.ARM_LIMITS[1])
                or np.any(q[:, 4:8].sum(1) < self.ARM_LIMITS[0]) or np.any(q[:, 4:8].sum(1) > self.ARM_LIMITS[1])):
            raise ValueError('own_lift_or_arm_workspace_violation')
        if (np.any(q[:, 8:11] < self.WRIST_LIMITS[:, 0]-1e-5)
                or np.any(q[:, 8:11] > self.WRIST_LIMITS[:, 1]+1e-5)
                or np.any(target[:, 2:5] < self.WRIST_LIMITS[:, 0]-1e-5)
                or np.any(target[:, 2:5] > self.WRIST_LIMITS[:, 1]+1e-5)
                or np.max(np.abs(s['wrist_lag'])) > np.deg2rad(.02)
                or np.max(np.abs(qd[:, 8:11])) > np.deg2rad(.1)
                or np.max(np.abs(target[:, 2:5]-self.fixed_targets)) > 1e-6
                or np.max(np.abs(q[:, 8:11]-self.fixed_q)) > np.deg2rad(.03)):
            raise ValueError('unresolved_fixed_wrist_target_or_motion')
        if (np.any(q[:, 11:13] < -.001) or np.any(q[:, 11:13] > .18)
                or np.any(target[:, 5] < -.001) or np.any(target[:, 5] > .18)):
            raise ValueError('closed_jaw_posture_guard')
        relative = np.einsum('nji,njk->nik', self.base_rotations0, s['rotations'])
        angle = np.arccos(np.clip((np.trace(relative, axis1=1, axis2=2)-1)/2, -1., 1.))
        if np.max(angle) > .003 or np.max(np.abs(target[:, 8])) > 1e-5:
            raise ValueError('unresolved_base_orientation_or_yaw_target')
        if np.any(s['pending'] > self.MAX_CANCEL_EXCURSION+1e-10):
            raise ValueError('unresolved_integrated_linear_targets_over_0_75mm')
        maximum_speed = .04 if handoff else 2*speed+.0002
        if (np.max(s['endpoint_speed']) > maximum_speed
                or np.max(np.linalg.norm(s['twist'][:, :3], axis=1)) > maximum_speed
                or np.max(np.linalg.norm(s['linear_velocity'], axis=1)) > maximum_speed
                or np.max(np.linalg.norm(target[:, 6:8], axis=1)) > maximum_speed
                or np.max(np.abs(qd[:, 4:8])) > maximum_speed/4+.0002
                or np.max(np.linalg.norm(s['twist'][:, 3:], axis=1)) > .005):
            raise ValueError('unresolved_measured_velocity')

    def _is_rest(self, s):
        return bool(np.max(np.abs(s['lag'])) <= self.SETTLED_LAG
            and np.max(np.abs(s['arm_stage_lag']).sum(1)) <= self.SETTLED_LAG
            and np.max(np.abs(s['wrist_lag'])) <= np.deg2rad(.005)
            and np.max(np.abs(s['qd'][:, 8:11])) <= np.deg2rad(.02)
            and np.max(np.abs(s['qd'][:, 4:8])) <= self.SETTLED_SPEED/4
            and np.max(np.linalg.norm(s['linear_velocity'], axis=1)) <= self.SETTLED_SPEED
            and np.max(s['endpoint_speed']) <= self.SETTLED_SPEED
            and np.max(np.linalg.norm(s['twist'][:, :3], axis=1)) <= self.SETTLED_SPEED
            and np.max(np.linalg.norm(s['twist'][:, 3:], axis=1)) <= .0002
            and np.max(np.abs(s['target'][:, 6:9])) <= 1e-5)

    def _result(self, action=None):
        if action is None or self.failure:
            action = self._hold()
        cancellation = self.mode in ('handoff', 'cancel') and not self.failure
        self.debug.update(mode=self.mode, measured_rest_seconds=self.stable,
                          common_scale=self.debug.get('common_scale', 0.),
                          common_command_scale=self.debug.get('common_scale', 0.),
                          pending_failure=self.pending_failure,
                          pending_bound_scope='Integrated linear target displacement plus separately reported measured-rate interval; no inertia or physical stopping certificate.',
                          geometry_or_path_checked=False)
        return dict(action=np.asarray(action, np.float32), failure=self.failure,
                    pending_failure=self.pending_failure, cancellation_only=cancellation,
                    settled=bool(self.mode=='ready' and self.stable >= self.SETTLE_SECONDS-1e-9 and not self.failure),
                    debug=dict(self.debug))

    def _begin_cancel(self, now, reason=None):
        if reason:
            self.pending_failure = self.pending_failure or reason
        if self.mode not in ('handoff', 'cancel'):
            self.mode = 'cancel'; self.cancel_since = now; self.stable = 0.

    def _cancel(self, s, dt, speed, issue_action):
        if s['time']-self.cancel_since > self.CANCEL_SECONDS:
            raise ValueError('unresolved_linear_target_or_measured_rest_timeout')
        action = self._hold()
        # One common interpolation fraction cancels lift AND aggregate arm on
        # both robots; individual stage residuals must still physically settle.
        error = -s['lag']
        alpha = min(1., speed*self.DT/max(float(np.linalg.norm(error, axis=1).max()), 1e-12))
        rates = error*alpha/self.DT
        if issue_action:
            action[:, 3:5] = rates/np.array([1.54, 1.21])
        rest = self._is_rest(s)
        self.stable = self.stable+dt if rest else 0.
        self.debug.update(cancellation_common_fraction=alpha, common_scale=0.,
                          cancellation_linear_rates_m_s=rates.tolist(), unresolved_target_lag=False)
        if self.stable >= self.SETTLE_SECONDS-1e-9:
            if self.pending_failure:
                self.failure = self.pending_failure; self.mode = 'failed'
            else:
                self.mode = 'ready'
                self.base_reference = s['base'][:, :2].copy()
                self.progress_reference = s['grasps'].copy()
                self.progress_base_reference = s['base'][:, :2].copy()
                self.last_progress[:] = s['time']
            return self._result()
        return self._result(action)

    @staticmethod
    def _line_scale(error, increment, limit):
        """Largest nonnegative alpha with ||error+alpha*increment||<=limit."""
        if np.linalg.norm(error) > limit+1e-12:
            return 0.
        a = float(increment @ increment)
        if a < 1e-24:
            return 1.
        b = 2*float(error @ increment); c = float(error @ error)-limit*limit
        return float(np.clip((-b+np.sqrt(max(0., b*b-4*a*c)))/(2*a), 0., 1.))

    def step(self, obs, proposed_action, *, halt=False, max_speed_mps=.01):
        """Gate a proposed action; preserve cancellation actions until settled.

        ``halt`` is a hold request, not a new failure. A later valid request may
        resume only after 0.20 s measured rest. Zero proposed translation is also
        a hold. Invalid proposals latch pending_failure while bounded targets
        are cancelled. ``settled`` never follows from zero commands alone.
        """
        if self.failure:
            return self._result()
        self.calls += 1
        self.debug = {}
        try:
            speed = float(max_speed_mps)
            if not np.isfinite(speed) or not 0 < speed <= .01:
                raise ValueError('speed_must_be_positive_and_at_most_0_01')
            s = self._read(obs)
            dt = s['time']-self.last_time
            if dt < -1e-8 or dt > .075:
                raise ValueError('unresolved_public_action_clock_gap')
            dt = max(dt, 0.)
            issue_action = dt > 1e-9 or self.calls == 1
            self.last_time = s['time']
            if dt > 1e-9:
                measured_speed = np.linalg.norm(s['grasps']-self.last_grasps, axis=1)/dt
                s['endpoint_speed'] = np.maximum(s['endpoint_speed'], measured_speed)
            self.last_grasps = s['grasps'].copy()
            self._validate(s, speed, handoff=self.mode=='handoff')
            self.debug.update(integrated_linear_target_lag_m=s['lag'].tolist(),
                individual_arm_target_lag_m=s['arm_stage_lag'].tolist(),
                pending_linear_excursion_m=s['pending'].tolist(),
                measured_endpoint_speed_m_s=s['endpoint_speed'].tolist(),
                one_measured_rate_interval_m=(s['endpoint_speed']*self.DT).tolist(),
                unresolved_target_lag=False)
            proposal = np.asarray(proposed_action, float)
            if (proposal.shape != (2, 9) or not np.isfinite(proposal).all()
                    or np.max(np.abs(proposal)) > 1. or np.max(np.abs(proposal[:, [2, 5, 6, 7]])) > 1e-12
                    or np.any(proposal[:, 8] < 0.)):
                self._begin_cancel(s['time'], 'unsupported_proposed_action')
                return self._cancel(s, dt, speed, issue_action)
            if not isinstance(halt, (bool, np.bool_)):
                self._begin_cancel(s['time'], 'halt_must_be_boolean')
            requested = proposal[:, self.COLUMNS]*self.SCALES
            request_active = np.max(np.abs(requested)) > 1e-10
            if halt or not request_active:
                if self.mode=='ready' and self._is_rest(s):
                    self.stable += dt
                    return self._result()
                self._begin_cancel(s['time'])
            if self.mode in ('handoff', 'cancel'):
                return self._cancel(s, dt, speed, issue_action)
            if self.mode == 'ready' and not self._is_rest(s):
                self._begin_cancel(s['time'])
                return self._cancel(s, dt, speed, issue_action)
            if not issue_action:
                return self._result()
            # A newly admitted bout starts from measured rest. Thereafter the
            # reference is cumulative so a blocked base cannot be hidden by
            # recreating a per-frame displacement target.
            self.mode = 'moving'; self.stable = 0.
            world_base = np.einsum('nij,nj->ni', s['planar'], requested[:, :2])
            endpoint = (np.pad(world_base, ((0, 0), (0, 1)))
                +s['rotations'][:, :, 2]*requested[:, 2:3]
                +s['rotations'][:, :, 0]*requested[:, 3:4])
            largest = max(float(np.linalg.norm(endpoint, axis=1).max()),
                          float(np.linalg.norm(requested[:, :2], axis=1).max()),
                          float(np.linalg.norm(requested[:, 2:4], axis=1).max()))
            alpha = min(1., speed/max(largest, 1e-12))
            for robot in (0, 1):
                for lag, increment, cap in [(s['lag'][robot, 0], requested[robot, 2]*self.DT, self.TARGET_LEAD),
                        *[(lag, requested[robot, 3]*self.DT/4, self.TARGET_LEAD/4) for lag in s['arm_stage_lag'][robot]]]:
                    if abs(lag) > cap+1e-10:
                        alpha = 0.
                    elif abs(increment) > 1e-15:
                        bound = (cap-lag)/increment if increment > 0 else (-cap-lag)/increment
                        alpha = min(alpha, max(0., bound))
                alpha = min(alpha, self._line_scale(self.base_reference[robot]-s['base'][robot, :2],
                    world_base[robot]*self.DT, self.MAX_BASE_REFERENCE_LEAD))
            rates = requested*alpha
            next_target = s['target'][:, :2]+rates[:, 2:4]*self.DT
            if (np.any(next_target[:, 0] < self.LIFT_LIMITS[0]) or np.any(next_target[:, 0] > self.LIFT_LIMITS[1])
                    or np.any(next_target[:, 1] < self.ARM_LIMITS[0]) or np.any(next_target[:, 1] > self.ARM_LIMITS[1])):
                self._begin_cancel(s['time'], 'proposed_linear_target_outside_own_workspace')
                return self._cancel(s, dt, speed, issue_action)
            progress = np.maximum(np.linalg.norm(s['grasps']-self.progress_reference, axis=1),
                                  np.linalg.norm(s['base'][:, :2]-self.progress_base_reference, axis=1))
            active = np.linalg.norm(requested, axis=1) > 1e-10
            refresh = (progress > .0002) | ~active
            self.progress_reference[refresh] = s['grasps'][refresh]
            self.progress_base_reference[refresh] = s['base'][refresh, :2]
            self.last_progress[refresh] = s['time']
            if np.any(s['time']-self.last_progress > self.STALL_SECONDS):
                self._begin_cancel(s['time'], 'no_measured_pair_progress_for_3s')
                return self._cancel(s, dt, speed, issue_action)
            self.base_reference += world_base*alpha*self.DT
            action = self._hold(); action[:, self.COLUMNS] = rates/self.SCALES
            self.debug.update(common_scale=float(alpha), base_reference_error_m=(self.base_reference-s['base'][:, :2]).tolist(),
                              outgoing_linear_target_lag_m=(next_target-np.column_stack((s['q'][:, 3], s['q'][:, 4:8].sum(1)))).tolist(),
                              outgoing_physical_rates_m_s=rates.tolist())
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.failure = (self.pending_failure+': ' if self.pending_failure else '')+str(error)
            self.mode = 'failed'; self.debug['unresolved_target_lag'] = True
            return self._result()
