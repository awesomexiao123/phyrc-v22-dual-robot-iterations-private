"""Conservative visible opening proposals from public RGB-D, not sleeve labels.

A closed non-cloth image region is only a candidate when observed depth behind
it is farther than a plane fitted to surrounding cloth. This rejects ordinary
foreground occlusion and flat texture patches. It cannot prove physical topology,
an opening's garment identity, or a clear path through folded material.
"""
import importlib.util
from pathlib import Path

import cv2
import numpy as np
from camera_geometry import pixel_rays

_SPEC = importlib.util.spec_from_file_location(
    '_v23_opening_public_geometry', Path(__file__).with_name('human_targets.py'))
_PUBLIC = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_PUBLIC)


def _cloth_masks(color):
    red, green, blue = color.astype(float).transpose(2, 0, 1)
    blue_cloth = (blue > 100) & (blue > 1.25 * red) & (blue > 1.25 * green)
    yellow = (red > 120) & (green > 100) & (blue < .65 * np.minimum(red, green))
    yellow &= (red > .65 * green) & (green > .55 * red)
    near_blue = cv2.dilate(blue_cloth.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)
    trim = yellow & near_blue
    # Deliberately do not close image gaps: an open edge is not a verified hole.
    return blue_cloth | trim, trim


def _optical_points(u, v, z):
    return pixel_rays(u, v, _PUBLIC._FOCAL)*np.asarray(z)[..., None]


def _inner_aperture(hole, cloth, centre, normal, rotation, origin, axis, camera, now):
    """Ordered inner image boundary projected onto an estimated cloth plane.

    Pixel centers on the non-cloth side are used. CHAIN_APPROX_SIMPLE removes
    only collinear steps; no convex hull, gap closing or metric dilation is used.
    The projected vertices are ray/plane estimates, not measured physical rim
    points. The surrounding cloth band remains separately available for depth.
    """
    result = dict(available=False, reason=None, source_camera=_PUBLIC._CAMERAS[camera][0],
        camera_index=camera, observation_time_s=now, contour_pixels_uv=[],
        contour_world_on_plane=[], polygon_plane_xy_m=[], plane_origin_world=None,
        plane_basis_world=None, area_on_plane_m2=None, maximum_vertices=512,
        boundary_basis='ordered non-cloth interior boundary pixel centers; no convex hull or gap filling',
        projection_basis='camera rays intersect same-frame cloth-band plane; not measured physical rim',
        physical_opening_verified=False, insertion_allowed=False)
    free = (hole.astype(bool) & ~cloth).astype(np.uint8)
    contours, hierarchy = cv2.findContours(free, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None or len(contours) != 1:
        return dict(result, reason='inner_region_has_multiple_components_or_cloth_islands')
    pixels = contours[0].reshape(-1, 2)
    if not 3 <= len(pixels) <= 512 or len(np.unique(pixels, axis=0)) != len(pixels):
        return dict(result, reason='inner_contour_complex_or_degenerate')
    rays = pixel_rays(pixels[:, 0], pixels[:, 1], _PUBLIC._FOCAL)
    denominator = rays @ normal
    if np.any(np.abs(denominator) <= .15):
        return dict(result, reason='inner_contour_rays_nearly_parallel_to_plane')
    distance = float(centre @ normal)/denominator
    if not np.isfinite(distance).all() or np.any(distance <= .03) or np.any(distance >= 5.):
        return dict(result, reason='inner_contour_plane_intersections_invalid')
    world = (rays*distance[:, None]) @ rotation.T+origin
    plane_origin = rotation @ centre+origin
    world_normal = rotation @ normal
    basis = np.stack((rotation @ axis, np.cross(world_normal, rotation @ axis)))
    polygon = (world-plane_origin) @ basis.T
    area = abs(float(cv2.contourArea(polygon.astype(np.float32))))
    if area < 1e-8:
        return dict(result, reason='inner_contour_projected_area_degenerate')
    return dict(result, available=True, reason='same_frame_inner_image_contour_projected_to_estimated_plane',
        contour_pixels_uv=pixels.tolist(), contour_world_on_plane=world.tolist(),
        polygon_plane_xy_m=polygon.tolist(), plane_origin_world=plane_origin.tolist(),
        plane_basis_world=basis.tolist(), area_on_plane_m2=area)


def _segment_pair_distances(first, second):
    """Distances between all cyclic polygon segments, retaining concave edges."""
    a, b = first, np.roll(first, -1, axis=0)
    c, d = second, np.roll(second, -1, axis=0)

    def cross(x, y):
        return x[..., 0]*y[..., 1]-x[..., 1]*y[..., 0]

    ab, cd = b-a, d-c
    den = cross(ab[:, None], cd[None])
    diff = c[None]-a[:, None]
    proper = np.abs(den) > 1e-12
    t = np.divide(cross(diff, cd[None]), den, out=np.zeros_like(den), where=proper)
    u = np.divide(cross(diff, ab[:, None]), den, out=np.zeros_like(den), where=proper)
    crossing = proper & (t >= 0) & (t <= 1) & (u >= 0) & (u <= 1)

    def point_segment(points, starts, ends):
        direction = ends-starts
        delta = points[:, None]-starts[None]
        fraction = np.clip(np.sum(delta*direction[None], axis=2)/
                           np.maximum(np.sum(direction*direction, axis=1)[None], 1e-16), 0, 1)
        return np.linalg.norm(delta-fraction[..., None]*direction[None], axis=2)

    distances = np.minimum.reduce((point_segment(a, c, d), point_segment(b, c, d),
                                   point_segment(c, a, b).T, point_segment(d, a, b).T))
    distances[crossing] = 0.
    return distances


def compare_hand_surface_footprint(obs, candidate, hand_surface_samples, direction_world,
                                   *, margin_m=.01, max_projection_m=.15):
    """Project actual public depth samples along a caller's hypothesized axis.

    Samples are ``camera_indices`` and integer ``source_pixels_uv`` arrays,
    maximum 512 unique pixels from cameras 1..4. World positions are rebuilt
    here, never accepted from the caller. A convex *observed hand footprint* is
    compared with the non-convex inner image polygon, including edge crossings.
    It remains a partial visible-surface envelope, not a complete hand or path.
    The same-frame candidate requires an equal public simulation timestamp.
    """
    result = dict(status='unknown', observed_footprint_fits=False, reason=None,
        minimum_edge_clearance_m=None, required_margin_m=float(margin_m),
        projected_surface_points_world=[], projected_surface_plane_xy_m=[],
        observed_footprint_hull_plane_xy_m=[], sample_count=0,
        source_camera=candidate.get('source_camera'), camera_index=candidate.get('camera_index'),
        observation_time_s=None, projection_direction_world=None,
        physical_hand_complete=False, sleeve_identity_verified=False, insertion_allowed=False,
        scope='measured visible surface envelope in same-frame projected image aperture only')
    try:
        if not np.isfinite([margin_m, max_projection_m]).all() or not 0 <= margin_m <= .05 or not 0 < max_projection_m <= .30:
            raise ValueError('invalid_bounded_projection_parameters')
        now = float(np.asarray(obs['simulation_time_s']).item())
        recorded = candidate.get('observation_time_s')
        aperture = candidate.get('inner_aperture', {})
        if (not np.isfinite(now) or recorded is None or not np.isfinite(recorded)
                or abs(now-recorded) > 1e-7 or aperture.get('observation_time_s') != recorded):
            raise ValueError('candidate_is_not_identified_with_this_public_observation_time')
        result['observation_time_s'] = now
        if not aperture.get('available'):
            raise ValueError('inner_aperture_polygon_unavailable')
        camera = candidate['camera_index']
        if camera not in (1, 2, 3, 4) or aperture.get('camera_index') != camera:
            raise ValueError('invalid_same_frame_robot_camera_provenance')
        values = _PUBLIC._validated(obs, wrists=True)
        pixels = np.asarray(aperture['contour_pixels_uv'], dtype=int)
        current_cloth, _ = _cloth_masks(values['rgb'][camera])
        if (pixels.ndim != 2 or pixels.shape[1] != 2 or not 3 <= len(pixels) <= 512
                or np.any(pixels < 0) or np.any(pixels >= 256)
                or np.any(current_cloth[pixels[:, 1], pixels[:, 0]])):
            raise ValueError('inner_image_contour_no_longer_matches_current_noncloth_pixels')
        ids = np.asarray(hand_surface_samples['camera_indices'])
        uv = np.asarray(hand_surface_samples['source_pixels_uv'])
        if (ids.ndim != 1 or uv.shape != (len(ids), 2) or not 12 <= len(ids) <= 512
                or not np.isfinite(ids).all() or not np.isfinite(uv).all()
                or np.any(ids != ids.astype(int)) or np.any(uv != uv.astype(int))
                or not np.isin(ids, (1, 2, 3, 4)).all() or np.any(uv < 0) or np.any(uv >= 256)):
            raise ValueError('bounded_integer_robot_camera_hand_samples_required')
        ids, uv = ids.astype(int), uv.astype(int)
        if len(np.unique(np.column_stack((ids, uv)), axis=0)) != len(ids):
            raise ValueError('duplicate_surface_pixels_do_not_add_observed_footprint_support')
        points = []
        for source in np.unique(ids):
            chosen = uv[ids == source]
            u, v = chosen.T
            z = values['depth'][source, v, u, 0]
            valid = (values['depth_valid'][source, v, u, 0] & np.isfinite(z)
                     & (z > .03) & (z < (3. if source < 3 else 5.)))
            fabric, _ = _cloth_masks(values['rgb'][source])
            if not valid.all() or np.any(fabric[v, u]):
                raise ValueError('hand_samples_include_invalid_depth_or_recognized_fabric')
            points.append(_PUBLIC._world_pixels(values, source, u, v, z))
        points = np.concatenate(points)
        direction = np.asarray(direction_world, dtype=float).copy()
        normal = np.asarray(candidate['normal_world'], dtype=float).copy()
        origin = np.asarray(aperture['plane_origin_world'], dtype=float)
        basis = np.asarray(aperture['plane_basis_world'], dtype=float)
        polygon = np.asarray(aperture['polygon_plane_xy_m'], dtype=float)
        if (direction.shape != (3,) or normal.shape != (3,) or origin.shape != (3,) or basis.shape != (2, 3)
                or polygon.shape != (len(pixels), 2) or not np.isfinite(np.r_[direction, normal, origin, basis.ravel(), polygon.ravel()]).all()
                or np.linalg.norm(direction) < .5 or np.linalg.norm(normal) < .5):
            raise ValueError('invalid_projection_geometry')
        direction /= np.linalg.norm(direction); normal /= np.linalg.norm(normal)
        denominator = float(normal @ direction)
        if abs(denominator) < .8:
            raise ValueError('hypothesized_surface_axis_is_too_oblique_to_aperture_plane')
        travel = (origin-points) @ normal/denominator
        if np.max(np.abs(travel)) > max_projection_m:
            raise ValueError('surface_to_aperture_projection_exceeds_local_range')
        projected = points+travel[:, None]*direction
        plane = (projected-origin) @ basis.T
        hull = cv2.convexHull(plane.astype(np.float32)).reshape(-1, 2)
        if len(hull) < 3 or abs(cv2.contourArea(hull)) < 1e-6:
            raise ValueError('observed_surface_footprint_has_no_resolved_two_dimensional_extent')
        signed = np.array([cv2.pointPolygonTest(polygon.astype(np.float32), tuple(map(float, point)), True) for point in hull])
        edge_clearance = float(_segment_pair_distances(hull, polygon).min())
        clearance = min(float(signed.min()), edge_clearance)
        fits = bool(np.all(signed > 0) and edge_clearance > 1e-8 and clearance >= margin_m)
        return dict(result, status='observed_footprint_within_candidate' if fits else 'observed_footprint_outside_or_insufficient_margin',
            observed_footprint_fits=fits, reason='same_frame_public_surface_projection_only',
            minimum_edge_clearance_m=clearance, projected_surface_points_world=projected.tolist(),
            projected_surface_plane_xy_m=plane.tolist(), observed_footprint_hull_plane_xy_m=hull.tolist(),
            sample_count=len(points), projection_direction_world=direction.tolist(),
            signed_projection_distance_range_m=[float(travel.min()), float(travel.max())],
            sampled_hand_extent_is_complete=False)
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason=str(error))


def detect_opening_candidates(obs):
    """Return candidate planes, measured background-depth support and uncertainty.

    Cameras are own robot head/wrist cameras only, never the human-mounted
    overview. Plane normals face the observing camera; their sign is a viewpoint
    convention, not the sleeve's inside/outside. Missing depth causes abstention.
    Candidate observations in separate cameras are not identity-matched.
    """
    values = _PUBLIC._validated(obs, wrists=True)
    now = float(np.asarray(obs['simulation_time_s']).item()) if 'simulation_time_s' in obs else None
    if now is not None and not np.isfinite(now):
        raise ValueError('invalid public observation time')
    candidates, rejected = [], {}

    def reject(reason):
        rejected[reason] = rejected.get(reason, 0) + 1

    for camera in (1, 2, 3, 4):
        cloth, trim = _cloth_masks(values['rgb'][camera])
        contours, hierarchy = cv2.findContours(cloth.astype(np.uint8), cv2.RETR_CCOMP,
                                               cv2.CHAIN_APPROX_SIMPLE)
        if hierarchy is None:
            continue
        depth = values['depth'][camera, ..., 0]
        valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < 5)
        for index, contour in enumerate(contours):
            parent = int(hierarchy[0, index, 3])
            if parent < 0:
                continue
            area = float(cv2.contourArea(contour))
            if area < 25 or area > 12000 or cv2.contourArea(contours[parent]) < 150:
                continue
            x, y, width, height = cv2.boundingRect(contour)
            if min(x, y) <= 1 or x + width >= 255 or y + height >= 255:
                reject('image_boundary'); continue
            hole = np.zeros((256, 256), np.uint8)
            cv2.drawContours(hole, [contour], -1, 1, cv2.FILLED)
            interior = cv2.erode(hole, np.ones((3, 3), np.uint8)).astype(bool) & ~cloth
            ring = cv2.dilate(hole, np.ones((5, 5), np.uint8)).astype(bool) & cloth
            if interior.sum() < 12 or ring.sum() < 20:
                reject('too_few_visible_pixels'); continue
            ring_support = float(valid[ring].mean())
            interior_support = float(valid[interior].mean())
            if ring_support < .8 or interior_support < .7:
                reject('insufficient_observed_depth'); continue
            rv, ru = np.where(ring & valid)
            ring_optical = _optical_points(ru, rv, depth[rv, ru])
            centre = ring_optical.mean(axis=0)
            _, singular, axes = np.linalg.svd(ring_optical - centre, full_matrices=False)
            if singular[1] < .005:
                reject('collapsed_or_edge_on_ring'); continue
            planarity = float(singular[2] / singular[1])
            if planarity > .30:
                reject('nonplanar_or_mixed_depth_ring'); continue
            normal = axes[2]
            if np.dot(normal, centre) > 0:
                normal = -normal
            iv, iu = np.where(interior & valid)
            rays = pixel_rays(iu, iv, _PUBLIC._FOCAL)
            denominators = rays @ normal
            usable = np.abs(denominators) > .15
            expected = np.zeros(len(iu))
            expected[usable] = float(centre @ normal) / denominators[usable]
            usable &= (expected > .03) & (expected < 5)
            if usable.mean() < .9:
                reject('edge_on_plane'); continue
            residual = depth[iv[usable], iu[usable]] - expected[usable]
            median_gap = float(np.median(residual))
            near_gap = float(np.percentile(residual, 25))
            behind_fraction = float((residual > .02).mean())
            if median_gap < .04 or near_gap < .02 or behind_fraction < .85:
                reject('foreground_occlusion_or_no_background_gap'); continue
            moments = cv2.moments(contour)
            if moments['m00'] <= 0:
                continue
            pixel = np.array([moments['m10'] / moments['m00'], moments['m01'] / moments['m00']])
            ray = pixel_rays(pixel[0], pixel[1], _PUBLIC._FOCAL)
            denom = float(ray @ normal)
            if abs(denom) <= .15:
                reject('edge_on_plane'); continue
            opening_centre = ray * float(centre @ normal) / denom
            rotation, origin = _PUBLIC._camera_transform(values, camera)
            world_centre = rotation @ opening_centre + origin
            world_normal = rotation @ normal
            world_axis = rotation @ axes[0]
            ring_world = ring_optical @ rotation.T + origin
            trim_fraction = float(trim[ring].mean())
            confidence = float(np.clip(.45 + .2 * behind_fraction + .1 * ring_support
                                       + .1 * interior_support - .4 * planarity, 0, .85))
            candidates.append(dict(
                kind='unclassified_opening', opening_verified=False,
                observation_time_s=now,
                candidate_identity_scope='same-frame source camera and pixels only; no persistent identity',
                source_camera=_PUBLIC._CAMERAS[camera][0], camera_index=camera,
                inner_aperture=_inner_aperture(hole, cloth, centre, normal, rotation, origin, axes[0], camera, now),
                centroid_world=world_centre.tolist(), plane_centre_world=(rotation @ centre + origin).tolist(),
                normal_world=world_normal.tolist(), normal_convention='points_toward_observing_camera',
                principal_axis_world=world_axis.tolist(), planarity=planarity,
                pixel_centroid=pixel.tolist(), pixel_area=area,
                visible_ring_extent_m=np.ptp((ring_optical - centre) @ axes[:2].T, axis=0).tolist(),
                # At most 64 measured points for downstream visual diagnostic overlays.
                ring_points_world=ring_world[::max(1, int(np.ceil(len(ring_world) / 64)))].tolist(),
                yellow_trim_fraction=trim_fraction, collar_like=bool(trim_fraction >= .25),
                collar_hint_basis='yellow trim appearance only; hem or folds may also be yellow',
                confidence=confidence,
                observed_depth_support=dict(ring_valid_fraction=ring_support,
                    interior_valid_fraction=interior_support, interior_pixels=int(usable.sum()),
                    background_fraction=behind_fraction, median_background_gap_m=median_gap,
                    lower_quartile_background_gap_m=near_gap),
                reason='closed_colour_boundary_with_observed_background_behind_local_cloth_plane'))
    candidates.sort(key=lambda item: (item['camera_index'], -item['confidence'], -item['pixel_area']))
    return dict(opening_candidates=candidates, detected=bool(candidates),
                status='candidate_only' if candidates else 'unknown',
                reason='depth_supported_visible_candidates' if candidates else 'no_supported_closed_visible_opening',
                rejected_candidate_counts=rejected, opening_verified=False,
                anatomical_or_garment_identity_known=False, cross_view_identity_matched=False,
                limitations='Side-view open edges, hidden/folded openings and missing background depth cause abstention; no sleeve or traversal guarantee.')


def opening_candidates(obs):
    """Convenience API alias; both entry points return the same candidate report."""
    return detect_opening_candidates(obs)
