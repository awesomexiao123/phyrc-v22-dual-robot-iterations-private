"""Separate simulation contact trial after a fresh staging calibration.

The inherited fixed cloth trackers, original time/path limits and persistent
governor span every pulse. Geometry always consumes the raw public observation.
Neither a calibrated target nor a successful pulse certifies sleeve insertion.
"""
from copy import deepcopy

from calibrated_contact_governor import CalibratedContactGovernor
from calibrated_contact_clearance import check_calibrated_contact_clearance
from hypothesis_contact_experiment import HypothesisContactExperiment


class CalibratedHypothesisContactExperiment(HypothesisContactExperiment):
    def __init__(self, obs, initial_edge_report, robot_assignment,
                 original_hand_report, original_observed_at, *, calibration,
                 skin_anchor, skin_anchor_observed_at):
        if calibration.get('variant') != 'staging_passive_prior_compatible':
            raise ValueError('fresh_prior_compatible_staging_calibration_required')
        self.calibration = deepcopy(calibration)
        super().__init__(obs, initial_edge_report, robot_assignment,
                         original_hand_report, original_observed_at)
        # This original anchor must survive the stage handoff; the inherited
        # current skin detector still has to obtain its own new observation.
        self.skin_anchor = deepcopy(skin_anchor)
        self.skin_anchor_stamp = skin_anchor_observed_at

    def _create_governor(self, obs):
        return CalibratedContactGovernor(obs, calibration=self.calibration)

    def _check_clearance(self, obs, action, now):
        report = check_calibrated_contact_clearance(obs, self.governor.motion_evidence,
            action, skin=self.skin, skin_observed_at=self.skin_stamp,
            skin_anchor=self.skin_anchor, skin_anchor_observed_at=self.skin_anchor_stamp)
        self.clearance = deepcopy(report.get('checks', []))
        if not report.get('valid'):
            raise ValueError('calibrated contact clearance: '+str(report.get('reason')))

    def _result(self, action=None):
        result = super()._result(action)
        result['debug'].update(
            control_variant='fresh_staging_calibrated_hypothesis_contact',
            staging_calibration_observed_at_s=self.calibration['observed_at_s'],
            prior_calibration_original_observed_at_s=self.calibration.get(
                'prior_calibration_original_observed_at_s'),
            calibration_refreshed_during_contact=False,
            physical_simulation_validation_completed=False)
        return result
