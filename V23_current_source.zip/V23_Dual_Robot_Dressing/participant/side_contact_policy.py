"""Interior sleeve-side pickup plus the separate contact-hypothesis branch.

Pickup targets are the original planar-shirt interior proposals. Observed
external edge geometry supplies only a historical size prior for later contact
hypotheses; this variant never presents the interior targets as edge pickups.
The inherited current cloth-support checks and fixed-feature test lift remain.
"""
from copy import deepcopy

import numpy as np

from planar_shirt import estimate_planar_shirt
from planar_sleeve_edge import estimate_planar_sleeve_edges
from sleeve_contact_policy import Policy as ContactPolicy
from sleeve_pair_policy import Policy as SleeveSidePolicy


class Policy(ContactPolicy):
    VERSION = 'v23_18_contact_sleeve_sides'
    METHOD = ('frozen V22 visual approach; original interior sleeve-side pickups; '
              'observed edge size prior only; synchronized lift/carry and shared '
              'bounded 10-degree wrist/contact hypothesis experiment')

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.cached_edge_prior = None

    def _estimate_shirt(self, obs):
        planar = estimate_planar_shirt(obs)
        if planar.get('detected'):
            edges = estimate_planar_sleeve_edges(obs, planar)
            if edges.get('detected'):
                now = float(np.asarray(obs['simulation_time_s']).item())
                stamp = float(edges['observation_time_s'])
                if not np.isfinite([now, stamp]).all() or stamp != now:
                    raise ValueError('edge size prior did not come from the current planar observation')
                # Preserve actual observation times; later missing edge views
                # neither refresh nor replace this historical geometry.
                self.cached_edge_prior = deepcopy(edges)
        return planar

    def _prepare_pair(self, obs):
        now = float(np.asarray(obs['simulation_time_s']).item())
        prior = self.cached_edge_prior
        if not isinstance(prior, dict) or not prior.get('detected'):
            raise ValueError('observed edge size prior unavailable for interior sleeve-side contact variant')
        try:
            stamp = float(prior['observation_time_s'])
            shirt_stamp = float(self.shirt_observed_at)
            if (not np.isfinite([now, stamp, shirt_stamp]).all() or not 0 <= now-stamp <= 30.
                    or not 0 <= now-shirt_stamp <= 30.):
                raise ValueError('interior sleeve-side or edge size prior unavailable, stale or from future')
            originals, current, edges = prior['original_interior_candidates'], self.shirt['candidates'], prior['candidates']
            if not self.shirt.get('detected') or any(len(items) != 2 for items in (originals, current, edges)):
                raise ValueError('two ordered original interior candidates and boundary priors required')
            for index, side in enumerate(('negative_lateral', 'positive_lateral')):
                if any(items[index].get('geometric_side') != side for items in (originals, current, edges)):
                    raise ValueError('edge prior and interior pickup candidate order disagree')
                if (float(edges[index]['observation_time_s']) != stamp or
                        float(edges[index]['boundary_evidence']['observation_time_s']) != stamp):
                    raise ValueError('edge prior contains mixed or refreshed observation timestamps')
            old = np.asarray([candidate['target_world'] for candidate in originals], float)
            new = np.asarray([candidate['target_world'] for candidate in current], float)
            if old.shape != (2, 3) or new.shape != (2, 3) or not np.isfinite([old, new]).all():
                raise ValueError('invalid original or current interior sleeve-side target points')
            if np.max(np.linalg.norm(new-old, axis=1)) > .03:
                raise ValueError('edge size prior original interior targets differ by over3cm')
        except (KeyError, TypeError, IndexError) as error:
            raise ValueError('invalid observed edge size prior provenance: '+str(error)) from error
        self.initial_edge_report = deepcopy(prior)
        # Deliberately keep self.shirt and its actual observation timestamp.
        # The original route/support/test-lift logic consumes interior targets.
        return SleeveSidePolicy._prepare_pair(self, obs)
