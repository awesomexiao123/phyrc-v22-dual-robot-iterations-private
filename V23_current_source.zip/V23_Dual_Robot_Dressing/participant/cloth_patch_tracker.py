"""Fixed-identity public RGB-D feature tracks for cloth-motion evidence.

Features are seeded only by reset(), never by update(). World displacement is
relative to each feature's original measured point, not a moving search sphere.
This is visual evidence with possible abstention, not attachment verification.
"""
import importlib.util
from copy import deepcopy
from pathlib import Path

import cv2
import numpy as np

_SPEC = importlib.util.spec_from_file_location(
    '_v23_patch_public_geometry', Path(__file__).with_name('human_targets.py'))
_PUBLIC = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_PUBLIC)


def _cloth_mask(image):
    r, g, b = image.astype(float).transpose(2, 0, 1)
    blue = (b > 100) & (b > 1.25 * r) & (b > 1.25 * g)
    yellow = (r > 120) & (g > 100) & (b < .65 * np.minimum(r, g))
    near = cv2.dilate(blue.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)
    return blue | (yellow & near)


def _measure(values, camera, pixel, fabric):
    """Depth from local fabric-supported pixels; reject mixed-depth boundaries."""
    u, v = np.asarray(pixel, dtype=float)
    if not np.isfinite([u, v]).all() or not (3 <= u < 253 and 3 <= v < 253):
        return None
    x, y = int(round(u)), int(round(v))
    z = values['depth'][camera, y-1:y+2, x-1:x+2, 0]
    visible = fabric[y-1:y+2, x-1:x+2]
    valid = values['depth_valid'][camera, y-1:y+2, x-1:x+2, 0]
    valid = valid & visible & np.isfinite(z) & (z > .03) & (z < (3. if camera < 3 else 5.))
    if not fabric[y, x] or np.count_nonzero(valid) < 5:
        return None
    depth = z[valid]
    if np.percentile(depth, 90) - np.percentile(depth, 10) > .035:
        return None
    depth = float(np.median(depth))
    point = _PUBLIC._world_pixels(values, camera, np.array([u]), np.array([v]), np.array([depth]))[0]
    return point, depth


class ClothPatchTracker:
    """Track a fixed cohort at frequent observation intervals (preferably 20 Hz).

    Large per-update motion (>6 cm) is rejected rather than bridged by new
    identities. Confidence thresholds are heuristics, not measured probabilities.
    Head and wrist images are supported symmetrically; overview is excluded.
    A camera losing its entire view does not reduce another camera's cohort
    retention. Motion evidence requires at least one view retaining >=25% of
    its own original cohort and >=min_features consistent identities. The
    existing 65% motion-consensus criterion also remains mandatory.
    """

    def __init__(self, min_features=6, max_features_per_camera=60):
        self.min_features = int(min_features)
        self.max_features_per_camera = int(max_features_per_camera)
        if self.min_features < 3 or self.max_features_per_camera < self.min_features:
            raise ValueError('Expected at least three features and sufficient per-camera capacity')
        self.groups = {}
        self.initial_count = 0
        self.updates = 0
        self.initialized = False
        self._clear_diagnostics()

    @staticmethod
    def _empty_rejections():
        return dict(optical_flow=0, depth_or_cloth_support=0,
                    excessive_world_step=0, inconsistent_motion=0)

    def _clear_diagnostics(self):
        self.observation_time = None
        self.initial_observation_time = None
        self.initialization_diagnostics = {}
        self.cumulative_rejected = self._empty_rejections()
        self.cumulative_rejected_by_camera = {c: self._empty_rejections() for c in (1, 2, 3, 4)}
        self.rejected_by_camera_this_update = {c: self._empty_rejections() for c in (1, 2, 3, 4)}
        self.first_unreliable = None
        self.first_view_unreliable = {}
        self.ever_reliable = False

    @staticmethod
    def _observation_time(obs):
        # Diagnostic only: older synthetic fixtures omit the public clock. Do
        # not manufacture a timestamp or change their existing tracker result.
        try:
            value = np.asarray(obs['simulation_time_s'], float)
            return float(value.item()) if value.size == 1 and np.isfinite(value).all() else None
        except (KeyError, ValueError, TypeError):
            return None

    def _drop(self, dropped, camera, reason, count=1):
        count = int(count)
        dropped[reason] += count
        self.rejected_by_camera_this_update[camera][reason] += count
        self.cumulative_rejected[reason] += count
        self.cumulative_rejected_by_camera[camera][reason] += count

    def _report(self, reliable, reason, displacement=None, **extra):
        views = {}
        for camera, group in self.groups.items():
            initial = group['initial_count']
            views[_PUBLIC._CAMERAS[camera][0]] = dict(
                initial_feature_count=initial, tracked_count=len(group['pixels']),
                initial_feature_retention_fraction=len(group['pixels'])/max(initial, 1),
                motion_consensus_fraction=group.get('motion_consensus_fraction'),
                meets_view_motion_thresholds=bool(group.get('meets_view_motion_thresholds', False)))
            if (self.updates > 0 and not group.get('meets_view_motion_thresholds', False)
                    and camera not in self.first_view_unreliable):
                self.first_view_unreliable[camera] = dict(
                    observation_time_s=self.observation_time, update_count=self.updates,
                    tracked_count=len(group['pixels']), initial_feature_count=initial,
                    motion_consensus_fraction=group.get('motion_consensus_fraction'))
        if not reliable and self.ever_reliable and self.first_unreliable is None:
            self.first_unreliable = dict(observation_time_s=self.observation_time,
                update_count=self.updates, reason=reason,
                tracked_count=sum(len(g['pixels']) for g in self.groups.values()),
                view_cohorts=deepcopy(views))
        self.ever_reliable = self.ever_reliable or bool(reliable)
        return dict(tracked_count=sum(len(g['pixels']) for g in self.groups.values()),
            initial_feature_count=self.initial_count,
            median_displacement_world=None if displacement is None else np.asarray(displacement).tolist(),
            reliable=bool(reliable), reason=reason, update_count=self.updates,
            source_cameras=[_PUBLIC._CAMERAS[c][0] for c, g in self.groups.items() if len(g['pixels'])],
            feature_ids=[int(i) for g in self.groups.values() for i in g['ids']],
            view_cohorts=views,
            retention_basis='fixed initial cohort of each camera; global retention is diagnostic only',
            observation_time_s=self.observation_time,
            initial_observation_time_s=self.initial_observation_time,
            initialization_by_camera=deepcopy(self.initialization_diagnostics),
            cumulative_rejected=deepcopy(self.cumulative_rejected),
            cumulative_rejected_by_camera={_PUBLIC._CAMERAS[c][0]: deepcopy(counts)
                for c, counts in self.cumulative_rejected_by_camera.items()},
            rejected_by_camera_this_update={_PUBLIC._CAMERAS[c][0]: deepcopy(counts)
                for c, counts in self.rejected_by_camera_this_update.items()},
            first_unreliable_after_initialization=deepcopy(self.first_unreliable),
            first_view_below_motion_thresholds={_PUBLIC._CAMERAS[c][0]: deepcopy(item)
                for c, item in self.first_view_unreliable.items()},
            rejection_counter_scope='rejected is this update only; cumulative fields cover all updates since reset, not the current frame alone',
            attachment_verified=False, features_reseeded=False,
            evidence='same initially visible RGB features with public RGB-D and own camera poses', **extra)

    def reset(self, obs, center_world, radius=.12):
        values = _PUBLIC._validated(obs, wrists=True)
        center = np.asarray(center_world, dtype=float)
        if center.shape != (3,) or not np.isfinite(center).all() or not .02 <= radius <= .3:
            raise ValueError('Invalid world patch centre or radius')
        self.groups, self.initial_count, self.updates = {}, 0, 0
        self.initialized = True
        self._clear_diagnostics()
        self.observation_time = self.initial_observation_time = self._observation_time(obs)
        for camera in (1, 2, 3, 4):
            stats = dict(fabric_valid_pixel_count=0, near_patch_pixel_count=0,
                proposed_feature_count=0, measurement_valid_feature_count=0,
                supported_in_patch_feature_count=0, accepted_feature_count=0,
                excluded_counts=dict(depth_or_cloth_support=0, outside_patch_after_depth_measurement=0,
                                     cohort_below_minimum=0), reason=None)
            self.initialization_diagnostics[_PUBLIC._CAMERAS[camera][0]] = stats
            image = values['rgb'][camera]
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            fabric = _cloth_mask(image)
            depth = values['depth'][camera, ..., 0]
            valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < 5)
            v, u = np.where(fabric & valid)
            stats['fabric_valid_pixel_count'] = len(u)
            if len(u) < self.min_features:
                stats['reason'] = 'insufficient_fabric_valid_pixels'
                continue
            world = _PUBLIC._world_pixels(values, camera, u, v, depth[v, u])
            near = np.linalg.norm(world - center, axis=1) <= radius
            stats['near_patch_pixel_count'] = int(np.count_nonzero(near))
            mask = np.zeros((256, 256), np.uint8)
            mask[v[near], u[near]] = 255
            proposed = cv2.goodFeaturesToTrack(gray, maxCorners=self.max_features_per_camera,
                qualityLevel=.01, minDistance=3., mask=mask, blockSize=3)
            if proposed is None:
                stats['reason'] = 'no_corner_features_in_supported_patch_mask'
                continue
            stats['proposed_feature_count'] = len(proposed)
            pixels, points = [], []
            for pixel in proposed.reshape(-1, 2):
                measured = _measure(values, camera, pixel, fabric)
                if measured is None:
                    stats['excluded_counts']['depth_or_cloth_support'] += 1
                else:
                    stats['measurement_valid_feature_count'] += 1
                    if np.linalg.norm(measured[0] - center) > radius:
                        stats['excluded_counts']['outside_patch_after_depth_measurement'] += 1
                if measured is not None and np.linalg.norm(measured[0] - center) <= radius:
                    pixels.append(pixel); points.append(measured[0])
            stats['supported_in_patch_feature_count'] = len(points)
            if len(points) < self.min_features:
                stats['excluded_counts']['cohort_below_minimum'] = len(points)
                stats['reason'] = 'supported_camera_cohort_below_min_features'
                continue
            stats['accepted_feature_count'] = len(points)
            stats['reason'] = 'accepted_fixed_camera_cohort'
            points = np.asarray(points, dtype=float)
            self.groups[camera] = dict(gray=gray, pixels=np.asarray(pixels, np.float32),
                initial_world=points.copy(), last_world=points.copy(),
                initial_count=len(points),
                camera_index=camera,
                ids=np.arange(len(points), dtype=int) + camera * 10000)
            self.initial_count += len(points)
        reliable = self.initial_count >= self.min_features
        return self._report(reliable, 'initialized_fixed_public_features' if reliable else 'insufficient_initial_cloth_features',
                            np.zeros(3) if reliable else None)

    def update(self, obs):
        self.observation_time = self._observation_time(obs)
        self.rejected_by_camera_this_update = {c: self._empty_rejections() for c in (1, 2, 3, 4)}
        if not self.initialized:
            return self._report(False, 'reset_required')
        values = _PUBLIC._validated(obs, wrists=True)
        self.updates += 1
        if not any(len(g['pixels']) for g in self.groups.values()):
            return self._report(False, 'no_remaining_initial_features')
        dropped = dict(optical_flow=0, depth_or_cloth_support=0, excessive_world_step=0, inconsistent_motion=0)
        for camera, group in self.groups.items():
            group['motion_consensus_fraction'] = 0.
            group['meets_view_motion_thresholds'] = False
            if not len(group['pixels']):
                continue
            gray = cv2.cvtColor(values['rgb'][camera], cv2.COLOR_RGB2GRAY)
            original = group['pixels'].reshape(-1, 1, 2)
            forward, ok1, err1 = cv2.calcOpticalFlowPyrLK(group['gray'], gray, original, None,
                winSize=(21, 21), maxLevel=3,
                criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, .01))
            if forward is None:
                self._drop(dropped, camera, 'optical_flow', len(group['pixels']))
                group['pixels'] = group['pixels'][:0]
                group['initial_world'] = group['initial_world'][:0]
                group['last_world'] = group['last_world'][:0]
                group['ids'] = group['ids'][:0]
                continue
            backward, ok2, _ = cv2.calcOpticalFlowPyrLK(gray, group['gray'], forward, None,
                winSize=(21, 21), maxLevel=3,
                criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, .01))
            if backward is None:
                ok2 = np.zeros_like(ok1); backward = original.copy()
            fb = np.linalg.norm(backward.reshape(-1, 2) - original.reshape(-1, 2), axis=1)
            flow_good = (ok1.reshape(-1).astype(bool) & ok2.reshape(-1).astype(bool)
                         & np.isfinite(fb) & (fb <= .8) & (err1.reshape(-1) < 20))
            fabric = _cloth_mask(values['rgb'][camera])
            rotation, origin = _PUBLIC._camera_transform(values, camera)
            pixels, points, selected = [], [], []
            for i, pixel in enumerate(forward.reshape(-1, 2)):
                if not flow_good[i]:
                    self._drop(dropped, camera, 'optical_flow'); continue
                measured = _measure(values, camera, pixel, fabric)
                if measured is None:
                    self._drop(dropped, camera, 'depth_or_cloth_support'); continue
                world, z = measured
                expected_z = ((group['last_world'][i] - origin) @ rotation)[2]
                if abs(z - expected_z) > .06 or np.linalg.norm(world - group['last_world'][i]) > .06:
                    self._drop(dropped, camera, 'excessive_world_step'); continue
                pixels.append(pixel); points.append(world); selected.append(i)
            selected = np.asarray(selected, dtype=int)
            group['gray'] = gray
            group['pixels'] = np.asarray(pixels, np.float32).reshape(-1, 2)
            group['last_world'] = np.asarray(points, dtype=float).reshape(-1, 3)
            group['initial_world'] = group['initial_world'][selected]
            group['ids'] = group['ids'][selected]
        live = [g for g in self.groups.values() if len(g['pixels'])]
        if not live:
            return self._report(False, 'initial_features_lost', rejected=dropped)
        motions = np.concatenate([g['last_world'] - g['initial_world'] for g in live])
        middle = np.median(motions, axis=0)
        deviation = np.linalg.norm(motions - middle, axis=1)
        inliers = deviation <= .025
        consensus = float(inliers.mean())
        # Permanently discard inconsistent features too; never replenish a cohort.
        for group in live:
            motion = group['last_world'] - group['initial_world']
            keep = np.linalg.norm(motion - middle, axis=1) <= .025
            group['motion_consensus_fraction'] = float(keep.mean())
            self._drop(dropped, group['camera_index'], 'inconsistent_motion', (~keep).sum())
            for key in ('pixels', 'last_world', 'initial_world', 'ids'):
                group[key] = group[key][keep]
            group['meets_view_motion_thresholds'] = (
                len(group['pixels']) >= self.min_features
                and len(group['pixels'])/group['initial_count'] >= .25
                and group['motion_consensus_fraction'] >= .65)
        count = sum(len(g['pixels']) for g in live)
        retention = count / max(self.initial_count, 1)
        qualified = {camera: group for camera, group in self.groups.items()
                     if group.get('meets_view_motion_thresholds', False)}
        reliable = bool(qualified) and consensus >= .65
        # Weak fragments remain tracked for honest diagnostics, but cannot
        # supply a displacement or pool together to impersonate a reliable view.
        if reliable:
            middle = np.median(np.concatenate([g['last_world'] - g['initial_world']
                                                for g in qualified.values()]), axis=0)
        return self._report(reliable, 'consistent_fixed_feature_tracks' if reliable else 'insufficient_consistent_initial_tracks',
            middle if reliable else None, motion_consensus_fraction=consensus,
            initial_feature_retention_fraction=retention,
            reliable_source_cameras=[_PUBLIC._CAMERAS[c][0] for c in qualified] if reliable else [],
            displacement_feature_ids=[int(i) for g in qualified.values() for i in g['ids']] if reliable else [],
            rejected=dropped)
