"""Visible elongated surfaces near measured hand points, never skeletal axes.

Only public robot RGB-D, fixed camera calibration and own poses are used.
Surface-axis direction is signed from the observed hand toward a one-sided
elongated surface, retaining all three world coordinates. No insertion action
or anatomical identity follows from this geometric observation.
"""
from collections import deque
from itertools import combinations

import numpy as np

from human_targets import _validated, _camera_transform, _world_pixels, _FOCAL, _CAMERAS
from public_vision import _fabric_mask

OUTER_RADIUS = .30
SEED_RADIUS = .04
FIT_INNER_RADIUS = .05
OTHER_HAND_RADIUS = .075
NEIGHBOR_DISTANCE = .025
MAX_COMPONENT_PIXELS = 6000


def _seed_components(allowed, seeds, world_image):
    """Bounded 4-neighbor components with a metric depth-continuity test."""
    visited = np.zeros(allowed.shape, bool)
    components = []
    height, width = allowed.shape
    for sy, sx in zip(*np.where(seeds & allowed)):
        if visited[sy, sx]:
            continue
        queue = deque([(int(sy), int(sx))]); visited[sy, sx] = True
        component = []
        while queue:
            y, x = queue.popleft(); component.append((y, x))
            if len(component) > MAX_COMPONENT_PIXELS:
                return [], 'depth_connected_region_exceeds_bounded_size'
            for ny, nx in ((y-1, x), (y+1, x), (y, x-1), (y, x+1)):
                if (0 <= ny < height and 0 <= nx < width and allowed[ny, nx] and not visited[ny, nx]
                        and np.linalg.norm(world_image[ny, nx]-world_image[y, x]) <= NEIGHBOR_DISTANCE):
                    visited[ny, nx] = True; queue.append((ny, nx))
        components.append(np.asarray(component, int))
    return components, None


def _fit_surface(points, hand, other_hand):
    distance = np.linalg.norm(points-hand, axis=1)
    measured = points[(distance >= FIT_INNER_RADIUS) & (distance <= OUTER_RADIUS)]
    if len(measured) < 24:
        return None, 'no_elongated_surface_beyond_hand_neighborhood'
    center = np.mean(measured, axis=0)
    _, singular, axes = np.linalg.svd(measured-center, full_matrices=False)
    if singular[1] < 1e-6 or singular[0]/singular[1] < 3.:
        return None, 'surface_not_uniquely_elongated'
    axis = axes[0]
    if np.dot(axis, center-hand) < 0:
        axis = -axis
    axial = (measured-hand) @ axis
    span = float(np.percentile(axial, 95)-np.percentile(axial, 5))
    radial = np.linalg.norm((measured-center)-np.outer((measured-center)@axis, axis), axis=1)
    hand_line_distance = float(np.linalg.norm((hand-center)-axis*((hand-center)@axis)))
    if span < .10 or span > .30 or np.mean(axial > .025) < .9:
        return None, 'surface_is_short_or_not_one_sided_from_hand'
    if np.sqrt(np.mean(radial**2)) > .025 or np.percentile(radial, 95) > .045 or hand_line_distance > .045:
        return None, 'surface_width_or_line_residual_too_large'
    other_axial = float((other_hand-hand) @ axis)
    other_radial = float(np.linalg.norm((other_hand-center)-axis*((other_hand-center)@axis)))
    if -.02 <= other_axial <= .35 and other_radial < .06:
        return None, 'axis_also_passes_near_other_hand_identity_ambiguous'
    # The proximal marker is an actual measured surface point, not an inferred
    # elbow or an extrapolated center inside the body.
    proximal_index = int(np.argmin(np.abs(axial-np.percentile(axial, 85))))
    selected = np.arange(0, len(measured), max(1, int(np.ceil(len(measured)/48))))
    return dict(axis_world=axis.tolist(), visible_surface_centroid_world=center.tolist(),
        proximal_observed_surface_point_world=measured[proximal_index].tolist(),
        observed_span_m=span, elongation_ratio=float(singular[0]/singular[1]),
        radial_rms_m=float(np.sqrt(np.mean(radial**2))), radial_p95_m=float(np.percentile(radial, 95)),
        hand_to_line_distance_m=hand_line_distance, point_count=len(measured),
        support_points_world=measured[selected].tolist()), None


def estimate_forearm_surfaces(obs, hand_surface_points_world):
    """Return per-hand weak or multi-view-consistent local surface candidates.

    Pass ``estimate_hands(obs)['hand_points_world']`` without assigning anatomy
    labels. Single-camera evidence is retained as a weak view candidate, but
    the top-level world axis is published only for agreeing views with >=8 deg
    parallax and >=8 cm optical-center separation. Even then it is not a bone,
    elbow location, anatomical forearm axis, or permission to insert a hand.
    """
    hands = np.asarray(hand_surface_points_world, dtype=float)
    if hands.shape != (2, 3) or not np.isfinite(hands).all():
        raise ValueError('expected two measured finite hand surface points')
    values = _validated(obs, wrists=True)
    candidate_views, rejections = [[], []], [[], []]
    overlapping_hands = np.linalg.norm(hands[1]-hands[0]) < 2*OTHER_HAND_RADIUS
    for camera in (1, 2, 3, 4):
        depth = values['depth'][camera, ..., 0]
        valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < (3. if camera < 3 else 5.))
        valid &= ~_fabric_mask(values['rgb'][camera])
        v, u = np.where(valid)
        points = _world_pixels(values, camera, u, v, depth[v, u])
        world_image = np.full((256, 256, 3), np.nan)
        world_image[v, u] = points
        _, camera_origin = _camera_transform(values, camera)
        for hand_index in (0, 1):
            if overlapping_hands:
                rejections[hand_index].append(dict(camera_index=camera,
                    reasons=['overlapping_hand_neighborhoods_identity_ambiguous']))
                continue
            hand, other = hands[hand_index], hands[1-hand_index]
            distance = np.linalg.norm(points-hand, axis=1)
            allowed = np.zeros((256, 256), bool)
            allowed[v, u] = (distance <= OUTER_RADIUS) & (np.linalg.norm(points-other, axis=1) > OTHER_HAND_RADIUS)
            seeds = np.zeros_like(allowed); seeds[v, u] = distance <= SEED_RADIUS
            components, failure = _seed_components(allowed, seeds, world_image)
            candidates = []
            reasons = [failure] if failure else []
            for component in components:
                if len(component) < 24:
                    continue
                yy, xx = component.T
                component_points = world_image[yy, xx]
                # Once the small hand neighborhood is removed, two sizable
                # disconnected branches cannot establish one proximal surface.
                annulus = np.zeros_like(allowed)
                annulus[yy, xx] = np.linalg.norm(component_points-hand, axis=1) >= FIT_INNER_RADIUS
                branches, branch_failure = _seed_components(annulus, annulus, world_image)
                long_branches = [branch for branch in branches if len(branch) >= 16 and
                    np.linalg.norm(np.ptp(world_image[branch[:, 0], branch[:, 1]], axis=0)) >= .08]
                if branch_failure or len(long_branches) != 1:
                    reasons.append(branch_failure or 'multiple_or_missing_connected_proximal_surface_branches')
                    continue
                branch = long_branches[0]
                fit, reason = _fit_surface(world_image[branch[:, 0], branch[:, 1]], hand, other)
                if fit is not None:
                    candidates.append(fit)
                else:
                    reasons.append(reason)
            if len(candidates) == 1:
                fit = candidates[0]
                fit.update(camera_index=camera, source_camera=_CAMERAS[camera][0],
                           optical_center_world=camera_origin.tolist(), hand_index=hand_index,
                           axis_kind='local_visible_surface_elongation',
                           axis_sign='measured_hand_toward_one_sided_visible_proximal_surface')
                candidate_views[hand_index].append(fit)
            else:
                rejections[hand_index].append(dict(camera_index=camera,
                    reasons=['multiple_depth_connected_surface_candidates'] if len(candidates) > 1 else
                    list(dict.fromkeys(reasons or ['no_depth_continuous_surface_seed_at_hand']))))

    reports = []
    for hand_index in (0, 1):
        views = candidate_views[hand_index]
        supporting_pairs, conflicts = [], []
        for first, second in combinations(range(len(views)), 2):
            a, b = views[first], views[second]
            axis_a, axis_b = np.asarray(a['axis_world']), np.asarray(b['axis_world'])
            center_a, center_b = np.asarray(a['visible_surface_centroid_world']), np.asarray(b['visible_surface_centroid_world'])
            origin_a, origin_b = np.asarray(a['optical_center_world']), np.asarray(b['optical_center_world'])
            ray_a, ray_b = hands[hand_index]-origin_a, hands[hand_index]-origin_b
            ray_lengths = [np.linalg.norm(ray_a), np.linalg.norm(ray_b)]
            parallax = (float(np.arccos(np.clip(ray_a@ray_b/np.prod(ray_lengths), -1, 1)))
                        if min(ray_lengths) >= .05 else 0.)
            axis_angle = float(np.arccos(np.clip(axis_a@axis_b, -1, 1)))
            separation = max(np.linalg.norm((center_b-center_a)-axis_a*((center_b-center_a)@axis_a)),
                             np.linalg.norm((center_b-center_a)-axis_b*((center_b-center_a)@axis_b)))
            agrees = axis_angle <= np.deg2rad(15) and separation <= .06
            pair = dict(camera_indices=[a['camera_index'], b['camera_index']],
                        parallax_degrees=float(np.rad2deg(parallax)), optical_baseline_m=float(np.linalg.norm(origin_a-origin_b)),
                        axis_disagreement_degrees=float(np.rad2deg(axis_angle)), line_separation_m=float(separation))
            if not agrees:
                conflicts.append(pair)
            elif parallax >= np.deg2rad(8) and np.linalg.norm(origin_a-origin_b) >= .08:
                supporting_pairs.append(pair)
        strong = bool(supporting_pairs and not conflicts)
        axis = np.mean([v['axis_world'] for v in views], axis=0) if strong else None
        if axis is not None:
            axis /= np.linalg.norm(axis)
        reason = ('overlapping_hand_neighborhoods_identity_ambiguous' if overlapping_hands else
                  'consistent_surface_axes_from_parallax_views' if strong else
                  'camera_surface_axes_conflict' if conflicts else
                  'single_view_cannot_establish_consistency' if len(views) == 1 else
                  'insufficient_parallax_between_candidate_views' if views else
                  'no_unique_depth_continuous_elongated_surface')
        reports.append(dict(hand_index=hand_index, hand_surface_world=hands[hand_index].tolist(),
            status='multi_view_consistent_candidate' if strong else 'single_view_candidate' if len(views) == 1 else 'unknown',
            axis_world=None if axis is None else axis.tolist(),
            axis_kind='visible_local_surface_elongation; not internal anatomy',
            axis_sign='hand_surface_toward_visible_proximal_surface',
            confidence=.70 if strong else .30 if len(views) == 1 else 0.,
            candidate_views=views, supporting_parallax_pairs=supporting_pairs, conflicting_pairs=conflicts,
            rejected_views=rejections[hand_index], reason=reason,
            internal_skeleton_estimated=False, anatomical_axis_verified=False,
            insertion_allowed=False))
    return dict(hand_surfaces=reports, read_only=True, cameras_used=[1, 2, 3, 4],
        insertion_allowed=False, hand_identity_basis='input measured hand points and exclusion of the other hand; not anatomy labels',
        limitation='Visible geometry can belong to another thin object; folds, occlusion and missing depth cause abstention. '
                   'A consistent surface direction does not verify an internal forearm axis, elbow, sleeve fit or insertion path.')
