"""Separate far-field wrist experiment using a measured static servo baseline.

The launcher stops at dual_hold. Contact control has not been calibrated or
physically validated by this variant. Original V22 and prior variants remain.
"""
import numpy as np

from loaded_equilibrium_calibration import LoadedEquilibriumCalibration
from equilibrium_wrist_experiments import CalibratedLoadedRoll, CalibratedLoadedContactPitch
from public_vision import grasp_world, _rotation
from side_contact_policy import Policy as InteriorContactPolicy


class Policy(InteriorContactPolicy):
    VERSION = 'v23_19_equilibrium_wrist'
    METHOD = ('frozen V22; verified interior dual pickup; measured zero-command '
              'loaded equilibrium baseline; bounded far-field roll/pitch trial')
    RECALIBRATE_BEFORE_LOADED_PITCH = True
    CALIBRATION_CLASS = LoadedEquilibriumCalibration
    WRIST_PHASES = ('pair_settle_before_roll', 'pair_observe_roll',
                    'pair_settle_before_pitch', 'pair_observe_pitch')

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.wrist_global_reference = None
        self.equilibrium_handoffs = []

    def _create_wrist_handoff(self, obs):
        if self.wrist_global_reference is None:
            self.wrist_global_reference = dict(
                time=float(obs['simulation_time_s']),
                base=np.asarray(obs['base_pose_world'], float).copy(),
                grasp=np.stack([grasp_world(obs, r) for r in (0, 1)]))
        return self.CALIBRATION_CLASS(obs, self.hands,
            self.hand_observation_time, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def _create_loaded_roll(self, obs):
        return CalibratedLoadedRoll(obs, self.hands, self.hand_observation_time,
            calibration=self.wrist_calibration, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def _create_loaded_pitch(self, obs):
        return CalibratedLoadedContactPitch(obs, self.hands, self.hand_observation_time,
            calibration=self.wrist_calibration, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def __call__(self, obs):
        previous_phase = self.phase
        try:
            reference = self.wrist_global_reference
            if reference is not None and self.phase in self.WRIST_PHASES:
                base = np.asarray(obs['base_pose_world'], float)
                grasps = np.stack([grasp_world(obs, r) for r in (0, 1)])
                if (np.linalg.norm(base[:, :3]-reference['base'][:, :3], axis=1).max() > .003
                        or np.linalg.norm(grasps-reference['grasp'], axis=1).max() > .003):
                    raise ValueError('global wrist trial base or grasp drift exceeds3mm')
                for r in (0, 1):
                    relative = _rotation(base[r, 3:]) @ _rotation(reference['base'][r, 3:]).T
                    angle = np.arccos(np.clip((np.trace(relative)-1)/2, -1., 1.))
                    if angle > np.deg2rad(.25):
                        raise ValueError('global wrist trial base rotation exceeds0.25deg')
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.fail(str(error))
        action = super().__call__(obs)
        if (previous_phase in ('pair_settle_before_roll', 'pair_settle_before_pitch')
                and self.phase in ('pair_observe_roll', 'pair_observe_pitch')):
            self.equilibrium_handoffs.append(dict(stage=previous_phase,
                calibration=self.wrist_calibration, report=self.wrist_handoff_debug))
        self.debug['equilibrium_handoffs'] = self.equilibrium_handoffs
        self.debug['wrist_global_reference'] = self.wrist_global_reference
        self.debug['equilibrium_scope'] = ('Sampled public-state equilibrium calibration only; '
            'not a continuous-time rest certificate. Bias remains frozen within each wrist stage; '
            'the original3mm global base/grasp budget is not reset between wrist stages.')
        return action
