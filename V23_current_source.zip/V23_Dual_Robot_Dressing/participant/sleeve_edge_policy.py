"""Separate public-image edge-pickup hypothesis; original side grasp is retained.

The selected blue surface lies near an observed lateral boundary. This does
not establish a cuff lip, a free opening, or successful dressing.
"""
import numpy as np

from planar_sleeve_edge import estimate_planar_sleeve_edges
from sleeve_pair_policy import Policy as SleeveSidePolicy


class Policy(SleeveSidePolicy):
    VERSION = 'v23_14_sleeve_edges'
    METHOD = ('frozen V22 visual approach; observed lateral boundary inset '
              'pickup hypotheses; dual lift and bounded loaded wrist experiments')

    def _estimate_shirt(self, obs):
        # An unsupported edge proposal remains unknown; do not silently fall
        # back to the older interior patch under this experiment's name.
        return estimate_planar_sleeve_edges(obs)

    def _prepare_pair(self, obs):
        # Check the same two sides at the actual pre-contact handoff. Cached
        # flat-cloth pixels are not silently stamped as fresh boundary evidence.
        now = float(obs['simulation_time_s'])
        current = self._estimate_shirt(obs)
        if not current.get('detected') or current.get('observation_time_s') != now:
            raise ValueError('current sleeve-edge pair unavailable at pre-contact handoff: '+
                             str(current.get('reason')))
        if self.shirt.get('detected'):
            old = np.asarray([c['target_world'] for c in self.shirt['candidates']], float)
            new = np.asarray([c['target_world'] for c in current['candidates']], float)
            shift = np.linalg.norm(new-old, axis=1)
            if old.shape != (2, 3) or new.shape != (2, 3) or not np.isfinite(shift).all() or shift.max() > .03:
                raise ValueError('current sleeve-edge pair changed over 3cm before contact')
            current = dict(current, prior_to_handoff_shift_m=shift.tolist(),
                           prior_pair_observed_at_s=self.shirt_observed_at)
        self.shirt = current
        self.shirt_observed_at = now
        return super()._prepare_pair(obs)
