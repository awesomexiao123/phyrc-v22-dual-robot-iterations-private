"""Bounded wrist-view *proposals* from public observations, never an executor.

The four robot cameras can justify a small exploratory wrist scan only while
both measured grasp centers are stationary and the observed fabric is separated
from both observed hand neighborhoods. Unseen fabric/body, wrist swept volume,
attachment, and insertion clearance remain unknown. No (2,9) action is emitted.
"""
from collections import deque

import numpy as np
from scipy.spatial import cKDTree

from cooperative_transport import _snapshot
from human_targets import _validated, _world_pixels, estimate_hands
from public_vision import _fabric_mask, _rotation


def _public_clearance(obs):
    """Measure all visible cloth against actual depth samples near both hands.

    The hand detector provides only the seeds. Neither its surface point nor a
    sphere around it is treated as a complete hand shape. Missing depth and
    unobserved regions do not become free space.
    """
    values = _validated(obs, wrists=True)
    hands = estimate_hands(obs)
    centers = np.asarray(hands.get('hand_points_world'), dtype=float)
    error = hands.get('cross_view_error_m')
    if (not hands.get('detected') or centers.shape != (2, 3) or not np.isfinite(centers).all()
            or error is None or not np.isfinite(error) or error > .04
            or hands.get('confidence', 0.) < .65):
        raise ValueError('two_consistent_public_hand_surfaces_unavailable')
    cloth, surfaces = [], [[], []]
    colored, supported = 0, 0
    for camera in (1, 2, 3, 4):
        color = values['rgb'][camera]
        fabric = _fabric_mask(color)
        depth = values['depth'][camera, ..., 0]
        valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth)
                 & (depth > .03) & (depth < (3. if camera < 3 else 5.)))
        colored += int(fabric.sum()); supported += int((fabric & valid).sum())
        v, u = np.where(valid)
        world = _world_pixels(values, camera, u, v, depth[v, u])
        labels = fabric[v, u]
        cloth.append(world[labels])
        for index, hand in enumerate(centers):
            nearby = (~labels) & (np.linalg.norm(world-hand, axis=1) <= .08)
            surfaces[index].append(world[nearby])
    cloth = np.concatenate(cloth)
    surfaces = [np.concatenate(points) for points in surfaces]
    if len(cloth) < 48 or not colored:
        raise ValueError('insufficient_public_garment_depth')
    if supported/colored < .95:
        raise ValueError('visible_garment_has_unresolved_depth')
    if any(len(points) < 12 for points in surfaces):
        raise ValueError('insufficient_depth_support_around_each_hand_surface')
    # Exact nearest-neighbor distances, without NxM storage or downsampling
    # that could discard the closest observed point. Four 256x256 views bound N.
    distances = []
    for surface in surfaces:
        distances.append(float(cKDTree(surface).query(cloth, k=1, eps=0., workers=1)[0].min()))
    margin = max(.03, float(error))
    return dict(cloth=cloth, minimum_observed_distance_m=distances,
                hand_surface_sample_counts=[len(points) for points in surfaces],
                hand_points_world=centers.tolist(), cloth_sample_count=len(cloth),
                recognized_cloth_depth_fraction=supported/colored,
                measurement_margin_m=margin, required_measured_separation_m=.25+margin,
                clearance_scope='observed fabric to observed local hand surfaces only; unseen body and cloth unknown')


class CandidateActiveViewPlanner:
    """Call recommend repeatedly using fresh public observations and diagnostics.

    ``grasp_poses_world`` accepts robot-ordered (2,3) centers or (2,7) wxyz
    poses, and is checked against own robot poses. Pass the sleeve_observation
    report computed for that same observation. Stable centers/closed intent are
    not evidence of cloth attachment. The budget counts *measured* absolute
    pitch/roll travel across both robots, including reversals; proposals alone
    spend no motion budget and repeated calls retain the same pending target.
    """
    STEP = np.deg2rad(5.)
    BUDGET = np.deg2rad(10.)

    def __init__(self):
        self.history = deque(maxlen=32)
        self.last_time = None
        self.last_wrist = None
        self.initial_yaw = None
        self.measured_scan_travel = 0.
        self.pending = None
        self.completed_scans = 0
        self.robot_scan_counts = np.zeros(2, int)
        self.failure = None

    def _result(self, reason, evidence=None, candidate=None):
        return dict(recommendation='wrist_scan_candidate' if candidate else 'hold',
            reason=reason, candidate=None if candidate is None else dict(candidate),
            pending_candidate=None if self.pending is None else dict(self.pending),
            measured_cumulative_scan_degrees=float(np.rad2deg(self.measured_scan_travel)),
            completed_scans=self.completed_scans, failure=self.failure,
            observation_evidence=evidence or {}, proposed_action_only=True,
            motion_executor_included=False, attachment_verified=False,
            collision_free_verified=False, insertion_allowed=False,
            constraints=dict(maximum_step_degrees=5., maximum_cumulative_degrees=10.,
                maximum_angular_speed_rad_s=.05, both_grippers_must_remain_closed=True,
                other_wrist_and_bases_must_hold=True,
                grasp_center_feedback_compensation_required=True,
                maximum_grasp_center_drift_m=.005,
                current_public_clearance_recheck_required=True,
                executor_must_check_wrist_joint_limits_and_swept_robot_cloth_body_clearance=True,
                no_head_camera_action=True),
            unknowns=['unobserved garment and body surfaces', 'actual cloth attachment',
                      'effect of wrist rotation on soft fabric', 'full hand shape and sleeve identity',
                      'wrist swept volume and grasp compensation feasibility'])

    def recommend(self, obs, grasp_poses_world, sleeve_report):
        if self.failure:
            return self._result(self.failure)
        try:
            bases, grasps, _, tilt, now = _snapshot(obs)
            supplied = np.asarray(grasp_poses_world, dtype=float)
            if supplied.shape not in ((2, 3), (2, 7)) or not np.isfinite(supplied).all():
                raise ValueError('invalid_robot_ordered_public_grasp_poses')
            if np.max(np.linalg.norm(supplied[:, :3]-grasps, axis=1)) > .002:
                raise ValueError('supplied_grasps_disagree_with_public_own_poses')
            if supplied.shape == (2, 7):
                local = np.asarray(obs['grasp_pose_base'])
                for robot in (0, 1):
                    expected = _rotation(bases[robot, 3:]) @ _rotation(local[robot, 3:])
                    if np.linalg.norm(_rotation(supplied[robot, 3:])-expected) > .01:
                        raise ValueError('supplied_grasp_orientation_disagrees_with_public_pose')
            joints = np.asarray(obs['joint_position'], dtype=float)
            if joints.shape != (2, 13) or not np.isfinite(joints).all():
                raise ValueError('measured_public_joint_positions_unavailable')
            wrist = joints[:, 9:11].copy()
            if self.last_time is not None and now < self.last_time-1e-8:
                self.failure = 'public_clock_moved_backwards'
                return self._result(self.failure)
            if self.last_wrist is not None:
                change = wrist-self.last_wrist
                self.measured_scan_travel += float(np.abs(change).sum())
                if self.pending is not None:
                    permitted = np.zeros((2, 2), bool)
                    permitted[self.pending['robot'], self.pending['joint_position_index']-9] = True
                    if np.max(np.abs(change[~permitted])) > np.deg2rad(.5):
                        self.failure = 'unplanned_other_wrist_motion_during_scan'
            self.last_wrist = wrist.copy()
            if self.initial_yaw is None:
                self.initial_yaw = joints[:, 8].copy()
            if self.measured_scan_travel > self.BUDGET+1e-6:
                self.failure = 'measured_cumulative_wrist_travel_exceeded_10_degrees'
            if self.failure:
                return self._result(self.failure)
            if np.max(np.abs(joints[:, 8]-self.initial_yaw)) > np.deg2rad(.5):
                raise ValueError('unplanned_wrist_yaw_motion')
            closed = np.asarray(obs['gripper_close_command']).reshape(2)
            if not closed.astype(bool).all():
                raise ValueError('both_grippers_are_not_closed')
            gap = np.asarray(obs['fingertip_origin_distance'], dtype=float).reshape(2)
            if not np.isfinite(gap).all() or np.max(gap) > .08:
                raise ValueError('fingertip_gap_does_not_support_closed_state')
            if np.max(tilt) > .065 or np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
                raise ValueError('robot_tilt_or_base_separation_guard')
            regions = sleeve_report['grasp_regions']
            if len(regions) != 2:
                raise ValueError('two_current_grasp_region_diagnostics_required')
            for robot, region in enumerate(regions):
                if (region.get('grasp_index') != robot
                        or np.linalg.norm(np.asarray(region['grasp_world'])-grasps[robot]) > .005):
                    raise ValueError('sleeve_report_grasp_identity_or_pose_is_stale')
                if region.get('observed_cloth_point_count', 0) < 24:
                    raise ValueError('both_grasp_regions_need_observed_fabric')
            if self.last_time is not None and now-self.last_time > .15:
                self.history.clear()
            if self.last_time is None or now > self.last_time+1e-8:
                self.history.append((now, grasps.copy(), bases[:, :3].copy(), wrist.copy()))
            self.last_time = now
            while len(self.history) > 1 and now-self.history[1][0] >= .5-1e-8:
                self.history.popleft()
            if not self.history:
                raise ValueError('public_pose_history_unavailable')
            position_spread = max(float(np.max(np.linalg.norm(row[1]-grasps, axis=1))) for row in self.history)
            base_spread = max(float(np.max(np.linalg.norm(row[2]-bases[:, :3], axis=1))) for row in self.history)
            if max(position_spread, base_spread) > .004:
                self.history.clear()
                raise ValueError('grasp_centers_or_bases_are_not_stable')
            evidence = _public_clearance(obs)
            cloth = evidence.pop('cloth')
            local_counts = [int(np.count_nonzero(np.linalg.norm(cloth-grasp, axis=1) <= .12)) for grasp in grasps]
            evidence['measured_cloth_samples_within_12cm_of_each_grasp'] = local_counts
            evidence['stable_observation_span_s'] = now-self.history[0][0]
            if min(local_counts) < 24:
                raise ValueError('fresh_depth_does_not_support_both_grasp_regions')
            if min(evidence['minimum_observed_distance_m']) < evidence['required_measured_separation_m']:
                return self._result('observed_garment_too_close_to_a_hand_surface', evidence)
            if all(region.get('opening_visible_in_rgbd') for region in regions):
                return self._result('both_opening_candidates_visible_resolve_identity_before_more_motion', evidence)
            if len(self.history) < 6 or now-self.history[0][0] < .5-1e-8:
                return self._result('waiting_for_half_second_of_measured_stable_closed_grasps', evidence)
            if self.pending is not None:
                robot, joint = self.pending['robot'], self.pending['joint_position_index']-9
                remaining = self.pending['target_angle_rad']-wrist[robot, joint]
                start = self.pending['start_angle_rad']
                goal = self.pending['target_angle_rad']
                if np.max(np.linalg.norm(grasps-np.asarray(self.pending['grasp_centers_at_proposal_world']), axis=1)) > .005:
                    self.failure = 'pending_scan_grasp_compensation_drift_exceeds_5mm'
                    return self._result(self.failure, evidence)
                if abs(remaining) > self.BUDGET-self.measured_scan_travel+np.deg2rad(.01):
                    self.failure = 'pending_scan_would_exceed_remaining_cumulative_budget'
                    return self._result(self.failure, evidence)
                if not min(start, goal)-np.deg2rad(.5) <= wrist[robot, joint] <= max(start, goal)+np.deg2rad(.5):
                    self.failure = 'pending_scan_angle_left_its_bounded_interval'
                    return self._result(self.failure, evidence)
                if abs(remaining) <= np.deg2rad(.25):
                    self.completed_scans += 1; self.robot_scan_counts[robot] += 1
                    self.pending = None; self.history.clear()
                    return self._result('scan_target_observed_wait_for_new_stable_view', evidence)
                # This is the same absolute proposal, not an additional 5 deg.
                return self._result('same_pending_scan_requires_independent_feedback_executor', evidence, self.pending)
            wrist_spread = max(float(np.max(np.abs(row[3]-wrist))) for row in self.history)
            if len(self.history) < 6 or now-self.history[0][0] < .5-1e-8 or wrist_spread > .004:
                return self._result('waiting_for_half_second_of_measured_stable_closed_grasps', evidence)
            remaining_budget = self.BUDGET-self.measured_scan_travel
            if remaining_budget < np.deg2rad(.5) or self.completed_scans >= 2:
                return self._result('bounded_scan_budget_finished_reassess_or_regrasp', evidence)
            eligible = [r for r in (0, 1) if not regions[r].get('opening_visible_in_rgbd')]
            robot = min(eligible, key=lambda r: (self.robot_scan_counts[r], r))
            # Alternating axes is a finite exploration schedule, not an inferred
            # cloth Jacobian or a promise that the view will improve.
            axis_index = self.completed_scans % 2
            angle = wrist[robot, axis_index]
            direction = -1. if angle > 0 else 1.
            step = direction*min(self.STEP, remaining_budget)
            self.pending = dict(robot=robot, axis=('pitch', 'roll')[axis_index],
                action_index=(6, 7)[axis_index], joint_position_index=(9, 10)[axis_index],
                start_angle_rad=float(angle), target_angle_rad=float(angle+step),
                proposed_delta_rad=float(step), proposed_delta_degrees=float(np.rad2deg(step)),
                grasp_centers_at_proposal_world=grasps.tolist(),
                direction_basis='bounded exploration toward joint zero when possible; improvement unknown',
                expected_view_improvement_verified=False)
            return self._result('small_wrist_scan_candidate_after_public_observation_checks', evidence, self.pending)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.history.clear()
            return self._result(str(error))
