"""Experimental sleeve-side acquisition using V22 approach plus public geometry.

The frozen network approaches the garment, then rules redirect both robots to
observed sleeve-side fabric patches before the first close. These patches are
not verified openings. Neither this variant nor the transport stage claims
complete dressing. No scene truth or evaluator state enters the actor.
"""
import numpy as np

import cooperative_policy as cooperative
from cloth_patch_tracker import ClothPatchTracker
from navigation import guard_base_velocity
from planar_navigation import plan_base_route, validate_base_route_segment
from planar_shirt import estimate_planar_shirt
from public_vision import _rotation
from loaded_roll_observation import LoadedRollObservation
from loaded_pitch_observation import LoadedPitchObservation
from loaded_wrist_handoff import LoadedWristHandoff


class Policy(cooperative.Policy):
    VERSION = 'v23_13_sleeve_sides'
    METHOD = 'frozen V22 visual approach; public planar sleeve-side hypotheses; two-sided approach and synchronous lift'
    SINGLE_HELPER_LIFT = False
    ALIGN_SLEEVE_SIDE_PAIR = True
    USE_DISTAL_SURFACE_STAGING = True
    ENABLE_OBSERVED_OPENING_APPROACH = True
    ENABLE_FAR_CLOTH_ROLL_OBSERVATION = True
    ENABLE_FAR_CLOTH_PITCH_PILOT = True
    STOP_WRIST_EXPERIMENT_ON_OPENING_DIAGNOSTICS = True
    REQUIRE_COMPLETED_WRIST_EXPERIMENTS = False
    REQUIRE_PASSIVE_WRIST_HANDOFF = False
    RECALIBRATE_BEFORE_LOADED_PITCH = False
    ENABLE_DEPTH_CAVITY_DIAGNOSTICS = True
    # Longer two-sided route. Only valid for this stationary mannequin task;
    # retained coordinates remain actual earlier observations, not refreshed.
    # The pinned official mannequin is static within an episode; see
    # validation/stationary_mannequin_review.json. Probe geometry stays fresh.
    HAND_CACHE_MAX_AGE_S = 300.
    # Leave more table-edge clearance while staying within the published
    # telescoping arm range (the initial grasp X is about 0.47 m).
    APPROACH_REACH_M = .76
    ROUTE_CLEARANCE_M = .12
    NAVIGATION_SPEED_MPS = .05
    CONTACT_OFFSET_M = .024  # Frozen V22's flat-surface refine_descend height.

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.shirt = {}
        self.shirt_observed_at = None
        self.pair_targets = None
        self.pair_candidate_indices = None
        self.pair_base_goals = None
        self.pair_yaws = None
        self.routes = None
        self.route_indices = [1, 1]
        self.pair_trackers = [ClothPatchTracker(), ClothPatchTracker()]
        self.pair_tracks = [{}, {}]
        self.pair_tracks_observed_at = None
        self.pair_lift = None
        self.pair_lift_origin = None
        self.test_lift_visibility_lost = 0
        self.pair_raise_precondition = {}
        self.navigation_debug = []
        self.navigation_blocked_steps = [0, 0]
        self.navigation_slow_steps = [0, 0]
        self.route_replans = [0, 0]
        self.navigation_progress_position = None
        self.navigation_progress_time = None
        self.handoff_done = False
        self.phase_started_at = None
        self.descent_alignment_paused = False
        self.descent_alignment_stable = 0
        self.wrist_pitch_goal = None
        self.wrist_hold_centers = None
        self.loaded_roll = None
        self.loaded_roll_debug = {}
        self.loaded_pitch = None
        self.loaded_pitch_debug = {}
        self.wrist_handoff = None
        self.wrist_handoff_debug = {}
        self.wrist_calibration = None

    def _create_wrist_handoff(self, obs):
        return LoadedWristHandoff(obs, self.hands,
            self.hand_observation_time, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def _create_loaded_roll(self, obs):
        return LoadedRollObservation(obs, self.hands,
            self.hand_observation_time, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def _estimate_shirt(self, obs):
        return estimate_planar_shirt(obs)

    def _create_loaded_pitch(self, obs):
        return LoadedPitchObservation(obs, self.hands,
            self.hand_observation_time, stationary_human=True,
            max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def _cache_scene(self, obs):
        if self.step == 1 or self.step % 20 == 0:
            hands = cooperative.estimate_hands(obs)
            if hands.get('detected'):
                points = np.asarray(hands['hand_points_world'])
                old = np.asarray(self.hands.get('hand_points_world', []))
                agrees = not self.hands.get('detected') or min(
                    np.max(np.linalg.norm(points-old, axis=1)), np.max(np.linalg.norm(points[::-1]-old, axis=1))) < .12
                if agrees:
                    self.hands = hands
                    self.hand_observation_time = float(obs['simulation_time_s'])
                    self.forearm_surfaces = cooperative.estimate_forearm_surfaces(obs, points)
                    self.forearm_surfaces['observation_time_s'] = self.hand_observation_time
            if not self.handoff_done:
                shirt = self._estimate_shirt(obs)
                if shirt.get('detected'):
                    self.shirt = shirt
                    self.shirt_observed_at = float(obs['simulation_time_s'])
            elif self.phase in ('pair_close', 'pair_test_lift', 'pair_raise'):
                self.sleeve_observability = self.observe_sleeves(
                    obs, np.stack([cooperative.grasp_world(obs, r) for r in (0, 1)]))

    def _prepare_pair(self, obs):
        now = float(obs['simulation_time_s'])
        if not self.shirt.get('detected') or self.shirt_observed_at is None or now-self.shirt_observed_at > 30:
            raise ValueError('no recent observed planar sleeve-side pair before contact')
        if np.asarray(obs['gripper_close_command']).reshape(2).any():
            raise ValueError('sleeve-side redirection must occur before either gripper closes')
        candidates = self.shirt['candidates']
        points = np.array([c['target_world'] for c in candidates], dtype=float)
        if (points.shape != (2, 3) or not np.isfinite(points).all() or
                not .30 < np.linalg.norm(points[1]-points[0]) < 1. or
                np.linalg.norm(points[1, :2]-points[0, :2]) < .25):
            raise ValueError('invalid observed sleeve-side fabric pair')
        axis = points[1, :2]-points[0, :2]
        axis /= np.linalg.norm(axis)
        yaw_for_candidate = [float(np.arctan2(axis[1], axis[0])),
                             float(np.arctan2(-axis[1], -axis[0]))]
        bases = np.asarray(obs['base_pose_world'])
        grip = np.asarray(obs['grasp_pose_base'])
        options = []
        for assignment in ((0, 1), (1, 0)):
            goals, yaws = [], []
            for robot, candidate in enumerate(assignment):
                yaw = yaw_for_candidate[candidate]
                c, s = np.cos(yaw), np.sin(yaw)
                offset = np.array([c*self.APPROACH_REACH_M-s*grip[robot, 1],
                                   s*self.APPROACH_REACH_M+c*grip[robot, 1]])
                goals.append(points[candidate, :2]-offset); yaws.append(yaw)
            cost = np.linalg.norm(np.asarray(goals)-bases[:, :2], axis=1).sum()
            options.append((cost, assignment, goals, yaws))
        _, assignment, goals, yaws = min(options, key=lambda entry: entry[0])
        self.pair_candidate_indices = list(assignment)
        self.pair_targets = points[list(assignment)]
        self.pair_base_goals = np.asarray(goals)
        self.pair_yaws = np.asarray(yaws)
        self.active = int(self.baseline.active)
        self.helper = 1-self.active
        self.handoff_done = True
        self.change('pair_clear_raise')
        self.phase_started_at = now

    def _begin_routes(self, obs):
        self.routes = [plan_base_route(obs, r, self.pair_base_goals[r],
                       execution_clearance_m=self.ROUTE_CLEARANCE_M) for r in (0, 1)]
        if not all(route['feasible'] for route in self.routes):
            raise ValueError('no public-depth route to both sleeve-side approach poses: ' +
                             '; '.join(route['reason'] for route in self.routes))
        self.route_indices = [1, 1]
        self.navigation_progress_position = np.asarray(obs['base_pose_world'])[:, :2].copy()
        self.navigation_progress_time = np.full(2, float(obs['simulation_time_s']))
        self.change('pair_navigate')

    def _replace_route(self, obs, robot):
        if self.route_replans[robot] >= 4:
            raise ValueError('sleeve-side route repeatedly blocked for robot '+str(robot))
        route = plan_base_route(obs, robot, self.pair_base_goals[robot],
            execution_clearance_m=self.ROUTE_CLEARANCE_M)
        if not route['feasible']:
            raise ValueError('new observed obstacle blocks sleeve-side route: '+route['reason'])
        self.routes[robot] = route
        self.route_indices[robot] = 1
        self.route_replans[robot] += 1
        self.navigation_blocked_steps[robot] = self.navigation_slow_steps[robot] = 0

    @staticmethod
    def _track_has_evidence(report):
        displacement = np.asarray(report.get('median_displacement_world'), dtype=float)
        return bool(report.get('reliable') and displacement.shape == (3,) and np.isfinite(displacement).all())

    @staticmethod
    def _validate_common_lift(obs, worlds, rise):
        """Own measured lift reach with fixed wrist/arm and a 15 mm joint margin."""
        points = np.asarray(worlds, dtype=float)
        joints = np.asarray(obs['joint_position'], dtype=float)
        bases = np.asarray(obs['base_pose_world'], dtype=float)
        local_grasps = np.asarray(obs['grasp_pose_base'], dtype=float)
        if (points.shape != (2, 3) or joints.shape != (2, 13) or bases.shape != (2, 7)
                or local_grasps.shape != (2, 7) or not all(np.isfinite(item).all()
                for item in (points, joints, bases, local_grasps)) or not np.isfinite(rise)):
            raise ValueError('invalid public own pose or joint data before paired lift')
        rzz = np.array([_rotation(base[3:])[2, 2] for base in bases])
        for grasp in local_grasps:
            _rotation(grasp[3:])  # Validate the complete supplied own pose.
        measured = np.stack([cooperative.grasp_world(obs, r) for r in (0, 1)])
        if np.max(np.linalg.norm(points-measured, axis=1)) > 1e-6:
            raise ValueError('paired lift world grasps do not match current public own poses')
        if np.any(rzz < np.cos(.065)):
            raise ValueError('paired lift base tilt exceeds reach assumption')
        q = joints[:, 3]
        if np.any(q < -1e-6) or np.any(q > 1.2+1e-6):
            raise ValueError('paired lift current joint outside own 0..1.2m range')
        shifts = rzz[:, None]*(np.array([.015, 1.185])[None, :]-q[:, None])
        common = np.array([shifts[:, 0].max(), shifts[:, 1].min()])
        if common[0] > common[1]+1e-8 or rise < common[0]-1e-8 or rise > common[1]+1e-8:
            raise ValueError('requested paired lift exceeds common own lift reach with 15mm margin')
        return dict(requested_common_vertical_shift_m=float(rise),
            common_vertical_shift_interval_m=common.tolist(),
            reachable_midpoint_z_interval_m=(points[:, 2].mean()+common).tolist(),
            predicted_lift_joint_positions_m=(q+rise/rzz).tolist(), lift_joint_margin_m=.015,
            source='public own grasp/base pose and joint_position[:,3]; static own lift limits 0..1.2m',
            wrist_and_arm_held=True, requested_height_clamped=False)

    def _prepare_hand_height_raise(self, obs, worlds):
        now = float(np.asarray(obs['simulation_time_s']).item())
        stamp = self.hand_observation_time
        if (stamp is None or not np.isfinite([now, stamp]).all()
                or not 0 <= now-stamp <= self.HAND_CACHE_MAX_AGE_S):
            raise ValueError('measured hand height is missing, stale or from future before paired raise')
        hands = np.asarray(self.hands.get('hand_points_world'), dtype=float)
        if (not self.hands.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all()
                or not .06 <= np.linalg.norm(hands[1]-hands[0]) <= 1.2):
            raise ValueError('no valid measured mannequin hand pair for paired garment lift')
        height = float(hands[:, 2].mean())
        rise = max(0., height-float(np.mean(worlds[:, 2])))
        if rise > .60:
            raise ValueError('observed hand height requires more than bounded 0.60m paired raise')
        self.pair_raise_precondition = self._validate_common_lift(obs, worlds, rise)
        self.pair_raise_precondition.update(observed_hand_height_m=height,
            hand_observation_time_s=float(stamp), hand_observation_age_s=now-stamp)
        return rise

    def _finish_pair(self, obs, action):
        if self.failure:
            action = np.zeros((2, 9), np.float32)
        action = np.clip(action, -1, 1).astype(np.float32)
        if not np.isfinite(action).all() or action.shape != (2, 9):
            self.fail('invalid sleeve-side action')
            action = np.zeros((2, 9), np.float32)
        self.previous_action = action.copy()
        self.debug = dict(version=self.VERSION, method=self.METHOD, step=self.step,
            phase=self.phase, phase_steps=self.phase_steps, failure=self.failure,
            active_robot=self.active, helper_robot=self.helper, idle_mode=self.phase,
            parent_debug=self.baseline.debug, initial_planar_shirt=self.shirt,
            sleeve_side_targets_world=self.pair_targets, approach_base_goals_world=self.pair_base_goals,
            pair_candidate_indices=self.pair_candidate_indices,
            routes=self.routes, navigation=self.navigation_debug, fixed_feature_tracks=self.pair_tracks,
            fixed_feature_tracks_observed_at_s=self.pair_tracks_observed_at,
            fixed_feature_tracks_scope='4cm test-lift evidence; not refreshed during later transport',
            test_lift_visibility_lost_frames=self.test_lift_visibility_lost,
            pair_raise_precondition=self.pair_raise_precondition,
            route_replans=self.route_replans, route_indices=self.route_indices,
            navigation_slow_steps=self.navigation_slow_steps,
            descent_alignment_paused=self.descent_alignment_paused,
            unloaded_wrist_pitch_goal_rad=self.wrist_pitch_goal,
            human_hand_estimate=self.hands, hand_observation_time_s=self.hand_observation_time,
            public_forearm_surface_candidates=self.forearm_surfaces,
            visual_dual_grasp_candidate=self.visual_dual_grasp_candidate,
            synchronous_transport=self.transport_debug, checkpoint_is_frozen=True,
            sleeve_observability=self.sleeve_observability,
            loaded_roll_observation=self.loaded_roll_debug,
            loaded_pitch_observation=self.loaded_pitch_debug,
            loaded_wrist_handoff=self.wrist_handoff_debug,
            new_network_training=False, complete_dressing_claimed=False,
            sleeve_openings_verified=False)
        return action

    def __call__(self, obs):
        if self.handoff_done and self.phase in ('dual_hold', 'dual_position_before_hands', 'dual_align_hand_span', 'await_sleeve_geometry', 'observed_sleeve_approach', 'await_sleeve_entry'):
            action = super().__call__(obs)
            self.debug['loaded_roll_observation'] = self.loaded_roll_debug
            self.debug['loaded_pitch_observation'] = self.loaded_pitch_debug
            self.debug['loaded_wrist_handoff'] = self.wrist_handoff_debug
            return action
        self.step += 1
        self.phase_steps += 1
        action = np.zeros((2, 9), np.float32)
        hard_hold = [False, False]
        constrained_motion = False
        try:
            self._cache_scene(obs)
            if self.phase == 'stopped':
                return self._finish_pair(obs, action)
            if not self.handoff_done:
                action = self.baseline(obs)
                if self.baseline.failure:
                    raise ValueError('baseline: '+self.baseline.failure)
                pickup = self.baseline.parent.pickup
                if pickup.phase == 'refine_raise':
                    if pickup.debug.get('executed_phase') != 'neural_approach':
                        raise ValueError('missed exact pre-contact sleeve-side handoff')
                    self._prepare_pair(obs)
                    action[:] = 0
                    action[:, 8] = -1
                return self._finish_pair(obs, action)
            poses = np.asarray(obs['base_pose_world'])
            grips = np.asarray(obs['grasp_pose_base'])
            yaw, tilt = cooperative.yaw_tilt(poses)
            if np.max(tilt) > .065 or np.linalg.norm(poses[0, :2]-poses[1, :2]) < .60:
                raise ValueError('sleeve-side base tilt or pair spacing guard')
            closed = np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
            worlds = np.stack([cooperative.grasp_world(obs, r) for r in (0, 1)])
            action[:, 8] = -1 if self.phase not in ('pair_close', 'pair_test_lift', 'pair_raise', 'pair_settle_before_roll', 'pair_settle_before_pitch', 'pair_observe_roll', 'pair_observe_pitch') else 1
            if self.phase in ('pair_clear_raise', 'pair_clear_retract', 'pair_survey'):
                # Continue only the original idle visual observer while both
                # grippers remain open. The pickup network no longer runs.
                action[self.helper, :3] = self.baseline._observe_idle(obs)
            if self.phase == 'pair_clear_raise':
                error = self.pair_targets[:, 2]+.25-worlds[:, 2]
                action[:, 3] = np.clip(1.8*error, -.07, .07)/1.54
                if np.max(np.abs(error)) < .015:
                    # The trained approach pitched only its active wrist.
                    # Copy that observed unloaded contact posture to the helper
                    # while still well above the table, before either closes.
                    joints = np.asarray(obs['joint_position'])
                    self.wrist_pitch_goal = float(joints[self.active, 9])
                    if not .2 <= self.wrist_pitch_goal <= 1.10:
                        raise ValueError('V22 observed contact wrist pitch is outside downward posture range')
                    self.wrist_hold_centers = worlds.copy()
                    self.change('pair_set_wrist')
                    hard_hold = [True, True]
            elif self.phase == 'pair_set_wrist':
                constrained_motion = True
                if closed.any():
                    raise ValueError('unloaded wrist alignment requires both grippers open')
                if self.wrist_hold_centers is None or self.wrist_pitch_goal is None:
                    raise ValueError('unloaded wrist alignment has no measured reference')
                if np.min(worlds[:, 2]-self.pair_targets[:, 2]) < .17:
                    raise ValueError('unloaded wrist alignment lost clearance above observed cloth')
                joints = np.asarray(obs['joint_position'])
                pitch_error = self.wrist_pitch_goal-joints[:, 9]
                errors = [self.track_grasp(obs, action, r, self.wrist_hold_centers[r],
                          speed=.04, allow_base=False) for r in (0, 1)]
                action[:, 6] = np.clip(1.8*pitch_error, -.15, .15)/5.5
                self.stable = self.stable+1 if (np.max(np.abs(pitch_error)) < .005 and
                    np.max(np.abs(np.asarray(errors)[:, [0, 2]])) < .008) else 0
                if self.stable >= 10:
                    self.change('pair_clear_retract')
                    hard_hold = [True, True]
            elif self.phase == 'pair_clear_retract':
                action[:, 4] = np.clip(1.8*(.48-grips[:, 0]), -.06, .06)/1.21
                if np.max(np.abs(grips[:, 0]-.48)) < .015:
                    self.change('pair_survey')
            elif self.phase == 'pair_survey':
                recent = self.hand_observation_time is not None and float(obs['simulation_time_s'])-self.hand_observation_time < 10
                if self.hands.get('detected') and recent and self.baseline.mode == 'view_hold':
                    self._begin_routes(obs)
                    action[:, :8] = 0
                    hard_hold = [True, True]
            elif self.phase == 'pair_navigate':
                constrained_motion = True
                reached = []
                self.navigation_debug = []
                for r in (0, 1):
                    route = np.asarray(self.routes[r]['waypoints_world_xy'])
                    index = min(self.route_indices[r], len(route)-1)
                    delta = route[index]-poses[r, :2]
                    # Settle close to each bend instead of cutting a corner
                    # 35mm early. The wider planning margin absorbs this 5mm
                    # arrival tolerance; the live depth guard still applies.
                    if np.linalg.norm(delta) < .005 and index < len(route)-1:
                        check = validate_base_route_segment(obs, r, poses[r, :2], route[index+1])
                        if not check['feasible']:
                            self._replace_route(obs, r)
                            hard_hold[r] = True
                            reached.append(False)
                            self.navigation_debug.append(dict(reason='replanned_observed_corner', segment_check=check))
                            continue
                        self.route_indices[r] = index+1
                        delta = route[index+1]-poses[r, :2]
                    # The guard predicts 1.5 seconds of constant velocity. Do
                    # not project beyond this waypoint before the planned turn.
                    velocity = cooperative.bounded(delta/1.5, self.NAVIGATION_SPEED_MPS)
                    c, s = np.cos(yaw[r]), np.sin(yaw[r])
                    body = np.array([c*velocity[0]+s*velocity[1], -s*velocity[0]+c*velocity[1]])
                    guarded = guard_base_velocity(obs, r, body, max_speed=self.NAVIGATION_SPEED_MPS)
                    self.navigation_debug.append(guarded)
                    action[r, :2] = np.asarray(guarded['body_velocity_xy'])/.616
                    hard_hold[r] = np.linalg.norm(guarded['body_velocity_xy']) < 1e-8
                    at_goal = np.linalg.norm(poses[r, :2]-self.pair_base_goals[r]) < .025
                    reached.append(at_goal)
                    blocked = hard_hold[r] and np.linalg.norm(body) > .005 and not at_goal
                    self.navigation_blocked_steps[r] = self.navigation_blocked_steps[r]+1 if blocked else 0
                    effective_scale = np.linalg.norm(guarded['body_velocity_xy'])/max(np.linalg.norm(body), 1e-9)
                    # Check early, while the start can still admit a wider
                    # route. A tangent .12m path legitimately gives scale .50,
                    # so slowdown alone is not grounds to replace that path.
                    too_slow = (effective_scale < .60 and np.linalg.norm(body) > .005 and not at_goal
                        and guarded.get('reason') != 'unknown_direction_limited_speed')
                    self.navigation_slow_steps[r] = self.navigation_slow_steps[r]+1 if too_slow else 0
                    now = float(obs['simulation_time_s'])
                    if self.navigation_progress_position is not None:
                        if np.linalg.norm(poses[r, :2]-self.navigation_progress_position[r]) > .01:
                            self.navigation_progress_position[r] = poses[r, :2]
                            self.navigation_progress_time[r] = now
                        if not at_goal and now-self.navigation_progress_time[r] > 12:
                            raise ValueError('sleeve-side route made no measured progress for robot '+str(r))
                    replan = self.navigation_blocked_steps[r] >= 30
                    if not replan and self.navigation_slow_steps[r] >= 20:
                        endpoint = route[min(self.route_indices[r], len(route)-1)]
                        check = validate_base_route_segment(obs, r, poses[r, :2], endpoint,
                            clearance_m=self.ROUTE_CLEARANCE_M)
                        guarded['slow_route_segment_check'] = check
                        replan = not check['feasible']
                        self.navigation_slow_steps[r] = 0
                    if replan:
                        self._replace_route(obs, r)
                        hard_hold[r] = True
                self.stable = self.stable+1 if all(reached) else 0
                if self.stable >= 10:
                    self.change('pair_face_cloth')
                    hard_hold = [True, True]
            elif self.phase == 'pair_face_cloth':
                errors = np.array([cooperative.wrapped_angle(self.pair_yaws[r]-yaw[r]) for r in (0, 1)])
                action[:, 2] = np.clip(1.2*errors, -.20, .20)/2.86
                self.stable = self.stable+1 if np.max(np.abs(errors)) < .008 else 0
                if self.stable >= 10:
                    self.change('pair_pregrasp')
            elif self.phase in ('pair_pregrasp', 'pair_touch'):
                # Both phases own their bounded commands. Zero base commands
                # do not hold measured XY in the real simulator: v08 drifted
                # 7.65mm sideways in 3.35s while descending. Use fresh feedback
                # at reduced speed, never inherited smoothed side commands.
                constrained_motion = True
                cloud = np.asarray(cooperative.cloth_cloud(obs)['world_points'])
                support = [len(cloud) and np.min(np.linalg.norm(cloud-self.pair_targets[r], axis=1)) < .04 for r in (0, 1)]
                if not all(support):
                    hard_hold = [True, True]
                    self.lost += 1
                    if self.lost >= 40:
                        raise ValueError('original sleeve-side fabric locations no longer visibly supported')
                else:
                    self.lost = 0
                offset = .12 if self.phase == 'pair_pregrasp' else self.CONTACT_OFFSET_M
                errors = [self.track_grasp(obs, action, r, self.pair_targets[r]+[0, 0, offset],
                          .035 if self.phase == 'pair_pregrasp' else .012, allow_base=False) for r in (0, 1)]
                lateral_error = max(abs(e[1]) for e in errors)
                if self.phase == 'pair_pregrasp':
                    if lateral_error > .06:
                        raise ValueError('sleeve-side lateral alignment exceeds local correction range')
                elif lateral_error > .010:
                    raise ValueError('sleeve-side lateral alignment drifted during contact descent')
                elif max(abs(e[0]) for e in errors) > .015:
                    raise ValueError('sleeve-side forward alignment displaced during contact descent')
                side_speed = .01 if self.phase == 'pair_pregrasp' else .005
                self.navigation_debug = []
                for r in (0, 1):
                    velocity = np.array([0., np.clip(1.2*errors[r][1], -side_speed, side_speed)])
                    guarded = guard_base_velocity(obs, r, velocity, max_speed=side_speed)
                    self.navigation_debug.append(guarded)
                    action[r, :2] = np.asarray(guarded['body_velocity_xy'])/.616
                    if np.linalg.norm(velocity) > .001 and np.linalg.norm(guarded['body_velocity_xy']) < 1e-8:
                        hard_hold[r] = True
                if self.phase == 'pair_touch':
                    if lateral_error > .004:
                        self.descent_alignment_paused = True
                        self.descent_alignment_stable = 0
                    if self.descent_alignment_paused:
                        self.descent_alignment_stable = self.descent_alignment_stable+1 if lateral_error < .003 else 0
                        if self.descent_alignment_stable >= 5:
                            self.descent_alignment_paused = False
                    if self.descent_alignment_paused:
                        action[:, 3:5] = 0
                    if any(hard_hold):
                        hard_hold = [True, True]
                tolerance = .008 if self.phase == 'pair_pregrasp' else .010
                aligned = lateral_error < .003 and not self.descent_alignment_paused
                self.stable = self.stable+1 if all(support) and aligned and max(np.linalg.norm(e) for e in errors) < tolerance else 0
                if self.stable >= 10:
                    self.change('pair_touch' if self.phase == 'pair_pregrasp' else 'pair_close')
            elif self.phase == 'pair_close':
                if closed.all() and np.min(self.execution.stable) >= 30:
                    self.pair_lift_origin = worlds.copy()
                    self.pair_tracks = [self.pair_trackers[r].reset(obs, worlds[r], radius=.12) for r in (0, 1)]
                    self.pair_tracks_observed_at = float(obs['simulation_time_s'])
                    if not all(self._track_has_evidence(track) for track in self.pair_tracks):
                        raise ValueError('visual verification unavailable before test lift; actual grasp status unknown')
                    self._validate_common_lift(obs, worlds, .04)
                    self.test_lift_visibility_lost = 0
                    self.pair_lift = cooperative.RigidPairTransport(obs, [0, 0, .04], max_speed=.012)
                    self.change('pair_test_lift')
            elif self.phase in ('pair_test_lift', 'pair_raise'):
                constrained_motion = True
                if not closed.all():
                    raise ValueError('paired lift gripper opened')
                visible = True
                if self.phase == 'pair_test_lift':
                    self.pair_tracks = [tracker.update(obs) for tracker in self.pair_trackers]
                    self.pair_tracks_observed_at = float(obs['simulation_time_s'])
                    visible = all(self._track_has_evidence(track) for track in self.pair_tracks)
                    self.test_lift_visibility_lost = 0 if visible else self.test_lift_visibility_lost+1
                    if not visible:
                        hard_hold = [True, True]
                        self.transport_debug = dict(self.transport_debug, visual_verification_paused_pair=True,
                            visual_verification_lost_frames=self.test_lift_visibility_lost)
                        if self.test_lift_visibility_lost >= 20:
                            raise ValueError('visual verification unavailable: fixed-feature evidence lost for 20 frames; actual grasp status unknown')
                result = None
                if visible:
                    result = self.pair_lift.step(obs)
                    self.transport_debug = dict(result['debug'], visual_verification_paused_pair=False)
                    if result['failure']:
                        raise ValueError(result['failure'])
                    action = result['action']
                    if result['done'] or result['debug'].get('navigation_paused_pair', False):
                        hard_hold = [True, True]
                if result is not None and result['done']:
                    if self.phase == 'pair_test_lift':
                        followed = all(t.get('reliable') and t['median_displacement_world'][2] >= .018 for t in self.pair_tracks)
                        if not followed:
                            raise ValueError('sleeve-side test lift lacks fixed-feature evidence for both cloth patches')
                        self.visual_dual_grasp_candidate = True
                        rise = self._prepare_hand_height_raise(obs, worlds)
                        self.pair_lift = cooperative.RigidPairTransport(obs, [0, 0, rise], max_speed=.025)
                        self.change('pair_raise')
                    else:
                        self.dual_targets = worlds.copy()
                        self.active_hold = worlds[self.active].copy()
                        if self.ENABLE_FAR_CLOTH_ROLL_OBSERVATION:
                            # This observation still carries the prior base
                            # command. Apply this frame's hold before taking
                            # the wrist experiment's initial state snapshot.
                            self.loaded_roll = None
                            self.wrist_handoff = None
                            self.change('pair_settle_before_roll' if self.REQUIRE_PASSIVE_WRIST_HANDOFF else 'pair_observe_roll')
                        else:
                            self.change('dual_hold')
            elif self.phase in ('pair_settle_before_roll', 'pair_settle_before_pitch'):
                constrained_motion = True
                if self.wrist_handoff is None:
                    if self.phase_steps != 1:
                        raise ValueError('persistent passive wrist handoff missing')
                    self.wrist_handoff = self._create_wrist_handoff(obs)
                result = self.wrist_handoff.step(obs)
                self.wrist_handoff_debug = dict(result['debug'])
                action = result['action']
                if result['failure']:
                    raise ValueError('passive wrist handoff: '+result['failure'])
                if result['done']:
                    self.wrist_calibration = result.get('calibration')
                    self.dual_targets = worlds.copy()
                    self.active_hold = worlds[self.active].copy()
                    if self.phase == 'pair_settle_before_pitch':
                        self.loaded_pitch = None
                        self.change('pair_observe_pitch')
                    else:
                        self.loaded_roll = None
                        self.change('pair_observe_roll')
                    hard_hold = [True, True]
            elif self.phase == 'pair_observe_roll':
                # This experiment rotates a captured fabric patch, not just a
                # camera. Keep one persistent angle budget before transport.
                # The child may cancel integrated target lead before reporting
                # a latched failure; those bounded cancellation actions must
                # pass through unchanged (no smoothing or inherited servo).
                constrained_motion = True
                if self.loaded_roll is None:
                    if self.phase_steps != 1:
                        raise ValueError('persistent far cloth roll experiment missing')
                    self.loaded_roll = self._create_loaded_roll(obs)
                stop_for_openings = False
                if self.phase_steps == 1 or self.phase_steps % 4 == 0:
                    self.sleeve_observability = self.observe_sleeves(obs, worlds)
                    stop_for_openings = bool(self.STOP_WRIST_EXPERIMENT_ON_OPENING_DIAGNOSTICS and
                        self.sleeve_observability.get('both_regions_have_depth_supported_opening', False))
                result = self.loaded_roll.step(obs, stop_for_openings=stop_for_openings)
                self.loaded_roll_debug = dict(result['debug'],
                    cancellation_only=result.get('cancellation_only', False),
                    pending_failure=result.get('pending_failure'),
                    experiment_completed=result.get('experiment_completed', False),
                    skipped=result.get('skipped', False),
                    early_stopped=result.get('early_stopped', False),
                    report_observed_at_s=float(obs['simulation_time_s']))
                action = result['action']
                if result['failure']:
                    raise ValueError('far cloth roll observation: '+result['failure'])
                if result['done']:
                    if self.REQUIRE_COMPLETED_WRIST_EXPERIMENTS and not result.get('experiment_completed'):
                        raise ValueError('required loaded roll experiment did not complete: '+str(
                            result['debug'].get('ineligible_reason') or result['debug'].get('phase') or 'completion_not_verified'))
                    self.dual_targets = worlds.copy()
                    self.active_hold = worlds[self.active].copy()
                    if self.ENABLE_FAR_CLOTH_PITCH_PILOT:
                        self.loaded_pitch = None
                        if self.RECALIBRATE_BEFORE_LOADED_PITCH:
                            self.wrist_handoff = None
                            self.wrist_calibration = None
                            self.change('pair_settle_before_pitch')
                        else:
                            self.change('pair_observe_pitch')
                    else:
                        self.change('dual_hold')
                    hard_hold = [True, True]
            elif self.phase == 'pair_observe_pitch':
                constrained_motion = True
                if self.loaded_pitch is None:
                    if self.phase_steps != 1:
                        raise ValueError('persistent far cloth pitch pilot missing')
                    self.loaded_pitch = self._create_loaded_pitch(obs)
                stop_for_openings = False
                if self.phase_steps == 1 or self.phase_steps % 4 == 0:
                    self.sleeve_observability = self.observe_sleeves(obs, worlds)
                    stop_for_openings = bool(self.STOP_WRIST_EXPERIMENT_ON_OPENING_DIAGNOSTICS and
                        self.sleeve_observability.get('both_regions_have_depth_supported_opening', False))
                result = self.loaded_pitch.step(obs, stop_for_openings=stop_for_openings)
                self.loaded_pitch_debug = dict(result['debug'],
                    cancellation_only=result.get('cancellation_only', False),
                    pending_failure=result.get('pending_failure'),
                    experiment_completed=result.get('experiment_completed', False),
                    skipped=result.get('skipped', False),
                    early_stopped=result.get('early_stopped', False),
                    report_observed_at_s=float(obs['simulation_time_s']))
                action = result['action']
                if result['failure']:
                    raise ValueError('far cloth pitch pilot: '+result['failure'])
                if result['done']:
                    if self.REQUIRE_COMPLETED_WRIST_EXPERIMENTS and not result.get('experiment_completed'):
                        raise ValueError('required loaded pitch experiment did not complete: '+str(
                            result['debug'].get('ineligible_reason') or result['debug'].get('phase') or 'completion_not_verified'))
                    self.dual_targets = worlds.copy()
                    self.active_hold = worlds[self.active].copy()
                    self.change('dual_hold')
                    hard_hold = [True, True]
            else:
                raise ValueError('unknown sleeve-side phase: '+self.phase)
            limit = 2600 if self.phase == 'pair_navigate' else 1200
            if self.phase_steps > limit:
                raise ValueError('sleeve-side phase timed out: '+self.phase)
            if not constrained_motion:
                action[:, :8] = self.previous_action[:, :8]+np.clip(action[:, :8]-self.previous_action[:, :8], -.012, .012)
            for r in (0, 1):
                if hard_hold[r]:
                    action[r, :8] = 0
            action = self.execution.apply(obs, action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail(str(error))
        return self._finish_pair(obs, action)
