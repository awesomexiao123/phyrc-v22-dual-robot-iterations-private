"""Passive staging calibration for the separate development contact branch.

Only the far-field 50 cm scene gate is replaced. The long calibration's 2 s /
41-sample window, 6 s deadline, original 3 mm drift budget and statistical
limits remain. Every counted frame needs current public skin and cloth support;
retained skin is additional evidence, never a replacement for current pixels.

A completed earlier far-field baseline is a required compatibility prior, not
fresh control evidence. Its timestamp is preserved and must remain <=180 s old.
Raw own geometry and raw pending targets remain in every geometric check even
when a prior-excess target points in the opposite direction. Neither a sampled
window nor zero movement input cancels a native target or proves physical rest,
attachment, inertia bounds, unseen-body clearance, or safe contact.
"""
from copy import deepcopy

import numpy as np
from scipy.spatial import cKDTree

from calibrated_contact_governor import CalibratedContactGovernor
from contact_motion_governor import ContactMotionGovernor
from gripper_skin_clearance import observed_gripper_skin_clearance
from human_targets import _validated, _world_pixels
from loaded_equilibrium_calibration import LongLoadedEquilibriumCalibration
from observed_hand_reacquisition import _skin
from public_vision import _fabric_mask, cloth_cloud
from wrist_sweep_envelope import jaw_sweep_envelope, wrist_sweep_envelope


def _current_skin_points(obs, hands):
    """Current RGB-D only; same masks/support thresholds as the contact trial."""
    values = _validated(obs, wrists=True)
    clouds = []
    for camera in (1, 2, 3, 4):
        depth = values['depth'][camera, ..., 0]
        valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth) &
                 (depth > .03) & (depth < (3. if camera < 3 else 5.)) &
                 _skin(values['rgb'][camera]) & ~_fabric_mask(values['rgb'][camera]))
        v, u = np.where(valid)
        points = _world_pixels(values, camera, u, v, depth[v, u])
        points = points[np.min(np.linalg.norm(points[:, None]-hands[None], axis=2), axis=1) < .35]
        clouds.append(points)
    points = np.concatenate(clouds, axis=0)
    counts = [int(np.count_nonzero(np.linalg.norm(points-hand, axis=1) < .07)) for hand in hands]
    return points, counts


class StagingEquilibriumCalibration(LongLoadedEquilibriumCalibration):
    """Zero-motion-input acquisition with an immutable prior and raw geometry.

    ``prior_calibration`` must be the caller's completed far-field calibration;
    this class validates its public summary, not its physical provenance. It
    cannot manufacture that provenance or repair an unresolved upstream target.
    The result contract is the same as LoadedEquilibriumCalibration. Failures
    are terminal; every result contains only zero motion plus close intent.
    """
    MAX_PRIOR_AGE_S = 180.
    MIN_SKIN_CLEARANCE_M = .020

    def __init__(self, obs, hands, observed_at, *, prior_calibration=None,
                 stationary_human=False, max_hand_age_s=180.):
        self.prior_calibration = deepcopy(prior_calibration)
        self.skin_anchor = None
        self.skin_anchor_stamp = None
        self.current_skin_stamp = None
        self.current_skin_frame_count = 0
        self.clearance = []
        self._last_checked_state = None
        self._last_checked_time = None
        self._prior_bias = self._prior_peak = None
        super().__init__(obs, hands, observed_at, stationary_human=stationary_human,
                         max_hand_age_s=max_hand_age_s)
        if self.failure:
            return
        try:
            prior = self.prior_calibration
            if not isinstance(prior, dict):
                raise ValueError('completed_far_field_prior_calibration_required')
            stamps = np.asarray([prior['observed_at_s'], prior['window_start_s']], float)
            frames = float(prior['frame_count'])
            if (not np.isfinite(stamps).all() or not np.isfinite(frames) or
                    frames < 11 or frames != int(frames) or stamps[0]-stamps[1] < .5-1e-8 or
                    not isinstance(prior['method'], str) or not prior['method']):
                raise ValueError('completed_far_field_prior_window_required')
            for key in ('controller_bias', 'controller_bias_peak_deviation'):
                value = np.asarray(prior[key], float).copy()
                if value.shape != (2, 5) or not np.isfinite(value).all():
                    raise ValueError('invalid_prior_'+key)
                if 'peak' in key and np.any(value < 0):
                    raise ValueError('negative_prior_peak_deviation')
                value.setflags(write=False)
                if key == 'controller_bias':
                    self._prior_bias = value
                else:
                    self._prior_peak = value
            if np.any(np.abs(self._prior_bias) > self.BIAS_LIMITS):
                raise ValueError('prior_bias_outside_original_limits')
            self._prior_age(self.time0)
            self.debug['prior_calibration_original_observed_at_s'] = float(stamps[0])
        except (KeyError, TypeError, ValueError, IndexError, OverflowError) as error:
            self.failure = str(error)

    def _prior_age(self, now):
        age = now-float(self.prior_calibration['observed_at_s'])
        if not np.isfinite(age) or not -1e-8 <= age <= self.MAX_PRIOR_AGE_S:
            raise ValueError('prior_calibration_stale_or_from_future')
        self.debug['prior_calibration_age_s'] = age

    def _cloth_report(self, obs, grasps):
        cloud = cloth_cloud(obs)
        cloth = np.asarray(cloud['world_points'], float)
        cameras = np.asarray(cloud['camera_ids'])
        if (cloth.ndim != 2 or cloth.shape[1:] != (3,) or len(cloth) < 48 or
                not np.isfinite(cloth).all() or cameras.shape != (len(cloth),)):
            raise ValueError('insufficient_current_observed_cloth')
        support = []
        for grasp in grasps:
            near = np.linalg.norm(cloth-grasp, axis=1) <= .12
            counts = {int(c): int(np.count_nonzero(near & (cameras == c))) for c in np.unique(cameras[near])}
            if not counts or max(counts.values()) < 24:
                raise ValueError('insufficient_current_cloth_support_near_both_grasps')
            support.append(counts)

        now = float(np.asarray(obs['simulation_time_s']).reshape(-1)[0])
        skin, counts = _current_skin_points(obs, self.hands)
        skin = np.asarray(skin, float)
        counts = np.asarray(counts)
        if (skin.ndim != 2 or skin.shape[1:] != (3,) or not len(skin) or
                not np.isfinite(skin).all() or counts.shape != (2,) or
                not np.isfinite(counts).all() or np.min(counts) < 12):
            raise ValueError('current_frame_skin_support_required_for_both_hands')
        # Recount positions as well as accepting the extraction diagnostics.
        actual_counts = [int(np.count_nonzero(np.linalg.norm(skin-hand, axis=1) < .07)) for hand in self.hands]
        if min(actual_counts) < 12:
            raise ValueError('current_frame_skin_points_do_not_support_both_hands')
        if self.skin_anchor is None:
            self.skin_anchor = skin.copy()
            self.skin_anchor_stamp = now
        if now-self.skin_anchor_stamp > 180. or now < self.skin_anchor_stamp-1e-8:
            raise ValueError('original_skin_anchor_stale_or_from_future')
        points = np.concatenate((self.skin_anchor, skin), axis=0)
        # A visible fabric/skin proximity candidate cannot be learned as bias.
        # Retain every point without allocating the full cloth/skin product.
        cloth_skin_min = float(cKDTree(points).query(cloth, k=1)[0].min())
        if cloth_skin_min < self.MIN_SKIN_CLEARANCE_M:
            raise ValueError('observed_cloth_within20mm_of_skin_no_baseline')
        self._check_geometry(obs, points, now)
        if self.current_skin_stamp is None or now > self.current_skin_stamp+1e-8:
            self.current_skin_frame_count += 1
        self.current_skin_stamp = now
        return dict(observed_cloth_point_count=len(cloth), support_by_camera_per_grasp=support,
                    minimum_observed_cloth_to_skin_point_m=cloth_skin_min,
                    current_skin_support_per_hand=actual_counts,
                    current_skin_observed_at_s=now,
                    original_skin_anchor_observed_at_s=self.skin_anchor_stamp,
                    current_skin_frame_count=self.current_skin_frame_count,
                    retained_skin_used_instead_of_current=False,
                    far_field_50cm_gate_replaced_only_in_this_independent_module=True)

    def _check_geometry(self, obs, points, now):
        s = ContactMotionGovernor._read(obs)
        CalibratedContactGovernor._raw_limits(s, s['target'])
        self._prior_age(now)
        reports = []
        for robot in (0, 1):
            q = s['q'][robot]; target = s['target'][robot]; rotation = s['rotations'][robot]
            raw = s['lag'][robot]
            excess = raw-self._prior_bias[robot, :2]
            wrist_rate = np.abs(s['qd'][robot, 8:11])*.05
            raw_angles = np.column_stack((np.minimum(q[8:11], target[2:5])-wrist_rate,
                                          np.maximum(q[8:11], target[2:5])+wrist_rate))
            excess_center = target[2:5]-self._prior_bias[robot, 2:5]
            peak = self._prior_peak[robot, 2:5]
            excess_angles = np.column_stack((np.minimum(q[8:11], excess_center-peak)-wrist_rate,
                                             np.maximum(q[8:11], excess_center+peak)+wrist_rate))
            angular = wrist_sweep_envelope(q, raw_angles, excess_angles)
            if not angular.get('valid'):
                raise ValueError('invalid_staging_wrist_envelope:'+str(angular.get('reason')))
            angle_reserve = float(angular['max_displacement_reserve_m'])
            jaw = jaw_sweep_envelope(q, target[5], s['qd'][robot, 11:13])
            if not jaw.get('valid'):
                raise ValueError('invalid_staging_jaw_envelope:'+str(jaw.get('reason')))
            jaw_reserve = float(jaw['max_displacement_reserve_m'])
            rate_reserve = .05*float(s['endpoint_speed'][robot])
            uncertainty_reserve = float(self._prior_peak[robot, :2].sum())
            margin = .003+rate_reserve+angle_reserve+jaw_reserve+uncertainty_reserve
            for label, lag in (('raw_pending_target', raw), ('prior_excess_pending_target', excess)):
                pending = rotation[:, 2]*lag[0]+rotation[:, 0]*lag[1]
                report = observed_gripper_skin_clearance(
                    obs, robot, points, skin_observed_at=min(self.skin_anchor_stamp, now),
                    stationary_skin=True, max_skin_age_s=180.,
                    proposed_translation_world=pending, model_margin_m=margin)
                reports.append(dict(robot=robot, checked_segment=label,
                    pending_translation_world_m=pending.tolist(),
                    raw_rate_interval_reserve_m=rate_reserve,
                    additional_angular_reserve_m=angle_reserve,
                    additional_jaw_reserve_m=jaw_reserve,
                    jaw_target_ranges_rad=jaw['jaw_target_ranges_rad'],
                    wrist_raw_rate_angle_reserve_rad=wrist_rate.tolist(),
                    prior_linear_uncertainty_reserve_m=uncertainty_reserve,
                    model_margin_m=margin,
                    report={k:v for k,v in report.items() if k not in ('model_bounds', 'model_provenance')}))
                self.clearance = reports
                if not report.get('valid') or report['observed_minimum_clearance_m'] < self.MIN_SKIN_CLEARANCE_M:
                    raise ValueError('staging_own_geometry_unavailable_or_within20mm_of_observed_skin')

    def _guards(self, obs, bases, grasps, tilt, now):
        state = ContactMotionGovernor._read(obs)
        keys = ('q', 'qd', 'target', 'base', 'grasps', 'twist')
        if self._last_checked_time is not None:
            dt = now-self._last_checked_time
            if dt < -1e-8:
                raise ValueError('public_clock_moved_backwards')
            if dt <= 1e-8:
                if any(np.max(np.abs(state[k]-self._last_checked_state[k])) > 1e-8 for k in keys):
                    raise ValueError('same_timestamp_has_changed_public_state')
            elif abs(dt-self.ACTION_DT) > self.CLOCK_TOLERANCE:
                raise ValueError('staging_requires_consecutive_20hz_current_frames')
        for flag in ('unresolved_target_lag', 'cancellation_only', 'pending_failure'):
            if obs.get(flag):
                raise ValueError('unresolved_upstream_target_state:'+flag)
        result = super()._guards(obs, bases, grasps, tilt, now)
        if not result[3]:
            raise ValueError('staging_requires_zero_previous_motion_and_base_targets')
        self._last_checked_state = {key: state[key].copy() for key in keys}
        self._last_checked_time = now
        return result

    def _freeze(self):
        q = np.stack([frame['q'] for frame in self.window])
        targets = np.stack([frame['targets'] for frame in self.window])
        actual = np.concatenate((q[:, :, 3:4], q[:, :, 4:8].sum(2, keepdims=True), q[:, :, 8:11]), axis=2)
        residual = targets[:, :, :5]-actual
        bias = np.median(residual, axis=0)
        peak = np.max(np.abs(residual-bias), axis=0)
        compatibility_limit = self._prior_peak+peak+self.TERMINAL_RESIDUAL_LIMITS
        difference = np.abs(bias-self._prior_bias)
        self.debug.update(candidate_bias_difference_from_prior=difference.tolist(),
                          prior_bias_compatibility_limit=compatibility_limit.tolist())
        if np.any(difference > compatibility_limit):
            raise ValueError('new_staging_bias_incompatible_with_far_field_prior')
        if self.current_skin_stamp != self.window[-1]['time']:
            raise ValueError('freeze_requires_current_terminal_frame_skin')
        super()._freeze()
        if self.done:
            self.calibration.update(
                variant='staging_passive_prior_compatible',
                prior_calibration_original_observed_at_s=float(self.prior_calibration['observed_at_s']),
                original_hand_observed_at_s=self.observed_at,
                original_skin_anchor_observed_at_s=self.skin_anchor_stamp,
                current_skin_observed_at_s=self.current_skin_stamp,
                native_target_cancelled=False, physical_safety_proven=False)

    def _result(self):
        result = super()._result()
        result['debug'].update(calibration_variant='staging_passive_prior_compatible',
            own_geometry_clearance=deepcopy(self.clearance),
            prior_calibration_refreshed=False, original_observation_modified=False,
            current_skin_required_for_every_counted_frame=True,
            caller_owns_actor_integration=True, contact_authorized=False,
            physical_safety_proven=False, inertia_or_stopping_bound=False)
        return result
