"""One-shot 5 mm simulation probe hypotheses from current public RGB-D.

No commands, executor, accumulation, garment truth, or semantic sleeve promise.
The caller must measure the actual ring/cloth response and enforce a global
10 mm experimental budget before considering any subsequent hypothesis.
"""
from itertools import permutations

import cv2
import numpy as np

from cooperative_transport import _snapshot
from distal_staging import _hand_axis
from forearm_surface import _seed_components
from human_targets import _validated, _world_pixels
from opening_candidates import compare_hand_surface_footprint
from public_vision import _fabric_mask


def _visible_hand_samples(values, hand, other_hand, axis):
    """Depth-connected non-cloth regions within 8 cm of a measured hand seed."""
    points, cameras, pixels = [], [], []
    for camera in (1, 2, 3, 4):
        depth = values['depth'][camera, ..., 0]
        valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth)
                 & (depth > .03) & (depth < (3. if camera < 3 else 5.)))
        valid &= ~_fabric_mask(values['rgb'][camera])
        v, u = np.where(valid)
        world = _world_pixels(values, camera, u, v, depth[v, u])
        world_image = np.full((256, 256, 3), np.nan)
        world_image[v, u] = world
        distance = np.linalg.norm(world-hand, axis=1)
        allowed = np.zeros((256, 256), bool)
        allowed[v, u] = (distance <= .08) & (np.linalg.norm(world-other_hand, axis=1) > .075)
        seeds = np.zeros_like(allowed)
        seeds[v, u] = (distance <= .025) & allowed[v, u]
        components, error = _seed_components(allowed, seeds, world_image)
        if error:
            raise ValueError('hand_neighborhood_connectivity_exceeds_bound')
        components = [component for component in components if len(component) >= 12]
        if len(components) > 1:
            raise ValueError('multiple_depth_connected_hand_neighborhoods')
        if not components:
            continue
        yy, xx = components[0].T
        points.append(world_image[yy, xx])
        pixels.append(np.column_stack((xx, yy)))
        cameras.append(np.full(len(xx), camera, int))
    if not points:
        raise ValueError('no_current_depth_connected_hand_surface_pixels')
    points, pixels, cameras = np.concatenate(points), np.concatenate(pixels), np.concatenate(cameras)
    if len(points) < 12:
        raise ValueError('insufficient_current_hand_surface_support')
    # Retain all projected-envelope extrema, instead of uniform sampling that
    # could falsely discard a wide fingertip. Projection along this same axis
    # onto any admissible plane is affine, so these hull vertices suffice.
    reference = np.eye(3)[int(np.argmin(np.abs(axis)))]
    first = np.cross(axis, reference); first /= np.linalg.norm(first)
    basis = np.stack((first, np.cross(axis, first)))
    projection = (points-hand) @ basis.T
    selected = cv2.convexHull(projection.astype(np.float32), returnPoints=False).reshape(-1)
    if len(selected) > 512:
        raise ValueError('observed_hand_footprint_exceeds_bounded_complexity')
    if len(selected) < 12:
        extra = np.setdiff1d(np.arange(len(points)), selected)[:12-len(selected)]
        selected = np.r_[selected, extra]
    return dict(camera_indices=cameras[selected].tolist(), source_pixels_uv=pixels[selected].tolist()), points


def _candidate_polygon(candidate):
    aperture = candidate.get('inner_aperture', {})
    polygon = np.asarray(aperture.get('contour_world_on_plane'), float)
    if not aperture.get('available') or polygon.ndim != 2 or polygon.shape[1] != 3 or not 3 <= len(polygon) <= 512 or not np.isfinite(polygon).all():
        raise ValueError('current_inner_aperture_geometry_unavailable')
    return polygon


def _representative(candidates, now):
    if not 1 <= len(candidates) <= 8:
        raise ValueError('one_bounded_opening_group_required_per_grasp')
    chosen = max(candidates, key=lambda candidate: candidate.get('confidence', 0.))
    center = np.asarray(chosen['centroid_world'], float)
    normal = np.asarray(chosen['normal_world'], float)
    for candidate in candidates:
        _candidate_polygon(candidate)
        if (candidate.get('observation_time_s') != now or
                candidate['inner_aperture'].get('observation_time_s') != now):
            raise ValueError('opening_candidate_is_not_from_current_observation')
        if candidate.get('camera_index') not in (1, 2, 3, 4):
            raise ValueError('opening_candidate_has_no_public_robot_camera')
        delta = np.asarray(candidate['centroid_world'], float)-center
        n = np.asarray(candidate['normal_world'], float)
        if np.linalg.norm(delta) > .03 or abs(float(n @ normal)) < .85:
            raise ValueError('multiple_distinct_openings_near_one_grasp_are_ambiguous')
        if candidate['camera_index'] == chosen['camera_index']:
            a = set(map(tuple, candidate['inner_aperture']['contour_pixels_uv']))
            b = set(map(tuple, chosen['inner_aperture']['contour_pixels_uv']))
            if a != b:
                raise ValueError('different_inner_contours_in_one_camera_are_not_one_identity')
    return chosen


def propose_sleeve_probe(obs, current_grasps, sleeve_report, current_hands, current_forearms):
    """Return hold or one simulation-only pair of 5 mm grasp target hypotheses.

    Reports need current public timestamps; hand_report may omit its timestamp
    when bound to the current forearm report and reacquired depth supports it.
    The 0..20 mm distal-plane test uses the nearest actually observed hand
    surface along each proposed axis, not a .3 m staging midpoint. Two different
    visible openings suffice as a hypothesis; semantic cuff identity is not a
    prerequisite. No prior/cached candidate index is used for matching.
    """
    result = dict(recommendation='hold', reason=None, target_grasps_world=None,
        simulation_only=True, proposal_frame_time_s=None, per_grasp_hypotheses=[], matching_checks=[],
        recommended_max_speed_m_s=.003, maximum_single_probe_displacement_m=.005,
        required_hand_footprint_margin_m=.01, physical_traversal_verified=False,
        sleeve_identity_verified=False, full_hand_geometry_observed=False,
        attachment_verified=False, collision_free_verified=False, motion_executor_included=False,
        caller_must_verify_actual_ring_and_cloth_response=True,
        caller_must_enforce_global_probe_limit_m=.01,
        requires_new_observation_and_global_budget_check_before_further_probe=True,
        unknowns=['semantic opening identity and garment topology', 'unseen hand/body/cloth surfaces',
                  'grasp-to-opening displacement response', 'global experiment motion already spent'])
    try:
        _, grasps, _, tilt, now = _snapshot(obs)
        result['proposal_frame_time_s'] = now
        supplied = np.asarray(current_grasps, float)
        if supplied.shape not in ((2, 3), (2, 7)) or not np.isfinite(supplied).all() or np.max(np.linalg.norm(supplied[:, :3]-grasps, axis=1)) > .002:
            raise ValueError('supplied_grasps_do_not_match_current_public_own_poses')
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('both_grippers_must_have_closed_intent')
        gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isfinite(gap).all() or np.max(gap) > .08 or np.max(tilt) > .065:
            raise ValueError('public_gripper_or_robot_tilt_guard')
        if current_forearms.get('observation_time_s') != now or current_hands.get('observation_time_s', now) != now:
            raise ValueError('hand_and_surface_reports_must_be_current_for_probe')
        hands = np.asarray(current_hands.get('hand_points_world'), float)
        if not current_hands.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all() or np.linalg.norm(hands[1]-hands[0]) < .15:
            raise ValueError('two_separated_current_public_hand_surfaces_required')
        rows = current_forearms['hand_surfaces']
        if len(rows) != 2:
            raise ValueError('two_hand_bound_surface_axis_reports_required')
        axes, evidence = zip(*[_hand_axis(rows[i], hands[i], i) for i in (0, 1)])
        values = _validated(obs, wrists=True)
        sampled = [_visible_hand_samples(values, hands[i], hands[1-i], axes[i]) for i in (0, 1)]
        regions = sleeve_report['grasp_regions']
        if len(regions) != 2:
            raise ValueError('two_current_grasp_regions_required')
        candidates = []
        for robot, region in enumerate(regions):
            if (region.get('grasp_index') != robot or region.get('ambiguous_candidate_indices')
                    or np.linalg.norm(np.asarray(region['grasp_world'])-grasps[robot]) > .005):
                raise ValueError('grasp_opening_association_is_ambiguous_or_stale')
            candidates.append(_representative(region['depth_supported_opening_candidates'], now))
        centers = np.array([candidate['centroid_world'] for candidate in candidates])
        radii = [float(np.max(np.linalg.norm(_candidate_polygon(candidate)-centers[i], axis=1)))
                 for i, candidate in enumerate(candidates)]
        if np.linalg.norm(centers[1]-centers[0]) <= sum(radii)+.01:
            raise ValueError('opening_regions_are_not_geometrically_disjoint')
        links = {}
        for robot, candidate in enumerate(candidates):
            center = centers[robot]
            normal = np.asarray(candidate['normal_world'], float)
            normal /= np.linalg.norm(normal)
            for hand_index in (0, 1):
                axis = axes[hand_index]
                cosine = float(normal @ axis)
                check = dict(robot=robot, hand_index=hand_index, normal_axis_absolute_cosine=abs(cosine))
                result['matching_checks'].append(check)
                if abs(cosine) < .8:
                    check['reason'] = 'surface_axis_too_oblique_to_hole_plane'
                    continue
                samples, hand_points = sampled[hand_index]
                # Positive means the observed hand is proximal to this plane.
                axial_gaps = (hand_points-center) @ normal/cosine
                distal_gap = float(axial_gaps.min())
                check['nearest_observed_hand_distal_gap_m'] = distal_gap
                if not -1e-6 <= distal_gap <= .020+1e-6:
                    check['reason'] = 'hole_plane_not_within_0_to_20mm_distal_to_visible_hand'
                    continue
                footprint = compare_hand_surface_footprint(obs, candidate, samples, axis, margin_m=.01)
                check['footprint_status'] = footprint['status']
                check['minimum_observed_footprint_margin_m'] = footprint['minimum_edge_clearance_m']
                if not footprint.get('observed_footprint_fits'):
                    check['reason'] = footprint['reason']
                    continue
                check['reason'] = 'eligible_geometric_hand_hole_link'
                intersection = hands[hand_index]+axis*(float(normal @ (center-hands[hand_index]))/cosine)
                links[(robot, hand_index)] = dict(hand_index=hand_index,
                    lateral_center_error_m=float(np.linalg.norm(intersection-center)),
                    nearest_observed_hand_distal_gap_m=distal_gap,
                    minimum_observed_footprint_margin_m=footprint['minimum_edge_clearance_m'],
                    normal_axis_absolute_cosine=abs(cosine),
                    observed_hand_source_pixel_count=len(samples['camera_indices']),
                    observed_hand_region_point_count=len(hand_points),
                    proximal_surface_axis_world=axis.tolist(), axis_evidence=evidence[hand_index],
                    source_camera=candidate['source_camera'], camera_index=candidate['camera_index'],
                    source_pixel_centroid=candidate['pixel_centroid'], observation_time_s=now,
                    opening_identity_basis='same-frame camera and contour geometry; no cached index join')
        choices = []
        for assignment in permutations((0, 1)):
            if all((robot, assignment[robot]) in links for robot in (0, 1)):
                cost = sum(links[(robot, assignment[robot])]['lateral_center_error_m'] for robot in (0, 1))
                choices.append((cost, assignment))
        if not choices:
            raise ValueError('no_bijective_matching_with_0_to_20mm_distal_gap_and_10mm_footprint_margin')
        choices.sort()
        if len(choices) > 1 and choices[1][0]-choices[0][0] < .01:
            raise ValueError('hand_to_opening_assignment_has_no_clear_geometric_preference')
        assignment = choices[0][1]
        targets = grasps+np.array([.005*axes[assignment[r]] for r in (0, 1)])
        hypotheses = [dict(links[(robot, assignment[robot])], robot=robot) for robot in (0, 1)]
        return dict(result, recommendation='one_shot_5mm_simulation_hypothesis',
            reason='two_disjoint_current_openings_with_observed_surface_clearance_and_unambiguous_assignment',
            target_grasps_world=targets.tolist(), per_grasp_hypotheses=hypotheses,
            contains_weak_single_view_evidence=any(item['weak_single_view'] for item in evidence),
            grasp_to_opening_motion_is_unverified_hypothesis=True)
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        return dict(result, reason=str(error))
