"""Geometric hypotheses for simulated cloth contact, never motion commands.

Inputs are same-frame held-edge/hand/signed-surface reports and public RGB-D.
The initial external edge span is only a size prior: W/pi is NOT a measured
mouth radius. No closed image hole or semantic cuff label is required. Geometry
availability is separate from own-pose reach and observed housing clearance.
"""
from itertools import permutations

import numpy as np

from cooperative_transport import _snapshot
from distal_staging import _hand_axis, _point
from grasp_pair_alignment import GraspPairAlignment
from human_targets import _validated, _world_pixels
from navigation import _HOUSING_LO, _HOUSING_HI
from observed_hand_reacquisition import _camera_hand_views, _skin
from public_vision import _rotation


MAX_ENDPOINT_TRAVEL_M = .30
MAX_SPAN_INCREASE_M = .02
HOUSING_CLEARANCE_M = .02
MAX_SKIN_PIXELS = 8000


def _same_frame(report, now, name):
    stamp = float(report['observation_time_s'])
    if not np.isfinite(stamp) or abs(stamp-now) > 1e-7:
        raise ValueError(name+'_not_from_current_observation')


def _measured_pixels(values, camera, pixels, *, blue=False):
    uv = np.asarray(pixels)
    if (camera not in (1, 2, 3, 4) or uv.ndim != 2 or uv.shape[1] != 2
            or not 1 <= len(uv) <= 1200 or not np.isfinite(uv).all()
            or not np.equal(uv, np.floor(uv)).all() or np.any(uv < 0) or np.any(uv > 255)):
        raise ValueError('invalid_public_source_pixels')
    uv = uv.astype(int); u, v = uv.T
    depth = values['depth'][camera, v, u, 0]
    good = values['depth_valid'][camera, v, u, 0] & np.isfinite(depth) & (depth > .03) & (depth < (3 if camera < 3 else 5))
    if blue:
        rgb = values['rgb'][camera, v, u].astype(float)
        good &= (rgb[:, 2] > 100) & (rgb[:, 2] > 1.25*rgb[:, 0]) & (rgb[:, 2] > 1.25*rgb[:, 1])
    if not good.all():
        raise ValueError('source_pixel_missing_current_depth_or_color')
    return _world_pixels(values, camera, u, v, depth), uv, depth


def _current_edges(values, report, grasps, now):
    _same_frame(report, now, 'held_edge_report')
    if not report.get('detected') or not report.get('distinct_current_regions'):
        raise ValueError('two_distinct_current_held_edge_hypotheses_required')
    hypotheses, rows = report['hypotheses'], report['robots']
    if len(hypotheses) != 2 or len(rows) != 2:
        raise ValueError('two_robot_ordered_edge_rows_required')
    points, widths, evidence, initial_ids = [], [], [], []
    for robot, (item, row) in enumerate(zip(hypotheses, rows)):
        if (item['robot_index'] != robot or row['robot_index'] != robot or row.get('ambiguous')
                or row.get('ambiguous_camera_indices') or not row.get('hypothesis_available')
                or any(not pair.get('agrees') for pair in row.get('current_camera_agreement', []))):
            raise ValueError('held_edge_role_or_view_ambiguity')
        _same_frame(item, now, 'held_edge_candidate')
        for saved in (row['current_grasp_world'], item['current_grasp_world']):
            if np.linalg.norm(_point(saved, 'edge_grasp')-grasps[robot]) > .002:
                raise ValueError('held_edge_associated_grasp_changed_over_2mm')
        camera = item['camera_index']
        point, uv, depth = _measured_pixels(values, camera, [item['edge_source_pixel_uv']], blue=True)
        point = point[0]
        if (np.linalg.norm(point-_point(item['edge_point_world'], 'reported_edge')) > .001
                or abs(float(item['measured_edge_depth_z_m'])-depth[0]) > 1e-5):
            raise ValueError('held_edge_point_not_supported_by_current_source_pixel')
        offset = point-grasps[robot]
        if (np.linalg.norm(offset) > .08 or np.linalg.norm(offset-_point(
                item['edge_from_current_grasp_world'], 'edge_offset')) > .002):
            raise ValueError('held_edge_offset_mismatch_or_over_8cm')
        arc, arc_uv, _ = _measured_pixels(values, camera, item['arc_source_pixels_uv'], blue=True)
        saved_arc = np.asarray(item['arc_measured_points_world'], float)
        if (len(arc) < 4 or len(np.unique(arc_uv, axis=0)) != len(arc)
                or saved_arc.shape != arc.shape or not np.isfinite(saved_arc).all()
                or np.max(np.linalg.norm(arc-saved_arc, axis=1)) > .001
                or not np.any(np.all(arc_uv == uv[0], axis=1))
                or np.max(np.linalg.norm(arc-grasps[robot], axis=1)) > .08001):
            raise ValueError('current_held_arc_evidence_invalid')
        prior = row['initial_size_prior']
        width = float(prior['initial_observed_boundary_span_m'])
        initial_time = float(prior['initial_boundary_observation_time_s'])
        if (not np.isfinite([width, initial_time]).all() or not .01 <= width <= .5
                or not 0 <= initial_time <= now or prior.get('initial_boundary_camera_index') not in (1, 2, 3, 4)):
            raise ValueError('invalid_initial_observed_external_arc_width_prior')
        initial_ids.append(prior['initial_candidate_index'])
        points.append(point); widths.append(width)
        evidence.append(dict(robot_index=robot, camera_index=camera, source_pixel_uv=uv[0].tolist(),
            measured_depth_z_m=float(depth[0]), observation_time_s=now,
            edge_point_world=point.tolist(), edge_from_current_grasp_world=offset.tolist(),
            initial_observed_edge_width_m=width, initial_observation_time_s=initial_time,
            initial_boundary_camera_index=prior['initial_boundary_camera_index'],
            width_scope='historical observed external arc span, not measured cuff circumference',
            material_identity_verified=False))
    if sorted(initial_ids) != [0, 1] or np.linalg.norm(points[1]-points[0]) <= .02:
        raise ValueError('initial_or_current_edge_pair_not_distinct')
    return np.asarray(points), np.asarray(widths), evidence


def _hand_surfaces(obs, values, hands, axes):
    """Actual current color/depth patches, preserving every footprint extremum."""
    clouds, evidence = [], []
    for index, (hand, axis) in enumerate(zip(hands, axes)):
        views, points, sources = [], [], []
        for camera in (1, 2, 3, 4):
            candidates, _ = _camera_hand_views(obs, values, camera, hand, hands[1-index])
            if len(candidates) > 1:
                raise ValueError('multiple_current_hand_surface_components')
            if not candidates:
                continue
            view = candidates[0]
            if not view['prior_shift_within_limit']:
                raise ValueError('current_hand_pixels_disagree_with_reported_hand')
            cloud, uv, _ = _measured_pixels(values, camera, view['source_pixels_uv'])
            views.append(view); points.append(cloud)
            sources.extend([dict(camera_index=camera, source_pixel_uv=pixel.tolist()) for pixel in uv])
        if not points:
            raise ValueError('missing_current_visible_hand_surface_pixels')
        medoids = np.asarray([v['hand_surface_world'] for v in views])
        if np.max(np.linalg.norm(medoids[:, None]-medoids[None], axis=2)) > .035:
            raise ValueError('current_hand_surface_views_conflict')
        cloud = np.concatenate(points)
        if len(cloud) > MAX_SKIN_PIXELS:
            raise ValueError('current_hand_surface_exceeds_bounded_pixel_count')
        down = np.array([0., 0., -1.]); down -= axis*(down @ axis)
        norm = np.linalg.norm(down)
        if norm < .2:
            raise ValueError('gravity_projection_degenerate_for_observed_axis')
        down /= norm
        across = np.cross(axis, down); across /= np.linalg.norm(across)
        relative = cloud-hand
        transverse = relative @ np.stack((across, down)).T
        center_xy = (transverse.min(0)+transverse.max(0))/2
        distal_index = int(np.argmin(relative @ axis))
        axial = float(relative[distal_index] @ axis)
        center = hand + center_xy[0]*across+center_xy[1]*down+axial*axis
        radius = float(np.linalg.norm(transverse-center_xy, axis=1).max())
        clouds.append(cloud)
        evidence.append(dict(hand_index=index, observation_time_s=float(obs['simulation_time_s']),
            surface_points_world=cloud.tolist(), source_pixels=sources,
            actual_distal_surface_point_world=cloud[distal_index].tolist(),
            actual_distal_source=sources[distal_index],
            inferred_visible_distal_footprint_center_world=center.tolist(),
            observed_projected_half_diagonal_m=radius, observed_projected_spans_m=np.ptp(transverse, axis=0).tolist(),
            projected_gravity_down_world=down.tolist(), camera_indices=[v['camera_index'] for v in views],
            full_hand_geometry_observed=False, center_is_inferred_not_measured_point=True))
    return clouds, evidence


def _skin_points(values, hands, axes):
    """Hand/forearm-near skin-colored returns for an observed-only screen.

    No own mask here: an observed skin-colored point inside a housing envelope
    must not disappear from a collision screen as if it were robot geometry.
    """
    clouds, sources = [], []
    for camera in (1, 2, 3, 4):
        depth = values['depth'][camera, ..., 0]
        good = (_skin(values['rgb'][camera]) & values['depth_valid'][camera, ..., 0]
                & np.isfinite(depth) & (depth > .03) & (depth < (3 if camera < 3 else 5)))
        v, u = np.where(good)
        world = _world_pixels(values, camera, u, v, depth[v, u])
        near = np.zeros(len(world), bool)
        for hand, axis in zip(hands, axes):
            relative = world-hand; axial = relative @ axis
            radial = np.linalg.norm(relative-axial[:, None]*axis, axis=1)
            near |= (axial >= -.08) & (axial <= .30) & (radial <= .08)
        clouds.append(world[near])
        sources.extend([dict(camera_index=camera, source_pixel_uv=[int(x), int(y)]) for x, y in zip(u[near], v[near])])
    cloud = np.concatenate(clouds)
    if not 24 <= len(cloud) <= MAX_SKIN_PIXELS:
        raise ValueError('insufficient_or_unbounded_current_skin_surface')
    return cloud, sources


def _feasibility(obs, bases, grasps, yaw, goals, skin, margin):
    q = np.asarray(obs['joint_position'], float)
    if q.shape != (2, 13) or not np.isfinite(q).all():
        raise ValueError('finite_public_joint_positions_required')
    if np.any(q[:, 3] < -1e-6) or np.any(q[:, 3] > 1.2+1e-6):
        raise ValueError('measured_own_lift_outside_physical_range')
    arm = GraspPairAlignment._arm_workspace(obs)
    delta = goals-grasps
    rotations = np.array([_rotation(base[3:]) for base in bases])
    lift = q[:, 3]+delta[:, 2]/rotations[:, 2, 2]
    fixed = np.array([np.linalg.solve(GraspPairAlignment._axes(bases[r], yaw[r]), delta[r]) for r in (0, 1)])
    grip_local = np.asarray(obs['grasp_pose_base'], float)
    bounds = np.asarray(arm['guarded_grasp_x_bounds_m'])
    fixed_arm = grip_local[:, 0]+fixed[:, 0]
    common = delta.mean(0); relative = delta-common
    shape = np.array([np.linalg.solve(GraspPairAlignment._axes(bases[r], yaw[r]), relative[r]) for r in (0, 1)])
    aligned_arm = grip_local[:, 0]+shape[:, 0]
    housing = []
    for robot in (0, 1):
        rotation = rotations[robot] @ _rotation(grip_local[robot, 3:])
        length = np.linalg.norm(delta[robot]); intervals = max(1, int(np.ceil(length/.002)))
        minimum = np.inf
        for fraction in np.linspace(0., 1., intervals+1):
            local = (skin-(grasps[robot]+fraction*delta[robot])) @ rotation
            distance = np.linalg.norm(np.maximum(np.maximum(_HOUSING_LO-local, local-_HOUSING_HI), 0.), axis=1)
            minimum = min(minimum, float(distance.min()))
        # Distance is 1-Lipschitz in translation; subtract half sample spacing
        # so sparse segment samples never overstate this observed-only bound.
        lower = max(0., minimum-length/intervals/2)
        housing.append(dict(robot_index=robot, minimum_sampled_observed_skin_distance_m=minimum,
            conservative_straight_translation_distance_lower_bound_m=lower,
            observed_housing_conflict=lower < HOUSING_CLEARANCE_M,
            minimum_requested_clearance_m=HOUSING_CLEARANCE_M,
            source='published own housing grasp-frame visual AABB from navigation.py; current measured grasp orientation',
            scope='fixed-orientation straight segment only, not the executor route or unobserved skin',
            finger_tip_or_full_wrist_mesh_checked=False))
    within_lift = bool(np.all((lift >= margin) & (lift <= 1.2-margin)))
    shape_ok = bool(np.all((aligned_arm >= bounds[:, 0]) & (aligned_arm <= bounds[:, 1]))
                    and np.max(np.abs(shape[:, 1])) <= .15)
    span0, span_goal = (float(np.linalg.norm(pair[1]-pair[0])) for pair in (grasps, goals))
    angle = float(np.rad2deg(np.arccos(np.clip((grasps[1]-grasps[0]) @ (goals[1]-goals[0]) /
                                             max(span0*span_goal, 1e-12), -1., 1.))))
    endpoint_ok = bool(np.linalg.norm(delta, axis=1).max() <= MAX_ENDPOINT_TRAVEL_M)
    span_ok = bool(span_goal <= span0+MAX_SPAN_INCREASE_M)
    return dict(current_wrist_pose_held=True, lift_joint_margin_m=margin,
        predicted_lift_joint_positions_m=lift.tolist(), lift_reachable_at_current_wrist=within_lift,
        arm_workspace=arm, common_translation_world=common.tolist(),
        paired_shape_adjustment_world=relative.tolist(),
        alignment_then_common_translation_arm_feasible=shape_ok,
        common_translation_requires_base_xy_route=bool(np.linalg.norm(common[:2]) > .001),
        common_translation_keeps_measured_arm_extension=True,
        fixed_base_alignment_predicted_grasp_x_m=fixed_arm.tolist(),
        fixed_base_alignment_arm_feasible=bool(np.all((fixed_arm >= bounds[:, 0]) & (fixed_arm <= bounds[:, 1]))),
        fixed_base_alignment_limit_is_not_common_transport_rejection=True,
        maximum_endpoint_travel_m=float(np.linalg.norm(delta, axis=1).max()),
        endpoint_travel_within_30cm=endpoint_ok,
        desired_grasp_span_m=span_goal, span_does_not_exceed_initial_plus_2cm=span_ok,
        desired_pair_rotation_degrees=angle, pair_rotation_within_20degrees=bool(angle <= 20.),
        feasible_at_current_wrist=bool(within_lift and shape_ok and endpoint_ok and span_ok and angle <= 20.),
        reach_feasibility_is_not_collision_or_execution_permission=True,
        observed_housing_screen=housing,
        full_gripper_skin_swept_clearance_verified=False,
        own_reach_source='measured own grasp pose and joint positions; own lift0..1.2m, arm stages0..0.13m',
        transport_route_checked=False)


def plan_hypothesis_contact(obs, held_edge_report, hand_report, forearm_report, *, distal_gap_m=.020,
                            lift_margin_m=.015):
    """Propose two near-hand goals; preserve measured edge minus grasp offsets.

    Initial widths come from robots[r].initial_size_prior in the held-edge
    report. Hand indices are associated geometrically, not anatomical sides.
    A valid geometric proposal may have infeasible current-pitch reach; targets
    remain available for review, never silently clamped or authorized to move.
    """
    result = dict(available=False, reason='unknown', status='unknown', target_grasps_world=None,
        motion_authorized=False, contact_authorized=False, insertion_allowed=False,
        physical_opening_verified=False, sleeve_identity_verified=False,
        closed_opening_required=False, hypothesis_based_simulation_only=True,
        full_hand_geometry_observed=False, attachment_verified=False,
        old_20mm_stop_is_user_constraint=False, read_only=True)
    try:
        values = _validated(obs, wrists=True)
        bases, grasps, yaw, tilt, now = _snapshot(obs)
        result['observation_time_s'] = now
        if (not np.isfinite([distal_gap_m, lift_margin_m]).all() or not .015 <= distal_gap_m <= .020
                or not .005 <= lift_margin_m <= .03 or now < 0 or np.max(tilt) > .065):
            raise ValueError('invalid_gap_margin_clock_or_own_base_tilt')
        closed = np.asarray(obs['gripper_close_command']).reshape(2)
        gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isin(closed, [False, True]).all() or not closed.astype(bool).all() or not np.isfinite(gap).all() or np.any(gap < 0) or np.any(gap > .08):
            raise ValueError('both_closed_controls_and_bounded_actual_finger_gap_required')
        edges, widths, edge_evidence = _current_edges(values, held_edge_report, grasps, now)
        for report, name in ((hand_report, 'hands'), (forearm_report, 'forearm_surfaces')):
            _same_frame(report, now, name)
        hands = np.asarray(hand_report['hand_points_world'], float)
        if (not hand_report.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all()
                or not .12 < np.linalg.norm(hands[1]-hands[0]) < 1.2):
            raise ValueError('two_distinct_current_observed_hand_points_required')
        surfaces = forearm_report['hand_surfaces']
        if len(surfaces) != 2:
            raise ValueError('two_current_signed_surface_reports_required')
        axes_and_evidence = [_hand_axis(row, hands[i], i) for i, row in enumerate(surfaces)]
        axes = np.asarray([item[0] for item in axes_and_evidence])
        if axes[0] @ axes[1] < np.cos(np.deg2rad(20.)):
            raise ValueError('signed_surface_axes_disagree_over_20degrees')
        _, hand_evidence = _hand_surfaces(obs, values, hands, axes)
        skin, skin_sources = _skin_points(values, hands, axes)
        rho = widths/np.pi
        options = []
        for assignment in permutations((0, 1)):
            targets, models = [], []
            for robot, hand_index in enumerate(assignment):
                evidence, axis = hand_evidence[hand_index], axes[hand_index]
                down = np.asarray(evidence['projected_gravity_down_world'])
                center = np.asarray(evidence['inferred_visible_distal_footprint_center_world'])-distal_gap_m*axis
                offset = edges[robot]-grasps[robot]
                target = center-rho[robot]*down-offset
                targets.append(target)
                models.append(dict(robot_index=robot, hand_index=hand_index,
                    hypothesized_radius_m=float(rho[robot]), radius_hypothesis_bounds_m=(widths[robot]*np.array([.2, .4])).tolist(),
                    radius_basis='W/pi assumes observed external arc W approximates one flattened cuff lip; not measured topology',
                    initial_width_m=float(widths[robot]), current_edge_world=edges[robot].tolist(),
                    edge_from_current_grasp_world=offset.tolist(), projected_gravity_down_world=down.tolist(),
                    current_hypothesized_mouth_center_world=(edges[robot]+rho[robot]*down).tolist(),
                    target_hypothesized_mouth_center_world=center.tolist(),
                    goal_grasp_z_range_for_radius_hypothesis_m=(center[2]-widths[robot]*np.array([.2, .4])*down[2]-offset[2]).tolist(),
                    distal_gap_to_observed_surface_m=float(distal_gap_m),
                    modeled_radial_margin_to_visible_footprint_m=float(rho[robot]-evidence['observed_projected_half_diagonal_m']),
                    mouth_center_is_inferred=True, physical_cuff_lip_identity_verified=False,
                    edge_offset_constant_during_proposal_only=True, actual_cloth_response_must_be_remeasured=True))
            targets = np.asarray(targets)
            options.append((float(np.linalg.norm(targets-grasps, axis=1).sum()), assignment, targets, models))
        options.sort(key=lambda item: item[0])
        if options[1][0]-options[0][0] < .03:
            raise ValueError('hand_to_held_edge_assignment_ambiguous_within_3cm_cost')
        _, assignment, goals, models = options[0]
        feasibility = _feasibility(obs, bases, grasps, yaw, goals, skin, lift_margin_m)
        feasibility['modeled_visible_footprint_fits_nominal_radius'] = all(m['modeled_radial_margin_to_visible_footprint_m'] >= 0 for m in models)
        return dict(result, available=True, status='unverified_simulation_contact_geometry_hypothesis',
            reason='current_measured_edge_offset_and_visible_hand_distal_surface_model',
            target_grasps_world=goals.tolist(), current_grasps_world=grasps.tolist(),
            hand_points_world=hands.tolist(), robot_to_hand_assignment=list(assignment),
            robot_ordered_hand_points_world=hands[list(assignment)].tolist(),
            robot_ordered_axis_world=axes[list(assignment)].tolist(),
            contains_weak_single_view_evidence=any(item[1]['weak_single_view'] for item in axes_and_evidence),
            per_hand_axis_evidence=[item[1] for item in axes_and_evidence],
            hand_surface_observations=hand_evidence, current_edge_evidence=edge_evidence,
            skin_surface_points_world=skin.tolist(), skin_surface_source_pixels=skin_sources,
            skin_surface_observation_time_s=now,
            skin_surface_scope='current skin-colored robot-camera depth near observed hands/forearms; partial visible surfaces only',
            per_robot_hypotheses=models, feasibility=feasibility,
            assumptions=['current blue edge could be a fold/silhouette rather than cuff lip',
                'gravity-projected W/pi radius is a shape hypothesis, not a detected opening',
                'goal assumes local edge-to-grasp offset remains constant only during this proposed displacement',
                'executor must verify cloth response and full own gripper clearance before and during motion'])
    except (KeyError, TypeError, ValueError, IndexError, AttributeError, np.linalg.LinAlgError) as error:
        return dict(result, reason=str(error))
