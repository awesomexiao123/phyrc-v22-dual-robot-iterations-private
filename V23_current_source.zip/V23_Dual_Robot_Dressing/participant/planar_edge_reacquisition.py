"""Local current RGB-D remeasurement of earlier planar edge-inset proposals.

The original report is a spatial/side prior, preserved with its old timestamp.
Current visible collar/hem labels are unnecessary. Every returned target,
boundary arc, depth and local plane has new evidence from this observation.
The resulting correspondence is geometric, never tracked material identity.
"""
from copy import deepcopy

import cv2
import numpy as np

from held_edge_hypotheses import _local_edge_supported
from human_targets import _validated, _world_pixels, _CAMERAS
from planar_sleeve_edge import _cyclic_runs
from public_vision import _fabric_mask


_CAMERA_ORDER = (3, 4, 1, 2)
_INSET = (.008, .025)


def _prior(initial, now):
    if not isinstance(initial, dict) or not initial.get('detected') or len(initial.get('candidates', [])) != 2:
        raise ValueError('initial_edge_pair_unavailable')
    stamp = float(initial['observation_time_s'])
    normal = np.asarray(initial['plane']['normal_world'], float)
    lateral = np.asarray(initial['plane']['lateral_axis_world'], float)
    if (not np.isfinite(stamp) or not 0 <= stamp <= now or normal.shape != (3,)
            or lateral.shape != (3,) or not np.isfinite([normal, lateral]).all()
            or not .99 < np.linalg.norm(normal) < 1.01 or not .99 < np.linalg.norm(lateral) < 1.01
            or abs(normal @ lateral) > .01):
        raise ValueError('invalid_or_future_initial_plane_prior')
    targets, edges = [], []
    for side, candidate in zip(('negative_lateral', 'positive_lateral'), initial['candidates']):
        boundary = candidate['boundary_evidence']
        target = np.asarray(candidate['target_world'], float)
        edge = np.asarray(boundary['point_world'], float)
        if (candidate['geometric_side'] != side or target.shape != (3,) or edge.shape != (3,)
                or not np.isfinite([target, edge]).all()
                or float(candidate['observation_time_s']) != stamp
                or float(boundary['observation_time_s']) != stamp):
            raise ValueError('invalid_initial_edge_provenance_or_side')
        targets.append(target); edges.append(edge)
    return np.asarray(targets), np.asarray(edges), normal, lateral


def _fit_local_plane(points, prior_normal, prior_lateral):
    if len(points) < 8:
        raise ValueError('insufficient_current_local_blue_depth_support')
    centre = points.mean(0)
    _, singular, axes = np.linalg.svd(points-centre, full_matrices=False)
    if singular[1]/np.sqrt(len(points)) < .008:
        raise ValueError('current_local_blue_support_collapsed')
    normal = axes[2]
    normal *= 1 if normal @ prior_normal >= 0 else -1
    residual = np.abs((points-centre) @ normal)
    if np.quantile(residual, .95) > .008 or residual.max() > .015:
        raise ValueError('current_local_blue_support_not_planar_or_mixed_depth')
    if normal @ prior_normal < np.cos(np.deg2rad(30)):
        raise ValueError('current_local_plane_incompatible_with_initial_orientation_prior')
    lateral = prior_lateral-normal*(prior_lateral @ normal)
    lateral /= np.linalg.norm(lateral)
    longitudinal = np.cross(normal, lateral)
    return centre, normal, lateral, longitudinal, dict(point_world=centre.tolist(),
        normal_world=normal.tolist(), lateral_axis_world=lateral.tolist(),
        longitudinal_axis_world=longitudinal.tolist(), support_pixel_count=len(points),
        fit_rms_m=float(np.sqrt(np.mean(residual**2))), max_residual_m=float(residual.max()),
        fit_basis='current measured local blue points; initial normal/side only constrain orientation')


def _view(values, camera, old_target, old_edge, prior_normal, prior_lateral, side, now):
    rgb = values['rgb'][camera].astype(float)
    blue = (rgb[..., 2] > 100) & (rgb[..., 2] > 1.25*rgb[..., 0]) & (rgb[..., 2] > 1.25*rgb[..., 1])
    fabric = _fabric_mask(values['rgb'][camera])
    depth = values['depth'][camera, ..., 0]
    valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < (3 if camera < 3 else 5))
    vv, uu = np.where(blue & valid)
    observed = _world_pixels(values, camera, uu, vv, depth[vv, uu])
    near_target = np.linalg.norm(observed-old_target, axis=1) <= .03
    if near_target.sum() < 3:
        raise ValueError('no_current_blue_target_depth_within_3cm_initial_target')
    _, labels = cv2.connectedComponents(blue.astype(np.uint8), connectivity=8)
    possible = np.unique(labels[vv[near_target], uu[near_target]])
    if len(possible) != 1:
        raise ValueError('multiple_current_blue_components_near_initial_target')
    component = labels == possible[0]
    if np.any(component[[0, -1], :]) or np.any(component[:, [0, -1]]):
        raise ValueError('current_blue_component_clipped_by_image_border')
    same = labels[vv, uu] == possible[0]
    observed, uu, vv = observed[same], uu[same], vv[same]
    local = np.linalg.norm(observed-old_target, axis=1) <= .07
    centre, normal, lateral, longitudinal, plane = _fit_local_plane(observed[local], prior_normal, prior_lateral)
    plane.update(observation_time_s=now, camera_index=camera,
        support_source_pixels_uv=np.column_stack((uu[local], vv[local])).tolist(),
        support_measured_points_world=observed[local].tolist())
    in_plane = np.abs((observed-centre) @ normal) <= .0125
    supported_image = np.zeros((256, 256), bool)
    supported_image[vv[in_plane], uu[in_plane]] = True
    observed, uu, vv = observed[in_plane], uu[in_plane], vv[in_plane]
    contours, hierarchy = cv2.findContours(component.astype(np.uint8), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    outer = [c for i, c in enumerate(contours) if hierarchy[0, i, 3] < 0]
    if len(outer) != 1:
        raise ValueError('ambiguous_current_external_blue_component')
    boundary_uv = outer[0].reshape(-1, 2)
    if len(np.unique(boundary_uv, axis=0)) != len(boundary_uv) or np.any(boundary_uv <= 1) or np.any(boundary_uv >= 254):
        raise ValueError('current_outline_self_touching_or_border_clipped')
    bu, bv = boundary_uv.T
    boundary_world = _world_pixels(values, camera, bu, bv, np.where(valid[bv, bu], depth[bv, bu], 0.))
    eligible = (valid[bv, bu] & (np.abs((boundary_world-centre) @ normal) <= .0125)
        & (np.linalg.norm(boundary_world-old_edge, axis=1) <= .06)
        & (np.linalg.norm(boundary_world-old_target, axis=1) <= .07)
        & (side*((boundary_world-old_target) @ lateral) >= .005))
    exterior = {}
    for index in np.flatnonzero(eligible):
        u, v = boundary_uv[index]
        ok, _, evidence = _local_edge_supported(values, camera, int(u), int(v), blue, fabric, valid, depth)
        eligible[index] = ok
        if ok:
            exterior[int(index)] = evidence
    arcs = []
    for run in _cyclic_runs(eligible):
        jumps = np.flatnonzero(np.linalg.norm(np.diff(boundary_world[run], axis=0), axis=1) > .025)+1
        for arc in np.split(run, jumps):
            if len(arc) >= 3 and np.ptp(boundary_world[arc] @ longitudinal) >= .025:
                arcs.append(arc)
    if len(arcs) != 1:
        raise ValueError('missing_or_ambiguous_current_local_external_edge_arc')
    arc = arcs[0]
    all_uv = np.concatenate([c.reshape(-1, 2) for c in contours])
    au, av = all_uv.T; good = valid[av, au]
    all_boundary = _world_pixels(values, camera, au[good], av[good], depth[av[good], au[good]])
    all_boundary = all_boundary[np.abs((all_boundary-centre) @ normal) <= .0125]
    proposals = []
    shift = np.linalg.norm(observed-old_target, axis=1)
    for edge_index in arc:
        point_on_edge = boundary_world[edge_index]
        difference = observed-point_on_edge
        inset = -side*(difference @ lateral)
        close = ((shift <= .03) & (inset >= _INSET[0]) & (inset <= _INSET[1])
            & (np.abs(difference @ longitudinal) <= .012) & (np.linalg.norm(difference, axis=1) <= .032))
        for point_index in np.flatnonzero(close):
            point = observed[point_index]
            strip = np.zeros((256, 256), np.uint8)
            cv2.line(strip, tuple(map(int, boundary_uv[edge_index])),
                     (int(uu[point_index]), int(vv[point_index])), 1, 1, cv2.LINE_8)
            sv, su = np.where(strip)
            if not np.all(supported_image[sv, su]):
                continue
            minimum = float(np.linalg.norm(all_boundary-point, axis=1).min())
            if not _INSET[0] <= minimum <= _INSET[1]:
                continue
            support = np.flatnonzero(np.linalg.norm(observed-point, axis=1) <= .03)
            voxels = len(np.unique(np.floor(observed[support]/.006).astype(np.int32), axis=0))
            if (len(support) < 6 or voxels < 6 or np.ptp(observed[support] @ lateral) < .01
                    or np.ptp(observed[support] @ longitudinal) < .02):
                continue
            score = 4*shift[point_index]+abs(inset[point_index]-.015)
            proposals.append((float(score), int(vv[point_index]), int(uu[point_index]),
                int(point_index), int(edge_index), float(inset[point_index]), minimum, support, voxels,
                np.column_stack((su, sv))))
    if not proposals:
        raise ValueError('no_supported_current_8_to_25mm_inset_pixel_within_3cm_prior_target')
    _, _, _, pi, ei, inset, minimum, support, voxels, strip_uv = min(proposals, key=lambda item: item[:3])
    target, boundary = observed[pi], boundary_world[ei]
    support = support[::max(1, int(np.ceil(len(support)/64)))]
    return dict(target_world=target.tolist(), observation_time_s=now,
        camera_index=camera, source_camera=_CAMERAS[camera][0], source_cameras=[camera],
        source_pixel_uv=[int(uu[pi]), int(vv[pi])], measured_target_depth_z_m=float(depth[vv[pi], uu[pi]]),
        geometric_side='negative_lateral' if side < 0 else 'positive_lateral',
        target_is_observed_blue_fabric=True, support_pixel_count=int(np.count_nonzero(np.linalg.norm(observed-target, axis=1) <= .03)),
        support_unique_voxels=voxels, support_radius_m=.03,
        support_source_pixels_uv=np.column_stack((uu[support], vv[support])).tolist(),
        support_measured_points_world=observed[support].tolist(),
        actual_lateral_inset_m=inset, allowed_measured_inset_m=list(_INSET), requested_lateral_inset_m=.015,
        nearest_supported_blue_boundary_distance_m=minimum,
        nearest_boundary_scope='all measured external and internal boundaries of current blue component',
        actual_edge_to_target_distance_m=float(np.linalg.norm(target-boundary)),
        target_shift_from_initial_m=float(np.linalg.norm(target-old_target)),
        initial_target_world=old_target.tolist(), current_local_plane=plane,
        boundary_evidence=dict(observation_time_s=now, camera_index=camera, source_camera=_CAMERAS[camera][0],
            source_pixel_uv=boundary_uv[ei].tolist(), point_world=boundary.tolist(), measured_depth_z_m=float(depth[bv[ei], bu[ei]]),
            full_arc_source_pixels_uv=boundary_uv[arc].tolist(), full_arc_measured_points_world=boundary_world[arc].tolist(),
            exterior_depth_samples=exterior[ei], inset_strip_source_pixels_uv=strip_uv.tolist(),
            inset_strip_measured_points_world=_world_pixels(values, camera, strip_uv[:, 0], strip_uv[:, 1],
                depth[strip_uv[:, 1], strip_uv[:, 0]]).tolist(),
            inset_strip_all_observed_blue_valid_and_planar=True,
            boundary_kind='current external blue silhouette; original material/cuff identity unverified'),
        heuristic=True, anatomical_side=None, opening_verified=False, cuff_edge_verified=False,
        grasp_success_verified=False, insertion_allowed=False, cross_time_identity_verified=False,
        pixel_quantization_respected=True, target_interpolated=False, patch_recentered=False)


def reacquire_planar_sleeve_edges(obs, initial_edge_report):
    """Remeasure two local edge-inset targets, or return unknown without fallback.

The nested initial report retains its exact historical evidence and timestamp.
Only ``candidates`` and their ``current_local_plane`` are current measurements.
No current full-shirt estimate, collar/hem observation, or action is requested.
"""
    values = _validated(obs, wrists=True)
    now = float(np.asarray(obs['simulation_time_s']).item())
    if not np.isfinite(now) or now < 0:
        raise ValueError('finite nonnegative current public timestamp required')
    result = dict(kind='local_planar_edge_reacquisition', observation_time_s=now,
        initial_edge_report=deepcopy(initial_edge_report), candidates=[], detected=False,
        per_camera_diagnostics=[], read_only=True, policy_modified=False,
        full_shirt_redetected=False, original_geometry_relabelled_as_current=False,
        cross_time_identity_verified=False, physical_openings_verified=False, insertion_allowed=False,
        maximum_target_shift_m=.03, allowed_measured_inset_m=list(_INSET),
        limitations='Geometric local correspondence only; original material edge, cuff identity and future contact remain unverified.')
    try:
        targets, old_edges, normal, lateral = _prior(initial_edge_report, now)
    except (KeyError, ValueError, TypeError, IndexError) as error:
        result['reason'] = str(error)
        return result
    selected = []
    for index, side in enumerate((-1, 1)):
        views = []
        for camera in _CAMERA_ORDER:
            try:
                candidate = _view(values, camera, targets[index], old_edges[index], normal, lateral, side, now)
                views.append(candidate)
                result['per_camera_diagnostics'].append(dict(initial_candidate_index=index, camera_index=camera, supported=True))
            except ValueError as error:
                result['per_camera_diagnostics'].append(dict(initial_candidate_index=index, camera_index=camera,
                    supported=False, reason=str(error)))
        if not views:
            result['reason'] = 'no_current_local_edge_inset_for_initial_candidate_'+str(index)
            return result
        for a in range(len(views)):
            for b in range(a+1, len(views)):
                if (np.linalg.norm(np.asarray(views[a]['target_world'])-views[b]['target_world']) > .02
                        or np.linalg.norm(np.asarray(views[a]['boundary_evidence']['point_world'])-
                                          views[b]['boundary_evidence']['point_world']) > .02):
                    result['reason'] = 'current_local_edge_views_disagree_over_2cm'
                    return result
        chosen = views[0]
        chosen.update(initial_candidate_index=index,
            initial_observation_time_s=float(initial_edge_report['observation_time_s']),
            agreeing_camera_indices=[view['camera_index'] for view in views])
        selected.append(chosen)
    span = float(np.linalg.norm(np.asarray(selected[1]['target_world'])-selected[0]['target_world']))
    if not .30 < span < 1.:
        result['reason'] = 'current_reacquired_pair_span_outside_existing_policy_bounds'
        return result
    result.update(detected=True, reason='two_current_locally_remeasured_edge_inset_hypotheses',
        candidates=selected, candidate_span_m=span, candidate_world_heights_m=[c['target_world'][2] for c in selected])
    return result
