"""Passive, bounded measured settling before a loaded wrist experiment.

Zero rate commands preserve native integrated position targets. This module
does not cancel targets or certify physical stopping, attachment or entry.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from loaded_roll_observation import _cloth_evidence, _state
from public_vision import _rotation


class LoadedWristHandoff:
    MAX_SECONDS = 3.
    SETTLE_SECONDS = .25
    FIXED_LAG_LIMITS = np.array([.0015, .003, np.deg2rad(.15), np.deg2rad(.15)])

    def __init__(self, obs, hands, observed_at, *, stationary_human=True, max_hand_age_s=300.):
        self.done = False; self.failure = None; self.debug = {}
        self.stable_seconds = 0.; self.previous_stable = False; self.calls = 0
        self.time0 = self.last_time = None
        self.initial_error = None
        self.stationary_human = stationary_human is True
        self.hand_report = deepcopy(hands)
        self.observed_at = observed_at; self.max_hand_age_s = max_hand_age_s
        # Capture only the initial public state. Eligibility is checked by step.
        try:
            bases, grasps, _, _, now = _snapshot(obs)
            self.base0 = bases.copy(); self.grasp0 = grasps.copy()
            self.rotations0 = np.array([_rotation(b[3:]) for b in bases])
            self.time0 = self.last_time = now
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.initial_error = str(error)

    def _result(self):
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        self.debug.update(phase='failed' if self.failure else 'settled' if self.done else 'passive_settle',
            failure=self.failure, measured_stable_seconds=self.stable_seconds,
            settle_required_seconds=self.SETTLE_SECONDS, budget_seconds=self.MAX_SECONDS,
            initial_observation_time_s=self.time0, cached_hand_observed_at_s=self.observed_at,
            calls=self.calls, target_cancellation_performed=False,
            zero_action_cancels_integrated_target=False, attachment_verified=False,
            observed_point_clearance_only=True, full_human_or_wrist_sweep_clearance_verified=False,
            insertion_allowed=False)
        return dict(action=action, done=self.done, failure=self.failure, debug=deepcopy(self.debug))

    def step(self, obs):
        if self.done:
            return self._result()
        self.calls += 1
        try:
            if self.initial_error:
                raise ValueError(self.initial_error)
            bases, grasps, _, tilt, now = _snapshot(obs)
            q, qd, targets = _state(obs)
            twist = np.asarray(obs['base_twist_world'], float)
            if twist.shape != (2, 6) or not np.isfinite(twist).all():
                raise ValueError('finite_public_base_twist_required')
            dt = now-self.last_time
            if dt < -1e-8 or dt > .075:
                raise ValueError('nonconsecutive_public_observation_clock')
            self.last_time = now
            elapsed = now-self.time0
            self.debug.update(observation_time_s=now, elapsed_seconds=elapsed)
            if elapsed > self.MAX_SECONDS+1e-8:
                raise ValueError('passive_wrist_handoff_settle_timeout')
            observed_at = float(self.observed_at); max_age = float(self.max_hand_age_s)
            if not self.stationary_human:
                raise ValueError('explicit_verified_stationary_human_assumption_required')
            if not np.isfinite([observed_at, max_age]).all() or not 0 < max_age <= 300:
                raise ValueError('invalid_stationary_hand_cache_bound')
            hands = np.asarray(self.hand_report.get('hand_points_world'), float)
            if (not self.hand_report.get('detected') or hands.shape != (2, 3)
                    or not np.isfinite(hands).all() or not .06 <= np.linalg.norm(hands[1]-hands[0]) <= 1.2):
                raise ValueError('two_separated_observed_hand_points_required')
            report_time = self.hand_report.get('observation_time_s')
            if report_time is not None:
                report_time = float(report_time)
                if not np.isfinite(report_time) or abs(report_time-observed_at) > 1e-7:
                    raise ValueError('hand_observation_timestamp_sources_disagree')
            age = now-observed_at
            self.debug['hand_observation_age_s'] = age
            if not -1e-7 <= age <= max_age:
                raise ValueError('stationary_hand_cache_stale_or_from_future')
            if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
                raise ValueError('closed_gripper_intent_lost')
            gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
            if not np.isfinite(gap).all() or np.any(gap < 0) or gap.max() > .08:
                raise ValueError('closed_gripper_gap_guard')
            base_drift = np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1)
            grasp_drift = np.linalg.norm(grasps-self.grasp0, axis=1)
            rotations = np.array([_rotation(b[3:]) for b in bases])
            relative = np.einsum('nij,nkj->nik', rotations, self.rotations0)
            rotation_drift = np.arccos(np.clip((np.trace(relative, axis1=1, axis2=2)-1)/2, -1., 1.))
            self.debug.update(base_drift_m=base_drift.tolist(), grasp_drift_m=grasp_drift.tolist(),
                              base_rotation_drift_rad=rotation_drift.tolist())
            if grasp_drift.max() > .01:
                raise ValueError('passive_grasp_drift_over_1cm')
            if base_drift.max() > .003 or rotation_drift.max() > np.deg2rad(.25):
                raise ValueError('passive_base_drift_or_rotation_limit')
            if np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60 or tilt.max() > .065:
                raise ValueError('base_pair_separation_or_tilt_guard')
            fixed_lag = np.column_stack((targets[:, 0]-q[:, 3], targets[:, 1]-q[:, 4:8].sum(1),
                                        targets[:, 2]-q[:, 8], targets[:, 3]-q[:, 9]))
            roll_lag = targets[:, 4]-q[:, 10]
            arm_speed = qd[:, 4:8].sum(1)
            self.debug.update(fixed_joint_target_lag_lift_arm_yaw_pitch=fixed_lag.tolist(),
                fixed_joint_target_lag_limits_m_m_rad_rad=self.FIXED_LAG_LIMITS.tolist(),
                roll_target_lag_rad=roll_lag.tolist(), joint_velocity=qd.tolist(),
                aggregate_arm_velocity_m_s=arm_speed.tolist(), base_twist_world=twist.tolist(),
                applied_base_targets=targets[:, 6:9].tolist(), controller_target=targets.tolist())
            self.debug.update(_cloth_evidence(obs, grasps, hands))
            conditions = dict(
                fixed_joint_target_lag=bool(np.all(np.abs(fixed_lag) <= self.FIXED_LAG_LIMITS)),
                roll_target_lag=bool(np.max(np.abs(roll_lag)) <= np.deg2rad(.01)),
                linear_joint_velocity=bool(np.max(np.abs(qd[:, 3:8])) <= .003 and np.max(np.abs(arm_speed)) <= .003),
                wrist_velocity=bool(np.max(np.abs(qd[:, 8:11])) <= np.deg2rad(.1)),
                base_velocity=bool(np.max(np.linalg.norm(twist[:, :3], axis=1)) <= .002
                                   and np.max(np.linalg.norm(twist[:, 3:], axis=1)) <= .002),
                applied_base_targets_zero=bool(np.max(np.abs(targets[:, 6:9])) <= 1e-5))
            stable = all(conditions.values())
            self.debug.update(settle_conditions=conditions, currently_settled=stable)
            if not stable:
                self.stable_seconds = 0.; self.previous_stable = False
            elif dt > 1e-8:
                self.stable_seconds = self.stable_seconds+dt if self.previous_stable else 0.
                self.previous_stable = True
            elif self.calls == 1:
                self.previous_stable = True
            if self.stable_seconds >= self.SETTLE_SECONDS-1e-8:
                self.done = True
            elif elapsed >= self.MAX_SECONDS-1e-8:
                raise ValueError('passive_wrist_handoff_settle_timeout')
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error); self.done = True
        return self._result()
