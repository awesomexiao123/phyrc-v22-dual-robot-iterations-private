"""Unverified sleeve-side fabric hypotheses for a visibly planar shirt.

Public RGB-D only. Yellow trim geometry is an appearance heuristic, not a
semantic label. No sleeve opening, anatomical side, or safe insertion is claimed.
The hem-to-collar centre line estimates garment length. A V-neck or rounded
neckline can have its own principal axis parallel to the hem; that axis does
not determine whether the collar hypothesis is compatible.
"""
import argparse
import json
from pathlib import Path

import numpy as np

from public_vision import cloth_cloud
from human_targets import garment_edge_candidates


def _unit(value):
    value = np.asarray(value, dtype=float)
    norm = np.linalg.norm(value)
    return value/norm if norm > 1e-8 else None


def _connected_support(points, center, axes, cell=.025):
    """Largest 8-connected component in an observed plane's 2-D occupancy.

    Sparse grid connectivity avoids filling gaps or assigning unseen fabric.
    The returned fraction counts observed spatial points, not occupied cells.
    """
    grid = np.floor(((points-center) @ axes[:2].T)/cell).astype(np.int64)
    cells, inverse, counts = np.unique(grid, axis=0, return_inverse=True, return_counts=True)
    remaining = {tuple(key): index for index, key in enumerate(cells)}
    largest, largest_count = [], 0
    while remaining:
        key, index = remaining.popitem()
        component, stack = [index], [key]
        while stack:
            x, y = stack.pop()
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    neighbor = (x+dx, y+dy)
                    other = remaining.pop(neighbor, None)
                    if other is not None:
                        component.append(other)
                        stack.append(neighbor)
        count = int(counts[component].sum())
        if count > largest_count:
            largest, largest_count = component, count
    return np.isin(inverse, largest), largest_count/max(len(points), 1)


def _robust_plane(points, fit):
    """Reject nonplanar cloth while tolerating a small depth-boundary tail.

    Deterministic geometric RANSAC requires >=94% of spatial voxels AND pixels
    within 12.5 mm. Thus a large second fold cannot be discarded as outliers.
    At least 97% of those inliers must be one connected observed surface. These
    are conservative appearance checks, not a proof that all fabric is flat.
    """
    tolerance = .0125
    rng = np.random.default_rng(0)
    best = None
    for _ in range(256):
        triple = fit[rng.choice(len(fit), 3, replace=False)]
        cross = np.cross(triple[1]-triple[0], triple[2]-triple[0])
        # Near-collinear triples do not define a stable plane.
        if np.linalg.norm(cross) < .001:
            continue
        normal = _unit(cross)
        distance = np.abs((fit-triple[0]) @ normal)
        score = (int(np.count_nonzero(distance <= tolerance)), -float(np.median(distance)))
        if best is None or score > best[0]:
            best = score, triple[0], normal
    if best is None:
        return None, np.zeros(len(points), bool), 'unknown_fabric_not_sufficiently_planar'
    _, center, normal = best
    inlier = np.abs((fit-center) @ normal) <= tolerance
    for _ in range(3):
        if np.count_nonzero(inlier) < 100:
            return None, np.zeros(len(points), bool), 'unknown_fabric_not_sufficiently_planar'
        center = np.mean(fit[inlier], axis=0)
        _, singular, axes = np.linalg.svd(fit[inlier]-center, full_matrices=False)
        normal = axes[-1]
        inlier = np.abs((fit-center) @ normal) <= tolerance
    # Audit every original blue pixel too: voxel reduction must not conceal a
    # densely observed fold or include discarded depth outliers in targets.
    pixel_inlier = np.abs((points-center) @ normal) <= tolerance
    distance = np.abs((fit[inlier]-center) @ normal)
    thickness = float(np.percentile(distance, 95))
    ratio = float(singular[-1]/max(singular[1], 1e-12))
    component, connected_fraction = _connected_support(fit[inlier], center, axes)
    plane = dict(point_world=center.tolist(), normal_world=normal.tolist(),
                 p95_surface_distance_m=thickness, thin_axis_ratio=ratio,
                 spatial_points=int(len(fit)), spatial_inlier_count=int(inlier.sum()),
                 spatial_inlier_fraction=float(inlier.mean()), pixel_inlier_count=int(pixel_inlier.sum()),
                 pixel_inlier_fraction=float(pixel_inlier.mean()),
                 rejected_blue_pixel_count=int(np.count_nonzero(~pixel_inlier)),
                 connected_inlier_fraction=float(connected_fraction),
                 fit_method='deterministic_ransac_then_inlier_svd',
                 inlier_distance_limit_m=tolerance, minimum_inlier_fraction=.94,
                 minimum_connected_fraction=.97, connectivity_grid_m=.025,
                 hypothesis=True, full_garment_planarity_verified=False)
    if (inlier.mean() < .94 or pixel_inlier.mean() < .94 or
            singular[1]/np.sqrt(inlier.sum()) < .055 or thickness > .025 or ratio > .12):
        return plane, pixel_inlier, 'unknown_fabric_not_sufficiently_planar'
    if connected_fraction < .97:
        return plane, pixel_inlier, 'unknown_disconnected_planar_fabric_support'
    # Remove even the small disconnected planar tail from downstream target
    # proposals. Only pixels in cells connected to the supported component count.
    connected_grid = np.floor(((fit[inlier][component]-center) @ axes[:2].T)/.025).astype(np.int64)
    connected_cells = {tuple(cell) for cell in connected_grid}
    all_grid = np.floor(((points-center) @ axes[:2].T)/.025).astype(np.int64)
    pixel_inlier &= np.fromiter((tuple(cell) in connected_cells for cell in all_grid), bool, len(points))
    plane['retained_blue_pixel_count'] = int(pixel_inlier.sum())
    return plane, pixel_inlier, None


def _trim_groups(candidates, center, normal):
    """Combine repeated camera observations of one strip, not distinct strips."""
    groups = []
    for item in sorted(candidates, key=lambda c: -float(c.get('confidence', 0))):
        point = np.asarray(item.get('centroid_world', []), dtype=float)
        axis = np.asarray(item.get('principal_axis_world', []), dtype=float)
        extent = float(item.get('extent_m', 0))
        if point.shape != (3,) or axis.shape != (3,) or not np.isfinite(np.r_[point, axis, extent]).all():
            continue
        axis = _unit(axis)
        if axis is None or extent < .02 or abs((point-center)@normal) > .04 or abs(axis@normal) > .30:
            continue
        axis = _unit(axis-normal*(axis@normal))
        entry = dict(centroid_world=point.tolist(), principal_axis_world=axis.tolist(),
                     extent_m=extent, elongation=float(item.get('elongation', 0)),
                     cameras=[item.get('camera_index')], heuristic=True, verified=False)
        match = None
        for previous in groups:
            ratio = extent/previous['extent_m']
            if (item.get('camera_index') is not None and item.get('camera_index') not in previous['cameras'] and
                    np.linalg.norm(point-previous['centroid_world']) < .04 and
                    abs(axis @ previous['principal_axis_world']) > .9 and .65 < ratio < 1.55):
                match = previous
                break
        if match is None:
            groups.append(entry)
        elif item.get('camera_index') not in match['cameras']:
            # Keep the best observed strip's geometry. Averaging unmatched
            # endpoints would fabricate an unseen yellow segment.
            match['cameras'].append(item.get('camera_index'))
    return groups


def _supported_blue_patch(points, camera_ids, band_indices, desired, lateral_axis, longitudinal_axis, center):
    candidates = points[band_indices]
    plane_xy = np.column_stack(((candidates-center)@lateral_axis,
                                (candidates-center)@longitudinal_axis))
    order = np.argsort(np.linalg.norm(plane_xy-desired, axis=1))[:64]
    for proposal in order:
        point = candidates[proposal]
        near = np.linalg.norm(points-point, axis=1) < .045
        if np.count_nonzero(near) < 24:
            continue
        if len(np.unique(np.floor(points[near]/.006).astype(np.int32), axis=0)) < 12:
            continue
        # Re-centre within the supported observed surface, then audit the exact
        # measured target again. No imaginary opening centre is returned.
        local = points[near]
        median = np.median(local, axis=0)
        point = local[np.argmin(np.linalg.norm(local-median, axis=1))]
        near = np.linalg.norm(points-point, axis=1) < .045
        support = int(np.count_nonzero(near))
        unique = len(np.unique(np.floor(points[near]/.006).astype(np.int32), axis=0))
        if support >= 24 and unique >= 12:
            return dict(target_world=point.tolist(), support_pixel_count=support,
                        support_unique_voxels=int(unique), source_cameras=sorted(int(c) for c in np.unique(camera_ids[near])),
                        target_is_observed_blue_fabric=True, opening_verified=False,
                        anatomical_side=None, heuristic=True)
    return None


def estimate_planar_shirt(obs):
    """Return two supported fabric patches only if all geometric tests pass.

    Assumptions: a roughly flat blue T-shaped garment with a long yellow hem-like
    strip and one shorter collar-like contour separated along the garment's
    length. The hem-to-collar centre line must be roughly perpendicular to the
    hem. The collar's own principal axis is unconstrained within the fabric
    plane: V-necks and rounded necklines often extend parallel to the hem.
    These labels are hypotheses. Ambiguous trim, folds, or unsupported sides
    return unknown.
    """
    result = dict(detected=False, reason='unknown', candidates=[], hem_hypothesis=None,
                  collar_hypothesis=None, plane=None, opening_verified=False,
                  anatomical_left_right_verified=False, classification='heuristic_unverified',
                  assumptions='planar blue garment; unique long hem-like and shorter collar-like yellow trim separated along garment length; wider upper fabric region',
                  collar_principal_axis_is_orientation_constraint=False)
    cloud = cloth_cloud(obs)
    points = np.asarray(cloud['world_points'], dtype=float)
    color = np.asarray(cloud['rgb'], dtype=float)
    ids = np.asarray(cloud['camera_ids'])
    blue = ((color[:, 2] > 100) & (color[:, 2] > 1.25*color[:, 0]) & (color[:, 2] > 1.25*color[:, 1])
            & np.isfinite(points).all(axis=1)) if len(points) else np.zeros(0, bool)
    points, ids = points[blue], ids[blue]
    result['blue_pixel_count'] = int(len(points))
    if len(points) < 160:
        result['reason'] = 'unknown_insufficient_observed_blue_fabric'
        return result
    _, unique_indices = np.unique(np.floor(points/.008).astype(np.int32), axis=0, return_index=True)
    fit = points[unique_indices]
    if len(fit) < 100:
        result['reason'] = 'unknown_insufficient_spatial_blue_support'
        return result
    result['plane'], keep, rejection = _robust_plane(points, fit)
    if rejection is not None:
        result['reason'] = rejection
        return result
    points, ids = points[keep], ids[keep]
    center = np.asarray(result['plane']['point_world'])
    normal = np.asarray(result['plane']['normal_world'])
    edge_data = garment_edge_candidates(obs)
    groups = _trim_groups(edge_data.get('yellow_trim_candidates', []), center, normal)
    result['yellow_strip_hypothesis_count'] = len(groups)
    if len(groups) < 2:
        result['reason'] = 'unknown_no_unique_hem_collar_pair'
        return result
    largest = max(g['extent_m'] for g in groups)
    pairs = []
    for hem in groups:
        if hem['extent_m'] < max(.18, .8*largest) or hem['elongation'] < 3:
            continue
        lateral = np.asarray(hem['principal_axis_world'])
        for collar in groups:
            if collar is hem or not .12 <= collar['extent_m']/hem['extent_m'] <= .65:
                continue
            difference = np.asarray(collar['centroid_world'])-hem['centroid_world']
            difference -= normal*(difference@normal)
            length = np.linalg.norm(difference)
            if length < max(.14, .3*hem['extent_m']):
                continue
            longitudinal = difference/length
            # It is the hem-centre to collar-centre POSITION vector that follows
            # garment length. A V/round collar's transverse PCA axis can instead
            # be parallel to the hem, and must not disqualify that contour.
            if abs(longitudinal@lateral) > .35:
                continue
            pairs.append((hem, collar, lateral, longitudinal, float(length)))
    result['compatible_pair_count'] = len(pairs)
    if len(pairs) != 1:
        result['reason'] = 'unknown_ambiguous_hem_collar_pairs' if pairs else 'unknown_no_compatible_hem_collar_pair'
        return result
    hem, collar, lateral, longitudinal, length = pairs[0]
    # Orthonormalize against the actual hem direction, preserving the observed
    # direction from hem to collar. Signs are geometric, never anatomical sides.
    longitudinal = _unit(longitudinal-lateral*(longitudinal@lateral))
    origin = np.asarray(hem['centroid_world'])
    x = (points-origin)@lateral
    y = (points-origin)@longitudinal
    collar_y = float((np.asarray(collar['centroid_world'])-origin)@longitudinal)
    collar_x = float((np.asarray(collar['centroid_world'])-origin)@lateral)
    band = np.abs(y-collar_y) <= max(.08, .25*length)
    middle = (y > .25*collar_y) & (y < .65*collar_y)
    result.update(hem_hypothesis=dict(hem, role='hem_like_unverified'),
                  collar_hypothesis=dict(collar, role='collar_like_unverified'))
    result['plane'].update(lateral_axis_world=lateral.tolist(),
                           longitudinal_axis_world=longitudinal.tolist(), hem_to_collar_distance_m=length)
    if np.count_nonzero(band) < 80 or np.count_nonzero(middle) < 60:
        result['reason'] = 'unknown_insufficient_upper_or_midbody_support'
        return result
    low, high = np.percentile(x[band], [8, 92])
    mid_low, mid_high = np.percentile(x[middle], [8, 92])
    upper_span, body_span = float(high-low), float(mid_high-mid_low)
    result['observed_upper_span_m'], result['observed_midbody_span_m'] = upper_span, body_span
    extension = max(.02, .05*hem['extent_m'])
    if (upper_span < 1.10*body_span or upper_span < 1.10*hem['extent_m'] or
            low >= collar_x-.5*hem['extent_m']-extension or high <= collar_x+.5*hem['extent_m']+extension):
        result['reason'] = 'unknown_no_supported_wider_sleeve_side_shape'
        return result
    selected = []
    for sign, target_x in ((-1, low), (1, high)):
        region = band & ((x-collar_x)*sign > .25*hem['extent_m'])
        candidate = _supported_blue_patch(points, ids, np.flatnonzero(region),
                                           [target_x, collar_y], lateral, longitudinal, origin)
        if candidate is None:
            result['reason'] = 'unknown_insufficient_sleeve_side_patch_support'
            return result
        candidate['geometric_side'] = 'negative_lateral' if sign < 0 else 'positive_lateral'
        selected.append(candidate)
    result.update(detected=True, candidates=selected, reason='planar_sleeve_side_fabric_hypotheses',
                  candidate_span_m=float(np.linalg.norm(np.asarray(selected[0]['target_world'])-selected[1]['target_world'])),
                  candidate_world_heights_m=[p['target_world'][2] for p in selected],
                  confidence_basis=['dominant_connected_observed_plane', 'unique_hem_collar_size_and_position_pair',
                                    'upper_blue_fabric_wider_than_midbody_and_hem', 'two_locally_supported_observed_blue_patches'],
                  confidence_is_calibrated=False)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Offline public-observation-only planar shirt inspection')
    parser.add_argument('--sample', type=Path, default=Path(__file__).with_name('sample_observation.npz'))
    args = parser.parse_args()
    with np.load(args.sample, allow_pickle=False) as sample:
        output = estimate_planar_shirt({key: sample[key] for key in sample.files})
    print(json.dumps(dict(sample_path=str(args.sample.resolve()), offline_only=True, result=output),
                     ensure_ascii=False, indent=2, allow_nan=False))
