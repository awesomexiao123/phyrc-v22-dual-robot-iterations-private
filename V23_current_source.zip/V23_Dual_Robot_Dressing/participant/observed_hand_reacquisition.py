"""Current RGB-D surface reacquisition tied to previously observed identities.

The original stationary-human points are search/identity priors only. Returned
points are medoids of current measured skin-colored surface pixels, never
cached positions, a skeleton, or an averaged point inside an unseen hand.
"""
from collections import deque
from itertools import combinations

import cv2
import numpy as np

from camera_geometry import project_optical
from human_targets import _validated, _camera_transform, _world_pixels, _FOCAL, _CAMERAS
from public_vision import _fabric_mask, world_to_base
from navigation import (_model_mast_self_mask, _model_gripper_self_mask,
                        _model_base_surface_self_mask, _model_wheel_self_mask)


SEARCH_RADIUS_M = .06
MAX_MEDOID_PRIOR_SHIFT_M = .04
MAX_CROSS_VIEW_MEDOID_DISTANCE_M = .035
MAX_NEIGHBOR_DISTANCE_M = .025
MIN_VALID_PIXELS = 12
MIN_VALID_FRACTION = .80
MIN_SECOND_SURFACE_SPAN_M = .004
MAX_COMPONENT_PIXELS = 1200
MAX_DEPTH_IQR_M = .04
MAX_PRIOR_AGE_S = 300.


def _skin(rgb):
    # Same explicit color rule as the frozen public detector, not a new model.
    r, g, b = np.asarray(rgb, np.int16).transpose(2, 0, 1)
    return (r > 120) & (r-g > 4) & (r-b > 7) & (g-b < 12) & (g-b > -12)


def _own_surface_mask(obs, points):
    """Narrow published own visual envelopes; no 12cm grasp exclusion ball."""
    excluded = np.zeros(len(points), bool)
    for robot in (0, 1):
        local = world_to_base(obs, robot, points)
        excluded |= (_model_mast_self_mask(obs, robot, points) |
                     _model_gripper_self_mask(obs, robot, points) |
                     _model_base_surface_self_mask(local) | _model_wheel_self_mask(local))
    return excluded


def _components(mask, world_image):
    visited = np.zeros(mask.shape, bool)
    result = []
    for y, x in zip(*np.where(mask)):
        if visited[y, x]:
            continue
        queue = deque([(int(y), int(x))]); visited[y, x] = True
        component = []
        while queue:
            y, x = queue.popleft(); component.append((y, x))
            if len(component) > MAX_COMPONENT_PIXELS:
                raise ValueError('current_surface_component_exceeds_bounded_size')
            for yy, xx in ((y-1, x), (y+1, x), (y, x-1), (y, x+1)):
                if (0 <= yy < 256 and 0 <= xx < 256 and mask[yy, xx] and not visited[yy, xx]
                        and np.linalg.norm(world_image[yy, xx]-world_image[y, x]) <= MAX_NEIGHBOR_DISTANCE_M):
                    visited[yy, xx] = True; queue.append((yy, xx))
        if len(component) >= MIN_VALID_PIXELS:
            result.append(np.asarray(component, int))
    return result


def _medoid(points):
    # Exact medoid, in bounded batches: returned index is an actual source pixel.
    cost = np.zeros(len(points))
    for start in range(0, len(points), 64):
        cost[start:start+64] = np.linalg.norm(points[start:start+64, None]-points[None], axis=2).sum(axis=1)
    return int(np.argmin(cost))


def _camera_hand_views(obs, values, camera, hand, other):
    rotation, origin = _camera_transform(values, camera)
    optical = (hand-origin) @ rotation
    if optical[2] <= SEARCH_RADIUS_M+.03:
        return [], ['prior_not_in_front_of_camera']
    uv = project_optical(optical, _FOCAL)
    radius = _FOCAL*SEARCH_RADIUS_M/(optical[2]-SEARCH_RADIUS_M)
    if not np.isfinite(np.r_[uv, radius]).all():
        return [], ['invalid_prior_projection']
    yy, xx = np.indices((256, 256))
    projected = (xx-uv[0])**2+(yy-uv[1])**2 <= radius**2
    color = _skin(values['rgb'][camera]) & ~_fabric_mask(values['rgb'][camera]) & projected
    count, labels, stats, _ = cv2.connectedComponentsWithStats(color.astype(np.uint8), connectivity=8)
    depth = values['depth'][camera, ..., 0]
    valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth) &
             (depth > .03) & (depth < (3. if camera < 3 else 5.)))
    candidates, reasons = [], []
    for label in range(1, count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area < MIN_VALID_PIXELS:
            continue
        if area > MAX_COMPONENT_PIXELS:
            reasons.append('colored_component_exceeds_bounded_size'); continue
        component = labels == label
        fraction = float(valid[component].mean())
        if fraction < MIN_VALID_FRACTION:
            reasons.append('insufficient_current_valid_depth_fraction'); continue
        v, u = np.where(component & valid)
        points = _world_pixels(values, camera, u, v, depth[v, u])
        own = _own_surface_mask(obs, points)
        near = ((np.linalg.norm(points-hand, axis=1) <= SEARCH_RADIUS_M) &
                (np.linalg.norm(points-other, axis=1) > SEARCH_RADIUS_M) & ~own)
        if near.sum() < MIN_VALID_PIXELS:
            reasons.append('current_color_depth_not_near_prior_or_is_own_robot'); continue
        world_image = np.full((256, 256, 3), np.nan)
        world_image[v, u] = points
        allowed = np.zeros((256, 256), bool); allowed[v[near], u[near]] = True
        chunks = _components(allowed, world_image)
        for chunk in chunks:
            y, x = chunk.T
            observed = world_image[y, x]
            # Reject a narrow scan-line or mixed depth surfaces as hand support.
            center = np.median(observed, axis=0)
            _, _, axes = np.linalg.svd(observed-center, full_matrices=False)
            spans = np.ptp((observed-center) @ axes.T, axis=0)
            if spans[1] < MIN_SECOND_SURFACE_SPAN_M:
                reasons.append('current_surface_not_spatially_supportive'); continue
            depth_iqr = float(np.percentile(depth[y, x], 75)-np.percentile(depth[y, x], 25))
            if depth_iqr > MAX_DEPTH_IQR_M:
                reasons.append('current_surface_depth_spread_too_large'); continue
            selected = _medoid(observed)
            point = observed[selected]
            shift = float(np.linalg.norm(point-hand))
            candidates.append(dict(camera_index=camera, source_camera=_CAMERAS[camera][0],
                hand_surface_world=point.tolist(), surface_pixel_uv=[int(x[selected]), int(y[selected])],
                median_optical_depth_m=float(np.median(depth[y, x])), depth_iqr_m=depth_iqr,
                valid_pixel_count=len(observed), source_color_component_pixels=area,
                source_color_component_depth_valid_fraction=fraction,
                source_pixels_uv=np.column_stack((x, y)).tolist(),
                prior_distance_m=shift, prior_shift_within_limit=shift <= MAX_MEDOID_PRIOR_SHIFT_M,
                observed_surface_spans_m=spans.tolist(), filtered_own_pixel_count=int(own.sum()),
                source_pixels_scope='current measured connected patch only; not full hand shape'))
    return candidates, list(dict.fromkeys(reasons or ([] if candidates else ['no_supported_skin_surface_near_original_prior'])))


def reacquire_observed_hand_pair(obs, original_hand_report, original_observed_at,
                                stationary_human=True, max_prior_age_s=300):
    """Return a whole current pair or explicit unknown, preserving original IDs.

    A one-view surface is a weak reacquisition hypothesis. Even agreeing camera
    patches do not establish full hand geometry or anatomical identity. The
    caller must separately recompute current forearm axes and footprint pixels.
    """
    result = dict(detected=False, hand_points_world=[], midpoint_world=None, span_m=None,
        observation_time_s=None, original_observed_at_s=original_observed_at,
        original_prior_age_s=None, original_hand_points_world=None, hand_reports=[],
        reason='current_pair_unavailable', confidence=0., cameras=[],
        stationary_human_assumption_declared=stationary_human is True,
        original_prior_timestamp_refreshed=False, original_prior_coordinates_used_as_output=False,
        anatomical_labels=False, full_hand_geometry_observed=False, insertion_allowed=False,
        point_order='original measured hand identity order; not anatomical left/right',
        self_filter='both own robots narrow published mast/housing/finger/chassis/wheel visual masks; no broad grasp ball',
        limits=dict(search_radius_m=SEARCH_RADIUS_M, max_medoid_prior_shift_m=MAX_MEDOID_PRIOR_SHIFT_M,
                    cross_view_medoid_distance_m=MAX_CROSS_VIEW_MEDOID_DISTANCE_M,
                    min_valid_pixels=MIN_VALID_PIXELS, min_valid_fraction=MIN_VALID_FRACTION,
                    max_neighbor_distance_m=MAX_NEIGHBOR_DISTANCE_M, max_prior_age_s=max_prior_age_s),
        limitations=['Stationary-human identity prior is declared, not proven by this function.',
            'Scene-specific skin color can resemble other objects; partial surfaces can shift with view.',
            'Own visual masks are approximate; contacting surfaces may be excluded and unmodeled self surfaces may remain.',
            'Source pixels describe incomplete visible surfaces, not a skeleton or full hand envelope.',
            'No fallback to cached points, no automatic prior update, and no forearm or insertion direction is produced.'])
    try:
        now = float(np.asarray(obs['simulation_time_s']).item())
        prior_time, maximum_age = float(original_observed_at), float(max_prior_age_s)
        if not np.isfinite([now, prior_time, maximum_age]).all():
            raise ValueError('nonfinite_public_or_prior_timestamp')
        result.update(observation_time_s=now, original_prior_age_s=now-prior_time,
                      original_observed_at_s=prior_time)
        if stationary_human is not True:
            raise ValueError('explicit_stationary_human_assumption_required')
        if not 0 < maximum_age <= MAX_PRIOR_AGE_S or not 0 <= now-prior_time <= maximum_age:
            raise ValueError('original_stationary_prior_stale_future_or_age_limit_invalid')
        if (original_hand_report.get('observation_time_s') is not None and
                abs(float(original_hand_report['observation_time_s'])-prior_time) > 1e-6):
            raise ValueError('original_prior_timestamp_sources_disagree')
        hands = np.asarray(original_hand_report.get('hand_points_world'), float)
        if not original_hand_report.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all():
            raise ValueError('two_original_observed_surface_points_required')
        result['original_hand_points_world'] = hands.tolist()
        distance = float(np.linalg.norm(hands[1]-hands[0]))
        if distance <= 2*SEARCH_RADIUS_M or distance > 1.2:
            raise ValueError('overlapping_or_implausible_original_identity_neighborhoods')
        values = _validated(obs, wrists=True)
        if any(np.max(np.abs(np.linalg.norm(values[key][:, 3:], axis=1)-1)) > .01
               for key in ('base_pose_world', 'grasp_pose_base')):
            raise ValueError('own_camera_pose_quaternion_not_near_unit')
        for index in (0, 1):
            views, rejections, ambiguous = [], [], False
            for camera in (1, 2, 3, 4):
                found, reasons = _camera_hand_views(obs, values, camera, hands[index], hands[1-index])
                if len(found) > 1:
                    ambiguous = True
                    reasons.append('multiple_current_surface_patches_for_original_hand')
                elif len(found) == 1:
                    views.append(found[0])
                rejections.append(dict(camera_index=camera, reasons=reasons))
            conflicts = [dict(camera_indices=[a['camera_index'], b['camera_index']],
                              medoid_distance_m=float(np.linalg.norm(np.array(a['hand_surface_world'])-b['hand_surface_world'])))
                         for a, b in combinations(views, 2)
                         if np.linalg.norm(np.array(a['hand_surface_world'])-b['hand_surface_world']) > MAX_CROSS_VIEW_MEDOID_DISTANCE_M]
            reason = ('multiple_current_surface_patches_for_original_hand' if ambiguous else
                      'current_camera_surface_points_conflict' if conflicts else
                      'current_surface_medoid_exceeds_original_prior_shift' if any(not v['prior_shift_within_limit'] for v in views) else
                      'no_current_supported_surface_for_original_hand' if not views else
                      'single_view_current_surface_hypothesis' if len(views) == 1 else
                      'agreeing_current_camera_surface_hypotheses')
            detected = bool(views and not ambiguous and not conflicts and all(v['prior_shift_within_limit'] for v in views))
            chosen = min(views, key=lambda v: (v['prior_distance_m'], -v['valid_pixel_count'])) if detected else None
            result['hand_reports'].append(dict(hand_index=index, detected=detected, reason=reason,
                hand_surface_world=chosen['hand_surface_world'] if chosen else None,
                selected_camera_index=chosen['camera_index'] if chosen else None,
                selected_surface_pixel_uv=chosen['surface_pixel_uv'] if chosen else None,
                observation_time_s=now, original_observed_at_s=prior_time,
                original_surface_prior_world=hands[index].tolist(),
                point_selection='actual current component medoid from one camera; never a cross-view average',
                weak_single_view=len(views) == 1, candidate_views=views,
                conflicting_views=conflicts, rejected_views=rejections,
                incomplete_visible_surface=True, anatomical_identity_verified=False))
        if not all(hand['detected'] for hand in result['hand_reports']):
            result['reason'] = 'whole_current_pair_required: '+'; '.join(
                f"hand{hand['hand_index']}={hand['reason']}" for hand in result['hand_reports'] if not hand['detected'])
            return result
        points = np.asarray([hand['hand_surface_world'] for hand in result['hand_reports']])
        result.update(detected=True, hand_points_world=points.tolist(), midpoint_world=points.mean(axis=0).tolist(),
            span_m=float(np.linalg.norm(points[1]-points[0])), reason='both_original_identities_have_current_rgbd_surface_support',
            confidence=.45 if any(hand['weak_single_view'] for hand in result['hand_reports']) else .65,
            confidence_is_calibrated_probability=False,
            cameras=sorted({view['source_camera'] for hand in result['hand_reports'] for view in hand['candidate_views']}))
    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
        result['reason'] = str(error)
    return result
