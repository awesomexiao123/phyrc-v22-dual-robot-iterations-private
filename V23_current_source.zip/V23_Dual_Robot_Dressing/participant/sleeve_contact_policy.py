"""Independent V22-derived dual-edge contact-hypothesis experiment."""
from copy import deepcopy

import numpy as np

from hypothesis_contact_experiment import HypothesisContactExperiment
from loaded_contact_pitch import LoadedContactPitch
from planar_edge_reacquisition import reacquire_planar_sleeve_edges
from sleeve_edge_policy import Policy as EdgePolicy
from sleeve_pair_policy import Policy as SleeveSidePolicy


class Policy(EdgePolicy):
    VERSION = 'v23_15_contact_hypothesis'
    METHOD = ('frozen V22 visual approach; two observed edge-inset pickups; '
              'synchronized lift/carry; bounded hypothetical cloth/hand contact')
    # The new hypothesis includes the actual edge-to-grasp offset. Do not first
    # shrink the grasp span to hand-center spacing and then re-expand it.
    ALIGN_SLEEVE_SIDE_PAIR = False
    ENABLE_OBSERVED_OPENING_APPROACH = False
    # Color-hole diagnostics do not establish a cuff and must not skip the
    # posture experiment. Child measured guards and completion still apply.
    STOP_WRIST_EXPERIMENT_ON_OPENING_DIAGNOSTICS = False
    REQUIRE_COMPLETED_WRIST_EXPERIMENTS = True
    REQUIRE_PASSIVE_WRIST_HANDOFF = True

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.initial_edge_report = None
        self.contact_experiment = None

    def _prepare_pair(self, obs):
        now = float(obs['simulation_time_s'])
        if self.shirt_observed_at is None or not 0 <= now-self.shirt_observed_at <= 30.:
            raise ValueError('initial planar edge prior unavailable or stale')
        original = deepcopy(self.shirt)
        current = reacquire_planar_sleeve_edges(obs, original)
        if not current.get('detected') or current.get('observation_time_s') != now:
            raise ValueError('current local sleeve edges unavailable at handoff: '+str(current.get('reason')))
        self.initial_edge_report = original
        self.shirt, self.shirt_observed_at = current, now
        return SleeveSidePolicy._prepare_pair(self, obs)

    def _create_loaded_pitch(self, obs):
        return LoadedContactPitch(obs, self.hands, self.hand_observation_time,
            stationary_human=True, max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)

    def __call__(self, obs):
        if self.phase == 'contact_trial_complete':
            self.step += 1
            self.debug.update(step=self.step, phase=self.phase, failure=None)
            return HypothesisContactExperiment.hold()
        if self.phase != 'hypothesis_contact':
            action = super().__call__(obs)
            if self.phase == 'await_sleeve_geometry' and not self.failure:
                self.change('hypothesis_contact')
                # This transition only stops motion. The next public frame must
                # contain the previous stage's applied zero base command.
                self.debug.update(phase=self.phase, phase_steps=0, idle_mode=self.phase)
            self.debug['historical_initial_edge_report'] = self.initial_edge_report
            self.debug['pair_candidate_indices'] = self.pair_candidate_indices
            return action
        self.step += 1
        self.phase_steps += 1
        action = HypothesisContactExperiment.hold()
        try:
            if self.contact_experiment is None:
                self.contact_experiment = HypothesisContactExperiment(obs,
                    self.initial_edge_report, self.pair_candidate_indices,
                    self.hands, self.hand_observation_time)
            result = self.contact_experiment.step(obs)
            action = np.asarray(result['action'], np.float32)
            if result['failure']:
                self.fail('hypothesis contact: '+result['failure'])
            elif result['done']:
                self.change('contact_trial_complete')
            self.debug.update(version=self.VERSION, method=self.METHOD, step=self.step,
                phase=self.phase, phase_steps=self.phase_steps, idle_mode=self.phase,
                failure=self.failure, hypothesis_contact=result['debug'],
                complete_dressing_claimed=False, sleeve_openings_verified=False)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail('contact initialization: '+str(error))
            self.debug.update(step=self.step, phase=self.phase, phase_steps=self.phase_steps,
                failure=self.failure, idle_mode=self.phase)
        if action.shape != (2, 9) or not np.isfinite(action).all() or np.max(np.abs(action)) > 1:
            self.fail('invalid contact experiment action')
            action = HypothesisContactExperiment.hold()
            self.debug.update(failure=self.failure, phase=self.phase)
        self.previous_action = action.copy()
        return action
