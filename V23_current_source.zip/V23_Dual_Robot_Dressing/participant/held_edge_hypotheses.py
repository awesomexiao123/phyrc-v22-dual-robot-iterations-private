"""Current visible blue-edge hypotheses near public own-robot grasps.

An initial sleeve-side report provides a bounded size prior only. Cloth is not
assumed rigidly attached to a grasp frame. All returned points, arcs, tangents
and timestamps come from current robot-camera RGB-D. An outer colour boundary
can be a silhouette, fold or other garment edge; it is never a mouth estimate,
attachment verification, entry direction, or authorization for contact/motion.
"""
import cv2
import numpy as np

from camera_geometry import pixel_rays
from human_targets import _validated, _world_pixels, _FOCAL, _CAMERAS
from planar_sleeve_edge import _cyclic_runs
from public_vision import _fabric_mask, grasp_world


_CAMERAS_USED = (3, 4, 1, 2)
_NEIGHBOURS = ((1, 0), (-1, 0), (0, 1), (0, -1))


def _sizing_prior(report, candidate_index, now):
    if not isinstance(report, dict) or not report.get('detected'):
        raise ValueError('initial_edge_report_unavailable')
    candidate = report['candidates'][candidate_index]
    evidence = candidate['boundary_evidence']
    observed_at = float(evidence['observation_time_s'])
    points = np.asarray(evidence['full_arc_measured_points_world'], dtype=float)
    if (not np.isfinite(observed_at) or not 0 <= observed_at <= now
            or points.ndim != 2 or points.shape[1] != 3 or not 3 <= len(points) <= 512
            or not np.isfinite(points).all()):
        raise ValueError('initial_boundary_sizing_prior_invalid_or_from_future')
    width = float(np.linalg.norm(points[:, None]-points[None], axis=2).max())
    if not .01 <= width <= .5:
        raise ValueError('initial_boundary_width_outside_bounded_sizing_prior')
    return dict(initial_candidate_index=int(candidate_index),
        initial_boundary_observation_time_s=observed_at,
        initial_boundary_camera_index=evidence.get('camera_index'),
        initial_boundary_source_camera=evidence.get('source_camera'),
        initial_boundary_source_pixels_uv=evidence.get('full_arc_source_pixels_uv'),
        initial_observed_boundary_span_m=width,
        width_is_observed_arc_span_not_cuff_circumference=True,
        required_current_arc_span_m=float(np.clip(.15*width, .015, .03)),
        use='minimum current arc support size only; no transformed historical cloth geometry',
        material_identity_verified=False)


def _local_edge_supported(values, camera, u, v, blue, fabric, valid, depth):
    """Require actual near-edge blue support and nonforeground exterior depth."""
    if min(u, v) < 3 or max(u, v) > 252 or not valid[v, u]:
        return False, 'border_or_missing_boundary_depth', None
    outside = [(u+du, v+dv) for du, dv in _NEIGHBOURS if not blue[v+dv, u+du]]
    if not outside:
        return False, 'no_observed_external_neighbour', None
    for nu, nv in outside:
        if fabric[nv, nu]:
            return False, 'boundary_is_internal_colour_trim_transition', None
        if not valid[nv, nu]:
            return False, 'exterior_depth_missing', None
    patch = blue[v-3:v+4, u-3:u+4] & valid[v-3:v+4, u-3:u+4]
    pv, pu = np.where(patch); pu, pv = pu+u-3, pv+v-3
    if len(pu) < 6:
        return False, 'insufficient_current_blue_support', None
    points = pixel_rays(pu, pv, _FOCAL)*depth[pv, pu, None]
    centre = points.mean(axis=0)
    _, singular, axes = np.linalg.svd(points-centre, full_matrices=False)
    if singular[1]/np.sqrt(len(points)) < .001 or singular[2]/max(singular[1], 1e-12) > .25:
        return False, 'local_blue_edge_support_nonplanar_or_collapsed', None
    normal = axes[2]
    if np.max(np.abs((points-centre) @ normal)) > .006:
        return False, 'local_blue_depth_mixed_or_discontinuous', None
    exterior = []
    for nu, nv in outside:
        ray = pixel_rays(nu, nv, _FOCAL)
        denominator = float(ray @ normal)
        if abs(denominator) <= .15:
            return False, 'local_edge_plane_nearly_edge_on', None
        expected = float(centre @ normal)/denominator
        if not .03 < expected < (3 if camera < 3 else 5):
            return False, 'local_edge_plane_extrapolation_invalid', None
        residual = float(depth[nv, nu]-expected)
        if residual < -.01:
            return False, 'foreground_noncloth_occludes_edge', None
        exterior.append(dict(source_pixel_uv=[int(nu), int(nv)],
            measured_depth_z_m=float(depth[nv, nu]), observed_minus_local_cloth_plane_z_m=residual))
    return True, None, exterior


def _arc_hypothesis(values, camera, contour_index, uv, points, arc, grasp, now, minimum_span, exterior):
    if len(arc) < 4:
        raise ValueError('too_few_continuous_current_boundary_pixels')
    arc_points = points[arc]
    centre = arc_points.mean(axis=0)
    _, singular, axes = np.linalg.svd(arc_points-centre, full_matrices=False)
    tangent = axes[0]
    tangent *= 1 if tangent[np.argmax(np.abs(tangent))] >= 0 else -1
    projected = (arc_points-centre) @ tangent
    span = float(np.ptp(projected))
    residual = np.linalg.norm((arc_points-centre)-projected[:, None]*tangent, axis=1)
    path = float(np.linalg.norm(np.diff(arc_points, axis=0), axis=1).sum())
    if (span < minimum_span or singular[0] < 2*singular[1]
            or np.sqrt(np.mean(residual**2)) > .008 or path > .25):
        raise ValueError('current_arc_short_curved_ambiguous_or_discontinuous')
    nearest = int(np.argmin(np.linalg.norm(arc_points-grasp, axis=1)))
    point = arc_points[nearest]; selected_index = int(arc[nearest])
    depth = values['depth'][camera, ..., 0]
    pu, pv = uv[selected_index]
    return dict(kind='unclassified_current_blue_edge', observation_time_s=now,
        camera_index=camera, source_camera=_CAMERAS[camera][0],
        current_grasp_world=grasp.tolist(), edge_from_current_grasp_world=(point-grasp).tolist(),
        edge_point_world=point.tolist(), edge_source_pixel_uv=uv[selected_index].tolist(),
        measured_edge_depth_z_m=float(depth[pv, pu]),
        distance_from_current_grasp_m=float(np.linalg.norm(point-grasp)),
        arc_source_pixels_uv=uv[arc].tolist(), arc_measured_points_world=arc_points.tolist(),
        arc_measured_depth_z_m=depth[uv[arc, 1], uv[arc, 0]].astype(float).tolist(),
        tangent_world=tangent.tolist(), tangent_sign='largest absolute component positive; no anatomical or approach direction',
        observed_arc_span_m=span, observed_arc_path_m=path,
        tangent_fit_rms_m=float(np.sqrt(np.mean(residual**2))), support_pixel_count=len(arc),
        source_contour_index=int(contour_index), contour_identity_scope='current camera/frame only',
        boundary_basis='continuous measured external blue contour; internal colour holes excluded',
        selected_edge_exterior_depth=exterior[selected_index],
        actual_point_not_projected_or_averaged=True,
        mouth_point_inferred=False, physical_opening_verified=False, cuff_identity_verified=False,
        attachment_verified=False, rigid_cloth_transform_used=False, contact_authorized=False,
        insertion_allowed=False, read_only=True)


def _camera_hypotheses(values, camera, grasps, priors, radius, now):
    rgb = values['rgb'][camera].astype(float)
    blue = (rgb[..., 2] > 100) & (rgb[..., 2] > 1.25*rgb[..., 0]) & (rgb[..., 2] > 1.25*rgb[..., 1])
    fabric = _fabric_mask(values['rgb'][camera])
    depth = values['depth'][camera, ..., 0]
    valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < (3 if camera < 3 else 5))
    contours, hierarchy = cv2.findContours(blue.astype(np.uint8), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    candidates, rejected = [[], []], {}

    def reject(reason):
        rejected[reason] = rejected.get(reason, 0)+1

    if hierarchy is None:
        return candidates, rejected
    for contour_index, contour in enumerate(contours):
        if hierarchy[0, contour_index, 3] >= 0:
            reject('internal_colour_hole_excluded'); continue
        uv = contour.reshape(-1, 2)
        if len(uv) < 4 or len(uv) > 4096 or len(np.unique(uv, axis=0)) != len(uv):
            reject('external_contour_unresolved_or_self_touching'); continue
        if np.any(uv <= 1) or np.any(uv >= 254):
            reject('image_border_contour_excluded'); continue
        u, v = uv.T
        usable = valid[v, u]
        points = _world_pixels(values, camera, u, v, np.where(usable, depth[v, u], 0.))
        distances = np.linalg.norm(points[:, None]-grasps[None], axis=2)
        nearby = usable & np.any(distances <= radius, axis=1)
        supported = np.zeros(len(uv), bool); exterior = {}
        for index in np.flatnonzero(nearby):
            pu, pv = uv[index]
            ok, reason, evidence = _local_edge_supported(values, camera, int(pu), int(pv), blue, fabric, valid, depth)
            if not ok:
                reject(reason); continue
            supported[index] = True; exterior[int(index)] = evidence
        for robot in (0, 1):
            for run in _cyclic_runs(supported & (distances[:, robot] <= radius)):
                # Pixel adjacency alone cannot join an actual depth jump.
                jumps = np.flatnonzero(np.linalg.norm(np.diff(points[run], axis=0), axis=1) > .025)+1
                for arc in np.split(run, jumps):
                    try:
                        item = _arc_hypothesis(values, camera, contour_index, uv, points, arc,
                                               grasps[robot], now, priors[robot]['required_current_arc_span_m'], exterior)
                    except ValueError as error:
                        reject(str(error)); continue
                    candidates[robot].append(item)
    return candidates, rejected


def _view_agreement(first, second):
    point_error = float(np.linalg.norm(np.asarray(first['edge_point_world'])-second['edge_point_world']))
    a, b = np.asarray(first['arc_measured_points_world']), np.asarray(second['arc_measured_points_world'])
    distances = np.linalg.norm(a[:, None]-b[None], axis=2)
    arc_error = float(max(np.median(distances.min(0)), np.median(distances.min(1))))
    tangent_cosine = float(abs(np.asarray(first['tangent_world']) @ second['tangent_world']))
    return dict(point_disagreement_m=point_error, median_arc_disagreement_m=arc_error,
                tangent_absolute_cosine=tangent_cosine,
                agrees=point_error <= .02 and arc_error <= .02 and tangent_cosine >= .8)


def estimate_held_edge_hypotheses(obs, initial_edge_report, robot_assignment, *, radius_m=.08):
    """Return one current boundary hypothesis per robot, or explicit ambiguity.

    ``robot_assignment[r]`` is the initial report's candidate index for robot r;
    it must be an explicit permutation of (0,1). No material identity is inferred
    from it. Each current search is centred on the measured own grasp and never
    exceeds 8 cm. Initial boundary geometry is used only for an arc-size prior.
    """
    assignment = np.asarray(robot_assignment)
    if (assignment.shape != (2,) or not np.issubdtype(assignment.dtype, np.integer)
            or sorted(assignment.tolist()) != [0, 1]):
        raise ValueError('explicit robot-to-initial-candidate permutation [0,1] or [1,0] required')
    if not np.isfinite(radius_m) or not .03 <= radius_m <= .08:
        raise ValueError('current grasp search radius must be between 3 and 8 cm')
    values = _validated(obs, wrists=True)
    now = float(np.asarray(obs['simulation_time_s']).item())
    if not np.isfinite(now) or now < 0:
        raise ValueError('finite nonnegative current public timestamp required')
    grasps = np.stack([grasp_world(obs, robot) for robot in (0, 1)])
    result = dict(kind='current_held_edge_hypothesis_report', observation_time_s=now,
        robot_assignment=assignment.tolist(), search_radius_m=float(radius_m), cameras_used=[1, 2, 3, 4],
        detected=False, both_hypotheses_available=False, hypotheses=[None, None], robots=[],
        per_camera_diagnostics=[], distinct_current_regions=False,
        initial_geometry_rigidly_transformed=False, attachment_verified=False,
        physical_openings_verified=False, sleeve_identity_verified=False,
        contact_authorized=False, insertion_allowed=False, motion_executor_included=False, read_only=True,
        limitations='Current outer blue image boundaries are unclassified; they can be folds or silhouettes. '
                    'Grasp proximity does not verify attachment or identify the initial material edge. '
                    'Visible edge tangent is not a mouth normal or contact direction.')
    try:
        priors = [_sizing_prior(initial_edge_report, int(assignment[r]), now) for r in (0, 1)]
    except (KeyError, ValueError, TypeError, IndexError) as error:
        result['reason'] = str(error)
        return result
    per_robot = [[], []]; ambiguous = [[], []]
    for camera in _CAMERAS_USED:
        candidates, rejected = _camera_hypotheses(values, camera, grasps, priors, radius_m, now)
        result['per_camera_diagnostics'].append(dict(camera_index=camera,
            candidate_counts=[len(c) for c in candidates], rejected_counts=rejected))
        for robot in (0, 1):
            if len(candidates[robot]) > 1:
                ambiguous[robot].append(camera)
            elif candidates[robot]:
                per_robot[robot].append(candidates[robot][0])
    for robot in (0, 1):
        row = dict(robot_index=robot, current_grasp_world=grasps[robot].tolist(),
            initial_size_prior=priors[robot], hypothesis_available=False, ambiguous=False,
            ambiguous_camera_indices=ambiguous[robot], current_camera_agreement=[],
            observed_camera_indices=[c['camera_index'] for c in per_robot[robot]])
        if ambiguous[robot]:
            row.update(reason='multiple_current_edges_near_grasp', ambiguous=True)
        elif not per_robot[robot]:
            row['reason'] = 'no_supported_current_external_blue_arc_near_grasp'
        else:
            views = per_robot[robot]
            for a in range(len(views)):
                for b in range(a+1, len(views)):
                    row['current_camera_agreement'].append(dict(camera_indices=[views[a]['camera_index'], views[b]['camera_index']],
                                                               **_view_agreement(views[a], views[b])))
            if any(not item['agrees'] for item in row['current_camera_agreement']):
                row.update(reason='current_camera_edges_disagree_over_2cm_or_tangent', ambiguous=True)
            else:
                chosen = dict(views[0], robot_index=robot, initial_candidate_index=int(assignment[robot]),
                    agreeing_camera_indices=[c['camera_index'] for c in views],
                    multi_view_agreement_checked=len(views) > 1, material_identity_verified=False)
                result['hypotheses'][robot] = chosen
                row.update(reason='current_visible_edge_hypothesis_only', hypothesis_available=True)
        result['robots'].append(row)
    first, second = result['hypotheses']
    if first is not None and second is not None:
        a, b = np.asarray(first['arc_measured_points_world']), np.asarray(second['arc_measured_points_world'])
        separation = float(np.linalg.norm(a[:, None]-b[None], axis=2).min())
        result['minimum_current_arc_separation_m'] = separation
        if separation <= .02:
            result['hypotheses'] = [None, None]
            for row in result['robots']:
                row.update(hypothesis_available=False, ambiguous=True, reason='two_grasps_do_not_identify_distinct_current_edge_regions')
        else:
            result['distinct_current_regions'] = True
            result['detected'] = result['both_hypotheses_available'] = True
    result['reason'] = ('two_distinct_current_unclassified_edge_hypotheses' if result['detected']
                        else 'current_edge_hypotheses_incomplete_or_ambiguous')
    return result
