"""Experimental observed-rim approach, ending distal to the visible hands.

One persistent instance owns the entire approach budget. Each <=5 mm common
world translation is an experiment, not a claim that cloth follows the grasps.
Both tracked rims must respond before another pulse is allowed. No traversal,
semantic cuff identification, force measurement or whole-arm collision proof.
"""
from copy import deepcopy
from itertools import permutations

import numpy as np

from cooperative_transport import _snapshot, _bounded
from distal_staging import _hand_axis
from grasp_pair_alignment import GraspPairAlignment
from navigation import guard_base_velocity
from opening_candidates import compare_hand_surface_footprint
from public_vision import _rotation
from sleeve_probe import _visible_hand_samples, _validated, _candidate_polygon


def _measure_geometry(obs, rims, hands_report, surface_report):
    """Require same-frame tracker provenance and reacquire the hand footprint.

    Rims are OpeningRimTracker.update results in robot order. A fresh tracked
    rim can contain an occluding hand; no old empty-background claim is reused.
    """
    now = float(np.asarray(obs['simulation_time_s']).item())
    if hands_report.get('observation_time_s') != now or surface_report.get('observation_time_s') != now:
        raise ValueError('current_hand_and_signed_surface_reports_required')
    hands = np.asarray(hands_report.get('hand_points_world'), float)
    if not hands_report.get('detected') or hands.shape != (2, 3) or not np.isfinite(hands).all():
        raise ValueError('two_current_visible_hand_surfaces_required')
    if np.linalg.norm(hands[1]-hands[0]) < .15:
        raise ValueError('hand_pair_not_separated')
    rows = surface_report.get('hand_surfaces', [])
    if len(rows) != 2 or len(rims) != 2:
        raise ValueError('two_current_rims_and_signed_surface_axes_required')
    axes, evidence = zip(*[_hand_axis(rows[i], hands[i], i) for i in (0, 1)])
    if float(axes[0] @ axes[1]) < np.cos(np.deg2rad(10.)):
        raise ValueError('regrasp_required: signed_axes_incompatible_with_common_translation')
    values = _validated(obs, wrists=True)
    sampled = [_visible_hand_samples(values, hands[i], hands[1-i], axes[i]) for i in (0, 1)]
    _, grasps, _, _, _ = _snapshot(obs)
    candidates, identities, medians = [], [], []
    for robot, rim in enumerate(rims):
        identity = rim.get('identity')
        candidate = rim.get('rim_geometry')
        if (rim.get('reliable') is not True or rim.get('kind') != 'tracked_unclassified_rim'
                or rim.get('features_reseeded') is not False or rim.get('tracked_count', 0) < 8
                or not isinstance(identity, dict) or not isinstance(candidate, dict)):
            raise ValueError('fixed_identity_tracked_rim_required')
        camera = candidate.get('camera_index')
        if (camera not in (1, 2, 3, 4) or identity.get('initial_camera_index') != camera
                or identity.get('initial_background_depth_supported') is not True
                or candidate.get('observation_time_s') != now
                or candidate.get('inner_aperture', {}).get('observation_time_s') != now):
            raise ValueError('rim_camera_or_current_timestamp_provenance_invalid')
        depth_support = np.asarray([candidate.get('current_rim_depth_valid_fraction', 0.),
                                    candidate.get('current_rim_depth_sample_count', 0)], float)
        if (not np.isfinite(depth_support).all() or not .9 <= depth_support[0] <= 1.
                or depth_support[1] < 20):
            raise ValueError('fresh_rim_depth_support_insufficient')
        center = np.asarray(candidate.get('centroid_world'), float)
        normal = np.asarray(candidate.get('normal_world'), float)
        median = np.asarray(rim.get('median_displacement_world'), float)
        if any(x.shape != (3,) or not np.isfinite(x).all() for x in (center, normal, median)):
            raise ValueError('invalid_current_rim_geometry_or_fixed_feature_displacement')
        if np.linalg.norm(normal) < .5 or np.linalg.norm(center-grasps[robot]) > .25:
            raise ValueError('rim_not_bound_to_nearby_public_grasp')
        _candidate_polygon(candidate)
        candidates.append(candidate); identities.append(deepcopy(identity)); medians.append(median)
    centers = np.array([c['centroid_world'] for c in candidates])
    normals = np.array([c['normal_world'] for c in candidates], float)
    normals /= np.linalg.norm(normals, axis=1)[:, None]
    radii = [float(np.max(np.linalg.norm(_candidate_polygon(c)-centers[r], axis=1)))
             for r, c in enumerate(candidates)]
    if identities[0] == identities[1] or np.linalg.norm(centers[1]-centers[0]) <= sum(radii)+.01:
        raise ValueError('two_distinct_disjoint_rim_identities_required')
    links = {}
    for robot, candidate in enumerate(candidates):
        for hand in (0, 1):
            cosine = float(normals[robot] @ axes[hand])
            if abs(cosine) < .8:
                continue
            samples, points = sampled[hand]
            gap = float(np.min((points-centers[robot]) @ normals[robot]/cosine))
            if not .015 <= gap <= .30:
                continue
            footprint = compare_hand_surface_footprint(obs, candidate, samples, axes[hand],
                                                       margin_m=.01, max_projection_m=.30)
            if not footprint.get('observed_footprint_fits'):
                continue
            intersection = hands[hand]+axes[hand]*(float(normals[robot] @ (centers[robot]-hands[hand]))/cosine)
            links[(robot, hand)] = dict(gap=gap, lateral_error=float(np.linalg.norm(intersection-centers[robot])),
                margin=float(footprint['minimum_edge_clearance_m']))
    choices = [(sum(links[(r, assignment[r])]['lateral_error'] for r in (0, 1)), assignment)
               for assignment in permutations((0, 1)) if all((r, assignment[r]) in links for r in (0, 1))]
    if not choices:
        raise ValueError('regrasp_required: no_matching_visible_footprints_normals_and_distal_gaps')
    choices.sort()
    if len(choices) > 1 and choices[1][0]-choices[0][0] < .01:
        raise ValueError('hand_to_rim_assignment_ambiguous')
    assignment = choices[0][1]
    selected = [links[(r, assignment[r])] for r in (0, 1)]
    return dict(centers=centers, normals=normals, identities=identities,
        feature_displacements=np.asarray(medians), axes=np.asarray([axes[i] for i in assignment]),
        hands=hands[list(assignment)], gaps=np.array([link['gap'] for link in selected]),
        margins=np.array([link['margin'] for link in selected]), assignment=list(assignment),
        cameras=[c['camera_index'] for c in candidates], observation_time_s=now,
        weak_axes=any(item['weak_single_view'] for item in evidence))


class ObservedPairApproach:
    """step(obs, rim_reports, hands, forearms) -> action/done/failure/debug.

    Reports must be fresh at every action, including during a pulse. Missing
    geometry immediately stops new approach commands and times out after 2 s.
    Pending integrated lift targets are bounded and cancelled, not described as
    frozen by a zero action. Callers MUST pass cancellation_only actions while
    failure is None. Unsafe cancellation returns unresolved_target_lag and
    requires an external simulation stop. Controller
    failure latches; constructing another instance must not reset an experiment's
    spent motion budget. The caller should keep this instance for the episode.
    Response tolerances are explicit development heuristics, not sensor-noise
    calibration or proof of safe interaction with a real person.
    """
    PULSE_M = .005
    PULSE_GOAL_M = .004  # Leave 1 mm feedback tolerance inside the 5 mm ceiling.
    SPEED_M_S = .003
    MAX_TRAVEL_M = .30
    MAX_SECONDS = 180.
    LIFT_LIMITS = (.005, 1.195)  # Published 0..1.2 m lift, 5 mm execution margin.
    ACTION_DT = .05
    LIFT_RATE = 1.54
    TARGET_LEAD_M = .0003
    MAX_CANCEL_LAG_M = .00075
    SETTLED_LIFT_LAG_M = .000025
    SETTLED_SPEED_M_S = .0002
    FIXED_WRIST_LEVER_M = .35  # Conservative own wrist-pivot-to-grasp envelope.

    def __init__(self, obs):
        bases, grasps, yaw, _, now = _snapshot(obs)
        self.base0, self.grasp0, self.yaw0 = bases.copy(), grasps.copy(), yaw.copy()
        self.joints0 = np.asarray(obs['joint_position'], float).copy()
        if self.joints0.shape != (2, 13) or not np.isfinite(self.joints0).all():
            raise ValueError('finite public joint_position (2,13) required')
        self.time0 = self.last_time = now
        self.last_bases, self.last_grasps = bases.copy(), grasps.copy()
        self.base_path = np.zeros(2); self.endpoint_path = np.zeros(2)
        self.requested_path = 0.; self.verified_pulses = 0; self.calls = 0
        self.phase = 'acquire'; self.failure = None; self.done = False
        self.geometry_wait_since = None; self.stable = 0.; self.settle_since = None
        self.identities = None; self.hand_reference = None; self.pulse = None
        self.last_response = None; self.debug = {}; self.hold_reason = 'await_current_geometry'
        self.targets0 = np.asarray(obs.get('controller_target', []), float).copy()
        self.pending_failure = None; self.cancellation = None
        self.last_observation_dt = 0.; self.measured_endpoint_speed = np.zeros(2)

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        return action

    def _result(self, action=None):
        if action is None or self.failure or self.done:
            action = self._hold()
        if not np.any(action[:, :8]):
            self.debug['command_world_velocities'] = np.zeros((2, 3)).tolist()
        self.debug.update(phase=self.phase, failure=self.failure, done=self.done,
            pending_failure=self.pending_failure, cancellation_only=self.cancellation is not None,
            hold_reason=self.hold_reason, calls=self.calls, verified_pulses=self.verified_pulses,
            requested_path_m=self.requested_path, measured_endpoint_path_m=self.endpoint_path.tolist(),
            measured_base_path_m=self.base_path.tolist(), maximum_approach_m=self.MAX_TRAVEL_M,
            response=self.last_response, first_pulse_is_unverified_motion_experiment=self.verified_pulses == 0,
            insertion_allowed=False, traversal_performed=False, sleeve_identity_verified=False,
            full_hand_geometry_observed=False, observed_footprint_only=True,
            attachment_verified=False, whole_arm_collision_clearance_verified=False,
            scope='bounded simulation-only common translation toward observed distal hand surfaces; no traversal')
        return dict(action=np.asarray(action, np.float32), done=self.done, failure=self.failure,
                    pending_failure=self.pending_failure, cancellation_only=self.cancellation is not None,
                    debug=deepcopy(self.debug))

    def _drive_state(self, obs, bases, grasps):
        """Public measured state, never synthesized from commanded actions."""
        q = np.asarray(obs['joint_position'], float)
        qd = np.asarray(obs['joint_velocity'], float)
        targets = np.asarray(obs['controller_target'], float)
        twist = np.asarray(obs['base_twist_world'], float)
        if (q.shape != (2, 13) or qd.shape != (2, 13) or targets.shape != (2, 9)
                or twist.shape != (2, 6) or self.targets0.shape != (2, 9)
                or not all(np.isfinite(v).all() for v in (q, qd, targets, twist, self.targets0))):
            raise ValueError('finite_public_controller_targets_joint_velocities_and_base_twists_required')
        lift_lag = targets[:, 0]-q[:, 3]
        arm_lag = targets[:, 1, None]/4-q[:, 4:8]
        wrist_lag = targets[:, 2:5]-q[:, 8:11]
        wrist_low = np.array([-1.135, -4.276, -1.135])
        wrist_high = np.array([4.276, 1.135, 4.276])
        if (np.any(targets[:, 0] < self.LIFT_LIMITS[0]) or np.any(targets[:, 0] > self.LIFT_LIMITS[1])
                or np.any(q[:, 3] < self.LIFT_LIMITS[0]) or np.any(q[:, 3] > self.LIFT_LIMITS[1])
                or np.any(targets[:, 1] < 0.) or np.any(targets[:, 1] > .52)
                or np.any(q[:, 8:11] < wrist_low-1e-6) or np.any(q[:, 8:11] > wrist_high+1e-6)
                or np.any(targets[:, 2:5] < wrist_low-1e-6) or np.any(targets[:, 2:5] > wrist_high+1e-6)
                or np.any(q[:, 4:8] < -1e-5) or np.any(q[:, 4:8] > .13001)):
            raise ValueError('own_target_lift_or_individual_arm_limit')
        # Fixed axes cannot be cancelled by this translation-only controller.
        if (np.max(np.abs(targets[:, 1:5]-self.targets0[:, 1:5])) > 1e-5
                or np.max(np.abs(arm_lag)) > .0001
                or np.max(np.abs(wrist_lag)) > np.deg2rad(.02)
                or np.max(np.abs(qd[:, 4:8])) > .0002
                or np.max(np.abs(qd[:, 8:11])) > np.deg2rad(.1)):
            raise ValueError('unresolved_fixed_arm_or_wrist_target_lag_or_velocity')
        rotations = np.array([_rotation(p[3:]) for p in bases])
        endpoint_velocity = (twist[:, :3]+np.cross(twist[:, 3:], grasps-bases[:, :3])
            +rotations[:, :, 2]*qd[:, 3, None]+rotations[:, :, 0]*qd[:, 4:8].sum(1)[:, None])
        speed = np.linalg.norm(endpoint_velocity, axis=1)+self.FIXED_WRIST_LEVER_M*np.abs(qd[:, 8:11]).sum(1)
        speed = np.maximum(speed, self.measured_endpoint_speed)
        if (np.any(np.linalg.norm(twist[:, :3], axis=1) > 2*self.SPEED_M_S+1e-8)
                or np.any(np.linalg.norm(twist[:, 3:], axis=1) > .005)
                or np.any(np.abs(qd[:, 3]) > 2*self.SPEED_M_S+1e-8)
                or np.any(speed > 2*self.SPEED_M_S+1e-8)):
            raise ValueError('unresolved_measured_base_or_endpoint_velocity')
        if np.any(np.abs(lift_lag) > self.MAX_CANCEL_LAG_M):
            raise ValueError('unresolved_excessive_integrated_lift_target_lag')
        fixed_pending = np.abs(arm_lag).sum(1)+self.FIXED_WRIST_LEVER_M*np.abs(wrist_lag).sum(1)
        # This is a checked one-action-interval reserve, not an acceleration or
        # inertia certificate. Further measured motion is counted every frame.
        pending = np.abs(lift_lag)+fixed_pending+speed*self.ACTION_DT
        settled = bool(np.max(np.abs(lift_lag)) <= self.SETTLED_LIFT_LAG_M
            and np.max(speed) <= self.SETTLED_SPEED_M_S
            and np.max(np.linalg.norm(twist[:, :3], axis=1)) <= self.SETTLED_SPEED_M_S
            and np.max(np.linalg.norm(twist[:, 3:], axis=1)) <= .0002
            and np.max(np.abs(targets[:, 6:9])) <= 1e-5
            and np.max(np.abs(arm_lag)) <= .000025
            and np.max(np.abs(wrist_lag)) <= np.deg2rad(.005))
        self.debug.update(integrated_lift_target_lag_m=lift_lag.tolist(),
            individual_arm_target_lag_m=arm_lag.tolist(), wrist_target_lag_rad=wrist_lag.tolist(),
            measured_endpoint_speed_bound_m_s=speed.tolist(), pending_endpoint_excursion_bound_m=pending.tolist(),
            measured_drive_settled=settled,
            pending_bound_scope='target lead plus fixed-axis kinematic envelope and one measured-rate action interval; no inertia guarantee')
        return dict(q=q, qd=qd, targets=targets, twist=twist, rotations=rotations,
                    lift_lag=lift_lag, pending=pending, speed=speed, settled=settled)

    def _pending_fits(self, state, grasps, now):
        pending = state['pending']
        if np.any(self.endpoint_path+pending > self.MAX_TRAVEL_M+1e-9):
            raise ValueError('unresolved_lift_target_has_no_persistent_path_reserve')
        if np.any(self.base_path+np.linalg.norm(state['twist'][:, :2], axis=1)*self.ACTION_DT > self.MAX_TRAVEL_M+1e-9):
            raise ValueError('unresolved_base_velocity_has_no_persistent_path_reserve')
        if self.pulse is not None:
            ceiling = min(self.PULSE_M, self.pulse['length']+.001)
            if (np.any(np.linalg.norm(grasps-self.pulse['grasps'], axis=1)+pending > ceiling+1e-9)
                    or np.any(self.endpoint_path-self.pulse['endpoint_path_start']+pending > ceiling+1e-9)):
                raise ValueError('unresolved_lift_target_has_no_current_pulse_reserve')
            if now-self.pulse['start_time'] > 8.:
                raise ValueError('pulse_execution_or_settling_timed_out' if state['settled']
                                 else 'unresolved_lift_target_exceeds_existing_pulse_deadline')
        elif np.max(pending) > .001:
            raise ValueError('unresolved_pre_pulse_target_excursion_over_1mm')
        if (now-self.time0 > self.MAX_SECONDS or self.calls > 4000) and not state['settled']:
            raise ValueError('unresolved_lift_target_exceeds_existing_approach_deadline')

    def _begin_cancel(self, obs, bases, grasps, now, reason, *, failure=False):
        if failure:
            self.pending_failure = self.pending_failure or reason
        self.hold_reason = reason
        if self.cancellation is None:
            self.cancellation = dict(start=now, calls=0, stable=0., resume_phase=self.phase)
        return self._cancel(obs, bases, grasps, now, 0.)

    def _cancel(self, obs, bases, grasps, now, dt):
        """Cancel only bounded lift lead; both bases and all fixed axes stop."""
        try:
            cancel = self.cancellation; cancel['calls'] += 1
            state = self._drive_state(obs, bases, grasps)
            self._pending_fits(state, grasps, now)
            if now-cancel['start'] > 1.5 or cancel['calls'] > 40:
                raise ValueError('unresolved_lift_cancellation_timeout')
            # q and target are both within workspace, so every interpolated
            # cancellation target is too. The pending segment already fits the
            # original pulse and cumulative measured travel budgets above.
            error = -state['lift_lag']
            action = self._hold()
            if dt > 0 or cancel['calls'] == 1:
                action[:, 3] = np.clip(error/self.ACTION_DT, -self.SPEED_M_S, self.SPEED_M_S)/self.LIFT_RATE
            self.debug.update(unresolved_target_lag=False,
                command_world_velocities=(state['rotations'][:, :, 2]*action[:, 3, None]*self.LIFT_RATE).tolist())
            cancel['stable'] = cancel['stable']+dt if state['settled'] else 0.
            if cancel['stable'] >= .15-1e-9:
                resume = cancel['resume_phase']; self.cancellation = None
                self.stable = 0.; self.settle_since = None
                if self.pending_failure:
                    self.failure = self.pending_failure; self.phase = 'stopped'
                else:
                    self.phase = resume
                return self._result()
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = (self.pending_failure or self.hold_reason or 'approach_hold')+': '+str(error)
            self.phase = 'stopped'; self.cancellation = None
            self.debug['unresolved_target_lag'] = True
            return self._result()

    def _abort(self, obs, reason, now):
        try:
            bases, grasps, _, _, _ = _snapshot(obs)
            state = self._drive_state(obs, bases, grasps)
            if state['settled']:
                self.failure = reason; self.phase = 'stopped'; self.cancellation = None
                self.debug['unresolved_target_lag'] = False
                return self._result()
            return self._begin_cancel(obs, bases, grasps, now, reason, failure=True)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = reason+': '+str(error); self.phase = 'stopped'; self.cancellation = None
            self.debug['unresolved_target_lag'] = True
            return self._result()

    def _own_guards(self, obs, bases, grasps, yaw, tilt, now):
        joints = np.asarray(obs['joint_position'], float)
        endpoint_increment = np.linalg.norm(grasps-self.last_grasps, axis=1)
        self.endpoint_path += endpoint_increment
        self.base_path += np.linalg.norm(bases[:, :2]-self.last_bases[:, :2], axis=1)
        self.measured_endpoint_speed = endpoint_increment/self.last_observation_dt if self.last_observation_dt > 1e-9 else np.zeros(2)
        self.last_grasps, self.last_bases = grasps.copy(), bases.copy()
        workspace = GraspPairAlignment._arm_workspace(obs)
        bounds = np.asarray(workspace['guarded_grasp_x_bounds_m'])
        local_x = np.asarray(obs['grasp_pose_base'])[:, 0]
        if np.any(local_x < bounds[:, 0]-1e-6) or np.any(local_x > bounds[:, 1]+1e-6):
            raise ValueError('regrasp_required: wrist_dependent_arm_workspace')
        if np.any(joints[:, 3] < self.LIFT_LIMITS[0]) or np.any(joints[:, 3] > self.LIFT_LIMITS[1]):
            raise ValueError('regrasp_required: lift_joint_margin')
        if (np.max(np.abs(joints[:, 4:8].sum(1)-self.joints0[:, 4:8].sum(1))) > .003
                or np.max(np.abs(joints[:, 8:11]-self.joints0[:, 8:11])) > .025):
            raise ValueError('uncommanded_arm_or_wrist_posture_change')
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('closed_gripper_intent_lost')
        gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
        if not np.isfinite(gap).all() or gap.max() > .08:
            raise ValueError('closed_gripper_gap_guard')
        if tilt.max() > .065 or np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
            raise ValueError('base_tilt_or_separation_guard')
        drift = (yaw-self.yaw0+np.pi) % (2*np.pi)-np.pi
        if np.max(np.abs(drift)) > .025:
            raise ValueError('cumulative_base_yaw_drift')
        if np.linalg.norm((grasps[1]-grasps[0])-(self.grasp0[1]-self.grasp0[0])) > .005:
            raise ValueError('cumulative_relative_grasp_change_over_5mm')
        if max(self.endpoint_path.max(), self.base_path.max(), self.requested_path) > self.MAX_TRAVEL_M+1e-6:
            raise ValueError('persistent_approach_travel_budget_exhausted')
        if now-self.time0 > self.MAX_SECONDS or self.calls > 4000:
            raise ValueError('bounded_approach_duration_exhausted')
        self.debug['arm_workspace'] = workspace
        return joints

    def _start_pulse(self, geometry, bases, grasps, joints, now):
        gaps, axes, normals = (geometry[k] for k in ('gaps', 'axes', 'normals'))
        if np.ptp(gaps) > .004:
            raise ValueError('regrasp_required: distal_gaps_need_differential_motion')
        if np.max(gaps) <= .0205:
            self.done = True; self.phase = 'distal_wait'; self.hold_reason = 'near_20mm_distal_gap_reached_no_traversal'
            return
        direction = axes.sum(axis=0); direction /= np.linalg.norm(direction)
        progress_rates = np.sum(normals*direction, axis=1)/np.sum(normals*axes, axis=1)
        if np.min(progress_rates) < .9:
            raise ValueError('regrasp_required: no_consistent_common_translation')
        length = min(self.PULSE_GOAL_M, float(np.max((gaps-.020)/progress_rates)),
                     float(np.min((gaps-.015)/progress_rates)))
        if length < .0005:
            raise ValueError('regrasp_required: common_step_cannot_preserve_distal_clearance')
        shift = direction*length
        side_drift = shift[None]-axes*(length*progress_rates)[:, None]
        if np.any(np.linalg.norm(side_drift, axis=1) > geometry['margins']-.01+1e-8):
            raise ValueError('regrasp_required: common_step_consumes_observed_footprint_margin')
        rotations = np.array([_rotation(p[3:]) for p in bases])
        lift_delta = shift[2]/rotations[:, 2, 2]
        if np.any(joints[:, 3]+lift_delta < self.LIFT_LIMITS[0]) or np.any(joints[:, 3]+lift_delta > self.LIFT_LIMITS[1]):
            raise ValueError('regrasp_required: proposed_pulse_exceeds_lift_workspace')
        if self.requested_path+length > self.MAX_TRAVEL_M+1e-9:
            raise ValueError('persistent_approach_travel_budget_exhausted')
        self.requested_path += length
        self.pulse = dict(start_time=now, grasps=grasps.copy(), bases=bases.copy(), shift=shift,
            length=length, reference=0., centers=geometry['centers'].copy(),
            endpoint_path_start=self.endpoint_path.copy(), lift_goal=joints[:, 3]+lift_delta,
            features=geometry['feature_displacements'].copy(), normals=normals.copy(),
            axes=axes.copy(),
            grasp_goal=grasps+shift, base_goal=bases[:, :2]+shift[:2]-rotations[:, :2, 2]*lift_delta[:, None],
            tolerance=min(.001, .15*length))
        self.phase = 'pulse'; self.stable = 0.; self.hold_reason = None

    def _verify_response(self, geometry, grasps):
        pulse = self.pulse
        grip_shift = grasps-pulse['grasps']; rim_shift = geometry['centers']-pulse['centers']
        feature_shift = geometry['feature_displacements']-pulse['features']
        grip_length = np.linalg.norm(grip_shift, axis=1); rim_length = np.linalg.norm(rim_shift, axis=1)
        direction_cosine = np.sum(grip_shift*rim_shift, axis=1)/np.maximum(grip_length*rim_length, 1e-12)
        gain = rim_length/np.maximum(grip_length, 1e-12)
        residual = np.linalg.norm(rim_shift-grip_shift, axis=1)
        cohort_residual = np.linalg.norm(rim_shift-feature_shift, axis=1)
        normal_cosine = np.abs(np.sum(geometry['normals']*pulse['normals'], axis=1))
        reliable = bool(np.all(grip_length >= .8*pulse['length']) and np.all(direction_cosine >= .8)
            and np.all((gain >= .4) & (gain <= 1.6))
            and np.all(residual <= np.maximum(.001, .5*grip_length))
            and np.all(cohort_residual <= .003) and np.all(normal_cosine >= np.cos(np.deg2rad(10.))))
        self.last_response = dict(accepted=reliable, actual_grasp_displacement_world=grip_shift.tolist(),
            actual_rim_centroid_displacement_world=rim_shift.tolist(), fixed_feature_displacement_world=feature_shift.tolist(),
            direction_cosine=direction_cosine.tolist(), response_gain=gain.tolist(), residual_m=residual.tolist(),
            centroid_to_fixed_feature_residual_m=cohort_residual.tolist(),
            tolerance_scope='bounded development heuristics; not a calibrated sensor uncertainty model')
        if not reliable:
            raise ValueError('both_rims_did_not_follow_measured_grasp_pulse_with_bounded_response')
        self.verified_pulses += 1
        self.phase = 'acquire'; self.stable = 0.; self.pulse = None
        self.hold_reason = 'verified_response_reobserve_before_next_pulse'

    def step(self, obs, rim_reports, hands_report, forearm_report):
        if self.failure or self.done:
            return self._result()
        self.calls += 1
        try:
            bases, grasps, yaw, tilt, now = _snapshot(obs)
            raw_dt = now-self.last_time
            if raw_dt < -1e-8 or raw_dt > .25:
                raise ValueError('public_observation_clock_jump')
            dt = max(0., min(.05, raw_dt)); self.last_time = now
            self.last_observation_dt = max(0., raw_dt)
            joints = self._own_guards(obs, bases, grasps, yaw, tilt, now)
            state = self._drive_state(obs, bases, grasps)
            self._pending_fits(state, grasps, now)
            if self.cancellation is not None:
                return self._cancel(obs, bases, grasps, now, dt)
            try:
                geometry = _measure_geometry(obs, rim_reports, hands_report, forearm_report)
            except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
                self.hold_reason = str(error)
                self.geometry_wait_since = now if self.geometry_wait_since is None else self.geometry_wait_since
                self.stable = 0.
                self.settle_since = None
                if now-self.geometry_wait_since > 2.:
                    raise ValueError('geometry_reacquisition_timed_out: '+str(error))
                if not state['settled']:
                    return self._begin_cancel(obs, bases, grasps, now, self.hold_reason)
                return self._result()
            self.geometry_wait_since = None
            if self.identities is None:
                self.identities = deepcopy(geometry['identities']); self.hand_reference = geometry['hands'].copy()
            if geometry['identities'] != self.identities:
                raise ValueError('tracked_rim_identity_changed_no_automatic_reseed')
            if np.max(np.linalg.norm(geometry['hands']-self.hand_reference, axis=1)) > .02:
                raise ValueError('hand_identity_or_observed_position_changed')
            self.debug.update(distal_gaps_m=geometry['gaps'].tolist(), source_cameras=geometry['cameras'],
                hand_assignment=geometry['assignment'], observed_footprint_margins_m=geometry['margins'].tolist(),
                contains_weak_surface_axis_evidence=geometry['weak_axes'])
            self.hold_reason = None
            if dt <= 0:
                self.hold_reason = 'no_fresh_simulation_time'; return self._result()
            if self.phase == 'acquire':
                if not state['settled']:
                    self.stable = 0.
                    return self._begin_cancel(obs, bases, grasps, now, 'await_measured_targets_and_velocities_settled')
                self.stable += dt
                if self.stable >= .15-1e-9:
                    self._start_pulse(geometry, bases, grasps, joints, now)
                return self._result()
            pulse = self.pulse
            if now-pulse['start_time'] > 8.:
                raise ValueError('pulse_execution_or_settling_timed_out')
            if np.any(np.sum(geometry['axes']*pulse['axes'], axis=1) < np.cos(np.deg2rad(10.))):
                raise ValueError('signed_surface_axis_changed_during_pulse')
            if np.max(np.linalg.norm(grasps-pulse['grasps'], axis=1)) > min(self.PULSE_M, pulse['length']+.001):
                raise ValueError('measured_pulse_displacement_exceeded_goal_plus_1mm')
            if self.phase == 'settle':
                if np.max(np.linalg.norm(grasps-pulse['grasp_goal'], axis=1)) > pulse['tolerance']:
                    raise ValueError('measured_grasp_endpoint_drift_during_settle')
                if not state['settled']:
                    self.settle_since = None
                    return self._begin_cancel(obs, bases, grasps, now, 'settle_requires_cancelled_lift_target_and_measured_rest')
                if self.settle_since is None:
                    self.settle_since = now
                if now-self.settle_since >= .25-1e-9:
                    self._verify_response(geometry, grasps)
                return self._result()
            direction = pulse['shift']/pulse['length']
            reference = pulse['grasps']+pulse['reference']*direction
            advance = min(self.SPEED_M_S*dt, pulse['length']-pulse['reference'])
            if np.max(np.linalg.norm(grasps-reference, axis=1)) > .0015:
                advance = 0.
            requested = pulse['grasps']+(pulse['reference']+advance)*direction
            velocities, lift_rates, bodies, scales, guards = [], [], [], [], []
            for robot in (0, 1):
                velocity = _bounded(direction*advance/dt+2.*(requested[robot]-grasps[robot]), self.SPEED_M_S)
                rotation = _rotation(bases[robot, 3:])
                lift_rate = velocity[2]/rotation[2, 2]
                # Integrate toward the measured pulse's lift endpoint, never
                # accumulate beyond it or more than .3mm ahead of actual lift.
                target = state['targets'][robot, 0]
                remaining_lift = pulse['lift_goal'][robot]-target
                if abs(lift_rate) > 1e-12:
                    sign = np.sign(lift_rate)
                    room = max(0., self.TARGET_LEAD_M-sign*state['lift_lag'][robot])
                    goal_room = max(0., sign*remaining_lift)
                    lift_rate = sign*min(abs(lift_rate), room/self.ACTION_DT, goal_room/self.ACTION_DT)
                world_base_velocity = velocity[:2]-rotation[:2, 2]*lift_rate
                c, s = np.cos(yaw[robot]), np.sin(yaw[robot])
                body = np.array([[c, s], [-s, c]]) @ world_base_velocity
                guard = guard_base_velocity(obs, robot, body, max_speed=self.SPEED_M_S)
                allowed = np.asarray(guard['body_velocity_xy'], float)
                norm = float(np.linalg.norm(body)); scale = min(1., self.SPEED_M_S/max(norm, 1e-12))
                guard_scale = float(np.clip(np.linalg.norm(allowed)/norm, 0., 1.)) if norm > 1e-9 else 1.
                if allowed.shape != (2,) or not np.isfinite(allowed).all() or np.linalg.norm(allowed-body*guard_scale) > 1e-7:
                    raise ValueError('navigation_guard_must_only_scale_requested_velocity')
                scale = min(scale, guard_scale)
                available = self.LIFT_LIMITS[1]-joints[robot, 3] if lift_rate > 0 else joints[robot, 3]-self.LIFT_LIMITS[0]
                if abs(lift_rate) > 1e-10:
                    scale = min(scale, max(0., available)/(abs(lift_rate)*max(.05, dt)))
                velocities.append(velocity); lift_rates.append(lift_rate); bodies.append(body); scales.append(scale); guards.append(guard)
            common = float(np.clip(min(scales), 0., 1.))
            pulse['reference'] += advance*common
            action = self._hold()
            action[:, :2] = np.asarray(bodies)*common/.616
            action[:, 3] = np.asarray(lift_rates)*common/1.54
            outgoing_lag = state['lift_lag']+action[:, 3]*self.LIFT_RATE*self.ACTION_DT
            commanded_speed = np.linalg.norm(np.asarray(velocities)*common, axis=1)
            next_speed = np.maximum(state['speed'], commanded_speed)
            next_twist = state['twist'].copy()
            for robot in (0, 1):
                body = np.asarray(bodies[robot])*common
                c, s = np.cos(yaw[robot]), np.sin(yaw[robot])
                base_velocity = np.array([c*body[0]-s*body[1], s*body[0]+c*body[1], 0.])
                if np.linalg.norm(base_velocity) > np.linalg.norm(next_twist[robot, :3]):
                    next_twist[robot, :3] = base_velocity
            next_state = dict(state, twist=next_twist,
                pending=state['pending']-np.abs(state['lift_lag'])+np.abs(outgoing_lag)
                    +(next_speed-state['speed'])*self.ACTION_DT)
            self._pending_fits(next_state, grasps, now)
            error = np.linalg.norm(grasps-pulse['grasp_goal'], axis=1)
            base_error = np.linalg.norm(bases[:, :2]-pulse['base_goal'], axis=1)
            reached = (pulse['reference'] >= pulse['length']-1e-10 and error.max() <= pulse['tolerance']
                       and base_error.max() <= pulse['tolerance'])
            self.stable = self.stable+dt if reached else 0.
            if self.stable >= .15-1e-9:
                self.phase = 'settle'; self.settle_since = now; action = self._hold()
                if not state['settled']:
                    return self._begin_cancel(obs, bases, grasps, now, 'pulse_reached_cancel_pending_lift_before_settle')
            self.debug.update(pulse_length_m=pulse['length'], pulse_reference_m=pulse['reference'],
                pulse_endpoint_tolerance_m=pulse['tolerance'], measured_endpoint_error_m=error.tolist(),
                common_guard_scale=common, navigation_guards=guards,
                command_world_velocities=(np.asarray(velocities)*common).tolist())
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError, np.linalg.LinAlgError) as error:
            return self._abort(obs, str(error), self.last_time)
