"""Separate far-field dual-grasp, wrist and 2mm translation development trial."""
import numpy as np

from equilibrium_contact_policy import Policy as WristPolicy
from loaded_equilibrium_calibration import LongLoadedEquilibriumCalibration
from loaded_translation_trial import LoadedTranslationTrial


class Policy(WristPolicy):
    VERSION = 'v23_20_equilibrium_translation'
    METHOD = ('frozen V22; dual interior pickup; calibrated wrist trials; '
              'new loaded baseline and finite 2mm lift/arm return trials far from hands')
    CALIBRATION_CLASS = LongLoadedEquilibriumCalibration

    def __init__(self, checkpoint, device=None):
        super().__init__(checkpoint, device=device)
        self.translation_handoff = None; self.translation_calibration = None
        self.translation_trial = None; self.translation_debug = {}

    def __call__(self, obs):
        if self.phase not in ('translation_settle', 'translation_trial', 'translation_trial_complete'):
            previous_phase = self.phase
            action = super().__call__(obs)
            if not self.failure and previous_phase == 'pair_observe_pitch' and self.phase == 'dual_hold':
                self.change('translation_settle')
                # The pitch completion frame emits only hold. Calibration is
                # constructed on the next fresh observation, never this frame.
                self.debug.update(phase=self.phase, phase_steps=0)
            return action
        self.step += 1; self.phase_steps += 1
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        try:
            if self.phase == 'translation_settle':
                if self.translation_handoff is None:
                    self.translation_handoff = self.CALIBRATION_CLASS(obs,
                        self.hands, self.hand_observation_time, stationary_human=True,
                        max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)
                result = self.translation_handoff.step(obs)
                self.translation_debug['handoff'] = result['debug']
                if result['failure']:
                    raise ValueError('translation calibration: '+result['failure'])
                if result['done']:
                    self.translation_calibration = result['calibration']
                    self.change('translation_trial')
            elif self.phase == 'translation_trial':
                if self.translation_trial is None:
                    self.translation_trial = LoadedTranslationTrial(obs, self.hands,
                        self.hand_observation_time, calibration=self.translation_calibration,
                        max_hand_age_s=self.HAND_CACHE_MAX_AGE_S)
                result = self.translation_trial.step(obs)
                action = result['action']
                self.translation_debug['trial'] = result['debug']
                if result['failure']:
                    raise ValueError('far-field translation trial: '+result['failure'])
                if result['done']:
                    self.change('translation_trial_complete')
            executed = self.execution.apply(obs, action)
            if np.max(np.abs(executed[:, :8]-action[:, :8])) > 1e-8:
                raise ValueError('execution modified calibrated translation motion')
            action = executed
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.fail(str(error))
        action = self._finish_pair(obs, action)
        self.debug.update(equilibrium_handoffs=self.equilibrium_handoffs,
            wrist_global_reference=self.wrist_global_reference,
            translation_calibration=self.translation_calibration,
            far_field_translation=self.translation_debug,
            near_human_contact_attempted=False)
        return action
