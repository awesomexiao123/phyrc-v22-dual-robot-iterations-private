"""Observed lateral edge-inset fabric proposals, not verified cuff grasps.

Refines the current public planar-shirt heuristic without changing it. Every
target and edge point is an actual current camera/depth sample. A requested
15 mm inset is quantized to a supported pixel in the explicit 8..25 mm band;
there is no interpolation or 45 mm patch recentering. Original blue-interior
proposals and timestamped boundary evidence remain available for comparison.
"""
from copy import deepcopy

import cv2
import numpy as np

from camera_geometry import pixel_rays, project_optical
from human_targets import _validated, _camera_transform, _world_pixels, _FOCAL, _CAMERAS
from planar_shirt import estimate_planar_shirt
from public_vision import _fabric_mask


_INSET = (.008, .025)
_REQUESTED = .015
_PLANE_TOL = .0125
_CAMERA_ORDER = (3, 4, 1, 2)


def _cyclic_runs(mask):
    """Actual consecutive contour indices; never bridge missing edge samples."""
    indices = np.flatnonzero(mask)
    if not len(indices):
        return []
    runs = list(np.split(indices, np.where(np.diff(indices) != 1)[0]+1))
    if len(runs) > 1 and runs[0][0] == 0 and runs[-1][-1] == len(mask)-1:
        runs = [np.r_[runs[-1], runs[0]], *runs[1:-1]]
    return runs


def _report_matches(supplied, current):
    """The original report has no timestamp; never accept a stale cached plane."""
    try:
        if not supplied.get('detected'):
            return False
        for key in ('point_world', 'normal_world', 'lateral_axis_world', 'longitudinal_axis_world'):
            if not np.allclose(supplied['plane'][key], current['plane'][key], rtol=0, atol=1e-6):
                return False
        for key in ('hem_hypothesis', 'collar_hypothesis'):
            if not np.allclose(supplied[key]['centroid_world'], current[key]['centroid_world'], rtol=0, atol=1e-6):
                return False
        return np.allclose([c['target_world'] for c in supplied['candidates']],
                           [c['target_world'] for c in current['candidates']], rtol=0, atol=1e-6)
    except (KeyError, ValueError, TypeError):
        return False


def _view_candidate(values, report, original, side, camera, now):
    plane = report['plane']
    centre = np.asarray(plane['point_world']); normal = np.asarray(plane['normal_world'])
    lateral = np.asarray(plane['lateral_axis_world'])
    longitudinal = np.asarray(plane['longitudinal_axis_world'])
    origin = np.asarray(report['hem_hypothesis']['centroid_world'])
    collar_y = float((np.asarray(report['collar_hypothesis']['centroid_world'])-origin) @ longitudinal)
    band_half = max(.08, .25*plane['hem_to_collar_distance_m'])
    rgb = values['rgb'][camera].astype(float)
    blue = (rgb[..., 2] > 100) & (rgb[..., 2] > 1.25*rgb[..., 0]) & (rgb[..., 2] > 1.25*rgb[..., 1])
    fabric = _fabric_mask(values['rgb'][camera])
    depth = values['depth'][camera, ..., 0]
    valid = values['depth_valid'][camera, ..., 0] & np.isfinite(depth) & (depth > .03) & (depth < (3 if camera < 3 else 5))
    rotation, camera_origin = _camera_transform(values, camera)
    optical = (np.asarray(original['target_world'])-camera_origin) @ rotation
    if optical[2] <= .03:
        raise ValueError('original_patch_not_in_front_of_camera')
    projected = project_optical(optical, _FOCAL)
    u, v = np.rint(projected).astype(int)
    if not (1 <= u < 255 and 1 <= v < 255):
        raise ValueError('original_patch_outside_camera')
    if not valid[v, u] or not blue[v, u] or abs(depth[v, u]-optical[2]) > .015:
        raise ValueError('original_patch_occluded_or_not_depth_supported_in_this_camera')
    _, labels = cv2.connectedComponents(blue.astype(np.uint8), connectivity=8)
    component = labels == labels[v, u]
    if np.any(component[[0, -1], :]) or np.any(component[:, [0, -1]]):
        raise ValueError('blue_component_is_clipped_by_image_border')
    contours, hierarchy = cv2.findContours(component.astype(np.uint8), cv2.RETR_CCOMP,
                                          cv2.CHAIN_APPROX_NONE)
    outer = [contours[i] for i in range(len(contours)) if hierarchy[0, i, 3] < 0]
    if len(outer) != 1:
        raise ValueError('ambiguous_external_blue_component')
    boundary_uv = outer[0].reshape(-1, 2)
    if len(np.unique(boundary_uv, axis=0)) != len(boundary_uv):
        raise ValueError('self_touching_or_unresolved_blue_outline')
    bu, bv = boundary_uv.T
    boundary_depth = depth[bv, bu]
    # Invalid boundary depth is never allowed to contribute to support or an
    # extreme. Replace it only for safe arithmetic; its eligibility stays false.
    safe_depth = np.where(valid[bv, bu], boundary_depth, 0.)
    boundary_world = _world_pixels(values, camera, bu, bv, safe_depth)
    boundary_x = (boundary_world-origin) @ lateral
    boundary_y = (boundary_world-origin) @ longitudinal
    plane_supported = valid[bv, bu] & (np.abs((boundary_world-centre) @ normal) <= _PLANE_TOL)
    eligible = plane_supported.copy()
    exterior = {}
    plane_optical = (centre-camera_origin) @ rotation
    optical_normal = rotation.T @ normal
    for index, (pu, pv) in enumerate(boundary_uv):
        if not eligible[index]:
            continue
        outside = [(pu+du, pv+dv) for du, dv in ((1, 0), (-1, 0), (0, 1), (0, -1))
                   if not component[pv+dv, pu+du]]
        if not outside:
            eligible[index] = False; continue
        evidence = []
        for nu, nv in outside:
            ray = pixel_rays(nu, nv, _FOCAL)
            denominator = float(ray @ optical_normal)
            if not valid[nv, nu] or fabric[nv, nu] or abs(denominator) <= .15:
                eligible[index] = False; break
            expected = float(plane_optical @ optical_normal)/denominator
            residual = float(depth[nv, nu]-expected)
            if not .03 < expected < (3 if camera < 3 else 5) or residual < -.01:
                eligible[index] = False; break
            evidence.append(dict(source_pixel_uv=[int(nu), int(nv)], measured_depth_z_m=float(depth[nv, nu]),
                                 observed_minus_cloth_plane_depth_z_m=residual))
        if eligible[index]:
            exterior[index] = evidence
    upper = ((np.abs(boundary_y-collar_y) <= band_half)
             & (side*boundary_x > .25*report['hem_hypothesis']['extent_m']))
    reliable = eligible & upper
    if not np.any(reliable):
        raise ValueError('no_depth_supported_unoccluded_lateral_blue_edge')
    # Preserve the actual silhouette; a lone extreme pixel cannot lend its
    # location to a disconnected or more central supported patch.
    extreme = float(np.max(side*boundary_x[reliable]))
    distal = reliable & (side*boundary_x >= extreme-.02)
    arcs = []
    for run in _cyclic_runs(distal):
        if len(run) >= 3 and np.ptp(boundary_y[run]) >= .025:
            arcs.append(run)
    if len(arcs) != 1:
        raise ValueError('missing_or_ambiguous_supported_distal_lateral_arc')
    arc = arcs[0]
    vv, uu = np.where(component & valid)
    observed = _world_pixels(values, camera, uu, vv, depth[vv, uu])
    supported = np.abs((observed-centre) @ normal) <= _PLANE_TOL
    observed, uu, vv = observed[supported], uu[supported], vv[supported]
    supported_image = np.zeros((256, 256), bool)
    supported_image[vv, uu] = True
    # An internal colour/depth opening must not be ignored when judging how
    # close the proposed patch lies to an observed blue boundary.
    all_boundary_uv = np.concatenate([c.reshape(-1, 2) for c in contours])
    au, av = all_boundary_uv.T
    all_good = valid[av, au]
    all_boundary_world = _world_pixels(values, camera, au[all_good], av[all_good], depth[av[all_good], au[all_good]])
    all_boundary_world = all_boundary_world[np.abs((all_boundary_world-centre) @ normal) <= _PLANE_TOL]
    x = (observed-origin) @ lateral; y = (observed-origin) @ longitudinal
    proposals = []
    for boundary_index in arc:
        edge = boundary_world[boundary_index]
        inset = side*(boundary_x[boundary_index]-x)
        close = ((inset >= _INSET[0]) & (inset <= _INSET[1])
                 & (np.abs(y-boundary_y[boundary_index]) <= .012)
                 & (np.abs(y-collar_y) <= .065)
                 & (np.linalg.norm(observed-edge, axis=1) <= .032))
        for point_index in np.flatnonzero(close):
            point = observed[point_index]
            strip = np.zeros((256, 256), np.uint8)
            cv2.line(strip, tuple(map(int, boundary_uv[boundary_index])),
                     (int(uu[point_index]), int(vv[point_index])), 1, 1, cv2.LINE_8)
            strip_v, strip_u = np.where(strip)
            if not np.all(supported_image[strip_v, strip_u]):
                continue
            distances = np.linalg.norm(all_boundary_world-point, axis=1)
            minimum = float(distances.min())
            if not _INSET[0] <= minimum <= _INSET[1]:
                continue
            near = np.linalg.norm(observed-point, axis=1) <= .03
            count = int(near.sum())
            voxels = len(np.unique(np.floor(observed[near]/.006).astype(np.int32), axis=0))
            if (count < 6 or voxels < 6 or np.ptp(x[near]) < .01 or np.ptp(y[near]) < .02):
                continue
            local_arc = arc[np.linalg.norm(boundary_world[arc]-edge, axis=1) <= .04]
            if len(local_arc) < 3:
                continue
            score = abs(inset[point_index]-_REQUESTED)+2*abs(y[point_index]-collar_y)
            proposals.append((float(score), int(vv[point_index]), int(uu[point_index]),
                              point_index, int(boundary_index), minimum, count, voxels, local_arc,
                              np.column_stack((strip_u, strip_v))))
    if not proposals:
        raise ValueError('no_actual_supported_pixel_in_8_to_25mm_inset_band')
    _, _, _, point_index, edge_index, minimum, count, voxels, local_arc, strip_uv = min(proposals, key=lambda p: p[:3])
    point = observed[point_index]; edge = boundary_world[edge_index]
    actual_inset = float(side*(boundary_x[edge_index]-x[point_index]))
    support = np.flatnonzero(np.linalg.norm(observed-point, axis=1) <= .03)
    # Keep complete small support, bounded samples for unusually fine images.
    support = support[::max(1, int(np.ceil(len(support)/64)))]
    return dict(target_world=point.tolist(), target_is_observed_blue_fabric=True,
        support_pixel_count=count, support_unique_voxels=int(voxels), support_radius_m=.03,
        source_cameras=[camera], source_camera=_CAMERAS[camera][0], camera_index=camera,
        source_pixel_uv=[int(uu[point_index]), int(vv[point_index])],
        measured_target_depth_z_m=float(depth[vv[point_index], uu[point_index]]),
        observation_time_s=now, geometric_side='negative_lateral' if side < 0 else 'positive_lateral',
        heuristic=True, anatomical_side=None, opening_verified=False, cuff_edge_verified=False,
        grasp_success_verified=False, insertion_allowed=False,
        target_basis='actual observed blue pixel inward from a supported lateral external blue boundary',
        requested_lateral_inset_m=_REQUESTED, allowed_measured_inset_m=list(_INSET),
        actual_lateral_inset_m=actual_inset, nearest_supported_blue_boundary_distance_m=minimum,
        nearest_boundary_scope='all measured external and internal boundaries of the same blue component',
        actual_edge_to_target_distance_m=float(np.linalg.norm(point-edge)),
        original_interior_target_world=deepcopy(original['target_world']),
        target_shift_from_original_m=float(np.linalg.norm(point-original['target_world'])),
        boundary_evidence=dict(observation_time_s=now, camera_index=camera,
            source_camera=_CAMERAS[camera][0], source_pixel_uv=boundary_uv[edge_index].tolist(),
            measured_depth_z_m=float(boundary_depth[edge_index]), point_world=edge.tolist(),
            boundary_kind='external blue silhouette; actual cuff identity not established',
            full_arc_source_pixels_uv=boundary_uv[arc].tolist(),
            full_arc_measured_points_world=boundary_world[arc].tolist(),
            local_support_source_pixels_uv=boundary_uv[local_arc].tolist(),
            local_support_measured_points_world=boundary_world[local_arc].tolist(),
            exterior_depth_samples=exterior[edge_index],
            inset_strip_source_pixels_uv=strip_uv.tolist(),
            inset_strip_measured_points_world=_world_pixels(values, camera, strip_uv[:, 0], strip_uv[:, 1],
                depth[strip_uv[:, 1], strip_uv[:, 0]]).tolist(),
            inset_strip_all_observed_blue_valid_and_planar=True,
            inset_strip_scope='one-pixel raster path between actual edge and target; no gap filling or whole gripper-footprint claim',
            occlusion_scope='adjacent current visible image pixels only; no future grasp collision guarantee'),
        support_source_pixels_uv=np.column_stack((uu[support], vv[support])).tolist(),
        support_measured_points_world=observed[support].tolist(),
        pixel_quantization_respected=True, target_interpolated=False, patch_recentered=False,
        cross_time_stability_verified=False)


def estimate_planar_sleeve_edges(obs, planar_report=None):
    """Return the planar report with two observed edge-inset targets or unknown.

    Camera choice is deterministic (heads before wrists). Every call rebuilds
    current geometry and provenance; consumers must compare fresh evidence at
    initial selection and handoff rather than treating cached boundary pixels
    as tracked material identities. This function issues no action.
    """
    values = _validated(obs, wrists=True)
    now = float(np.asarray(obs['simulation_time_s']).item())
    if not np.isfinite(now) or now < 0:
        raise ValueError('finite nonnegative current public timestamp required')
    current = estimate_planar_shirt(obs)
    result = deepcopy(current)
    result.update(proposal_version='public_lateral_edge_inset_v1', observation_time_s=now,
        original_interior_candidates=deepcopy(current.get('candidates', [])), candidates=[],
        detected=False, edge_refinement_diagnostics=[], requested_lateral_inset_m=_REQUESTED,
        allowed_measured_inset_m=list(_INSET), read_only=True, policy_modified=False,
        cuff_edges_verified=False, physical_openings_verified=False, insertion_allowed=False,
        cross_time_identity_verified=False,
        edge_refinement_scope='same-frame supported blue lateral silhouettes; sleeve-side heuristic only')
    if not current.get('detected'):
        result['reason'] = 'unknown_initial_planar_shirt: '+str(current.get('reason'))
        return result
    if planar_report is not None and not _report_matches(planar_report, current):
        result['reason'] = 'unknown_supplied_planar_report_does_not_match_current_observation'
        return result
    selected = []
    for side, original in zip((-1, 1), current['candidates']):
        views = []
        for camera in _CAMERA_ORDER:
            try:
                candidate = _view_candidate(values, current, original, side, camera, now)
                views.append(candidate)
                result['edge_refinement_diagnostics'].append(dict(geometric_side=original['geometric_side'],
                    camera_index=camera, supported=True))
            except ValueError as error:
                result['edge_refinement_diagnostics'].append(dict(geometric_side=original['geometric_side'],
                    camera_index=camera, supported=False, reason=str(error)))
        if not views:
            result['reason'] = 'unknown_no_supported_edge_inset_for_'+original['geometric_side']
            return result
        chosen = views[0]
        if any(np.linalg.norm(np.asarray(v['target_world'])-chosen['target_world']) > .025
               or np.linalg.norm(np.asarray(v['boundary_evidence']['point_world'])-
                                 chosen['boundary_evidence']['point_world']) > .025 for v in views[1:]):
            result['reason'] = 'unknown_edge_proposals_disagree_across_current_views'
            return result
        chosen['agreeing_camera_indices'] = [v['camera_index'] for v in views]
        selected.append(chosen)
    span = float(np.linalg.norm(np.asarray(selected[1]['target_world'])-selected[0]['target_world']))
    if not .30 < span < 1.:
        result['reason'] = 'unknown_edge_inset_pair_span_outside_existing_policy_bounds'
        return result
    result.update(detected=True, reason='observed_planar_lateral_edge_inset_fabric_hypotheses',
                  candidates=selected, candidate_span_m=span,
                  candidate_world_heights_m=[c['target_world'][2] for c in selected])
    return result
