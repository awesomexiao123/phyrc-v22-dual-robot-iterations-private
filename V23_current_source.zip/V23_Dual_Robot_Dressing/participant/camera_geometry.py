"""Pixel-index to optical geometry for the new controller's public RGB-D.

Array element (v,u) samples the render pixel centre (u+.5,v+.5). The
principal point is (width/2,height/2) in continuous image-edge coordinates.
Frozen V22 projection/code is deliberately untouched. This correction was
checked against a public depth point on the published own-robot mast visual.
"""
import numpy as np


def pixel_rays(u, v, focal, width=256, height=256):
    if not np.isfinite(focal) or focal <= 0 or width <= 0 or height <= 0:
        raise ValueError('invalid public camera intrinsics')
    u, v = np.broadcast_arrays(np.asarray(u, dtype=float), np.asarray(v, dtype=float))
    return np.stack(((u+.5-width/2)/focal, (v+.5-height/2)/focal, np.ones_like(u)), axis=-1)


def project_optical(points, focal, width=256, height=256):
    points = np.asarray(points, dtype=float)
    if points.shape[-1:] != (3,) or not np.isfinite(points).all() or np.any(points[..., 2] <= 0):
        raise ValueError('expected finite optical points in front of camera')
    if not np.isfinite(focal) or focal <= 0 or width <= 0 or height <= 0:
        raise ValueError('invalid public camera intrinsics')
    return points[..., :2]/points[..., 2:3]*focal + np.array([width/2-.5, height/2-.5])
