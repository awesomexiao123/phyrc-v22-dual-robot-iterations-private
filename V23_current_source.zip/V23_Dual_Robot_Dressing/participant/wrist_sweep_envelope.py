"""Additional displacement reserve for the static OWN articulated wrist boxes.

Only the 13 enclosing boxes and joint tree already extracted in
``gripper_skin_clearance`` are used. No assets, simulator, human or cloth data
are read. This is a kinematic geometric bound, not a physical safety,
inertia/dynamics, contact-offset, or whole-robot collision proof.

The wrist-only helper requires a fixed wrist_link root and fixed measured jaws.
The companion jaw helper covers declared finger intervals; its reserve can be
added to the wrist reserve for combined articulation. A common fixed rigid
root transform preserves Euclidean displacement, so no root pose is needed
here. Each bound applies to every material point of each box, not merely its
centre or sampled corners.

For an ancestor wrist joint k, let R_k be the maximum local-box point norm,
plus ||position1_k||, plus ||position0_j|| + ||position1_j|| for every joint
strictly downstream on the path to the box. Rotations preserve lengths; the
triangle inequality therefore bounds distance to joint k's pivot by R_k at
ALL downstream configurations, including mixed yaw/pitch/roll states. Distance
to its axis is no greater. Changing that joint by d moves any such point by
2*r*sin(|d|/2) <= R_k*|d|. Change the three wrist joints one at a time and apply
the triangle inequality again. Thus sum_k R_k*|d_k| bounds the combined change.
This telescoping argument includes downstream combinations without treating
the three axes as if they shared one fixed world frame.

Raw and excess candidate ranges are evaluated separately and their reserves
are unioned with max, never by adding signed angles. The returned reserve is
ADDITIONAL to any existing geometric margin, including the caller's 3 mm;
this module neither accepts nor reduces that pre-existing margin.
"""

import math

import numpy as np

try:
    from .gripper_skin_clearance import _OWN_GEOMETRY_DATA
except ImportError:  # Existing participant runners import modules directly.
    from gripper_skin_clearance import _OWN_GEOMETRY_DATA


WRIST_AXES = ('yaw', 'pitch', 'roll')
MAX_AXIS_CHANGE_RAD = math.radians(0.5)
_WRIST_INDICES = (8, 9, 10)


def _upward_norm(values):
    value = math.hypot(*(float(v) for v in values))
    return math.nextafter(value, math.inf) if value else 0.0


def _upward_sum(values):
    value = math.fsum(values)
    return math.nextafter(value, math.inf) if value else 0.0


def _box_axis_radii(collider, indices=_WRIST_INDICES):
    """Configuration-independent pivot-distance envelopes, in metres."""
    incoming = {joint['child']: joint for joint in _OWN_GEOMETRY_DATA['joints']}
    path = []
    link = collider['link']
    visited = set()
    while link != 'wrist_link':
        if link in visited or link not in incoming:
            raise ValueError('invalid_static_own_joint_tree')
        visited.add(link)
        joint = incoming[link]
        path.append(joint)
        link = joint['parent']
    # Walk from the local box back towards the root. The local maximum norm
    # is attained at a corner chosen independently on each coordinate.
    corner_magnitudes = np.maximum(np.abs(collider['lower_m']),
                                   np.abs(collider['upper_m']))
    terms = [_upward_norm(corner_magnitudes)]
    radii = [0.0]*len(indices)
    for joint in path:
        terms.append(_upward_norm(joint['position1']))
        index = joint['public_index']
        if index in indices:
            radii[indices.index(index)] = _upward_sum(terms)
        terms.append(_upward_norm(joint['position0']))
    return radii


def _unknown(reason):
    return dict(valid=False, reason=reason, per_box=[],
                max_displacement_reserve_m=None,
                reserve_is_additional_to_existing_geometry_margin=True,
                existing_geometry_margin_consumed_m=0.0,
                physical_safety_proven=False, inertia_or_dynamics_bounded=False,
                fullbody_clearance=False, collision_free=False)


def jaw_sweep_envelope(current_raw_q, raw_scalar_jaw_target_rad,
                       raw_jaw_velocity_rad_s, *, interval_s=.05,
                       max_axis_change_rad=MAX_AXIS_CHANGE_RAD):
    """Additional box displacement for declared left/right finger intervals.

    The official own-robot driver addresses both finger revolute joints with
    the same scalar ``grip_pos`` target (public controller_target column 5):
    Teleop_TShirt_Stretch4_Env.py's _all_pos appends [grip_pos, grip_pos].
    Actual left/right angles and velocities still remain independent inputs.

    Each interval is [min(q, target)-abs(qdot)*.05,
                      max(q, target)+abs(qdot)*.05]. The target end is expanded
    as well as the current end. No clipping at limits or the 0.5 degree cap is
    allowed. Only the official 50 ms interval is supported here. A current raw
    velocity times one interval is an engineering reserve, NOT a bound on
    future velocity, inertia, braking, or continuous physical motion.

    For each box, the same ancestor-pivot radius proof as the wrist helper is
    applied to public joints 11 and 12. Finger radii are independent of wrist
    orientation, so this reserve may be ADDED to the wrist reserve using the
    triangle inequality, including simultaneous wrist/jaw changes. No original
    model margin is consumed. Root motion requires a separate check.
    """
    try:
        q = np.asarray(current_raw_q, dtype=float)
        target = np.asarray(raw_scalar_jaw_target_rad, dtype=float)
        velocity = np.asarray(raw_jaw_velocity_rad_s, dtype=float)
        duration = float(interval_s)
        if q.shape != (13,) or not np.isfinite(q).all():
            raise ValueError('current_raw_q_must_be_finite_shape_13')
        if target.shape != () or not np.isfinite(target):
            raise ValueError('raw_jaw_target_must_be_one_finite_scalar')
        if velocity.shape != (2,) or not np.isfinite(velocity).all():
            raise ValueError('raw_jaw_velocity_must_be_finite_shape_2')
        if not np.isfinite(duration) or duration != .05:
            raise ValueError('jaw_rate_reserve_requires_official_50ms_interval')
        cap = np.asarray(max_axis_change_rad, dtype=float)
        if cap.shape == ():
            cap = np.full(2, float(cap))
        if (cap.shape != (2,) or not np.isfinite(cap).all() or
                np.any(cap <= 0) or np.any(cap > MAX_AXIS_CHANGE_RAD)):
            raise ValueError('jaw_axis_cap_must_be_positive_and_at_most_half_degree')
        joint_map = {j['public_index']: j for j in _OWN_GEOMETRY_DATA['joints']
                     if j['public_index'] is not None}
        for index, joint in joint_map.items():
            if not joint['limits_rad'][0] <= q[index] <= joint['limits_rad'][1]:
                raise ValueError('current_raw_joint_outside_own_limit:'+joint['name'])
        limits = np.asarray([joint_map[i]['limits_rad'] for i in (11, 12)])
        rate = np.abs(velocity)*duration
        ranges = np.column_stack((np.minimum(q[11:13], float(target))-rate,
                                  np.maximum(q[11:13], float(target))+rate))
        if (not np.isfinite(ranges).all() or np.any(ranges[:, 0] < limits[:, 0]) or
                np.any(ranges[:, 1] > limits[:, 1])):
            raise ValueError('expanded_jaw_range_outside_own_limits')
        deltas = np.max(np.abs(ranges-q[11:13, None]), axis=1)
        if np.any(deltas > cap):
            raise ValueError('expanded_jaw_range_exceeds_axis_change_cap')
        per_box = []
        for collider in _OWN_GEOMETRY_DATA['colliders']:
            radii = _box_axis_radii(collider, (11, 12))
            terms = []
            for radius, delta in zip(radii, deltas):
                value = radius*float(delta)
                terms.append(math.nextafter(value, math.inf) if value else 0.0)
            per_box.append(dict(link=collider['link'], source_prim=collider['source_prim'],
                                axis_radius_envelope_m=radii,
                                displacement_reserve_m=_upward_sum(terms)))
    except (TypeError, ValueError, OverflowError) as error:
        return _unknown(str(error))
    return dict(valid=True, reason='static_own_finger_boxes_declared_angle_intervals_only',
                jaw_axes=['left', 'right'], current_jaw_angles_rad=q[11:13].tolist(),
                raw_scalar_jaw_target_rad=float(target), raw_jaw_velocity_rad_s=velocity.tolist(),
                rate_interval_s=duration, raw_rate_angle_reserve_rad=rate.tolist(),
                jaw_target_ranges_rad=ranges.tolist(), max_abs_delta_rad=deltas.tolist(),
                per_box=per_box,
                max_displacement_reserve_m=max(row['displacement_reserve_m'] for row in per_box),
                reserve_is_additional_to_existing_geometry_margin=True,
                existing_geometry_margin_consumed_m=0.0,
                declared_jaw_angle_sweep_bounded=True,
                future_jaw_motion_bounded=False, root_motion_bounded=False,
                physical_safety_proven=False, inertia_or_dynamics_bounded=False,
                fullbody_clearance=False, collision_free=False)


def wrist_sweep_envelope(current_raw_q, raw_wrist_target_ranges_rad,
                         excess_wrist_target_ranges_rad, *,
                         max_axis_change_rad=MAX_AXIS_CHANGE_RAD):
    """Bound both candidate sweeps from one measured 13-joint raw state.

    Both target inputs have shape (3, 2): [lower, upper] ABSOLUTE raw joint
    angles in radians, in yaw/pitch/roll order (public indices 8, 9, 10).
    An excess-controller candidate must first be converted to those same raw
    coordinates. A single target is represented by equal endpoints. Neither
    input is a signed delta or an excess-coordinate angle.

    Each endpoint must remain within the authored wrist limits and within
    ``max_axis_change_rad`` of the current angle. This cap may be a positive
    scalar or length-3 vector, and each cap must be <= 0.5 degrees. It bounds
    absolute departure from the current state, not raw-to-excess separation.
    Current measured jaw angles are checked against authored limits and held
    fixed, regardless of any commanded jaw intent. No measured-state tolerance
    or endpoint clipping is applied. Other raw entries must be finite, but
    their limits are not present in this static wrist model.

    For either candidate, all combinations in the coordinate-wise hull of its
    range and the current wrist state are covered, so any continuous wrist
    trajectory remaining in that hull is covered. Overshoot, jaw motion and
    root motion are excluded. Invalid inputs return valid=False and no reserve.
    The per-box/global reserve is only geometric displacement from the current
    box; it is not permission to execute a command or a clearance claim.
    """
    try:
        q = np.asarray(current_raw_q, dtype=float)
        if q.shape != (13,) or not np.isfinite(q).all():
            raise ValueError('current_raw_q_must_be_finite_shape_13')
        cap = np.asarray(max_axis_change_rad, dtype=float)
        if cap.shape == ():
            cap = np.full(3, float(cap))
        if (cap.shape != (3,) or not np.isfinite(cap).all() or
                np.any(cap <= 0.0) or np.any(cap > MAX_AXIS_CHANGE_RAD)):
            raise ValueError('axis_change_cap_must_be_positive_and_at_most_half_degree')
        for joint in _OWN_GEOMETRY_DATA['joints']:
            index = joint['public_index']
            if index is not None:
                lo, hi = joint['limits_rad']
                if not lo <= q[index] <= hi:
                    raise ValueError('current_raw_joint_outside_own_limit:'+joint['name'])
        wrist_joints = {j['public_index']: j for j in _OWN_GEOMETRY_DATA['joints']
                        if j['public_index'] in _WRIST_INDICES}
        limits = np.asarray([wrist_joints[i]['limits_rad'] for i in _WRIST_INDICES])
        candidates = {}
        for name, value in (('raw', raw_wrist_target_ranges_rad),
                            ('excess', excess_wrist_target_ranges_rad)):
            ranges = np.asarray(value, dtype=float)
            if ranges.shape != (3, 2) or not np.isfinite(ranges).all():
                raise ValueError(name+'_wrist_ranges_must_be_finite_shape_3_by_2')
            if np.any(ranges[:, 0] > ranges[:, 1]):
                raise ValueError(name+'_wrist_range_lower_exceeds_upper')
            if np.any(ranges[:, 0] < limits[:, 0]) or np.any(ranges[:, 1] > limits[:, 1]):
                raise ValueError(name+'_wrist_target_outside_own_limit')
            deltas = np.max(np.abs(ranges-q[8:11, None]), axis=1)
            # Tiny representation error when constructing q + cap must not
            # silently widen the configured range: compare the actual inputs.
            if np.any(deltas > cap):
                raise ValueError(name+'_wrist_target_exceeds_axis_change_cap')
            candidates[name] = dict(ranges=ranges, deltas=deltas)
        per_box = []
        for collider in _OWN_GEOMETRY_DATA['colliders']:
            radii = _box_axis_radii(collider)
            reserves = {}
            for name, candidate in candidates.items():
                terms = []
                for radius, delta in zip(radii, candidate['deltas']):
                    product = radius*float(delta)
                    terms.append(math.nextafter(product, math.inf) if product else 0.0)
                reserves[name] = _upward_sum(terms)
            per_box.append(dict(link=collider['link'],
                                source_prim=collider['source_prim'],
                                axis_radius_envelope_m=radii,
                                raw_displacement_reserve_m=reserves['raw'],
                                excess_displacement_reserve_m=reserves['excess'],
                                displacement_reserve_m=max(reserves.values())))
    except (TypeError, ValueError, OverflowError) as error:
        return _unknown(str(error))

    return dict(valid=True, reason='static_own_boxes_fixed_root_and_measured_jaws_only',
                wrist_axes=list(WRIST_AXES),
                current_raw_wrist_rad=q[8:11].tolist(),
                fixed_measured_jaw_angles_rad=q[11:13].tolist(),
                axis_change_cap_rad=cap.tolist(),
                raw_wrist_target_ranges_rad=candidates['raw']['ranges'].tolist(),
                excess_wrist_target_ranges_rad=candidates['excess']['ranges'].tolist(),
                raw_max_abs_delta_rad=candidates['raw']['deltas'].tolist(),
                excess_max_abs_delta_rad=candidates['excess']['deltas'].tolist(),
                per_box=per_box,
                max_displacement_reserve_m=max(b['displacement_reserve_m'] for b in per_box),
                raw_max_displacement_reserve_m=max(b['raw_displacement_reserve_m'] for b in per_box),
                excess_max_displacement_reserve_m=max(b['excess_displacement_reserve_m'] for b in per_box),
                union_rule='per_box_max_of_separately_bounded_raw_and_excess_candidates',
                reserve_is_additional_to_existing_geometry_margin=True,
                existing_geometry_margin_consumed_m=0.0,
                fixed_wrist_link_root_required=True, fixed_measured_jaws_required=True,
                jaw_motion_bounded=False, root_motion_bounded=False,
                physical_safety_proven=False, inertia_or_dynamics_bounded=False,
                fullbody_clearance=False, collision_free=False)
