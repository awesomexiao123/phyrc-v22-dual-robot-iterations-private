"""Public-depth candidate routes executed as measured shared translations.

Height is adjusted first, then both bases follow the same planar route while
keeping their initial offsets. This protects neither extended arms nor cloth
and does not certify unobserved space, garment tension, or dressing success.
"""
import numpy as np

from cooperative_transport import RigidPairTransport, _snapshot
from planar_navigation import plan_pair_route, validate_pair_route_segment


class RoutedPairTransport:
    """Compatible action/done/failure/debug wrapper around straight segments.

    Route changes never reset the original relative-grasp and yaw guards.
    Each segment handoff emits zero movement with a close intent for both
    grippers. There is no smoothing after the straight controller's guards.
    """
    REPLAN_AFTER_S = 1.0
    MAX_REPLANS = 2
    MAX_DURATION_S = 600.
    MAX_CALLS = 16000
    GOAL_TOLERANCE_M = .008

    def __init__(self, observation, desired_shift_world, max_speed=.035):
        shift = np.asarray(desired_shift_world, dtype=float)
        if shift.shape != (3,) or not np.isfinite(shift).all():
            raise ValueError('desired shift must be a finite world XYZ vector')
        if not np.isfinite(max_speed) or not 0 < max_speed <= .035:
            raise ValueError('max_speed must be positive and at most 0.035 m/s')
        bases, grasps, yaw, _, now = _snapshot(observation)
        self.base0, self.grasp0, self.yaw0 = bases.copy(), grasps.copy(), yaw.copy()
        self.shift = shift.copy()
        self.max_speed = float(max_speed)
        self.center0 = bases[:, :2].mean(axis=0)
        self.goal_center = self.center0 + self.shift[:2]
        self.goal_grasps = self.grasp0 + self.shift
        self.goal_bases = self.base0[:, :2] + self.shift[:2]
        self.time0 = self.last_time = now
        self.calls = self.replans = self.completed_segments = 0
        self.failure = None
        self.done = False
        self.phase = 'height' if abs(shift[2]) > 1e-9 else 'plan_xy'
        self.route = {}
        self.waypoints = np.empty((0, 2))
        self.waypoint_index = 0
        self.segment = None
        self.segment_goal_grasps = self.segment_goal_bases = None
        self.segment_debug = {}
        self.blocked_since = None
        self.slow_since = None
        self.timeout_s = min(self.MAX_DURATION_S, max(30., 3*np.linalg.norm(shift)/max_speed+30.))
        self.debug = {}
        if self.phase == 'height':
            self._new_segment(observation, [0., 0., shift[2]])

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32)
        action[:, 8] = 1.
        return action

    def _result(self, action=None):
        if action is None or self.done:
            action = self._hold()
        if self.failure:
            action = np.zeros((2, 9), np.float32)
        self.debug.update(phase=self.phase, failure=self.failure, done=self.done,
            calls=self.calls, replans=self.replans, completed_segments=self.completed_segments,
            waypoint_index=self.waypoint_index,
            pair_center_waypoints_world_xy=self.waypoints.tolist(),
            desired_shift_world=self.shift.tolist(), route=self.route,
            segment_debug=dict(self.segment_debug), timeout_s=self.timeout_s,
            unknown_space=True, space_is_certified_free=False,
            scope='public-depth estimated base route; fixed grasp difference; no arm, garment, tension or sleeve guarantee')
        return dict(action=np.asarray(action, dtype=np.float32).copy(), done=bool(self.done),
                    failure=self.failure, debug=dict(self.debug))

    def _new_segment(self, obs, shift):
        bases, grasps, _, _, _ = _snapshot(obs)
        shift = np.asarray(shift, dtype=float)
        self.segment_goal_grasps = grasps + shift
        self.segment_goal_bases = bases[:, :2] + shift[:2]
        self.segment = RigidPairTransport(obs, shift, max_speed=self.max_speed)
        self.segment_debug = {}
        self.blocked_since = None
        self.slow_since = None

    def _plan_remaining_xy(self, obs, bases):
        center = bases[:, :2].mean(axis=0)
        remaining = self.goal_center-center
        if np.linalg.norm(remaining) < 1e-9:
            self.phase = 'verify_goal'
            self.segment = None
            return
        route = plan_pair_route(obs, remaining, execution_clearance_m=.12)
        self.route = route
        if not route.get('feasible'):
            raise ValueError('paired route unavailable: '+str(route.get('reason', 'unknown')))
        points = np.asarray(route['pair_center_waypoints_world_xy'], dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or not np.isfinite(points).all():
            raise ValueError('invalid paired route waypoints')
        if np.linalg.norm(points[0]-center) > .01 or np.linalg.norm(points[-1]-self.goal_center) > .01:
            raise ValueError('paired route does not connect current center to original goal')
        # Exact endpoints prevent repeated local replans moving the final goal.
        points = points.copy(); points[0] = center; points[-1] = self.goal_center
        self.waypoints = points
        self.waypoint_index = 1
        route_length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
        allowance = 3*(abs(self.shift[2])+route_length)/self.max_speed+30.
        self.timeout_s = min(self.MAX_DURATION_S, max(self.timeout_s, allowance))
        self.phase = 'translate'
        self._new_segment(obs, np.r_[points[1]-center, 0.])

    def _verify_final(self, bases, grasps, dt):
        grasp_errors = np.linalg.norm(grasps-self.goal_grasps, axis=1)
        base_errors = np.linalg.norm(bases[:, :2]-self.goal_bases, axis=1)
        self.debug.update(final_grasp_error_m=grasp_errors.tolist(), final_base_error_m=base_errors.tolist())
        if max(float(grasp_errors.max()), float(base_errors.max())) > self.GOAL_TOLERANCE_M:
            raise ValueError('routed transport final poses do not reach original desired shift')
        # The previous segment already required a measured settling interval.
        # This explicit global check prevents local segment/replan drift from
        # being mistaken for completion of the requested whole displacement.
        self.done = True
        self.phase = 'done'

    def step(self, obs):
        if self.failure or self.done:
            return self._result()
        self.calls += 1
        action = self._hold()
        self.debug = dict(navigation_paused_pair=False, segment_transition_hold=False)
        try:
            bases, grasps, yaw, tilt, now = _snapshot(obs)
            dt = now-self.last_time
            if dt < -1e-8:
                raise ValueError('routed transport public clock moved backwards')
            self.last_time = now
            if self.calls > self.MAX_CALLS or now-self.time0 > self.timeout_s:
                raise ValueError('routed transport exceeded total bounded duration')
            if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
                raise ValueError('routed transport gripper opened')
            if np.max(tilt) > .065 or np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
                raise ValueError('routed transport tilt or pair-spacing guard')
            yaw_error = (yaw-self.yaw0+np.pi) % (2*np.pi)-np.pi
            if np.max(np.abs(yaw_error)) > .04:
                raise ValueError('routed transport cumulative yaw drift')
            relative_error = float(np.linalg.norm((grasps[1]-grasps[0])-(self.grasp0[1]-self.grasp0[0])))
            self.debug['relative_grasp_error_m'] = relative_error
            if relative_error > .04:
                raise ValueError('routed transport cumulative relative grasp difference exceeds 4cm')
            if self.phase == 'plan_xy':
                self._plan_remaining_xy(obs, bases)
                self.debug['segment_transition_hold'] = True
            elif self.phase == 'verify_goal':
                self._verify_final(bases, grasps, dt)
            elif self.phase in ('height', 'translate'):
                result = self.segment.step(obs)
                self.segment_debug = dict(result['debug'])
                if result['failure']:
                    raise ValueError('routed segment failed: '+str(result['failure']))
                proposed = np.asarray(result['action'], dtype=np.float32)
                if proposed.shape != (2, 9) or not np.isfinite(proposed).all() or np.max(np.abs(proposed)) > 1:
                    raise ValueError('invalid routed segment action')
                action = proposed.copy()
                action[:, 8] = 1.
                blocked = bool(result['debug'].get('navigation_paused_pair', False))
                self.debug['navigation_paused_pair'] = blocked
                if blocked:
                    action = self._hold()
                    if self.blocked_since is None:
                        self.blocked_since = now
                    if self.phase == 'translate' and now-self.blocked_since >= self.REPLAN_AFTER_S:
                        if self.replans >= self.MAX_REPLANS:
                            raise ValueError('routed transport exhausted two obstacle replans')
                        self.replans += 1
                        self._plan_remaining_xy(obs, bases)
                        self.debug['segment_transition_hold'] = True
                    # A blocked segment cannot concurrently claim completion.
                    return self._result(action)
                self.blocked_since = None
                # Newly observed geometry can reduce speed almost to zero long
                # before the guard reports a full stop. Replan that route too.
                slow = (self.phase == 'translate' and not result['done'] and
                    result['debug'].get('common_navigation_scale', 1.) < .60 and
                    np.max(np.linalg.norm(bases[:, :2]-self.segment_goal_bases, axis=1)) > .025)
                if slow:
                    if self.slow_since is None:
                        self.slow_since = now
                    if now-self.slow_since >= self.REPLAN_AFTER_S:
                        check = validate_pair_route_segment(obs, bases[:, :2].mean(axis=0),
                            self.segment_goal_bases.mean(axis=0), clearance_m=.12)
                        self.debug['slow_route_segment_check'] = check
                        if not check['feasible']:
                            if self.replans >= self.MAX_REPLANS:
                                raise ValueError('routed transport exhausted two obstacle replans')
                            self.replans += 1
                            self._plan_remaining_xy(obs, bases)
                            self.debug['segment_transition_hold'] = True
                            return self._result(self._hold())
                        self.slow_since = None
                else:
                    self.slow_since = None
                if result['done']:
                    actual_error = max(float(np.linalg.norm(grasps-self.segment_goal_grasps, axis=1).max()),
                                       float(np.linalg.norm(bases[:, :2]-self.segment_goal_bases, axis=1).max()))
                    if actual_error > self.GOAL_TOLERANCE_M:
                        raise ValueError('segment reported done without measured target poses')
                    self.completed_segments += 1
                    action = self._hold()
                    self.debug['segment_transition_hold'] = True
                    if self.phase == 'height':
                        self.phase = 'plan_xy'
                        self.segment = None
                    else:
                        self.waypoint_index += 1
                        if self.waypoint_index >= len(self.waypoints):
                            self.phase = 'verify_goal'
                            self.segment = None
                        else:
                            center = bases[:, :2].mean(axis=0)
                            self._new_segment(obs, np.r_[self.waypoints[self.waypoint_index]-center, 0.])
            else:
                raise ValueError('unknown routed transport phase: '+self.phase)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error)
            self.phase = 'stopped'
        return self._result(action)
