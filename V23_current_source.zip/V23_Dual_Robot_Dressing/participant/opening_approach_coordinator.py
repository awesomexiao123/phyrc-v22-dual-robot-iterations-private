"""Bind same-frame opening diagnostics to one persistent observed approach.

This is simulation-only approach coordination, ending distal to the hands.
Neither initialization nor a completed approach establishes sleeve identity,
physical traversal or a completed dressing task. No automatic regrasp occurs.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from human_targets import estimate_hands
from forearm_surface import estimate_forearm_surfaces
from observed_pair_approach import ObservedPairApproach
from opening_rim_tracker import OpeningRimTracker
from sleeve_observation import _candidate_has_depth
from sleeve_probe import _candidate_polygon, _representative
from observed_hand_reacquisition import reacquire_observed_hand_pair


class OpeningApproachCoordinator:
    """step(obs, sleeve_observability=None) -> action/done/failure/debug.

    The sleeve report is required only before ``started``. Failed initialization
    may retry both trackers on a new frame for up to 20 simulation seconds. Once
    started, the trackers and controller are never reset or replaced. Repeated
    timestamps hold without advancing either component; backwards time stops.
    """
    INITIAL_WAIT_S = 20.

    def __init__(self, *, original_hand_report=None, original_observed_at=None,
                 stationary_human=False, max_prior_age_s=300.):
        self.started = False
        self.done = False
        self.failure = None
        self.pending_failure = None
        self.cancellation_only = False
        self.trackers = None
        self.approach = None
        self.rim_reports = []
        self.initial_time = self.last_time = None
        self.started_time = None
        self.initialization_reason = 'await_two_current_depth_supported_inner_contours'
        self.hold_reason = self.initialization_reason
        self.initialization_attempts = 0
        self.approach_debug = {}
        self.perception_error = None
        self.fresh_hands = {}
        self.fresh_forearms = {}
        # Fixed identity priors for this entire approach. Successful later
        # detections never move the original search points or refresh their age.
        self.original_hand_report = deepcopy(original_hand_report)
        self.original_hand_observed_at = original_observed_at
        self.stationary_human = stationary_human is True
        self.max_prior_age_s = max_prior_age_s
        self.hand_perception_source = None
        self.hand_reacquisition_debug = {}

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32)
        action[:, 8] = 1.
        return action

    def _result(self, action=None):
        if action is None or self.failure or self.done:
            action = self._hold()
        lost = self.started and not all(report.get('reliable') is True for report in self.rim_reports)
        return dict(action=np.asarray(action, np.float32).copy(), done=self.done, failure=self.failure,
            pending_failure=self.pending_failure, cancellation_only=self.cancellation_only,
            debug=dict(started=self.started, initialization_reason=self.initialization_reason,
                pending_failure=self.pending_failure, cancellation_only=self.cancellation_only,
                hold_reason=self.hold_reason, initialization_attempts=self.initialization_attempts,
                initial_wait_elapsed_s=(None if self.last_time is None else
                    (self.started_time if self.started_time is not None else self.last_time)-self.initial_time),
                tracker_reports=deepcopy(self.rim_reports), approach=deepcopy(self.approach_debug),
                perception_error=self.perception_error,
                hand_observation_time_s=self.fresh_hands.get('observation_time_s'),
                forearm_observation_time_s=self.fresh_forearms.get('observation_time_s'),
                hand_perception_source=self.hand_perception_source,
                original_hand_prior_observed_at_s=self.original_hand_observed_at,
                hand_surface_reacquisition=deepcopy(self.hand_reacquisition_debug),
                fixed_track_identity_lost=lost, regrasp_or_new_view_diagnostic_required=bool(lost),
                diagnostic_reason=('fixed rim evidence lost; evaluate a new view or regrasp separately; no automatic reseed'
                                   if lost else None),
                automatic_reseed=False, automatic_controller_restart=False,
                actual_grasp_failure_claimed=False, insertion_allowed=False,
                scope='simulation-only observed approach coordination; no traversal or dressing claim'))

    @staticmethod
    def _initial_candidates(obs, report, grasps, now):
        if not isinstance(report, dict):
            raise ValueError('current_sleeve_observability_report_required')
        regions = report.get('grasp_regions', [])
        if len(regions) != 2:
            raise ValueError('two_robot_ordered_grasp_regions_required')
        if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
            raise ValueError('both_closed_gripper_intents_required_before_initialization')
        chosen = []
        for robot, region in enumerate(regions):
            supplied = np.asarray(region.get('grasp_world'), float)
            if (region.get('grasp_index') != robot or supplied.shape != (3,)
                    or not np.isfinite(supplied).all() or np.linalg.norm(supplied-grasps[robot]) > .005):
                raise ValueError('initial_region_not_bound_to_current_robot_grasp')
            if region.get('ambiguous_candidate_indices'):
                raise ValueError('initial_opening_group_is_ambiguous_between_grasps')
            group = region.get('depth_supported_opening_candidates', [])
            if not group or not all(_candidate_has_depth(item) for item in group):
                raise ValueError('initial_opening_group_lacks_background_depth_support')
            candidate = _representative(group, now)
            center = np.asarray(candidate.get('centroid_world'), float)
            ring = np.asarray(candidate.get('ring_points_world'), float)
            if (center.shape != (3,) or not np.isfinite(center).all()
                    or ring.ndim != 2 or ring.shape[1] != 3 or not 1 <= len(ring) <= 64
                    or not np.isfinite(ring).all() or np.linalg.norm(center-grasps[robot]) > .25
                    or np.min(np.linalg.norm(ring-grasps[robot], axis=1)) > .18):
                raise ValueError('initial_observed_ring_is_not_near_its_own_grasp')
            chosen.append(candidate)
        # Distinct camera/index numbers alone do not establish two openings.
        # Use actual inner polygons, not the surrounding cloth band's extent.
        centers = np.array([candidate['centroid_world'] for candidate in chosen])
        radii = [float(np.max(np.linalg.norm(_candidate_polygon(candidate)-centers[r], axis=1)))
                 for r, candidate in enumerate(chosen)]
        if np.linalg.norm(centers[1]-centers[0]) <= sum(radii)+.01:
            raise ValueError('initial_rim_regions_are_not_distinct_and_disjoint')
        if (chosen[0]['camera_index'] == chosen[1]['camera_index'] and
                set(map(tuple, chosen[0]['inner_aperture']['contour_pixels_uv'])) ==
                set(map(tuple, chosen[1]['inner_aperture']['contour_pixels_uv']))):
            raise ValueError('initial_rim_identity_is_duplicated')
        return chosen

    def _observe_hands(self, obs, now):
        self.perception_error = None
        self.hand_reacquisition_debug = {}
        self.hand_perception_source = 'current_complete_head_pair_detector'
        try:
            hands = deepcopy(estimate_hands(obs))
            hands['observation_time_s'] = now
            if (not hands.get('detected') and self.stationary_human
                    and self.original_hand_report is not None
                    and self.original_hand_observed_at is not None):
                replacement = reacquire_observed_hand_pair(obs, self.original_hand_report,
                    self.original_hand_observed_at, stationary_human=True,
                    max_prior_age_s=self.max_prior_age_s)
                self.hand_reacquisition_debug = deepcopy(replacement)
                stamp = replacement.get('observation_time_s')
                if stamp is None or not np.isfinite(stamp) or abs(stamp-now) > 1e-7:
                    raise ValueError('hand_surface_reacquisition_did_not_return_current_frame')
                hands = deepcopy(replacement)
                self.hand_perception_source = 'current_surface_reacquisition_from_fixed_identity_priors'
            self.fresh_hands = hands
            if hands.get('detected'):
                surfaces = estimate_forearm_surfaces(obs, hands['hand_points_world'])
                self.fresh_forearms = dict(surfaces, observation_time_s=now)
            else:
                self.fresh_forearms = dict(observation_time_s=now, hand_surfaces=[],
                                          reason='current_public_hand_pair_unavailable')
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.perception_error = str(error)
            # These are explicitly missing current observations, never stamped
            # copies of a previous successful hand/forearm report.
            self.fresh_hands = dict(detected=False, hand_points_world=[], observation_time_s=now,
                                    reason='current_public_hand_perception_failed')
            self.fresh_forearms = dict(hand_surfaces=[], observation_time_s=now,
                                       reason='current_public_surface_perception_failed')

    def step(self, obs, sleeve_observability=None):
        if self.failure or self.done:
            return self._result()
        try:
            _, grasps, _, _, now = _snapshot(obs)
            if self.initial_time is None:
                self.initial_time = now
            if self.last_time is not None:
                if now < self.last_time-1e-8:
                    raise ValueError('coordinator_public_time_moved_backwards')
                if now <= self.last_time+1e-8:
                    self.hold_reason = 'await_fresh_observation_no_duplicate_tracker_or_controller_step'
                    return self._result()
            self.last_time = now
            just_started = False
            if not self.started:
                if now-self.initial_time >= self.INITIAL_WAIT_S:
                    raise ValueError('initial_opening_geometry_wait_timed_out: '+self.initialization_reason)
                try:
                    candidates = self._initial_candidates(obs, sleeve_observability, grasps, now)
                    self.initialization_attempts += 1
                    trackers = [OpeningRimTracker(), OpeningRimTracker()]
                    reports = [tracker.reset(obs, candidate) for tracker, candidate in zip(trackers, candidates)]
                    self.rim_reports = reports
                    if not all(report.get('reliable') is True for report in reports):
                        raise ValueError('both_initial_rim_feature_cohorts_required: '+
                                         '; '.join(str(report.get('reason')) for report in reports if not report.get('reliable')))
                    if reports[0].get('identity') == reports[1].get('identity'):
                        raise ValueError('initial_tracker_identities_are_not_distinct')
                    # Commit both trackers and one controller together. Failed
                    # attempts retain diagnostics but no live partial cohort.
                    approach = ObservedPairApproach(obs)
                    self.trackers, self.approach = trackers, approach
                    self.started = just_started = True
                    self.started_time = now
                    self.initialization_reason = 'both_current_rim_cohorts_initialized_once'
                except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
                    self.initialization_reason = str(error)
                    self.hold_reason = self.initialization_reason
                    return self._result()
            if not just_started:
                reports = []
                for tracker in self.trackers:
                    try:
                        reports.append(tracker.update(obs))
                    except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
                        reports.append(dict(reliable=False, reason='rim_update_failed: '+str(error),
                            kind='tracked_unclassified_rim', identity=deepcopy(tracker.identity),
                            features_reseeded=False, rim_geometry=None))
                self.rim_reports = reports
            self._observe_hands(obs, now)
            result = self.approach.step(obs, self.rim_reports, self.fresh_hands, self.fresh_forearms)
            self.approach_debug = deepcopy(result['debug'])
            self.done, self.failure = bool(result['done']), result['failure']
            self.pending_failure = result.get('pending_failure')
            self.cancellation_only = result.get('cancellation_only') is True
            self.hold_reason = self.approach_debug.get('hold_reason')
            action = np.asarray(result['action'], dtype=np.float32)
            if action.shape != (2, 9) or not np.isfinite(action).all() or np.max(np.abs(action)) > 1:
                raise ValueError('invalid_observed_approach_action')
            # Missing geometry blocks exploration, but zero lift velocity does
            # not cancel the native integrated position target. Preserve only
            # the child's explicitly bounded lift-target cancellation contract.
            if self.cancellation_only:
                if (np.max(np.abs(action[:, [0, 1, 2, 4, 5, 6, 7]])) > 1e-8
                        or np.max(np.abs(action[:, 3])) > .003/1.54+1e-8
                        or not np.all(action[:, 8] == 1)):
                    raise ValueError('invalid_lift_only_target_cancellation_action')
            if (not all(report.get('reliable') is True for report in self.rim_reports)
                    and not self.cancellation_only):
                action = self._hold()
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error)
            self.hold_reason = self.failure
            return self._result()
