"""Simulation-only wrist experiments using a frozen, measured equilibrium.

The original kernels receive explicitly DERIVED effective targets and measured
position-difference velocities. Raw observations remain unchanged. Calibration
is not an attachment sensor, an actuator stopping certificate or contact proof.
"""
from copy import deepcopy

import numpy as np

from cooperative_transport import _snapshot
from loaded_contact_pitch import LoadedContactPitch
from loaded_roll_observation import LoadedRollObservation, _cloth_evidence, _state
from public_vision import _rotation


def _raw_velocity_anomaly_evidence(calibration, raw_qd, departure, limits, allowance,
                                   *, now, q, targets, bases, grasps, phase):
    """Immutable-by-copy public evidence from the first offending frame."""
    names = ['lift', 'arm_segment_0', 'arm_segment_1', 'arm_segment_2',
             'arm_segment_3', 'wrist_yaw', 'wrist_pitch', 'wrist_roll']
    offending = []
    for robot, column in np.argwhere(departure > limits+1e-10):
        joint = int(column)+3
        offending.append(dict(robot=int(robot), joint_index=joint, axis=names[int(column)],
            raw_velocity=float(raw_qd[robot, joint]),
            frozen_median=float(calibration['raw_joint_velocity_median'][robot, joint]),
            absolute_departure=float(departure[robot, column]), limit=float(limits[robot, column])))
    return dict(observation_time_s=float(now), calibration_observed_at_s=float(calibration['observed_at_s']),
        phase=str(phase), checked_joint_indices=list(range(3, 11)),
        raw_joint_velocity=raw_qd.tolist(),
        frozen_raw_joint_velocity_median=calibration['raw_joint_velocity_median'].tolist(),
        frozen_raw_joint_velocity_peak_deviation=calibration['raw_joint_velocity_peak_deviation'].tolist(),
        absolute_departure=departure.tolist(), departure_limits=limits.tolist(),
        allowed_response_velocity=allowance.tolist(), offending=offending,
        raw_joint_position=q.tolist(), raw_controller_target=targets.tolist(),
        raw_base_pose_world=bases.tolist(), raw_grasp_position_world=grasps.tolist(),
        evidence_scope='First offending public sample; frozen forever, not evidence of later or between-sample state.')


class _CalibratedWrist:
    CORE = None
    IS_PITCH = False
    BIAS_LIMIT = np.array([.003, .003, *([np.deg2rad(.3)]*3)])
    LOWER = np.array([.005, .005, -1.1349999749656927+np.deg2rad(1.),
                      -4.275999675738779+np.deg2rad(1.), -1.1349999749656927+np.deg2rad(1.)])
    UPPER = np.array([1.195, .515, 4.275999675738779-np.deg2rad(1.),
                      1.1349999749656927-np.deg2rad(1.), 4.275999675738779-np.deg2rad(1.)])
    SCALES = np.array([1.54, 1.21, 5.5, 5.5, 5.5])

    def __init__(self, obs, hands, observed_at, *, calibration, stationary_human=True, max_hand_age_s=300.):
        self.core = None; self.failure = None; self.pending_failure = None
        self.first_raw_velocity_anomaly = None
        self.calibration = deepcopy(calibration)
        self.debug = {}; self.last_result = None; self.processed_time = None
        self.terminal = None; self.terminal_targets = None; self.history = []
        self.absolute_angle = np.zeros(2); self.previous_raw_q = None
        self.last_time = self.time0 = None
        self.hands = deepcopy(hands); self.observed_at = observed_at; self.max_hand_age_s = max_hand_age_s
        try:
            c = self.calibration
            for name, shape in [('controller_bias', (2, 5)), ('arm_position_offsets', (2, 4)),
                    ('raw_joint_velocity_median', (2, 13)), ('raw_joint_velocity_peak_deviation', (2, 13)),
                    ('last_joint_position', (2, 13)), ('last_base_pose', (2, 7)),
                    ('controller_target_reference', (2, 9))]:
                value = np.asarray(c[name], float).copy()
                if value.shape != shape or not np.isfinite(value).all():
                    raise ValueError('invalid_calibration_'+name)
                value.setflags(write=False); c[name] = value
            observed = float(c['observed_at_s']); start = float(c['window_start_s'])
            if (not np.isfinite([observed, start]).all() or observed-start < .5-1e-7
                    or int(c['frame_count']) < 11 or not isinstance(c['method'], str) or not c['method']):
                raise ValueError('calibration_requires_completed_half_second_observed_window')
            if (np.any(np.abs(c['controller_bias']) > self.BIAS_LIMIT+1e-10)
                    or np.max(np.abs(c['arm_position_offsets'].sum(1))) > 1e-9
                    or np.any(c['raw_joint_velocity_peak_deviation'] < 0)):
                raise ValueError('calibration_bias_offset_or_deviation_bound')
            bases, grasps, _, _, now = _snapshot(obs)
            q, raw_qd, targets = _state(obs)
            dt = now-observed
            if not -1e-8 <= dt <= .075:
                raise ValueError('calibration_end_frame_not_current_within_75ms')
            if np.max(np.abs(targets-c['controller_target_reference'])) > 1e-6:
                raise ValueError('raw_targets_changed_since_calibration')
            if np.max(np.abs(targets[:, 6:9])) > 1e-5:
                raise ValueError('nonzero_base_targets_at_calibrated_handoff')
            self._raw_limits(q, targets)
            if dt <= 1e-8:
                if (np.max(np.abs(q-c['last_joint_position'])) > 1e-8
                        or np.max(np.abs(bases-c['last_base_pose'])) > 1e-8):
                    raise ValueError('same_calibration_timestamp_has_changed_robot_state')
                velocity = np.zeros_like(q)
            else:
                velocity = (q-c['last_joint_position'])/dt
            self.base0 = bases.copy(); self.grasp0 = grasps.copy()
            self.time0 = self.last_time = now; self.previous_raw_q = q.copy()
            self.previous_raw_base = bases.copy(); self.previous_raw_targets = targets.copy()
            self.previous_raw_qd = raw_qd.copy()
            self._raw_velocity_guard(raw_qd, now=now, q=q, targets=targets, bases=bases, grasps=grasps)
            derived = self._derived(obs, q, velocity, targets)
            self.core = self.CORE(derived, hands, observed_at, stationary_human=stationary_human,
                                  max_hand_age_s=max_hand_age_s)
            self._append_history(now, q, bases, grasps)
            if self.core.eligible:
                goal = targets.copy()
                if self.IS_PITCH:
                    goal[:, [0, 1, 3]] = self.core.goal_u+c['controller_bias'][:, [0, 1, 3]]
                else:
                    goal[:, 4] = self.core.goals+c['controller_bias'][:, 4]
                self._raw_limits(q, goal)
            self.last_result = self.core._result()
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = str(error)

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32); action[:, 8] = 1.
        return action

    @staticmethod
    def _coordinates(q):
        return np.column_stack((q[:, 3], q[:, 4:8].sum(1), q[:, 8:11]))

    def _raw_limits(self, q, targets):
        if (np.any(self._coordinates(q) < self.LOWER-1e-7)
                or np.any(self._coordinates(q) > self.UPPER+1e-7)
                or np.any(targets[:, :5] < self.LOWER-1e-7)
                or np.any(targets[:, :5] > self.UPPER+1e-7)
                or np.any(q[:, 4:8] < -1e-5) or np.any(q[:, 4:8] > .13001)):
            raise ValueError('actual_joint_or_raw_controller_target_outside_own_margin')

    def _raw_velocity_guard(self, raw_qd, *, now, q, targets, bases, grasps):
        # Raw qd is never relabelled as corrected physical velocity. Only a new
        # departure from the frozen observed envelope is checked here.
        allowance = np.array([.003, .003, .003, .003, .003,
                              np.deg2rad(.1), np.deg2rad(.1), 2*LoadedRollObservation.RATE])
        if self.IS_PITCH:
            allowance = np.array([.02, .005, .005, .005, .005,
                                  np.deg2rad(.2), 2*LoadedContactPitch.RATE, np.deg2rad(.2)])
        departure = np.abs(raw_qd[:, 3:11]-self.calibration['raw_joint_velocity_median'][:, 3:11])
        limits = self.calibration['raw_joint_velocity_peak_deviation'][:, 3:11]+allowance
        self.debug.update(raw_joint_velocity_departure=departure.tolist(), raw_velocity_departure_limits=limits.tolist())
        if np.any(departure > limits+1e-10):
            if self.first_raw_velocity_anomaly is None:
                phase = self.core.debug.get('phase', 'unknown') if self.core is not None else 'constructor'
                self.first_raw_velocity_anomaly = _raw_velocity_anomaly_evidence(
                    self.calibration, raw_qd, departure, limits, allowance,
                    now=now, q=q, targets=targets, bases=bases, grasps=grasps, phase=phase)
            self.pending_failure = self.pending_failure or 'new_raw_joint_velocity_anomaly_outside_frozen_window'
            raise ValueError(self.pending_failure)

    def _derived(self, obs, q, velocity, targets):
        derived = dict(obs)
        derived_q = q.copy(); derived_q[:, 4:8] -= self.calibration['arm_position_offsets']
        effective = targets.copy(); effective[:, :5] -= self.calibration['controller_bias']
        derived.update(joint_position=derived_q, joint_velocity=velocity.copy(), controller_target=effective)
        self.debug.update(raw_joint_position=q.tolist(), raw_joint_velocity=np.asarray(obs['joint_velocity']).tolist(),
            raw_controller_target=targets.tolist(), derived_effective_controller_target=effective.tolist(),
            derived_arm_joint_position=derived_q[:, 4:8].tolist(),
            position_difference_velocity=velocity.tolist(), velocity_source='consecutive public joint position differences / simulation dt')
        return derived

    def _append_history(self, now, q, bases, grasps):
        if self.history and abs(now-self.history[-1][0]) <= 1e-8:
            return
        self.history.append((now, q.copy(), bases.copy(), grasps.copy()))
        while len(self.history) > 2 and now-self.history[1][0] >= .25-1e-8:
            self.history.pop(0)

    def _position_window_stable(self):
        if len(self.history) < 2:
            return False
        span = self.history[-1][0]-self.history[0][0]
        if span < .25-1e-8:
            return False
        q = np.stack([r[1] for r in self.history]); bases = np.stack([r[2] for r in self.history])
        grasps = np.stack([r[3] for r in self.history])
        linear = np.concatenate((q[:, :, 3:8], q[:, :, 4:8].sum(2, keepdims=True)), axis=2)
        okay = (np.max(np.ptp(linear, axis=0)) <= .00025
                and np.max(np.abs(linear[-1]-linear[0]))/span <= .0005
                and np.max(np.ptp(q[:, :, 8:11], axis=0)) <= np.deg2rad(.05)
                and np.max(np.abs(q[-1, :, 8:11]-q[0, :, 8:11]))/span <= np.deg2rad(.1))
        for points in (bases[:, :, :3], grasps):
            diameter = np.linalg.norm(points[:, None]-points[None, :], axis=-1).max()
            okay &= diameter <= .00025 and np.linalg.norm(points[-1]-points[0], axis=1).max()/span <= .0005
        rotations = np.array([[_rotation(b[3:]) for b in frame] for frame in bases])
        for robot in (0, 1):
            relative = np.einsum('aij,bkj->abik', rotations[:, robot], rotations[:, robot])
            angles = np.arccos(np.clip((np.trace(relative, axis1=2, axis2=3)-1)/2, -1, 1))
            okay &= angles.max() <= np.deg2rad(.05) and angles[0, -1]/span <= np.deg2rad(.1)
        self.debug.update(actual_position_window_seconds=span, actual_position_window_stable=bool(okay))
        return bool(okay)

    def _scene_and_budget(self, obs, q, bases, grasps, now):
        if (np.linalg.norm(grasps-self.grasp0, axis=1).max() > .003
                or np.linalg.norm(bases[:, :3]-self.base0[:, :3], axis=1).max() > .003):
            raise ValueError('original_base_or_grasp_3mm_drift_budget')
        for base, initial in zip(bases, self.base0):
            relative = _rotation(base[3:]) @ _rotation(initial[3:]).T
            if np.arccos(np.clip((np.trace(relative)-1)/2, -1, 1)) > np.deg2rad(.25):
                raise ValueError('original_base_rotation_budget')
        if (np.any(self.absolute_angle > self.core.PER_WRIST_RAD+1e-8)
                or self.absolute_angle.sum() > self.core.TOTAL_RAD+1e-8):
            raise ValueError('original_measured_absolute_angle_budget')
        if now-self.time0 > self.core.MAX_SECONDS+1e-8:
            raise ValueError('original_wrist_experiment_time_budget')

    def _result(self, result=None, *, repeated=False):
        result = deepcopy(result if result is not None else self.last_result)
        if result is None:
            result = dict(action=self._hold(), done=True, eligible=False, skipped=True, failure=self.failure,
                pending_failure=None, cancellation_only=False, motion_started=False,
                experiment_completed=False, early_stopped=False, debug={})
        if repeated:
            result['action'] = self._hold()
        if self.failure:
            result.update(action=self._hold(), failure=self.failure, done=True, experiment_completed=False)
        result['pending_failure'] = self.pending_failure or result.get('pending_failure')
        result['debug'].update(equilibrium_calibration=deepcopy(self.calibration),
            equilibrium_wrapper=deepcopy(self.debug), simulation_only=True,
            derived_effective_targets_used=True, raw_observations_modified=False,
            physical_stopping_certified=False, calibration_baseline_refreshed=False,
            wrapper_actual_absolute_angle_degrees=np.rad2deg(self.absolute_angle).tolist(),
            repeated_frame_no_action=bool(repeated))
        if self.first_raw_velocity_anomaly is not None:
            result['debug']['first_raw_velocity_anomaly'] = deepcopy(self.first_raw_velocity_anomaly)
        return result

    def step(self, obs, *, stop_for_openings=False):
        if self.failure:
            return self._result()
        try:
            bases, grasps, _, _, now = _snapshot(obs); q, raw_qd, targets = _state(obs)
            dt = now-self.last_time
            if dt < -1e-8 or dt > .075:
                raise ValueError('nonconsecutive_public_observation_clock')
            if dt <= 1e-8:
                if (np.max(np.abs(q-self.previous_raw_q)) > 1e-8
                        or np.max(np.abs(bases-self.previous_raw_base)) > 1e-8
                        or np.max(np.abs(targets-self.previous_raw_targets)) > 1e-8
                        or np.max(np.abs(raw_qd-self.previous_raw_qd)) > 1e-8):
                    raise ValueError('repeated_timestamp_has_changed_robot_state')
                if self.processed_time is not None:
                    return self._result(repeated=True)
                velocity = np.zeros_like(q)
            else:
                velocity = (q-self.previous_raw_q)/dt
                self.absolute_angle += np.abs(q[:, 9 if self.IS_PITCH else 10]-self.previous_raw_q[:, 9 if self.IS_PITCH else 10])
            self.last_time = self.processed_time = now
            self.previous_raw_q = q.copy(); self.previous_raw_base = bases.copy(); self.previous_raw_targets = targets.copy()
            self.previous_raw_qd = raw_qd.copy()
            self._raw_limits(q, targets); self._scene_and_budget(obs, q, bases, grasps, now)
            derived = self._derived(obs, q, velocity, targets)
            self._append_history(now, q, bases, grasps)
            stable = self._position_window_stable()
            try:
                self._raw_velocity_guard(raw_qd, now=now, q=q, targets=targets, bases=bases, grasps=grasps)
            except ValueError as error:
                self.pending_failure = self.pending_failure or str(error)
            if self.terminal is None:
                result = self.core.step(derived, stop_for_openings=stop_for_openings or bool(self.pending_failure))
                action = np.asarray(result['action'], float)
                if action.shape != (2, 9) or not np.isfinite(action).all() or np.max(np.abs(action)) > 1:
                    raise ValueError('invalid_inner_action')
                predicted = targets.copy(); predicted[:, :5] += action[:, 3:8]*self.SCALES*.05
                self._raw_limits(q, predicted)
                self.debug['predicted_next_raw_controller_target'] = predicted.tolist()
                terminal = result['done'] or result['failure']
                resolved = (result['done'] and not result['skipped']) or result['debug'].get('phase') == 'failed_after_target_cancellation'
                if terminal and resolved:
                    self.terminal = deepcopy(result); self.terminal_targets = targets.copy()
                elif terminal:
                    self.last_result = result
                    if self.pending_failure:
                        self.failure = self.pending_failure
                    return self._result()
            if self.terminal is not None:
                if np.max(np.abs(targets-self.terminal_targets)) > 1e-5:
                    raise ValueError('raw_target_changed_during_completion_position_window')
                if not 0 <= now-float(self.observed_at) <= float(self.max_hand_age_s):
                    raise ValueError('cached_hand_time_invalid_during_completion_window')
                gap = np.asarray(obs['fingertip_origin_distance'], float).reshape(2)
                if (not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all()
                        or not np.isfinite(gap).all() or np.any(gap < 0) or gap.max() > .08):
                    raise ValueError('closed_gripper_guard_during_completion_window')
                self.debug.update(_cloth_evidence(obs, grasps, np.asarray(self.hands['hand_points_world'], float)))
                if self.core.cancel_start is not None and now-self.core.cancel_start > 1.5+1e-8:
                    raise ValueError('original_cancellation_time_budget')
                result = deepcopy(self.terminal); result['action'] = self._hold()
                if stable:
                    if self.pending_failure:
                        result.update(failure=self.pending_failure, done=True, experiment_completed=False)
                else:
                    result.update(done=False, failure=None, experiment_completed=False,
                                  pending_failure=self.pending_failure or self.terminal.get('failure'),
                                  cancellation_only=not self.terminal.get('experiment_completed', False))
                    result['debug']['phase'] = 'awaiting_actual_position_window'
            self.last_result = result
            return self._result()
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = self.pending_failure or str(error)
            self.debug['terminal_guard_failure'] = str(error)
            self.debug['unresolved_integrated_target_possible'] = True
            return self._result()


class CalibratedLoadedRoll(_CalibratedWrist):
    CORE = LoadedRollObservation


class CalibratedLoadedContactPitch(_CalibratedWrist):
    CORE = LoadedContactPitch
    IS_PITCH = True
