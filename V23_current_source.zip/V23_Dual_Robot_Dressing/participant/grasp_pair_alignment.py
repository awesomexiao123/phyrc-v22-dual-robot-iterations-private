"""Bounded two-end shape adjustment from public robot poses, not dressing.

The caller supplies two robot-ordered grasp targets. This controller does not
identify sleeves, verify openings, measure garment tension or authorize hand
insertion. Both grips stay closed while arm/lift and guarded lateral base motion
follow one interpolation fraction. No base forward, yaw or wrist motion is used.
"""
import numpy as np

from cooperative_transport import _snapshot
from navigation import guard_base_velocity
from public_vision import _rotation


class GraspPairAlignment:
    MAX_SPEED = .01
    ARM_REACH = (.48, .92)
    # Published own stretch_4.usd arm_l1..l4 prismatic limits. The margin is
    # 5 mm of TOTAL telescoping travel, not 5 mm for each of the four stages.
    ARM_SEGMENT_LIMITS = (0., .13)
    ARM_EXTENSION_MARGIN = .005
    LIFT_LIMITS = (.005, 1.195)
    MAX_ENDPOINT_TRAVEL = .30
    MAX_BASE_LATERAL_TRAVEL = .15
    MAX_SPAN_INCREASE = .02
    MAX_PAIR_ROTATION_DEGREES = 20.
    GOAL_TOLERANCE_M = .003

    def __init__(self, observation, desired_grasp_world, max_speed=.01):
        desired = np.asarray(desired_grasp_world, dtype=float)
        if desired.shape != (2, 3) or not np.isfinite(desired).all():
            raise ValueError('expected two finite robot-ordered world grasp targets')
        if not np.isfinite(max_speed) or not 0 < max_speed <= self.MAX_SPEED:
            raise ValueError('alignment speed must be positive and at most .01 m/s')
        base, grasps, yaw, _, now = _snapshot(observation)
        self.base0, self.grasp0, self.yaw0 = base.copy(), grasps.copy(), yaw.copy()
        self.goal = desired.copy()
        self.delta = self.goal-self.grasp0
        self.lengths = np.linalg.norm(self.delta, axis=1)
        self.length = float(self.lengths.max())
        self.directions = self.delta/np.maximum(self.lengths[:, None], 1e-12)
        self.max_speed = float(max_speed)
        self.span0 = float(np.linalg.norm(self.grasp0[1]-self.grasp0[0]))
        self.reference_fraction = 0.
        self.time0 = self.last_time = now
        self.last_progress_time = now
        self.best_progress = 0.
        self.last_grasps, self.last_bases = grasps.copy(), base[:, :2].copy()
        self.endpoint_travel = np.zeros(2)
        self.base_lateral_travel = np.zeros(2)
        self.stable_seconds = 0.
        self.failure = None
        self.done = False
        self.calls = 0
        self.debug = {}
        self.arm_workspace = None
        self.initial_arm_workspace = None
        self.timeout_s = max(20., 4*self.length/self.max_speed+10.)
        grip_local = np.asarray(observation['grasp_pose_base'], dtype=float)
        self.goal_actuator_displacements = np.array([
            np.linalg.solve(self._axes(base[r], yaw[r]), self.delta[r]) for r in (0, 1)])
        # Geometry validation latches a stopped controller rather than silently
        # clamping caller goals into a different requested manipulation.
        span_goal = float(np.linalg.norm(self.goal[1]-self.goal[0]))
        angle = (float(np.arccos(np.clip((self.grasp0[1]-self.grasp0[0]) @ (self.goal[1]-self.goal[0]) /
                max(self.span0*span_goal, 1e-12), -1., 1.))) if min(self.span0, span_goal) > 1e-6 else np.inf)
        self.goal_pair_rotation_degrees = float(np.rad2deg(angle))
        try:
            self.arm_workspace = self._arm_workspace(observation)
            self.initial_arm_workspace = self.arm_workspace
        except (KeyError, ValueError, TypeError, IndexError) as error:
            self.failure = 'alignment public arm state: '+str(error)
            return
        arm_bounds = np.asarray(self.arm_workspace['guarded_grasp_x_bounds_m'])
        if self.length > self.MAX_ENDPOINT_TRAVEL:
            self.failure = 'desired endpoint displacement exceeds .30m'
        elif span_goal > self.span0+self.MAX_SPAN_INCREASE+1e-9:
            self.failure = 'desired grasp span would stretch beyond initial span plus .02m'
        elif self.goal_pair_rotation_degrees > self.MAX_PAIR_ROTATION_DEGREES:
            self.failure = 'desired pair rotation exceeds bounded 20 degree adjustment'
        elif np.max(np.abs(self.goal_actuator_displacements[:, 1])) > self.MAX_BASE_LATERAL_TRAVEL:
            self.failure = 'desired base lateral displacement exceeds .15m'
        elif np.any(grip_local[:, 0]+self.goal_actuator_displacements[:, 0] < arm_bounds[:, 0]-1e-9) or np.any(
                grip_local[:, 0]+self.goal_actuator_displacements[:, 0] > arm_bounds[:, 1]+1e-9):
            self.failure = 'desired target exceeds wrist-dependent own arm reach'
        else:
            lift_goal = np.asarray(observation['joint_position'])[:, 3]+self.goal_actuator_displacements[:, 2]
            if np.any(lift_goal < self.LIFT_LIMITS[0]) or np.any(lift_goal > self.LIFT_LIMITS[1]):
                self.failure = 'desired target exceeds own lift joint range with 5mm margin'

    @classmethod
    def _arm_workspace(cls, obs):
        """Infer current local-X travel while the wrist posture stays fixed.

        Telescoping extension translates the grasp by the sum of four stage
        positions. Subtract that measured sum from measured grasp X to retain
        the current wrist offset instead of assuming a neutral-wrist maximum.
        This is a kinematic bound, not an arm/cloth collision guarantee.
        """
        joints = np.asarray(obs['joint_position'], dtype=float)
        if joints.shape != (2, 13) or not np.isfinite(joints).all():
            raise ValueError('expected finite public joint_position shape (2,13)')
        segments = joints[:, 4:8]
        low, high = cls.ARM_SEGMENT_LIMITS
        if np.any(segments < low-1e-6) or np.any(segments > high+1e-6):
            raise ValueError('measured arm segment outside published 0..0.13m limits')
        grasp = np.asarray(obs['grasp_pose_base'], dtype=float)
        if grasp.shape != (2, 7) or not np.isfinite(grasp).all():
            raise ValueError('expected finite public grasp_pose_base shape (2,7)')
        extension = segments.sum(axis=1)
        offset = grasp[:, 0]-extension
        physical = np.column_stack((offset+4*low, offset+4*high))
        guarded = np.column_stack((np.maximum(cls.ARM_REACH[0], physical[:, 0]+cls.ARM_EXTENSION_MARGIN),
                                   np.minimum(cls.ARM_REACH[1], physical[:, 1]-cls.ARM_EXTENSION_MARGIN)))
        if np.any(guarded[:, 0] > guarded[:, 1]):
            raise ValueError('no arm reach interval after wrist posture and joint margin')
        return dict(source='public grasp_pose_base X minus public joint_position[:,4:8] sum; published own arm_l1..l4 limits; wrist held',
            arm_segment_limits_m=[low, high], total_extension_margin_m=cls.ARM_EXTENSION_MARGIN,
            measured_extension_sum_m=extension.tolist(), zero_extension_grasp_x_m=offset.tolist(),
            physical_grasp_x_bounds_m=physical.tolist(), guarded_grasp_x_bounds_m=guarded.tolist(),
            legacy_grasp_x_envelope_m=list(cls.ARM_REACH), collision_clearance_verified=False)

    @staticmethod
    def _axes(base_pose, yaw):
        rotation = _rotation(base_pose[3:])
        lateral = np.array([-np.sin(yaw), np.cos(yaw), 0.])
        # Columns are physical metres of arm extension, planar base side motion
        # and lift. Preserve full 3D geometry, including small measured tilt.
        return np.column_stack((rotation[:, 0], lateral, rotation[:, 2]))

    @staticmethod
    def _hold():
        action = np.zeros((2, 9), np.float32)
        action[:, 8] = 1.
        return action

    def _result(self, action=None):
        if action is None or self.failure or self.done:
            action = self._hold()
        self.debug.update(calls=self.calls, failure=self.failure, done=self.done,
            reference_fraction=self.reference_fraction, initial_grasp_span_m=self.span0,
            maximum_grasp_span_m=self.span0+self.MAX_SPAN_INCREASE,
            desired_grasp_world=self.goal.tolist(), goal_pair_rotation_degrees=self.goal_pair_rotation_degrees,
            measured_endpoint_travel_m=self.endpoint_travel.tolist(),
            measured_base_lateral_travel_m=self.base_lateral_travel.tolist(),
            arm_workspace=self.arm_workspace, initial_arm_workspace=self.initial_arm_workspace,
            guarded_lift_joint_interval_m=list(self.LIFT_LIMITS),
            initial_grasp_world=self.grasp0.tolist(), insertion_allowed=False,
            sleeve_openings_verified=False, scope='bounded shape adjustment only; no garment tension, arm collision or insertion guarantee')
        return dict(action=np.asarray(action, np.float32).copy(), done=bool(self.done),
                    failure=self.failure, debug=dict(self.debug))

    def step(self, obs):
        if self.failure or self.done:
            return self._result()
        self.calls += 1
        try:
            bases, grasps, yaw, tilt, now = _snapshot(obs)
            raw_dt = now-self.last_time
            if raw_dt < -1e-8:
                raise ValueError('alignment public clock moved backwards')
            dt = min(.05, max(0., raw_dt))
            self.last_time = now
            if self.calls > 5000 or now-self.time0 > self.timeout_s:
                raise ValueError('alignment exceeded bounded duration')
            if not np.asarray(obs['gripper_close_command']).reshape(2).astype(bool).all():
                raise ValueError('alignment lost a closed gripper')
            if 'fingertip_origin_distance' in obs:
                gap = np.asarray(obs['fingertip_origin_distance']).reshape(2)
                if not np.isfinite(gap).all() or np.max(gap) > .08:
                    raise ValueError('alignment gripper gap no longer supports closed state')
            if np.max(tilt) > .065 or np.linalg.norm(bases[1, :2]-bases[0, :2]) < .60:
                raise ValueError('alignment tilt or base separation guard')
            yaw_error = (yaw-self.yaw0+np.pi) % (2*np.pi)-np.pi
            if np.max(np.abs(yaw_error)) > .025:
                raise ValueError('alignment unexpected base yaw drift')
            forward = np.column_stack((np.cos(self.yaw0), np.sin(self.yaw0)))
            lateral = np.column_stack((-np.sin(self.yaw0), np.cos(self.yaw0)))
            base_delta = bases[:, :2]-self.base0[:, :2]
            if np.max(np.abs(np.sum(base_delta*forward, axis=1))) > .015:
                raise ValueError('alignment unexpected base forward drift')
            self.endpoint_travel += np.linalg.norm(grasps-self.last_grasps, axis=1)
            self.base_lateral_travel += np.abs(np.sum((bases[:, :2]-self.last_bases)*lateral, axis=1))
            self.last_grasps, self.last_bases = grasps.copy(), bases[:, :2].copy()
            if np.max(self.endpoint_travel) > self.MAX_ENDPOINT_TRAVEL+1e-6:
                raise ValueError('alignment cumulative endpoint travel exceeds .30m')
            if np.max(self.base_lateral_travel) > self.MAX_BASE_LATERAL_TRAVEL+1e-6:
                raise ValueError('alignment cumulative base lateral travel exceeds .15m')
            grip_local = np.asarray(obs['grasp_pose_base'], dtype=float)
            self.arm_workspace = self._arm_workspace(obs)
            arm_bounds = np.asarray(self.arm_workspace['guarded_grasp_x_bounds_m'])
            lift_positions = np.asarray(obs['joint_position'])[:, 3]
            if np.any(lift_positions < -1e-6) or np.any(lift_positions > 1.2+1e-6):
                raise ValueError('alignment measured lift joint outside own physical range')
            if np.any(grip_local[:, 0] < arm_bounds[:, 0]-1e-6) or np.any(grip_local[:, 0] > arm_bounds[:, 1]+1e-6):
                raise ValueError('alignment measured arm reach outside wrist-dependent guarded interval')
            span = float(np.linalg.norm(grasps[1]-grasps[0]))
            if span > self.span0+self.MAX_SPAN_INCREASE+1e-6:
                raise ValueError('alignment measured grasp span exceeds initial span plus .02m')
            reference = self.grasp0+self.reference_fraction*self.delta
            errors = grasps-reference
            tracking_error = np.linalg.norm(errors, axis=1)
            pair_tracking_error = float(np.linalg.norm(errors[1]-errors[0]))
            if np.max(tracking_error) > .05 or pair_tracking_error > .04:
                raise ValueError('alignment cumulative tracking deviation exceeds guard')
            progress = np.sum((grasps-self.grasp0)*self.directions, axis=1)
            lag = self.reference_fraction*self.lengths-progress
            moving = self.lengths > .001
            fractions = progress[moving]/self.lengths[moving]
            shared_measured = float(np.min(fractions)*self.length) if len(fractions) else 0.
            if shared_measured > self.best_progress+.001:
                self.best_progress = shared_measured; self.last_progress_time = now
            if now-self.last_progress_time > 12. and self.length > .003:
                raise ValueError('alignment made no measured pair progress for 12s')
            fraction_spread_m = float(np.ptp(fractions)*self.length) if len(fractions) else 0.
            pause = bool(np.max(lag) > .015 or fraction_spread_m > .015)
            advance = (0. if pause or self.length < 1e-12 else
                       min(self.max_speed*dt, .0005)/self.length)
            advance = min(advance, 1.-self.reference_fraction)
            requested_fraction = self.reference_fraction+advance
            requested = self.grasp0+requested_fraction*self.delta
            feedforward = self.delta*(advance/dt) if dt > 1e-10 else np.zeros((2, 3))
            actuator, guards, scales = [], [], []
            for robot in (0, 1):
                world_velocity = feedforward[robot]+1.8*(requested[robot]-grasps[robot])
                world_velocity *= min(1., self.max_speed/max(np.linalg.norm(world_velocity), 1e-12))
                matrix = self._axes(bases[robot], yaw[robot])
                joint_velocity = np.linalg.solve(matrix, world_velocity)
                joint_velocity *= min(1., self.max_speed/max(np.max(np.abs(joint_velocity)), 1e-12))
                body = np.array([0., joint_velocity[1]])
                guard = guard_base_velocity(obs, robot, body, max_speed=self.max_speed)
                allowed = np.asarray(guard['body_velocity_xy'], dtype=float)
                norm = float(np.linalg.norm(body))
                scale = float(np.clip(np.linalg.norm(allowed)/norm, 0., 1.)) if norm > 1e-9 else 1.
                if allowed.shape != (2,) or not np.isfinite(allowed).all() or np.linalg.norm(allowed-body*scale) > 1e-7:
                    raise ValueError('alignment navigation guard may only reduce lateral velocity')
                horizon = max(dt, .05)
                arm_speed = joint_velocity[0]
                arm_available = ((arm_bounds[robot, 1]-grip_local[robot, 0]) if arm_speed > 0 else
                                 (grip_local[robot, 0]-arm_bounds[robot, 0]))
                if abs(arm_speed) > 1e-10:
                    scale = min(scale, max(0., arm_available)/(abs(arm_speed)*horizon))
                lift_speed = joint_velocity[2]
                lift_available = ((self.LIFT_LIMITS[1]-lift_positions[robot]) if lift_speed > 0 else
                                  (lift_positions[robot]-self.LIFT_LIMITS[0]))
                if abs(lift_speed) > 1e-10:
                    scale = min(scale, max(0., lift_available)/(abs(lift_speed)*horizon))
                if abs(joint_velocity[1]) > 1e-10:
                    side_available = self.MAX_BASE_LATERAL_TRAVEL-self.base_lateral_travel[robot]
                    scale = min(scale, max(0., side_available)/(abs(joint_velocity[1])*horizon))
                endpoint_speed = float(np.linalg.norm(matrix @ joint_velocity))
                if endpoint_speed > 1e-10:
                    remaining_travel = self.MAX_ENDPOINT_TRAVEL-self.endpoint_travel[robot]
                    scale = min(scale, max(0., remaining_travel)/(endpoint_speed*horizon))
                actuator.append(joint_velocity); guards.append(guard); scales.append(scale)
            common_scale = float(np.clip(min(scales), 0., 1.))
            blocked = common_scale < 1e-6
            if blocked:
                common_scale = 0.
            velocities = np.array([self._axes(bases[r], yaw[r]) @ actuator[r] for r in (0, 1)])*common_scale
            predicted = grasps+velocities*max(dt, .05)
            if np.linalg.norm(predicted[1]-predicted[0]) > self.span0+self.MAX_SPAN_INCREASE+1e-6:
                raise ValueError('alignment predicted grasp span exceeds stretch guard')
            self.reference_fraction += advance*common_scale
            action = self._hold()
            for robot, physical in enumerate(actuator):
                action[robot, 4] = physical[0]*common_scale/1.21
                action[robot, 1] = physical[1]*common_scale/.616
                action[robot, 3] = physical[2]*common_scale/1.54
            goal_error = np.linalg.norm(grasps-self.goal, axis=1)
            at_goal = (self.reference_fraction >= 1.-1e-9 and np.max(goal_error) < self.GOAL_TOLERANCE_M)
            if self.length < 1e-12:
                at_goal = np.max(goal_error) < self.GOAL_TOLERANCE_M
            self.stable_seconds = self.stable_seconds+dt if at_goal and not blocked else 0.
            self.done = self.stable_seconds >= .25-1e-9
            self.debug = dict(reference_advance_fraction=advance*common_scale,
                maximum_reference_advance_m=advance*common_scale*self.length,
                measured_progress_m=progress.tolist(), lag_to_reference_m=lag.tolist(),
                pause_reference_for_lag=pause, pair_fraction_difference_m=fraction_spread_m,
                tracking_error_m=tracking_error.tolist(), pair_tracking_error_m=pair_tracking_error,
                measured_grasp_span_m=span, final_grasp_error_m=goal_error.tolist(),
                navigation_paused_pair=blocked, common_constraint_scale=common_scale,
                navigation_guards=guards, command_world_velocities=velocities.tolist(),
                stable_goal_seconds=self.stable_seconds)
            return self._result(action)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError, np.linalg.LinAlgError) as error:
            self.failure = str(error)
            return self._result()
