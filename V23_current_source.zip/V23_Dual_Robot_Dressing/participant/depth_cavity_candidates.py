"""Read-only, current-frame depth cavities near supplied public grasp poses.

A deeper BLUE cloth wall may be the first surface seen through a mouth. This
branch therefore does not require a non-cloth colour hole. It requires a closed,
measured near-cloth/deeper-surface depth boundary instead. A fold or depression
can produce the same evidence: topology, sleeve identity and a usable passage
remain unknown. No gap closing, convex rim hull, simulator state or motion is
used. This standalone kind is intentionally not accepted by the old pipeline.
"""
import cv2
import numpy as np

from camera_geometry import pixel_rays
from human_targets import _validated, _camera_transform, _FOCAL, _CAMERAS
from opening_candidates import _cloth_masks


_CROSS = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], np.uint8)
_RIM_TOL = .003
_MIN_RECESSION = .015
_MAX_VERTICES = 512


def _plane(points):
    if len(points) < 20:
        return None
    centre = points.mean(axis=0)
    _, singular, axes = np.linalg.svd(points-centre, full_matrices=False)
    if singular[1] < .005 or singular[2]/singular[1] > .2:
        return None
    normal = axes[2]
    if normal @ centre > 0:
        normal = -normal
    return centre, normal, axes[0], float(singular[2]/singular[1])


def _plane_hypotheses(points):
    """Bounded deterministic proposals, later refitted to the actual rim only."""
    if len(points) < 24:
        return []
    points = points[::max(1, int(np.ceil(len(points)/768)))]
    proposals = []
    for selected in (points, *np.array_split(points[np.argsort(points[:, 2])], 4)):
        fit = _plane(selected)
        if fit is not None:
            proposals.append(fit[:2])
    # Sampling measured pixels proposes planes, never missing image boundaries.
    rng = np.random.default_rng(271828)
    for _ in range(32):
        triangle = points[rng.choice(len(points), 3, replace=False)]
        normal = np.cross(triangle[1]-triangle[0], triangle[2]-triangle[0])
        length = np.linalg.norm(normal)
        if length > 1e-5:
            proposals.append((triangle[0], normal/length))
    fits = []
    for centre, normal in proposals:
        inliers = points[np.abs((points-centre) @ normal) <= _RIM_TOL]
        fit = _plane(inliers)
        if fit is None:
            continue
        centre, normal, axis, quality = fit
        equivalent = next((i for i, item in enumerate(fits)
                           if abs(normal @ item[1]) > .995
                           and abs((centre-item[0]) @ item[1]) < .004), None)
        proposed = (centre, normal, axis, quality, len(inliers))
        if equivalent is None:
            fits.append(proposed)
        elif (len(inliers), -quality) > (fits[equivalent][4], -fits[equivalent][3]):
            # An early mixed-depth fit must not suppress a later, well-supported
            # true near-rim plane merely because their normals are similar.
            fits[equivalent] = proposed
    return sorted(fits, key=lambda item: (-item[4], item[3]))[:6]


def _ordered_contour(mask):
    contours, hierarchy = cv2.findContours(mask.astype(np.uint8), cv2.RETR_CCOMP,
                                          cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None or len(contours) != 1:
        raise ValueError('interior_has_missing_depth_or_occluding_islands')
    pixels = contours[0].reshape(-1, 2)
    if not 3 <= len(pixels) <= _MAX_VERTICES or len(np.unique(pixels, axis=0)) != len(pixels):
        raise ValueError('unresolved_or_self_touching_interior_contour')
    return pixels


def _summary(values):
    quantiles = np.percentile(values, [0, 5, 25, 50, 75, 95, 100])
    return dict(zip(('min', 'p05', 'p25', 'median', 'p75', 'p95', 'max'),
                    map(float, quantiles)))


def _candidate(values, camera, region, valid, cloth, depth, rays, grasps, now,
               radius, min_recession_m):
    pixels = _ordered_contour(region)
    v, u = np.where(region)
    if len(u) < 16 or len(u) > 12000:
        raise ValueError('unresolved_or_oversized_depth_region')
    if min(u.min(), v.min()) <= 1 or max(u.max(), v.max()) >= 254:
        raise ValueError('image_border_or_open_depth_boundary')
    # Dilation only enumerates the immediately adjacent outside pixels. Every
    # one must already be observed cloth on the rim; no missing edge is filled.
    band = cv2.dilate(region.astype(np.uint8), _CROSS).astype(bool) & ~region
    if not np.all(valid[band]) or not np.all(cloth[band]):
        raise ValueError('rim_has_missing_depth_or_noncloth_occlusion_or_open_edge')
    rv, ru = np.where(band)
    rim_optical = rays[rv, ru]*depth[rv, ru, None]
    fit = _plane(rim_optical)
    if fit is None:
        raise ValueError('rim_nonplanar_collapsed_or_mixed_depth')
    centre, normal, axis, quality = fit
    rim_errors = (rim_optical-centre) @ normal
    if np.max(np.abs(rim_errors)) > _RIM_TOL:
        raise ValueError('rim_has_inconsistent_measured_depth')
    denominator = rays[v, u] @ normal
    if np.any(np.abs(denominator) <= .25):
        raise ValueError('rim_plane_is_nearly_edge_on')
    expected = float(centre @ normal)/denominator
    residual = depth[v, u]-expected
    if np.any(expected <= .03) or np.any(residual < min_recession_m-1e-6):
        raise ValueError('interior_is_shallow_or_foreground_obstructed')
    # A smooth depression's threshold contour has adjacent pixels at nearly
    # the same depth, not on a nearer lip. Requiring the entire adjacent band
    # to agree with one measured near-rim plane rejects that arbitrary contour.
    region_contours, _ = cv2.findContours(region.astype(np.uint8), cv2.RETR_EXTERNAL,
                                         cv2.CHAIN_APPROX_NONE)
    boundary = region_contours[0].reshape(-1, 2)
    pairs = []
    for pu, pv in boundary:
        neighbours = [(pu+du, pv+dv) for du, dv in ((0, -1), (1, 0), (0, 1), (-1, 0))
                      if 0 <= pu+du < 256 and 0 <= pv+dv < 256 and band[pv+dv, pu+du]]
        if not neighbours:
            raise ValueError('depth_boundary_lacks_observed_adjacent_lip')
        nu, nv = neighbours[0]
        predicted = float(centre @ normal)/float(rays[pv, pu] @ normal)
        if depth[pv, pu]-predicted < min_recession_m-1e-6:
            raise ValueError('depth_boundary_lacks_resolved_recession')
        pairs.append((pu, pv, nu, nv))
    # Trace the INNER boundary of that actual one-pixel cloth band. These are
    # measured near-side lip pixels, distinct from the deeper-side aperture.
    contours, hierarchy = cv2.findContours(band.astype(np.uint8), cv2.RETR_CCOMP,
                                          cv2.CHAIN_APPROX_SIMPLE)
    inside = [] if hierarchy is None else [contours[i] for i in range(len(contours))
                                           if hierarchy[0, i, 3] >= 0]
    if len(inside) != 1:
        raise ValueError('measured_lip_does_not_form_one_closed_ordered_contour')
    rim_uv = inside[0].reshape(-1, 2)
    if (not 3 <= len(rim_uv) <= _MAX_VERTICES or len(np.unique(rim_uv, axis=0)) != len(rim_uv)
            or not np.all(band[rim_uv[:, 1], rim_uv[:, 0]])):
        raise ValueError('measured_lip_contour_is_complex_or_self_touching')
    rim_z = depth[rim_uv[:, 1], rim_uv[:, 0]]
    rim_points = rays[rim_uv[:, 1], rim_uv[:, 0]]*rim_z[:, None]
    rotation, origin = _camera_transform(values, camera)
    world_normal = rotation @ normal
    plane_origin = rotation @ centre+origin
    basis = np.stack((rotation @ axis, np.cross(world_normal, rotation @ axis)))
    boundary_rays = rays[pixels[:, 1], pixels[:, 0]]
    boundary_z = float(centre @ normal)/(boundary_rays @ normal)
    aperture_world = (boundary_rays*boundary_z[:, None]) @ rotation.T+origin
    polygon = (aperture_world-plane_origin) @ basis.T
    if abs(cv2.contourArea(polygon.astype(np.float32))) < 1e-5:
        raise ValueError('projected_inner_region_has_no_resolved_area')
    moments = cv2.moments(region.astype(np.uint8))
    uv_centre = np.array([moments['m10']/moments['m00'], moments['m01']/moments['m00']])
    centre_ray = pixel_rays(*uv_centre, _FOCAL)
    candidate_centre = rotation @ (centre_ray*float(centre @ normal)/float(centre_ray @ normal))+origin
    rim_world = rim_points @ rotation.T+origin
    distances = np.linalg.norm(grasps-candidate_centre, axis=1)
    nearest_rim = np.linalg.norm(grasps[:, None]-rim_world[None], axis=2).min(1)
    eligible = np.flatnonzero((distances <= radius+.04) & (nearest_rim <= radius))
    if not len(eligible):
        raise ValueError('candidate_not_near_supplied_grasps')
    first_surface = rays[v, u]*depth[v, u, None]
    # A first-return depth provides an observed surface location, not a full
    # hand-sized corridor. In particular, inner cloth can obstruct any advance.
    along_ray = residual*np.linalg.norm(rays[v, u], axis=1)
    normal_recession = -(first_surface-centre) @ normal
    sample = np.arange(0, len(u), max(1, int(np.ceil(len(u)/256))))
    pair_sample = np.asarray(pairs)[::max(1, int(np.ceil(len(pairs)/256)))]
    return dict(kind='unclassified_depth_cavity', observation_time_s=now,
        source_camera=_CAMERAS[camera][0], camera_index=camera,
        candidate_identity_scope='same current frame/camera/source pixels only',
        proposal_basis='closed measured near-cloth lip around a deeper observed surface of any colour',
        eligible_grasp_indices=eligible.tolist(), distance_from_grasps_m=distances.tolist(),
        distance_from_measured_rim_m=nearest_rim.tolist(),
        centroid_world=candidate_centre.tolist(), pixel_centroid=uv_centre.tolist(),
        centroid_inside_projected_region=bool(cv2.pointPolygonTest(
            pixels.astype(np.float32), tuple(map(float, uv_centre)), False) > 0),
        centroid_scope='area centroid can lie outside a concave region; not an insertion target',
        fitted_rim_plane=dict(origin_world=plane_origin.tolist(), normal_world=world_normal.tolist(),
            basis_world=basis.tolist(), normal_convention='towards observing camera; not entry direction',
            planarity_ratio=quality, maximum_measured_residual_m=float(np.abs(rim_errors).max()),
            measured_rim_pixel_count=int(band.sum())),
        ordered_inner_lip=dict(source_pixels_uv=rim_uv.tolist(), measured_depth_z_m=rim_z.tolist(),
            measured_points_world=rim_world.tolist(), closed_observed=True,
            basis='ordered inner boundary of fully observed adjacent near-cloth pixels; no gap filling'),
        projected_aperture=dict(available=True, observation_time_s=now, camera_index=camera,
            contour_pixels_uv=pixels.tolist(), contour_world_on_plane=aperture_world.tolist(),
            polygon_plane_xy_m=polygon.tolist(), plane_origin_world=plane_origin.tolist(),
            plane_basis_world=basis.tolist(),
            basis='deeper-side observed pixel centres projected to measured rim plane; retains concavity',
            physical_inner_edge_measured=False, hand_footprint_compared=False),
        depth_evidence=dict(interior_pixel_count=int(len(u)), interior_valid_fraction=1.,
            adjacent_rim_valid_fraction=1., adjacent_rim_cloth_fraction=1.,
            minimum_required_recession_z_m=float(min_recession_m),
            optical_z_recession_m=_summary(residual),
            first_surface_distance_behind_plane_along_camera_ray_m=_summary(along_ray),
            first_surface_plane_normal_recession_m=_summary(normal_recession),
            first_surface_depth_z_m=_summary(depth[v, u]),
            deeper_cloth_fraction=float(cloth[v, u].mean()),
            sampled_source_pixels_uv=np.column_stack((u[sample], v[sample])).tolist(),
            sampled_first_surface_depth_z_m=depth[v[sample], u[sample]].tolist(),
            ordered_depth_edge_pairs_inner_uv_then_lip_uv=pair_sample.tolist(),
            missing_depth_pixels=0, foreground_obstruction_pixels=0,
            obstruction_scope='current accepted interior and immediately adjacent rim pixels only',
            first_surface_semantics='measured visible return, potentially cloth or another obstruction; not background identity',
            free_advance_verified=False, permitted_advance_m=None,
            free_advance_reason='first visible surface recession is not an unobstructed hand-sized trajectory'),
        physical_opening_verified=False, sleeve_identity_verified=False,
        garment_topology_known=False, attachment_verified=False, insertion_allowed=False,
        motion_authorized=False, fold_or_depression_excluded=False,
        read_only=True)


def detect_depth_cavity_candidates(obs, grasp_points_world, *, radius_m=.18,
                                   min_recession_m=_MIN_RECESSION):
    """Propose unclassified depth cavities; no action or legacy integration.

    Supplied world grasps select local observations only. All plane/rim/interior
    geometry is reconstructed from current public camera pixels and own poses.
    A 15 mm resolved recession is a detector floor, NOT permitted insertion
    travel. Unlike the old 40 mm median background test, every accepted region
    pixel has an actual nearer closed lip and a farther first surface; the first
    surface may itself be cloth. Partly visible rims are deliberately unknown.
    """
    grasps = np.asarray(grasp_points_world, dtype=float)
    if grasps.shape != (2, 3) or not np.isfinite(grasps).all():
        raise ValueError('expected two finite supplied public world grasp positions')
    if (not np.isfinite([radius_m, min_recession_m]).all()
            or not .06 <= radius_m <= .30 or not .01 <= min_recession_m <= .05):
        raise ValueError('invalid bounded local radius or depth recession floor')
    values = _validated(obs, wrists=True)
    now = float(np.asarray(obs['simulation_time_s']).item())
    if not np.isfinite(now) or now < 0:
        raise ValueError('finite nonnegative current public observation timestamp required')
    rows, cols = np.indices((256, 256))
    rays = pixel_rays(cols, rows, _FOCAL)
    rejected, diagnostics, candidates = {}, [], []

    def reject(reason):
        rejected[reason] = rejected.get(reason, 0)+1

    for camera in (1, 2, 3, 4):
        depth = np.asarray(values['depth'][camera, ..., 0], dtype=float)
        valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth)
                 & (depth > .03) & (depth < (3. if camera < 3 else 5.)))
        cloth, _ = _cloth_masks(values['rgb'][camera])
        rotation, origin = _camera_transform(values, camera)
        optical_grasps = (grasps-origin) @ rotation
        v, u = np.where(cloth & valid)
        points = rays[v, u]*depth[v, u, None]
        nearby = np.min(np.linalg.norm(points[:, None]-optical_grasps[None], axis=2), axis=1) <= radius_m
        hypotheses = _plane_hypotheses(points[nearby])
        details = dict(camera_index=camera, nearby_valid_cloth_pixels=int(nearby.sum()),
                       plane_hypotheses=len(hypotheses), depth_regions_examined=0,
                       accepted_candidates=0)
        accepted_regions = []
        for centre, normal, _, _, _ in hypotheses:
            denominator = rays @ normal
            usable = np.abs(denominator) > .25
            expected = np.divide(float(centre @ normal), denominator,
                                 out=np.zeros_like(depth), where=usable)
            plane_points = rays*expected[..., None]
            # A grasp can lie on one rim edge. Allow observing the opposite
            # edge of a nearby cavity, while _candidate still gates its centre
            # and nearest measured rim against the supplied grasp positions.
            local = np.min(np.linalg.norm(plane_points[..., None, :]-optical_grasps, axis=3), axis=2) <= 2*radius_m
            local &= usable & (expected > .03) & (expected < (3. if camera < 3 else 5.))
            deeper = local & valid & (depth-expected >= min_recession_m)
            count, labels, stats, _ = cv2.connectedComponentsWithStats(deeper.astype(np.uint8), connectivity=4)
            # Bound work even for a noisy depth map; this is not exhaustive.
            regions = sorted(range(1, count), key=lambda i: -int(stats[i, cv2.CC_STAT_AREA]))[:12]
            for label in regions:
                if stats[label, cv2.CC_STAT_AREA] < 16:
                    continue
                region = labels == label
                details['depth_regions_examined'] += 1
                if np.any(cv2.dilate(region.astype(np.uint8), _CROSS).astype(bool) & ~local):
                    reject('region_reaches_local_window_or_unresolved_plane'); continue
                if any(np.count_nonzero(region & previous)/max(1, np.count_nonzero(region | previous)) > .8
                       for previous in accepted_regions):
                    continue
                try:
                    candidate = _candidate(values, camera, region, valid, cloth, depth,
                                           rays, grasps, now, radius_m, min_recession_m)
                except ValueError as error:
                    reject(str(error)); continue
                candidates.append(candidate); accepted_regions.append(region)
                details['accepted_candidates'] += 1
                if len(accepted_regions) >= 3:
                    break
            if len(accepted_regions) >= 3:
                break
        diagnostics.append(details)
    return dict(depth_cavity_candidates=candidates, detected=bool(candidates),
        status='unclassified_observed_depth_cavities' if candidates else 'unknown',
        observation_time_s=now, cameras_used=[1, 2, 3, 4], rejected_candidate_counts=rejected,
        diagnostics=diagnostics, radius_m=float(radius_m), local_window_radius_m=float(2*radius_m),
        minimum_recession_z_m=float(min_recession_m),
        read_only=True, integrated_with_opening_pipeline=False, motion_authorized=False,
        physical_openings_verified=False, sleeve_identity_verified=False,
        cross_view_identity_matched=False, insertion_allowed=False,
        limitations=('Blue/yellow near-rim appearance is a scene assumption. A closed depth discontinuity '
                     'can be a fold, depression or occluding cloth layer. '
                     'No missing rim is completed, no physical cuff topology or clear path is inferred. '
                     'Finite depth is first-surface evidence only; camera rays are not a hand corridor. '
                     'Local plane hypotheses and candidate counts are bounded, not exhaustive.'))
