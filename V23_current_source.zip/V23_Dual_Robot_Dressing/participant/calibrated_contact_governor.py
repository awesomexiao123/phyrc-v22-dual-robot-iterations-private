"""Calibrated control wrapper; no near-human clearance is provided here.

Frozen empirical bias is removed only in a derived control representation.
Actual native arm-stage targets remain unobserved. Public raw poses, targets,
velocities and both raw/excess pending motions are retained for future geometry.
"""
from copy import deepcopy

import numpy as np

from contact_motion_governor import ContactMotionGovernor
from equilibrium_wrist_experiments import _CalibratedWrist, _raw_velocity_anomaly_evidence


class _EffectiveCore(ContactMotionGovernor):
    """Original rate/cancellation engine with stricter, explicit residual gates.

Its internal arm equal-share residual is a DERIVED consistency coordinate,
never an observation of the native per-stage drive targets.
"""
    def _read(self, obs):
        s = super()._read(obs)
        s['calibrated'] = obs['_calibrated_control_evidence']
        s['pending'] = s['calibrated']['conservative_pending_m']
        return s

    def _validate(self, s, speed, *, handoff=False):
        super()._validate(s, speed, handoff=handoff)
        if np.max(np.abs(s['wrist_lag'])+s['calibrated']['bias_deviation'][:, 2:5]) > np.deg2rad(.02):
            raise ValueError('effective_fixed_wrist_lag_and_sampled_deviation')

    def _is_rest(self, s):
        c = s['calibrated']
        return bool(super()._is_rest(s) and c['position_window_stable']
            and np.max(c['linear_rest_bound_m']) <= self.SETTLED_LAG
            and np.max(np.abs(s['wrist_lag'])+c['bias_deviation'][:, 2:5]) <= np.deg2rad(.005))


class CalibratedContactGovernor:
    """Same step interface as ContactMotionGovernor, with frozen calibration.

One instance must span all motion bouts. Callers own geometry, cumulative task
path limits and simulation termination on unresolved failure. This module is
does not authorize contact; a caller must separately check raw own geometry
and current observed skin. Physical validation remains a separate run result.
"""
    BIAS_LIMITS = np.array([.003, .003, *([np.deg2rad(.3)]*3)])

    def __init__(self, raw_obs, *, calibration):
        self.calibration = deepcopy(calibration)
        self.core = None; self.failure = None; self.last_result = None
        self.pending_failure = None; self.first_raw_velocity_anomaly = None
        self.debug = {}; self.motion_evidence = {}; self.history = []
        self.previous = None; self.expected_targets = None; self.processed_time = None
        self.endpoint_path = np.zeros(2); self.cancel_path = np.zeros(2)
        self.time0 = None; self.last_was_cancellation = False
        try:
            self._validate_calibration()
            s = ContactMotionGovernor._read(raw_obs)
            c = self.calibration; dt = s['time']-float(c['observed_at_s'])
            if not -1e-8 <= dt <= .075:
                raise ValueError('fresh_calibration_end_frame_within_75ms_required')
            if np.max(np.abs(s['target']-c['controller_target_reference'])) > 1e-6:
                raise ValueError('raw_targets_changed_since_calibration')
            if np.max(np.abs(s['target'][:, 6:9])) > 1e-5:
                raise ValueError('zero_base_targets_required_at_calibrated_entry')
            if dt <= 1e-8:
                if (np.max(np.abs(s['q']-c['last_joint_position'])) > 1e-8
                        or np.max(np.abs(s['base']-c['last_base_pose'])) > 1e-8):
                    raise ValueError('same_calibration_time_has_different_actual_state')
                fd = np.zeros_like(s['q'])
            else:
                fd = (s['q']-c['last_joint_position'])/dt
            self._raw_limits(s, s['target'])
            self._raw_velocity_guard(s, .01, handoff=True)
            self.time0 = s['time']; self.origin_grasps = s['grasps'].copy(); self.origin_base = s['base'].copy()
            self.previous = deepcopy(s)
            _CalibratedWrist._append_history(self, s['time'], s['q'], s['base'], s['grasps'])
            derived, evidence = self._derive(raw_obs, s, fd, False)
            self.core = _EffectiveCore(derived)
            if self.core.failure:
                raise ValueError(self.core.failure)
            self.last_result = self.core._result()
            self._motion_evidence(s, evidence, fd, np.zeros(2), self._hold(), s['target'])
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = str(error)
            self._invalidate_evidence(raw_obs)

    @staticmethod
    def _hold():
        return ContactMotionGovernor._hold()

    def _invalidate_evidence(self, raw_obs, *, unresolved=True):
        # Keep the last valid frame's timestamp intact; never relabel old
        # geometry as evidence from a failed/new observation.
        previous_time = (self.motion_evidence.get('observation_time_s')
                         or self.motion_evidence.get('last_valid_observation_time_s'))
        try:
            current_time = float(np.asarray(raw_obs['simulation_time_s']).reshape(-1)[0])
            if not np.isfinite(current_time): current_time = None
        except (KeyError, TypeError, ValueError, IndexError):
            current_time = None
        self.motion_evidence = dict(valid=False, observation_time_s=None,
            failed_observation_time_s=current_time, last_valid_observation_time_s=previous_time,
            reason=self.failure, geometry_checked=False, near_human_contact_authorized=False)
        if unresolved is not None:
            self.debug['unresolved_target_lag'] = unresolved

    def _validate_calibration(self):
        c = self.calibration
        shapes = {'controller_bias': (2, 5), 'controller_bias_peak_deviation': (2, 5),
            'arm_position_offsets': (2, 4), 'arm_position_offsets_peak_deviation': (2, 4),
            'raw_joint_velocity_median': (2, 13), 'raw_joint_velocity_peak_deviation': (2, 13),
            'last_joint_position': (2, 13), 'last_base_pose': (2, 7), 'controller_target_reference': (2, 9)}
        for name, shape in shapes.items():
            value = np.asarray(c[name], float).copy()
            if value.shape != shape or not np.isfinite(value).all():
                raise ValueError('invalid_calibration_'+name)
            if 'peak_deviation' in name and np.any(value < 0):
                raise ValueError('negative_calibration_'+name)
            value.setflags(write=False); c[name] = value
        stamps = np.array([c['observed_at_s'], c['window_start_s']], float)
        if (not np.isfinite(stamps).all() or stamps[0]-stamps[1] < .5-1e-7
                or int(c['frame_count']) < 11 or not isinstance(c['method'], str) or not c['method']):
            raise ValueError('completed_half_second_calibration_required')
        if (np.any(np.abs(c['controller_bias']) > self.BIAS_LIMITS+1e-10)
                or np.max(np.abs(c['arm_position_offsets'].sum(1))) > 1e-9):
            raise ValueError('calibration_bias_or_zero_sum_shape_bound')

    @staticmethod
    def _raw_limits(s, targets):
        q = s['q']; g = ContactMotionGovernor
        if (np.any(q[:, 3] < g.LIFT_LIMITS[0]) or np.any(q[:, 3] > g.LIFT_LIMITS[1])
                or np.any(targets[:, 0] < g.LIFT_LIMITS[0]) or np.any(targets[:, 0] > g.LIFT_LIMITS[1])
                or np.any(q[:, 4:8] < -1e-6) or np.any(q[:, 4:8] > .130001)
                or np.any(q[:, 4:8].sum(1) < g.ARM_LIMITS[0]) or np.any(q[:, 4:8].sum(1) > g.ARM_LIMITS[1])
                or np.any(targets[:, 1] < g.ARM_LIMITS[0]) or np.any(targets[:, 1] > g.ARM_LIMITS[1])
                or np.any(q[:, 8:11] < g.WRIST_LIMITS[:, 0]-1e-5)
                or np.any(q[:, 8:11] > g.WRIST_LIMITS[:, 1]+1e-5)
                or np.any(targets[:, 2:5] < g.WRIST_LIMITS[:, 0]-1e-5)
                or np.any(targets[:, 2:5] > g.WRIST_LIMITS[:, 1]+1e-5)
                or np.any(q[:, 11:13] < -.001) or np.any(q[:, 11:13] > .18)
                or np.any(targets[:, 5] < -.001) or np.any(targets[:, 5] > .18)):
            raise ValueError('actual_joint_or_raw_target_outside_original_limits')

    def _raw_velocity_guard(self, s, speed, *, handoff):
        maximum = .04 if handoff else 2*speed+.0002
        allowance = np.array([maximum, *([maximum/4+.0002]*4), *([np.deg2rad(.1)]*3)])
        deviation = np.abs(s['qd'][:, 3:11]-self.calibration['raw_joint_velocity_median'][:, 3:11])
        envelope = self.calibration['raw_joint_velocity_peak_deviation'][:, 3:11]+allowance
        self.debug.update(raw_velocity_departure=deviation.tolist(), raw_velocity_departure_limit=envelope.tolist())
        if np.any(deviation > envelope+1e-10):
            if self.first_raw_velocity_anomaly is None:
                self.first_raw_velocity_anomaly = _raw_velocity_anomaly_evidence(
                    self.calibration, s['qd'], deviation, envelope, allowance,
                    now=s['time'], q=s['q'], targets=s['target'], bases=s['base'], grasps=s['grasps'],
                    phase=self.core.mode if self.core is not None else 'constructor')
            self.pending_failure = self.pending_failure or 'new_raw_joint_velocity_anomaly'
            raise ValueError(self.pending_failure)

    def _derive(self, obs, s, fd, stable):
        c = self.calibration; q = s['q']; t = s['target']
        total = q[:, 4:8].sum(1)
        e = np.column_stack((t[:, 0]-q[:, 3], t[:, 1]-total))-c['controller_bias'][:, :2]
        d = q[:, 4:8]-total[:, None]/4-c['arm_position_offsets']
        beta = c['controller_bias_peak_deviation']; gamma = c['arm_position_offsets_peak_deviation']
        rest = np.column_stack((np.abs(e[:, 0])+beta[:, 0],
            np.abs(e[:, 1])+beta[:, 1]+(np.abs(d)+gamma).sum(1)))
        evidence = dict(excess=e, shape_change=d, bias_deviation=beta, shape_deviation=gamma,
            conservative_pending_m=rest.sum(1), linear_rest_bound_m=rest, position_window_stable=bool(stable))
        effective = t.copy(); effective[:, :5] -= c['controller_bias']
        represented_q = q.copy(); represented_q[:, 4:8] -= c['arm_position_offsets']
        derived = dict(obs, joint_position=represented_q, joint_velocity=fd.copy(), controller_target=effective,
                       _calibrated_control_evidence=evidence)
        return derived, evidence

    @staticmethod
    def _proposal_scale(proposal, c):
        rates = proposal[:, ContactMotionGovernor.COLUMNS]*ContactMotionGovernor.SCALES
        alpha = 1.
        for robot in (0, 1):
            caps = [ContactMotionGovernor.TARGET_LEAD-c['bias_deviation'][robot, 0],
                ContactMotionGovernor.TARGET_LEAD-c['bias_deviation'][robot, 1]
                -4*np.max(np.abs(c['shape_change'][robot])+c['shape_deviation'][robot])]
            for axis, cap in enumerate(caps):
                if cap < 0:
                    return 0.
                alpha = min(alpha, ContactMotionGovernor._line_scale(
                    np.array([c['excess'][robot, axis]]), np.array([rates[robot, axis+2]*.05]), cap))
        return alpha

    def _motion_evidence(self, s, c, fd, measured_speed, action, predicted):
        r = s['rotations']; raw = s['lag']; extra = c['excess']
        raw_pending = r[:, :, 2]*raw[:, :1]+r[:, :, 0]*raw[:, 1:2]
        excess_pending = r[:, :, 2]*extra[:, :1]+r[:, :, 0]*extra[:, 1:2]
        reserve = .05*np.maximum(s['endpoint_speed'], measured_speed)
        world_base = np.einsum('nij,nj->ni', s['planar'], action[:, :2]*.616)
        move = .05*(np.pad(world_base, ((0, 0), (0, 1)))
                    +r[:, :, 2]*(action[:, 3:4]*1.54)+r[:, :, 0]*(action[:, 4:5]*1.21))
        self.motion_evidence = dict(valid=True, observation_time_s=s['time'], calibration_observed_at_s=self.calibration['observed_at_s'],
            raw_joint_position=s['q'].tolist(), raw_joint_velocity=s['qd'].tolist(),
            raw_controller_target=s['target'].tolist(), predicted_next_raw_controller_target=predicted.tolist(),
            frozen_controller_bias=self.calibration['controller_bias'].tolist(),
            excess_aggregate_target_lead_m=extra.tolist(), arm_shape_change_m=c['shape_change'].tolist(),
            sampled_bias_peak_deviation=self.calibration['controller_bias_peak_deviation'].tolist(),
            sampled_shape_peak_deviation=self.calibration['arm_position_offsets_peak_deviation'].tolist(),
            conservative_pending_m=c['conservative_pending_m'].tolist(),
            raw_pending_translation_world=raw_pending.tolist(), excess_pending_translation_world=excess_pending.tolist(),
            raw_wrist_target_lag_rad=s['wrist_lag'].tolist(),
            excess_wrist_target_lag_rad=(s['wrist_lag']-self.calibration['controller_bias'][:, 2:5]).tolist(),
            raw_base_twist_world=s['twist'].tolist(), position_difference_joint_velocity=fd.tolist(),
            measured_grasp_difference_speed_m_s=measured_speed.tolist(),
            conservative_geometry_rate_reserve_m=reserve.tolist(), proposed_interval_translation_world=move.tolist(),
            raw_pending_plus_proposed_world=(raw_pending+move).tolist(),
            excess_pending_plus_proposed_world=(excess_pending+move).tolist(),
            cumulative_actual_endpoint_path_m=self.endpoint_path.tolist(),
            cumulative_actual_cancellation_path_m=self.cancel_path.tolist(),
            displacement_from_initial_grasp_world=(s['grasps']-self.origin_grasps).tolist(),
            actual_position_window_stable=bool(c['position_window_stable']),
            native_arm_stage_targets_observed=False, geometry_checked=False, angular_sweep_bounded=False,
            near_human_contact_authorized=False, physical_stopping_certified=False)

    def _result(self, *, repeat=False):
        r = deepcopy(self.last_result) if self.last_result is not None else dict(action=self._hold(), failure=None,
            pending_failure=None, cancellation_only=False, settled=False, debug={})
        if self.failure:
            r.update(action=self._hold(), failure=self.failure, settled=False, cancellation_only=False)
            r['debug'].setdefault('unresolved_target_lag', True)
            r['debug']['common_scale'] = r['debug']['common_command_scale'] = 0.
        if repeat:
            r['action'] = self._hold(); r['debug']['common_scale'] = r['debug']['common_command_scale'] = 0.
        r['pending_failure'] = self.pending_failure or r.get('pending_failure')
        # Relabel the reused kernel's private virtual-coordinate diagnostics.
        for old, new in [('individual_arm_target_lag_m', 'derived_equal_share_shape_residual_m'),
                         ('integrated_linear_target_lag_m', 'excess_aggregate_target_lead_m'),
                         ('outgoing_linear_target_lag_m', 'predicted_excess_aggregate_lead_m')]:
            if old in r['debug']:
                r['debug'][new] = r['debug'].pop(old)
        r['debug'].update(self.debug, derived_control_representation=True, native_arm_stage_targets_observed=False,
            original_observation_modified=False, calibration_refreshed=False, far_field_simulation_validation_only=True,
            geometry_checked=False, near_human_contact_authorized=False, repeated_frame_no_action=repeat,
            motion_evidence_valid=bool(self.motion_evidence.get('valid', False)),
            pending_bound_scope='Empirical excess aggregate lead plus shape consistency and sampled deviations; native arm-stage targets are unknown. Not a physical braking bound.')
        r['debug']['pending_failure'] = r['pending_failure']
        if self.first_raw_velocity_anomaly is not None:
            r['debug']['first_raw_velocity_anomaly'] = deepcopy(self.first_raw_velocity_anomaly)
        r['motion_evidence'] = deepcopy(self.motion_evidence)
        if repeat and r['motion_evidence'].get('valid'):
            e = r['motion_evidence']
            e['proposed_interval_translation_world'] = np.zeros((2, 3)).tolist()
            e['predicted_next_raw_controller_target'] = deepcopy(e['raw_controller_target'])
            e['raw_pending_plus_proposed_world'] = deepcopy(e['raw_pending_translation_world'])
            e['excess_pending_plus_proposed_world'] = deepcopy(e['excess_pending_translation_world'])
            e['repeated_frame_no_action'] = True
        return r

    def step(self, raw_obs, proposed_action, *, halt=False, max_speed_mps=.01):
        if self.failure:
            self._invalidate_evidence(raw_obs, unresolved=None)
            return self._result()
        try:
            speed = float(max_speed_mps)
            if not np.isfinite(speed) or not 0 < speed <= .01:
                raise ValueError('speed_must_be_positive_and_at_most_0_01')
            s = ContactMotionGovernor._read(raw_obs); dt = s['time']-self.previous['time']
            if dt < -1e-8 or dt > .075:
                raise ValueError('unresolved_public_action_clock_gap')
            if dt <= 1e-9:
                if any(np.max(np.abs(s[key]-self.previous[key])) > 1e-8 for key in ('q', 'qd', 'target', 'base', 'grasps', 'twist')):
                    raise ValueError('same_timestamp_has_changed_public_state')
                if self.processed_time is not None:
                    return self._result(repeat=True)
                fd = np.zeros_like(s['q']); measured_speed = np.zeros(2)
            else:
                if self.expected_targets is not None and np.max(np.abs(s['target'][:, :5]-self.expected_targets[:, :5])) > 1e-5:
                    raise ValueError('native_targets_disagree_with_previous_raw_prediction')
                fd = (s['q']-self.previous['q'])/dt
                distance = np.linalg.norm(s['grasps']-self.previous['grasps'], axis=1)
                measured_speed = distance/dt; self.endpoint_path += distance
                if self.last_was_cancellation:
                    self.cancel_path += distance
            self._raw_limits(s, s['target'])
            self._raw_velocity_guard(s, speed, handoff=self.core.mode == 'handoff')
            _CalibratedWrist._append_history(self, s['time'], s['q'], s['base'], s['grasps'])
            stable = _CalibratedWrist._position_window_stable(self)
            derived, evidence = self._derive(raw_obs, s, fd, stable)
            proposal = np.asarray(proposed_action, float); scale = 1.
            valid = (proposal.shape == (2, 9) and np.isfinite(proposal).all()
                and np.max(np.abs(proposal)) <= 1. and np.max(np.abs(proposal[:, [2, 5, 6, 7]])) <= 1e-12
                and np.all(proposal[:, 8] >= 0.))
            if valid and not halt:
                scale = self._proposal_scale(proposal, evidence)
                proposal = proposal.copy(); proposal[:, ContactMotionGovernor.COLUMNS] *= scale
            result = self.core.step(derived, proposal, halt=halt, max_speed_mps=speed)
            result['debug']['common_scale'] = result['debug']['common_command_scale'] = (
                result['debug'].get('common_command_scale', 0.)*scale)
            self.debug['conservative_shape_proposal_scale'] = scale
            action = np.asarray(result['action'], float)
            predicted = s['target'].copy(); predicted[:, :2] += action[:, 3:5]*np.array([1.54, 1.21])*.05
            self._raw_limits(s, predicted)
            self._motion_evidence(s, evidence, fd, measured_speed, action, predicted)
            self.expected_targets = predicted.copy(); self.previous = deepcopy(s); self.processed_time = s['time']
            self.last_was_cancellation = bool(result['cancellation_only'])
            self.last_result = result
            self.pending_failure = self.pending_failure or result.get('pending_failure')
            if result['failure']:
                self.failure = self.pending_failure or result['failure']
            return self._result()
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
            self.failure = self.pending_failure or str(error)
            self.debug['terminal_guard_failure'] = str(error)
            self._invalidate_evidence(raw_obs)
            return self._result()
