"""Measured formation-preserving local straight transport, not path planning.

Planar translation uses bases only; height uses the two lifts. Arms, yaw and
wrist commands remain zero. Public depth guards can stop this local segment;
they do not certify free space, protect extended arms, or solve dressing.
"""
import numpy as np

from public_vision import _rotation, grasp_world
from navigation import guard_base_velocity


def _bounded(vector, limit):
    vector = np.asarray(vector, dtype=float)
    return vector * min(1., limit / max(float(np.linalg.norm(vector)), 1e-12))


def _snapshot(obs):
    base = np.asarray(obs['base_pose_world'], dtype=float)
    grasp = np.asarray(obs['grasp_pose_base'], dtype=float)
    if base.shape != (2, 7) or grasp.shape != (2, 7) or not np.isfinite(base).all() or not np.isfinite(grasp).all():
        raise ValueError('invalid public robot poses')
    rotations = np.array([_rotation(p[3:]) for p in base])
    world_grasps = np.stack([grasp_world(obs, r) for r in (0, 1)])
    yaw = np.arctan2(rotations[:, 1, 0], rotations[:, 0, 0])
    tilt = np.arccos(np.clip(rotations[:, 2, 2], -1., 1.))
    clock = float(np.asarray(obs['simulation_time_s']).item())
    if not np.isfinite(clock):
        raise ValueError('invalid public simulation clock')
    return base, world_grasps, yaw, tilt, clock


class RigidPairTransport:
    """A bounded straight segment preserving the initial two-grasp difference.

    step returns a dictionary with action, done, failure and debug. max_speed is
    physical resultant translation speed in m/s, capped at 0.035. The reference
    advances at most 1.75 mm per call and only with increasing simulation time.
    Closed-gripper checks are enabled unless require_closed=False explicitly.
    """

    def __init__(self, observation, desired_shift_world, max_speed=.035, *, require_closed=True):
        shift = np.asarray(desired_shift_world, dtype=float)
        if shift.shape != (3,) or not np.isfinite(shift).all():
            raise ValueError('desired shift must be a finite world XYZ vector')
        if not np.isfinite(max_speed) or not 0 < max_speed <= .035:
            raise ValueError('max_speed must be positive and at most 0.035 m/s')
        self.base0, self.grasp0, self.yaw0, _, self.time0 = _snapshot(observation)
        self.base0 = self.base0.copy(); self.grasp0 = self.grasp0.copy()
        self.shift = shift.copy(); self.length = float(np.linalg.norm(shift))
        self.direction = shift / self.length if self.length > 1e-12 else np.zeros(3)
        self.max_speed = float(max_speed); self.require_closed = bool(require_closed)
        self.reference = 0.; self.last_time = self.time0
        self.best_measured_progress = 0.; self.last_progress_time = self.time0
        self.goal_stable_seconds = 0.; self.failure = None; self.done = False
        self.calls = 0; self.debug = {}

    def _result(self, action=None):
        if action is None or self.failure or self.done:
            action = np.zeros((2, 9), np.float32)
        return dict(action=np.asarray(action, dtype=np.float32), done=bool(self.done),
                    failure=self.failure, debug=dict(self.debug))

    def step(self, obs):
        if self.failure or self.done:
            return self._result()
        self.calls += 1
        action = np.zeros((2, 9), np.float32)
        try:
            bases, grasps, yaw, tilt, now = _snapshot(obs)
            dt = now - self.last_time
            if dt < -1e-8:
                raise ValueError('transport public clock moved backwards')
            dt = max(0., min(dt, .05))
            self.last_time = now
            if self.require_closed:
                closed = np.asarray(obs['gripper_close_command']).reshape(2).astype(bool)
                if not closed.all():
                    raise ValueError('transport gripper opened')
            if np.max(tilt) > .065:
                raise ValueError('transport base tilt')
            if np.linalg.norm(bases[0, :2] - bases[1, :2]) < .60:
                raise ValueError('transport bases too close')
            yaw_change = (yaw - self.yaw0 + np.pi) % (2*np.pi) - np.pi
            if np.max(np.abs(yaw_change)) > .04:
                raise ValueError('transport uncommanded yaw drift')
            relative_error = float(np.linalg.norm((grasps[1]-grasps[0]) - (self.grasp0[1]-self.grasp0[0])))
            if relative_error > .04:
                raise ValueError('transport relative grasp difference changed over 4cm')
            measured = np.column_stack((bases[:, :2]-self.base0[:, :2], grasps[:, 2]-self.grasp0[:, 2]))
            progress = measured @ self.direction
            reference_shift = self.reference * self.direction
            tracking_error = np.linalg.norm(measured-reference_shift, axis=1)
            grasp_error = np.linalg.norm(grasps-(self.grasp0+reference_shift), axis=1)
            if max(float(tracking_error.max()), float(grasp_error.max())) > .05:
                raise ValueError('transport tracking error exceeds 5cm')
            measured_min = float(progress.min())
            if measured_min > self.best_measured_progress + .002:
                self.best_measured_progress = measured_min; self.last_progress_time = now
            if now - self.last_progress_time > 15 and not self.length < .003:
                raise ValueError('transport made no measured pair progress for 15s')
            if now-self.time0 > max(25., 3*self.length/self.max_speed + 15.):
                raise ValueError('transport segment timed out')
            lag = self.reference - progress
            pair_lag = float(progress.max()-progress.min())
            pause_for_lag = bool(np.max(lag) > .015 or pair_lag > .015)
            advance = 0. if pause_for_lag else min(self.max_speed*dt, .00175, self.length-self.reference)
            advance = max(0., advance)
            tentative_reference = self.reference + advance
            requested_shift = tentative_reference*self.direction
            feedforward = self.direction*(advance/dt) if dt > 1e-10 else np.zeros(3)
            velocities, guards, guard_scales = [], [], []
            for robot in (0, 1):
                error = requested_shift - measured[robot]
                velocity = _bounded(feedforward + 2.*error, self.max_speed)
                c, s = np.cos(yaw[robot]), np.sin(yaw[robot])
                world_to_body = np.array([[c, s], [-s, c]])
                body = world_to_body @ velocity[:2]
                guard = guard_base_velocity(obs, robot, body, max_speed=self.max_speed)
                allowed = np.asarray(guard['body_velocity_xy'], dtype=float)
                if allowed.shape != (2,) or not np.isfinite(allowed).all():
                    raise ValueError('invalid transport navigation guard result')
                requested_norm = float(np.linalg.norm(body))
                scale = float(np.clip(np.linalg.norm(allowed)/requested_norm, 0, 1)) if requested_norm > 1e-9 else 1.
                if requested_norm > 1e-9 and np.linalg.norm(allowed-body*scale) > 1e-6:
                    raise ValueError('transport guard must only reduce requested velocity')
                velocities.append((velocity, body)); guards.append(guard); guard_scales.append(scale)
            common_scale = min(guard_scales)
            # One stopped base stops the whole pair, including height motion.
            blocked = common_scale < 1e-6
            if blocked:
                common_scale = 0.
            self.reference += advance*common_scale
            for robot, (velocity, body) in enumerate(velocities):
                action[robot, :2] = body*common_scale/.616
                action[robot, 3] = velocity[2]*common_scale/1.54
                action[robot, 8] = 1. if self.require_closed else 0.
            # No arm, base yaw or wrist commands are emitted by this module.
            if not np.isfinite(action).all() or np.max(np.abs(action)) > 1:
                raise ValueError('invalid transport action')
            target_error = np.linalg.norm(grasps-(self.grasp0+self.shift), axis=1)
            base_target_error = np.linalg.norm(bases[:, :2]-(self.base0[:, :2]+self.shift[:2]), axis=1)
            reached = (self.reference >= self.length-1e-9 and
                       np.max(target_error) < .005 and np.max(base_target_error) < .005 and
                       measured_min >= self.length-.003)
            self.goal_stable_seconds = self.goal_stable_seconds + dt if reached else 0.
            if self.length <= 1e-12 or self.goal_stable_seconds >= .25-1e-9:
                self.done = True
            self.debug = dict(reference_distance_m=self.reference, path_length_m=self.length,
                measured_progress_m=progress.tolist(), lag_to_reference_m=lag.tolist(),
                pair_progress_difference_m=pair_lag, reference_advance_m=advance*common_scale,
                pause_for_lag=pause_for_lag, navigation_paused_pair=blocked,
                common_navigation_scale=common_scale, navigation_guards=guards,
                tracking_error_m=tracking_error.tolist(), relative_grasp_error_m=relative_error,
                goal_stable_seconds=self.goal_stable_seconds, desired_shift_world=self.shift.tolist(),
                command_world_velocities=[(v[0]*common_scale).tolist() for v in velocities],
                closed_gripper_required=self.require_closed, calls=self.calls,
                scope='formation-preserving local straight segment; no global route, arm clearance, tension or sleeve guarantee')
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as error:
            self.failure = str(error)
            self.debug.update(failure=self.failure, calls=self.calls, reference_distance_m=self.reference)
        return self._result(action)
