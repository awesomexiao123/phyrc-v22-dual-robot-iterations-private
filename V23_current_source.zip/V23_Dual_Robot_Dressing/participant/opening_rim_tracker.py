"""Track an initially observed image aperture through interior occlusion.

The fixed cohort is on visible cloth beside the inner contour, not on the hand
or background. Every update needs a uniquely associated, still-closed image
contour and fresh surrounding cloth depth. A tracked boundary is not proof of
an open passage, cuff identity, attachment or insertion. No actions are issued.
"""
from copy import deepcopy

import cv2
import numpy as np

from cloth_patch_tracker import _measure
from opening_candidates import (_PUBLIC, _cloth_masks, _inner_aperture,
                                _optical_points, detect_opening_candidates)


def _closed_regions(cloth):
    contours, hierarchy = cv2.findContours(cloth.astype(np.uint8), cv2.RETR_CCOMP,
                                         cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None:
        return []
    regions = []
    for index, contour in enumerate(contours):
        if hierarchy[0, index, 3] < 0:
            continue
        x, y, width, height = cv2.boundingRect(contour)
        if min(x, y) <= 1 or x+width >= 255 or y+height >= 255:
            continue
        hole = np.zeros((256, 256), np.uint8)
        cv2.drawContours(hole, [contour], -1, 1, cv2.FILLED)
        free = hole.astype(bool) & ~cloth
        if 12 <= free.sum() <= 30000:
            regions.append((hole, free))
    return regions


def _quadrants(pixels, center):
    angle = np.arctan2(*(np.asarray(pixels)-center)[:, ::-1].T)
    counts = np.bincount(np.floor((angle+np.pi)/(np.pi/2)).astype(int) % 4, minlength=4)
    sorted_angles = np.sort(angle)
    max_gap = float(np.diff(np.r_[sorted_angles, sorted_angles[0]+2*np.pi]).max())
    return bool(np.count_nonzero(counts >= 2) >= 3 and max_gap <= np.pi*1.05)


class OpeningRimTracker:
    """Single-camera, fixed-identity diagnostic tracker; explicit reset to restart.

    Default lifetime 180 s and measured center path .40 m cover a bounded local
    approach. Updates must be fresh and no more than .25 s apart. Fixed cohort
    retention, optical-flow and plane tolerances are heuristics, not calibrated
    uncertainty. Failure latches: later images cannot silently acquire a new rim.
    """
    def __init__(self, *, max_age_s=180., max_path_m=.40, min_features=8):
        if not 0 < max_age_s <= 180 or not 0 < max_path_m <= .40 or not 8 <= min_features <= 40:
            raise ValueError('invalid bounded rim tracking limits')
        self.max_age_s, self.max_path_m = float(max_age_s), float(max_path_m)
        self.min_features = int(min_features)
        self.failure = 'reset_required'
        self.identity = None
        self.ids = np.empty(0, int)
        self.initial_count = 0
        self.path_m = 0.
        self.updates = 0

    def _result(self, geometry=None, displacement=None):
        return dict(reliable=geometry is not None and self.failure is None,
            reason=self.failure or 'same_initial_cloth_features_and_fresh_closed_rim_observed',
            kind='tracked_unclassified_rim', identity=deepcopy(self.identity),
            tracked_count=len(self.ids), initial_feature_count=self.initial_count,
            feature_ids=self.ids.tolist(), features_reseeded=False, update_count=self.updates,
            measured_center_path_m=self.path_m,
            median_displacement_world=None if displacement is None else np.asarray(displacement).tolist(),
            centroid_world=None if geometry is None else geometry['centroid_world'],
            normal_world=None if geometry is None else geometry['normal_world'],
            inner_aperture=None if geometry is None else deepcopy(geometry['inner_aperture']),
            rim_geometry=deepcopy(geometry),
            current_interior_free_space='unknown_even_when_rim_tracking_is_reliable',
            current_background_depth_required=False, physical_opening_verified=False,
            sleeve_identity_verified=False, attachment_verified=False, insertion_allowed=False,
            motion_executor_included=False,
            scope='fresh visible cloth rim and image contour; interior may contain hand, folds or other occlusion')

    def _geometry(self, values, hole, cloth, now):
        camera = self.camera
        depth = values['depth'][camera, ..., 0]
        valid = (values['depth_valid'][camera, ..., 0] & np.isfinite(depth)
                 & (depth > .03) & (depth < (3. if camera < 3 else 5.)))
        rim = cv2.dilate(hole, np.ones((5, 5), np.uint8)).astype(bool) & cloth
        if rim.sum() < 20 or valid[rim].mean() < .90:
            raise ValueError('fresh_cloth_rim_depth_is_missing_or_occluded')
        v, u = np.where(rim & valid)
        optical = _optical_points(u, v, depth[v, u])
        center = optical.mean(axis=0)
        _, singular, axes = np.linalg.svd(optical-center, full_matrices=False)
        if singular[1] < .005 or singular[2]/singular[1] > .25:
            raise ValueError('fresh_rim_is_collapsed_nonplanar_or_mixed_depth')
        normal = axes[2]
        if normal @ center > 0:
            normal = -normal
        if np.percentile(np.abs((optical-center) @ normal), 90) > .008:
            raise ValueError('fresh_rim_plane_residual_exceeds_8mm')
        rotation, origin = _PUBLIC._camera_transform(values, camera)
        aperture = _inner_aperture(hole, cloth, center, normal, rotation, origin,
                                   axes[0], camera, now)
        if not aperture['available']:
            raise ValueError('fresh_inner_contour_unresolved: '+aperture['reason'])
        polygon = np.asarray(aperture['contour_pixels_uv'], np.float32)
        moments = cv2.moments(polygon)
        if moments['m00'] <= 0:
            raise ValueError('fresh_inner_contour_has_no_area')
        pixel = np.array([moments['m10'], moments['m01']])/moments['m00']
        # Only a freshly measured rim plane is used for ray/plane projection.
        ray = _optical_points(pixel[0], pixel[1], 1.)
        denominator = float(ray @ normal)
        if abs(denominator) < .15:
            raise ValueError('fresh_inner_contour_is_edge_on')
        world_center = rotation @ (ray*float(center @ normal)/denominator)+origin
        points = optical @ rotation.T+origin
        stride = max(1, int(np.ceil(len(points)/64)))
        return dict(camera_index=camera, source_camera=_PUBLIC._CAMERAS[camera][0],
            observation_time_s=now, centroid_world=world_center.tolist(),
            pixel_centroid=pixel.tolist(), normal_world=(rotation @ normal).tolist(),
            normal_convention='toward_current_camera; not entry direction',
            ring_points_world=points[::stride].tolist(),
            ring_source_pixels_uv=np.column_stack((u, v))[::stride].tolist(),
            plane_centre_world=(rotation @ center+origin).tolist(),
            inner_aperture=aperture, planarity=float(singular[2]/singular[1]),
            current_rim_depth_valid_fraction=float(valid[rim].mean()),
            current_rim_depth_sample_count=len(points),
            current_interior_clearance_observed=False, opening_verified=False)

    def reset(self, obs, candidate):
        self.failure = None
        self.identity = None
        self.ids = np.empty(0, int)
        self.initial_count = self.updates = 0
        self.path_m = 0.
        try:
            values = _PUBLIC._validated(obs, wrists=True)
            now = float(np.asarray(obs['simulation_time_s']).item())
            self.camera = candidate.get('camera_index')
            if not np.isfinite(now) or self.camera not in (1, 2, 3, 4) or candidate.get('observation_time_s') != now:
                raise ValueError('initial_candidate_requires_current_public_robot_camera_and_time')
            initial_pixels = candidate.get('inner_aperture', {}).get('contour_pixels_uv', [])
            if not initial_pixels:
                raise ValueError('initial_inner_contour_required')
            # Recheck the supplied contour against THIS public RGB-D, including
            # initial empty-background support; a stale candidate cannot seed it.
            detected = detect_opening_candidates(obs)['opening_candidates']
            matches = [item for item in detected if item['camera_index'] == self.camera
                       and item['inner_aperture']['available']
                       and item['inner_aperture']['contour_pixels_uv'] == initial_pixels]
            if len(matches) != 1:
                raise ValueError('initial_contour_lacks_unique_current_background_depth_support')
            self.contour = np.asarray(initial_pixels, np.float32)
            cloth, _ = _cloth_masks(values['rgb'][self.camera])
            free = np.zeros((256, 256), np.uint8)
            cv2.fillPoly(free, [self.contour.astype(np.int32)], 1)
            geometry = self._geometry(values, free, cloth, now)
            band = (cv2.dilate(free, np.ones((17, 17), np.uint8)).astype(bool)
                    & cv2.erode(cloth.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool))
            self.gray = cv2.cvtColor(values['rgb'][self.camera], cv2.COLOR_RGB2GRAY)
            # Hand/background texture inside the hole must not become a flow
            # feature or pull a rim window toward the occluder. Cloth RGB and
            # its boundary remain measured; no missing cloth is filled in.
            self.gray[~cloth] = 0
            corners = cv2.goodFeaturesToTrack(self.gray, 96, .005, 3., mask=band.astype(np.uint8)*255, blockSize=3)
            measured = [] if corners is None else [(pixel, _measure(values, self.camera, pixel, cloth))
                                                    for pixel in corners.reshape(-1, 2)]
            measured = [(pixel, point) for pixel, point in measured if point is not None]
            self.pixels = np.asarray([pixel for pixel, _ in measured], np.float32).reshape(-1, 2)
            if len(measured) < self.min_features or not _quadrants(self.pixels, geometry['pixel_centroid']):
                raise ValueError('initial_rim_has_insufficient_spatially_distributed_cloth_features')
            self.initial_world = np.asarray([point[0] for _, point in measured])
            self.last_world = self.initial_world.copy()
            self.ids = np.arange(len(measured))
            self.initial_count = len(measured)
            self.last_time = self.initial_time = now
            self.last_rotation, self.last_origin = _PUBLIC._camera_transform(values, self.camera)
            self.last_geometry = geometry
            self.identity = dict(initial_camera_index=self.camera,
                initial_source_camera=_PUBLIC._CAMERAS[self.camera][0], initial_observation_time_s=now,
                initial_contour_pixels_uv=deepcopy(initial_pixels), initial_background_depth_supported=True,
                identity_basis='fixed initial cloth feature cohort plus uniquely matched fresh closed inner contour')
            return self._result(geometry, np.zeros(3))
        except (KeyError, ValueError, TypeError, IndexError, AttributeError, cv2.error) as error:
            self.failure = str(error)
            return self._result()

    def update(self, obs):
        if self.failure:
            return self._result()
        self.updates += 1
        try:
            values = _PUBLIC._validated(obs, wrists=True)
            now = float(np.asarray(obs['simulation_time_s']).item())
            dt = now-self.last_time
            if not np.isfinite(now) or not 0 < dt <= .25+1e-8 or now-self.initial_time > self.max_age_s:
                raise ValueError('rim_observation_is_not_fresh_or_exceeds_time_bound')
            rotation, origin = _PUBLIC._camera_transform(values, self.camera)
            angle = np.arccos(np.clip((np.trace(rotation @ self.last_rotation.T)-1)/2, -1., 1.))
            if np.linalg.norm(origin-self.last_origin) > .06 or angle > np.deg2rad(8):
                raise ValueError('camera_jump_exceeds_local_tracking_bound')
            cloth, _ = _cloth_masks(values['rgb'][self.camera])
            gray = cv2.cvtColor(values['rgb'][self.camera], cv2.COLOR_RGB2GRAY)
            gray[~cloth] = 0
            old = self.pixels.reshape(-1, 1, 2)
            settings = dict(winSize=(11, 11), maxLevel=2,
                criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, .01))
            new, ok1, err = cv2.calcOpticalFlowPyrLK(self.gray, gray, old, None, **settings)
            if new is None:
                raise ValueError('rim_optical_flow_lost')
            back, ok2, _ = cv2.calcOpticalFlowPyrLK(gray, self.gray, new, None, **settings)
            if back is None:
                raise ValueError('rim_backward_optical_flow_lost')
            new = new.reshape(-1, 2)
            keep = (ok1.ravel().astype(bool) & ok2.ravel().astype(bool) & (err.ravel() < 25)
                    & (np.linalg.norm(back.reshape(-1, 2)-self.pixels, axis=1) < .8)
                    & (np.linalg.norm(new-self.pixels, axis=1) <= 24))
            indices, points = [], []
            for index in np.flatnonzero(keep):
                measurement = _measure(values, self.camera, new[index], cloth)
                if measurement is not None and np.linalg.norm(measurement[0]-self.last_world[index]) <= .04:
                    indices.append(index); points.append(measurement[0])
            indices = np.asarray(indices, int)
            if len(indices) < self.min_features or len(indices) < .40*self.initial_count:
                raise ValueError('initial_cloth_rim_features_lost_or_depth_changed')
            affine, inliers = cv2.estimateAffine2D(self.pixels[indices], new[indices], method=cv2.RANSAC,
                ransacReprojThreshold=1.5, maxIters=500, confidence=.99, refineIters=10)
            if affine is None or inliers is None or inliers.mean() < .75:
                raise ValueError('rim_feature_motion_has_no_spatial_consensus')
            scales = np.linalg.svd(affine[:, :2], compute_uv=False)
            if scales.min() < .8 or scales.max() > 1.25 or np.linalg.det(affine[:, :2]) <= 0:
                raise ValueError('rim_image_deformation_exceeds_local_bound')
            selected = inliers.ravel().astype(bool)
            points = np.asarray(points)[selected]; indices = indices[selected]
            predicted = self.contour @ affine[:, :2].T+affine[:, 2]
            expected = np.zeros((256, 256), np.uint8)
            cv2.fillPoly(expected, [np.rint(predicted).astype(np.int32)], 1)
            matches = []
            for hole, free in _closed_regions(cloth):
                overlap = np.count_nonzero(free & (expected > 0))
                union = np.count_nonzero(free | (expected > 0))
                if overlap/max(union, 1) >= .20:
                    matches.append((hole, overlap/union))
            if len(matches) != 1:
                raise ValueError('multiple_matching_inner_contours' if matches else 'tracked_closed_inner_contour_missing')
            hole, overlap = matches[0]
            if overlap < .65:
                raise ValueError('fresh_contour_disagrees_with_tracked_rim_identity')
            geometry = self._geometry(values, hole, cloth, now)
            contour = np.asarray(geometry['inner_aperture']['contour_pixels_uv'], np.float32)
            # Overlap alone could accept a hand that covers part of the rim
            # and replaces it with a new occlusion boundary. Require the whole
            # fresh contour to stay near the motion predicted by the same cloth
            # features. This correspondence is only a rejection test; returned
            # geometry always uses the actual current contour, never this model.
            predicted = predicted.astype(np.float32)
            boundary_error = np.array(
                [abs(cv2.pointPolygonTest(contour, tuple(map(float, point)), True)) for point in predicted]
                + [abs(cv2.pointPolygonTest(predicted, tuple(map(float, point)), True)) for point in contour])
            if np.percentile(boundary_error, 95) > 2.5 or boundary_error.max() > 5.:
                raise ValueError('fresh_rim_boundary_changed_or_partially_occluded')
            geometry['contour_motion_residual_pixels_p95'] = float(np.percentile(boundary_error, 95))
            distances = np.array([cv2.pointPolygonTest(contour, tuple(map(float, point)), True)
                                  for point in new[indices]])
            beside_rim = (distances <= 1.) & (distances >= -12.)
            if beside_rim.mean() < .8:
                raise ValueError('tracked_features_no_longer_surround_the_same_inner_contour')
            indices, points = indices[beside_rim], points[beside_rim]
            if len(indices) < self.min_features or len(indices) < .40*self.initial_count or not _quadrants(new[indices], geometry['pixel_centroid']):
                raise ValueError('fresh_rim_lacks_distributed_fixed_feature_support')
            normal = np.asarray(geometry['normal_world'])
            if abs(normal @ self.last_geometry['normal_world']) < np.cos(np.deg2rad(15)):
                raise ValueError('rim_plane_rotation_exceeds_local_bound')
            plane = np.asarray(geometry['plane_centre_world'])
            if np.percentile(np.abs((points-plane) @ normal), 90) > .015:
                raise ValueError('tracked_cloth_features_disagree_with_fresh_rim_depth')
            motion = points-self.last_world[indices]
            if np.percentile(np.linalg.norm(motion-np.median(motion, axis=0), axis=1), 90) > .015:
                raise ValueError('rim_world_motion_has_no_local_consensus')
            increment = float(np.linalg.norm(np.asarray(geometry['centroid_world'])-self.last_geometry['centroid_world']))
            if increment > .05 or self.path_m+increment > self.max_path_m:
                raise ValueError('rim_center_motion_exceeds_bounded_path')
            self.path_m += increment
            self.ids, self.initial_world = self.ids[indices], self.initial_world[indices]
            self.pixels, self.last_world = new[indices], points
            self.gray, self.contour = gray, contour
            self.last_time, self.last_rotation, self.last_origin = now, rotation, origin
            self.last_geometry = geometry
            return self._result(geometry, np.median(points-self.initial_world, axis=0))
        except (KeyError, ValueError, TypeError, IndexError, AttributeError, cv2.error) as error:
            self.failure = str(error)
            return self._result()
