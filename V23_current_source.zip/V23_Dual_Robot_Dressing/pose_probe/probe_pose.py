#!/usr/bin/env python3
"""One official MediaPipe Lite pose model, one saved public RGB frame, CPU only.

No simulation, depth inference, GT, training, live capture, or controller import.
Model-provided world coordinates are deliberately not consumed or exported.
"""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import time

os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')

import mediapipe as mp
import numpy as np
from PIL import Image, ImageDraw, ImageFont

MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task'
MODEL_SHA256 = '59929e1d1ee95287735ddd833b19cf4ac46d29bc7afddbbf6753c459690d574a'
JOINTS = {11: 'left_shoulder', 12: 'right_shoulder', 13: 'left_elbow',
          14: 'right_elbow', 15: 'left_wrist', 16: 'right_wrist'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sheet', type=Path, required=True)
    parser.add_argument('--model', type=Path, default=here/'pose_landmarker_lite.task')
    parser.add_argument('--output', type=Path, default=here/'artifacts')
    args = parser.parse_args()
    if digest(args.model) != MODEL_SHA256:
        raise ValueError('Model checksum differs from this tested Lite bundle')
    args.output.mkdir(parents=True, exist_ok=True)
    sheet = Image.open(args.sheet).convert('RGB')
    if sheet.size != (768, 576):
        raise ValueError('Expected public five-camera 768x576 contact sheet')
    # participant/policy.py PublicDiagnostics.image: camera 3 starts at y=312.
    # This removes only the contact-sheet label/border, not a person-specific ROI.
    box = (0, 312, 256, 568)
    crop = sheet.crop(box)
    crop.save(args.output/'r0_head_input.png')
    options = mp.tasks.vision.PoseLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(args.model),
                                         delegate=mp.tasks.BaseOptions.Delegate.CPU),
        running_mode=mp.tasks.vision.RunningMode.IMAGE,
        num_poses=1, min_pose_detection_confidence=.5,
        min_pose_presence_confidence=.5, min_tracking_confidence=.5,
        output_segmentation_masks=False)
    start = time.perf_counter()
    with mp.tasks.vision.PoseLandmarker.create_from_options(options) as detector:
        initialized = time.perf_counter()
        result = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,
                                          data=np.asarray(crop)))
        finished = time.perf_counter()
    poses = []
    for landmarks in result.pose_landmarks:
        points = []
        for i, point in enumerate(landmarks):
            points.append(dict(index=i, name=JOINTS.get(i),
                x_normalized=float(point.x), y_normalized=float(point.y),
                x_pixel=float(point.x*256), y_pixel=float(point.y*256),
                visibility=float(point.visibility), presence=float(point.presence),
                within_image=bool(0 <= point.x < 1 and 0 <= point.y < 1)))
        poses.append(points)
    selected = [p for p in poses[0] if p['index'] in JOINTS] if poses else []
    gate = bool(selected) and all(p['visibility'] >= .8 and p['presence'] >= .8 and p['within_image']
                                 for p in selected)
    report = dict(model='Google MediaPipe Pose Landmarker Lite', model_url=MODEL_URL,
        model_sha256=MODEL_SHA256, model_bytes=args.model.stat().st_size,
        model_card='https://storage.googleapis.com/mediapipe-assets/Model%20Card%20BlazePose%20GHUM%203D.pdf',
        license_source='Model card page 2: Apache License, Version 2.0',
        api_guide='https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/python',
        python=platform.python_version(), mediapipe=mp.__version__, numpy=np.__version__,
        input_sheet=str(args.sheet.resolve()), input_sheet_sha256=digest(args.sheet),
        crop_box_xyxy=list(box), input_shape=[256, 256, 3], delegate='CPU',
        running_mode='IMAGE', input_frames=1, inference_calls=1,
        pose_count=len(poses), initialization_ms=(initialized-start)*1000,
        single_call_inference_ms=(finished-initialized)*1000,
        selected_shoulders_elbows_wrists=selected, landmarks_2d=poses,
        heuristic_six_joint_visibility_presence_gate_0_8=gate,
        gate_is_accuracy_validation=False,
        depth_used=False, model_world_landmarks_used=False,
        forearm_3d_axis_verified=False, sleeve_opening_verified=False,
        insertion_authorized=False,
        limitation='Single synthetic RGB frame only; confidence is not geometric error. '
                   'No ground truth, metric depth, multiview agreement, or time consistency validation.')
    (args.output/'pose_probe.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')

    scale = 3
    canvas = Image.new('RGB', (1536, 970), '#131923')
    raw = crop.resize((768, 768), Image.Resampling.NEAREST)
    annotated = raw.copy()
    draw = ImageDraw.Draw(annotated)
    font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    font = ImageFont.truetype(font_path, 20)
    title_font = ImageFont.truetype(font_path, 25)
    if poses:
        points = poses[0]
        for chain, color in (((11, 13, 15), '#2ee7f0'), ((12, 14, 16), '#ffad49')):
            for a, b in zip(chain[:-1], chain[1:]):
                draw.line([(points[j]['x_pixel']*scale, points[j]['y_pixel']*scale)
                           for j in (a, b)], fill=color, width=4)
            for j in chain:
                x, y = points[j]['x_pixel']*scale, points[j]['y_pixel']*scale
                draw.ellipse((x-6, y-6, x+6, y+6), fill=color, outline='black', width=1)
                draw.text((x+8, y-25), str(j), fill=color, font=font, stroke_width=2, stroke_fill='black')
    canvas.paste(raw, (0, 52)); canvas.paste(annotated, (768, 52))
    draw = ImageDraw.Draw(canvas)
    draw.text((15, 12), 'Original R0 head 256 x 256 (3x display)', fill='white', font=title_font)
    draw.text((783, 12), 'MediaPipe Lite: 2D model proposals only', fill='white', font=title_font)
    draw.text((16, 833), 'Cyan=model left   Orange=model right   Labels: shoulder 11/12, elbow 13/14, wrist 15/16', fill='white', font=font)
    draw.text((16, 867), f'CPU image inference: {report["single_call_inference_ms"]:.1f} ms; one frame, no depth or 3D validation.', fill='white', font=font)
    if selected:
        for row, side in enumerate(('left', 'right')):
            group = [p for p in selected if p['name'].startswith(side)]
            text = side + ': '+ ' | '.join(f'{p["name"].split("_")[1]} vis {p["visibility"]:.3f} / pres {p["presence"]:.3f}' for p in group)
            draw.text((16, 901+row*30), text, fill='#2ee7f0' if side=='left' else '#ffad49', font=font)
    else:
        draw.text((16, 901), 'No pose detected at default thresholds.', fill='#ffad49', font=font)
    canvas.save(args.output/'r0_head_pose_overlay.png')
    print(json.dumps({key: report[key] for key in ('pose_count', 'single_call_inference_ms',
        'selected_shoulders_elbows_wrists', 'heuristic_six_joint_visibility_presence_gate_0_8')}, indent=2))


if __name__ == '__main__':
    main()
