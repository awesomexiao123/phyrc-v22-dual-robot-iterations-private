#!/usr/bin/env bash
set -euo pipefail
phyrc_demo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 "$phyrc_demo_dir/launch_progress_gui.py"
