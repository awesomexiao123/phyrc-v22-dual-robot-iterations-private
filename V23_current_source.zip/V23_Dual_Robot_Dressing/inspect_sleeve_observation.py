#!/usr/bin/env python3
"""Compare saved public RGB-D reports; no actor imports or simulator access."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RECENT_REPORT_SECONDS = .25
CAVITY_RECENT_REPORT_SECONDS = 1.05  # Separate detector runs at most once per second.
NOTE = ('仅比较已保存的公共视觉报告，不向控制器回传数据。未检测到开口不等于没有袖口；'
        '深度支持的图像开口或未分类深度凹陷也不证明袖口身份、可穿入性或穿衣成功。'
        '凹陷内可能仍是布料或其他遮挡物。相机计数不是独立物理开口数。')


def number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def count(value):
    value = number(value)
    return int(value) if value is not None and value >= 0 and value.is_integer() else None


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def timestamp_state(now, stamp, recent_seconds=RECENT_REPORT_SECONDS):
    if stamp is None or now is None:
        return dict(status='unknown_timestamp', observation_time_s=stamp, age_s=None)
    age = now-stamp
    status = ('future_timestamp_invalid' if age < -1e-6 else 'same_frame' if abs(age) <= 1e-6
              else 'recent_report' if age <= recent_seconds else 'retained_stale')
    return dict(status=status, observation_time_s=stamp, age_s=age)


def supported(candidate):
    """Recheck the saved support contract, without importing the detector."""
    support = candidate.get('observed_depth_support', {})
    if not isinstance(support, dict):
        return False
    thresholds = {'ring_valid_fraction': .8, 'interior_valid_fraction': .7,
                  'background_fraction': .85, 'median_background_gap_m': .04,
                  'lower_quartile_background_gap_m': .02}
    return (candidate.get('kind') == 'unclassified_opening'
            and candidate.get('camera_index') in (1, 2, 3, 4)
            and all(number(support.get(k)) is not None and support[k] >= v for k, v in thresholds.items()))


def summarize_report(report):
    regions, identities, bad_candidates = [], {i: set() for i in (1, 2, 3, 4)}, 0
    report_stamp = number(report.get('observation_time_s'))
    candidate_stamps = []
    for region in report.get('grasp_regions', []):
        if not isinstance(region, dict):
            continue
        per_camera = {i: 0 for i in identities}
        for candidate in region.get('depth_supported_opening_candidates', []):
            if not isinstance(candidate, dict) or not supported(candidate):
                bad_candidates += 1
                continue
            stamp = number(candidate.get('observation_time_s'))
            if report_stamp is not None and stamp is not None and abs(report_stamp-stamp) > 1e-6:
                bad_candidates += 1
                continue
            camera = candidate['camera_index']
            index = count(candidate.get('candidate_index'))
            # Deduplicate a frame-local candidate listed by two regions. These
            # keys are NEVER joined between reports or different cameras.
            identity = ('index', index) if index is not None else ('payload', fingerprint(candidate))
            identities[camera].add(identity)
            per_camera[camera] += 1
            if stamp is not None:
                candidate_stamps.append(stamp)
        views = []
        for view in region.get('views', []):
            if not isinstance(view, dict) or view.get('camera_index') not in identities:
                continue
            views.append(dict(camera_index=view['camera_index'], source_camera=view.get('source_camera'),
                measured_cloth_pixels=count(view.get('measured_cloth_pixels')),
                measured_boundary_pixels=count(view.get('measured_boundary_pixels')),
                measured_internal_boundary_pixels=count(view.get('measured_internal_boundary_pixels')),
                measured_external_boundary_pixels=count(view.get('measured_external_boundary_pixels')),
                projected_rgb_cloth_pixels=count(view.get('projected_rgb_cloth_pixels')),
                projected_cloth_depth_valid_fraction=number(view.get('projected_cloth_depth_valid_fraction')),
                supported_candidate_count=per_camera[view['camera_index']]))
        regions.append(dict(grasp_index=region.get('grasp_index'),
            observed_cloth_point_count=count(region.get('observed_cloth_point_count')),
            observed_boundary_point_count=count(region.get('observed_boundary_point_count')),
            internal_image_boundary_point_count=count(region.get('internal_image_boundary_point_count')),
            external_image_boundary_point_count=count(region.get('external_image_boundary_point_count')),
            supported_candidate_counts_by_camera={str(k): v for k, v in per_camera.items()},
            ambiguous_candidate_indices=region.get('ambiguous_candidate_indices', []),
            reasons=region.get('reasons', []), views=views))
    return dict(grasp_regions=regions,
        supported_candidate_counts_by_camera={str(k): len(v) for k, v in identities.items()},
        supported_candidate_count=sum(map(len, identities.values())),
        invalid_saved_supported_candidates=bad_candidates,
        candidate_observation_times_s=sorted(set(candidate_stamps)),
        opening_candidate_rejections={str(k): count(v) for k, v in report.get('opening_candidate_rejections', {}).items()},
        rejection_scope='all cameras unless explicitly separated in source; not localized to a grasp',
        per_camera_boundary_split_available=any(v['measured_internal_boundary_pixels'] is not None
            for r in regions for v in r['views']),
        both_regions_have_depth_supported_opening=report.get('both_regions_have_depth_supported_opening'))


def summarize_roll(debug, now, axis='roll'):
    if not isinstance(debug, dict) or not debug:
        return None
    values = debug.get(f'measured_absolute_{axis}_degrees')
    values = ([number(v) for v in values] if isinstance(values, list) and len(values) == 2 else None)
    return dict(phase=debug.get('phase'),
        freshness=timestamp_state(now, number(debug.get('report_observed_at_s'))),
        **{f'measured_absolute_{axis}_degrees': values,
           f'measured_total_absolute_{axis}_degrees': number(debug.get(f'measured_total_absolute_{axis}_degrees')),
           f'total_absolute_{axis}_budget_degrees': number(debug.get(f'total_absolute_{axis}_budget_degrees'))},
        experiment_completed=debug.get('experiment_completed'), skipped=debug.get('skipped'),
        early_stopped=debug.get('early_stopped'), ineligible_reason=debug.get('ineligible_reason'),
        pending_failure=debug.get('pending_failure'), cancellation_only=debug.get('cancellation_only'),
        measurement_scope='actor-reported accumulated actual joint motion; never inferred from commands')


def summarize_cavities(report, now):
    """Keep the nested detector's own clock and kind separate from openings."""
    if not isinstance(report, dict) or not report:
        return None
    stamp = number(report.get('observation_time_s'))
    raw = report.get('depth_cavity_candidates', [])
    raw = raw if isinstance(raw, list) else []
    candidates, counts, invalid = [], {str(i): 0 for i in (1, 2, 3, 4)}, 0
    for item in raw:
        if not isinstance(item, dict):
            invalid += 1; continue
        own_stamp = number(item.get('observation_time_s'))
        if (item.get('kind') != 'unclassified_depth_cavity' or item.get('camera_index') not in (1, 2, 3, 4)
                or (stamp is not None and own_stamp is not None and abs(stamp-own_stamp) > 1e-6)):
            invalid += 1; continue
        depth = item.get('depth_evidence', {})
        plane = item.get('fitted_rim_plane', {})
        if not isinstance(depth, dict) or not isinstance(plane, dict):
            invalid += 1; continue
        counts[str(item['camera_index'])] += 1
        metrics = {key: number(depth.get(key)) for key in ('interior_pixel_count', 'interior_valid_fraction',
            'adjacent_rim_valid_fraction', 'adjacent_rim_cloth_fraction', 'deeper_cloth_fraction',
            'interior_blue_fraction', 'minimum_required_recession_z_m')}
        for key in ('optical_z_recession_m', 'first_surface_distance_behind_plane_along_camera_ray_m',
                    'first_surface_plane_normal_recession_m', 'first_surface_depth_z_m'):
            source = depth.get(key, {})
            metrics[key] = ({k: number(v) for k, v in source.items()} if isinstance(source, dict) else None)
        candidates.append(dict(kind='unclassified_depth_cavity', camera_index=item['camera_index'],
            source_camera=item.get('source_camera'), observation_time_s=own_stamp,
            freshness=timestamp_state(now, own_stamp, CAVITY_RECENT_REPORT_SECONDS),
            eligible_grasp_indices=item.get('eligible_grasp_indices'), depth_evidence=metrics,
            fitted_rim_plane=dict(planarity_ratio=number(plane.get('planarity_ratio')),
                maximum_measured_residual_m=number(plane.get('maximum_measured_residual_m')),
                measured_rim_pixel_count=count(plane.get('measured_rim_pixel_count')),
                normal_world=plane.get('normal_world'), normal_convention=plane.get('normal_convention')),
            free_advance_verified=False, permitted_advance_m=None, sleeve_identity_verified=False,
            insertion_allowed=False, scope='saved unclassified first-surface recession; not a free corridor'))
    rejections = report.get('rejected_candidate_counts', {})
    rejections = {str(k): count(v) for k, v in rejections.items()} if isinstance(rejections, dict) else {}
    diagnostics = []
    for view in report.get('diagnostics', []):
        if isinstance(view, dict) and view.get('camera_index') in (1, 2, 3, 4):
            diagnostics.append(dict(camera_index=view['camera_index'], **{k: count(view.get(k)) for k in
                ('nearby_valid_cloth_pixels', 'plane_hypotheses', 'depth_regions_examined', 'accepted_candidates')}))
    return dict(freshness=timestamp_state(now, stamp, CAVITY_RECENT_REPORT_SECONDS),
        observation_time_s=stamp, error=report.get('error'), available=report.get('available', not bool(report.get('error'))),
        reported_status=report.get('status'), saved_candidate_count=len(raw), candidate_count=len(candidates),
        candidate_counts_by_camera=counts, invalid_saved_candidates=invalid,
        rejected_candidate_counts=rejections,
        rejected_candidate_count=(sum(rejections.values()) if all(v is not None for v in rejections.values()) else None),
        diagnostics_by_camera=diagnostics, candidates=candidates,
        rejection_scope='global bounded detector proposals, not unique physical openings or per-camera attribution',
        cloth_fraction_scope='deeper_cloth_fraction uses the source blue/yellow cloth mask; a separate blue-only fraction is unknown unless provided',
        recent_report_limit_s=CAVITY_RECENT_REPORT_SECONDS,
        sleeve_identity_verified=False, free_advance_verified=False, insertion_allowed=False)


def compare_cavities(before, after):
    if before is None or after is None:
        return dict(status='insufficient_fresh_nested_cavity_reports', candidate_count_delta_by_camera=None)
    old, new = before['cavity'], after['cavity']
    delta = {k: new['candidate_counts_by_camera'][k]-old['candidate_counts_by_camera'][k] for k in ('1', '2', '3', '4')}
    return dict(status='unclassified_cavity_observations_only', candidate_count_delta_by_camera=delta,
        rejected_candidate_count_delta=(new['rejected_candidate_count']-old['rejected_candidate_count']
            if new['rejected_candidate_count'] is not None and old['rejected_candidate_count'] is not None else None),
        before_step=before['step'], after_step=after['step'],
        observation_gap_s=new['observation_time_s']-old['observation_time_s'],
        physical_opening_verified=False, free_advance_verified=False, insertion_allowed=False)


def compare_snapshots(before, after):
    if before is None or after is None:
        return dict(status='insufficient_fresh_timestamped_reports', candidate_count_delta_by_camera=None)
    delta = {k: after['metrics']['supported_candidate_counts_by_camera'][k]
                - before['metrics']['supported_candidate_counts_by_camera'][k] for k in ('1', '2', '3', '4')}
    def differences(old, new, keys):
        return {k: new[k]-old[k] if old.get(k) is not None and new.get(k) is not None else None for k in keys}
    regions = []
    old_regions = {r['grasp_index']: r for r in before['metrics']['grasp_regions']}
    for new in after['metrics']['grasp_regions']:
        old = old_regions.get(new['grasp_index'])
        if old is None:
            continue
        diff = differences(old, new, ('observed_cloth_point_count', 'observed_boundary_point_count',
                                      'internal_image_boundary_point_count', 'external_image_boundary_point_count'))
        old_views = {v['camera_index']: v for v in old['views']}
        cameras = []
        for view in new['views']:
            if view['camera_index'] in old_views:
                cameras.append(dict(camera_index=view['camera_index'], **differences(old_views[view['camera_index']], view,
                    ('measured_cloth_pixels', 'measured_boundary_pixels', 'measured_internal_boundary_pixels',
                     'measured_external_boundary_pixels', 'supported_candidate_count'))))
        regions.append(dict(grasp_index=new['grasp_index'], **diff, cameras=cameras))
    old_reject, new_reject = (s['metrics']['opening_candidate_rejections'] for s in (before, after))
    rejects = differences(old_reject, new_reject, sorted(set(old_reject)|set(new_reject)))
    return dict(status=('increased_supported_candidate_observations' if sum(delta.values()) > 0
                       else 'no_supported_candidate_count_increase_observed'),
        candidate_count_delta_by_camera=delta,
        per_grasp_pixel_count_deltas=regions, rejection_count_deltas=rejects,
        observation_gap_s=after['freshness']['observation_time_s']-before['freshness']['observation_time_s'],
        before_step=before['step'], after_step=after['step'],
        interpretation='observational comparison, not proof a wrist motion caused a change; no sleeve or insertion conclusion')


def orientation_windows(snapshots, axis):
    phase = 'pair_observe_'+axis
    other_phase = 'pair_observe_'+('pitch' if axis == 'roll' else 'roll')
    windows = []
    starts = [i for i, item in enumerate(snapshots) if item['phase'] == phase
              and (i == 0 or snapshots[i-1]['phase'] != phase)]
    for start in starts:
        end = start
        while end+1 < len(snapshots) and snapshots[end+1]['phase'] == phase:
            end += 1
        later = snapshots[end+1:]
        # Never count a later pitch experiment as the post-roll observation,
        # or vice versa. If no independent post sample exists, say unknown.
        cutoff = next((i for i, item in enumerate(later) if item['phase'] == other_phase), len(later))
        later = later[:cutoff]
        sources = {}
        for prefix, usable, clock, score in (
                ('', 'usable_for_comparison', 'freshness', lambda item: item['metrics']['supported_candidate_count']),
                ('cavity_', 'cavity_usable_for_comparison', 'cavity', lambda item: item['cavity']['candidate_count'])):
            def stamp(item):
                return item[clock]['observation_time_s']
            before = next((item for item in reversed(snapshots[:start]) if item.get(usable)), None)
            during = [item for item in snapshots[start:end+1] if item.get(usable)
                      and stamp(item) >= (snapshots[start]['simulation_time_s'] or 0)-1e-6]
            after = next((item for item in later if item.get(usable)
                          and stamp(item) > (snapshots[end]['simulation_time_s'] or 0)), None)
            peak = max(during, key=lambda item: (score(item), item['simulation_time_s']), default=None)
            compare = compare_cavities if prefix else compare_snapshots
            sources.update({prefix+'before': before, prefix+'during_peak': peak, prefix+'after': after,
                prefix+'during_observation_steps': [item['step'] for item in during],
                prefix+'comparison_during': compare(before, peak), prefix+'comparison_after': compare(before, after),
                prefix+f'before_gap_to_first_recorded_{axis}_s': (snapshots[start]['simulation_time_s']-stamp(before) if before else None),
                prefix+f'after_gap_from_last_recorded_{axis}_s': (stamp(after)-snapshots[end]['simulation_time_s'] if after else None)})
        motion = [item for item in snapshots[start:end+1] if item.get(axis)]
        windows.append(dict(axis=axis, first_recorded_step=snapshots[start]['step'],
            first_record_index=start, last_recorded_step=snapshots[end]['step'], **sources,
            **{f'last_{axis}_measurement': motion[-1][axis] if motion else None},
            next_orientation_phase_excluded=other_phase if cutoff < len(snapshots[end+1:]) else None,
            timing_scope='nearest available sparse observations; actual phase transitions may fall between recorded frames'))
    return windows


def review_records(records):
    """One episode only. Keep sparse samples and their original source ages."""
    snapshots, warnings, seen, seen_cavities, previous_time = [], [], set(), set(), None
    for index, row in enumerate(records):
        now = number(row.get('simulation_time_s'))
        monotonic = now is not None and (previous_time is None or now >= previous_time)
        if not monotonic:
            warnings.append('missing or reversed public time at record '+str(index))
        if now is not None:
            previous_time = now
        debug = row.get('debug', {})
        report = debug.get('sleeve_observability', {})
        roll = summarize_roll(debug.get('loaded_roll_observation'), now)
        pitch = summarize_roll(debug.get('loaded_pitch_observation'), now, 'pitch')
        item = dict(record_index=index, step=row.get('step'), simulation_time_s=now,
                    phase=row.get('phase', debug.get('phase')), metrics=None,
                    freshness=None, new_report=False, usable_for_comparison=False, roll=roll, pitch=pitch,
                    cavity=None, new_cavity_report=False, cavity_usable_for_comparison=False)
        nested = report.get('depth_cavity_observations') if isinstance(report, dict) else None
        if isinstance(nested, dict) and nested:
            item['cavity'] = summarize_cavities(nested, now)
            key = fingerprint(nested)
            item['new_cavity_report'] = key not in seen_cavities
            seen_cavities.add(key)
            item['cavity_usable_for_comparison'] = bool(monotonic and item['new_cavity_report']
                and item['cavity']['available'] and not item['cavity']['error']
                and item['cavity']['freshness']['status'] in ('same_frame', 'recent_report'))
            item['cavity']['retention'] = ('new_nested_report' if item['new_cavity_report'] else
                                         'identical_nested_report_not_independent_evidence')
        if isinstance(report, dict) and report.get('grasp_regions'):
            # An independently refreshed nested diagnostic cannot turn an
            # unchanged opening report into a new opening observation.
            key = fingerprint({k: v for k, v in report.items() if k != 'depth_cavity_observations'})
            item['new_report'] = key not in seen
            seen.add(key)
            item['freshness'] = timestamp_state(now, number(report.get('observation_time_s')))
            if not item['new_report']:
                item['retention'] = 'identical_saved_report_not_independent_evidence'
            elif item['freshness']['status'] == 'unknown_timestamp':
                item['retention'] = 'changed_payload_but_freshness_unproven'
            else:
                item['retention'] = 'new_timestamped_report'
            item['metrics'] = summarize_report(report)
            item['usable_for_comparison'] = (monotonic and item['new_report'] and
                item['freshness']['status'] in ('same_frame', 'recent_report'))
            # Candidate timestamps alone cannot date an entire zero-detection
            # report or prove that its cloth/boundary metrics were refreshed.
            item['freshness']['timestamp_scope'] = ('whole_report' if item['freshness']['observation_time_s'] is not None
                                                    else 'unknown_whole_report_even_if_candidates_are_dated')
        snapshots.append(item)
    phases = []
    for phase in dict.fromkeys(s['phase'] for s in snapshots):
        group = [s for s in snapshots if s['phase'] == phase]
        usable = [s for s in group if s['usable_for_comparison']]
        saved = [s for s in group if s['metrics']]
        cavities = [s for s in group if s['cavity_usable_for_comparison']]
        saved_cavities = [s for s in group if s['cavity']]
        phases.append(dict(phase=phase, recorded_rows=len(group), new_report_count=sum(s['new_report'] for s in group),
            usable_timestamped_observations=len(usable),
            freshness_counts=dict(Counter(s['freshness']['status'] if s['freshness'] else 'no_report' for s in group)),
            latest_usable_snapshot=usable[-1] if usable else None,
            latest_saved_snapshot=saved[-1] if saved else None,
            usable_cavity_observations=len(cavities),
            cavity_freshness_counts=dict(Counter(s['cavity']['freshness']['status'] if s['cavity'] else 'no_cavity_report' for s in group)),
            latest_saved_cavity_snapshot=saved_cavities[-1] if saved_cavities else None,
            maximum_unclassified_cavity_candidates=max((s['cavity']['candidate_count'] for s in cavities), default=None),
            maximum_supported_candidates=(max(s['metrics']['supported_candidate_count'] for s in usable) if usable else None)))
    return dict(record_count=len(records), snapshots=snapshots, phases=phases,
        roll_windows=orientation_windows(snapshots, 'roll'), pitch_windows=orientation_windows(snapshots, 'pitch'),
        latest_snapshot=snapshots[-1] if snapshots else None, warnings=warnings,
        recent_report_limit_s=RECENT_REPORT_SECONDS,
        cavity_recent_report_limit_s=CAVITY_RECENT_REPORT_SECONDS,
        limitations=['Only a new whole-report timestamp within 0.25s can enter comparisons; original ages are retained.',
            'Identical cached payloads never count as additional visual observations.',
            'Older reports without timestamps remain unknown, including zero-candidate reports.',
            'Missing per-camera boundary splits are null; region totals are not guessed into cameras.',
            'Nested cavity reports have a separate unchanged source clock and 1.05s recency limit for their 1Hz cadence.',
            'Cavity counts never enter depth-supported opening counts or imply sleeve identity/free insertion.',
            NOTE])


def read_records(path):
    records, warnings = [], []
    try:
        data = path.read_bytes()  # Snapshot once while a run may append.
    except OSError as exc:
        return [], [str(exc)]
    lines = data.splitlines() if path.suffix == '.jsonl' else [data]
    for index, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError('expected object')
            records.append(value)
        except (ValueError, UnicodeDecodeError) as exc:
            warnings.append(f'{path.name} line {index}: {exc}')
    return records, warnings


def review_run(run):
    diagnostics = run/'diagnostics'
    paths = sorted(diagnostics.glob('episode_*/progress.jsonl'))
    if not paths:
        paths = sorted(diagnostics.glob('episode_*/latest.json'))
    if not paths and (diagnostics/'latest.json').exists():
        paths = [diagnostics/'latest.json']
    episodes = []
    for path in paths:
        records, warnings = read_records(path)
        if path.suffix == '.jsonl' and (path.parent/'latest.json').exists():
            latest, extra = read_records(path.parent/'latest.json'); warnings.extend(extra)
            if latest and (not records or (number(latest[0].get('simulation_time_s')) is not None
                    and number(records[-1].get('simulation_time_s')) is not None
                    and latest[0]['simulation_time_s'] > records[-1]['simulation_time_s'])):
                records.extend(latest)
        episode = review_records(records)
        episode.update(source_file=str(path.resolve()), episode=path.parent.name)
        episode['warnings'].extend(warnings)
        episodes.append(episode)
    return dict(run=run.name, episodes=episodes, warnings=[] if paths else ['no saved public diagnostics found'])


def render_chinese(review):
    lines = ['袖侧公共视觉证据对比', NOTE,
             '说明：开口报告阈值为0.25秒；独立凹陷诊断约每秒更新，阈值为1.05秒。两者各自保留原始时间。', '']

    def cavity_lines(snapshot, label):
        if snapshot is None:
            return [f'    {label}凹陷：没有可比较的新鲜嵌套报告。']
        cavity = snapshot['cavity']
        entries = [f"    {label}凹陷：步骤{snapshot['step']}，原始时间{cavity['observation_time_s']}秒，"
                   f"年龄{cavity['freshness']['age_s']}秒（{cavity['freshness']['status']}）；"
                   f"各相机未分类候选{cavity['candidate_counts_by_camera']}，"
                   f"拒绝计数{cavity['rejected_candidate_counts']}；保存候选{cavity['saved_candidate_count']}，"
                   f"无效记录{cavity['invalid_saved_candidates']}。"]
        for view in cavity['diagnostics_by_camera']:
            entries.append(f"      相机{view['camera_index']}：当前布料支持{view['nearby_valid_cloth_pixels']}像素，"
                           f"平面假设{view['plane_hypotheses']}，检查区域{view['depth_regions_examined']}，"
                           f"源报告接受候选{view['accepted_candidates']}。")
        for candidate in cavity['candidates']:
            depth, plane = candidate['depth_evidence'], candidate['fitted_rim_plane']
            entries.append(f"      相机{candidate['camera_index']}未分类候选：内部深度支持"
                           f"{depth['interior_pixel_count']}像素；深处布料比例（蓝/黄）"
                           f"{depth['deeper_cloth_fraction']}，单独蓝色比例{depth['interior_blue_fraction']}；"
                           f"平面残差上限{plane['maximum_measured_residual_m']}米，"
                           f"平面性比{plane['planarity_ratio']}，实测边缘{plane['measured_rim_pixel_count']}像素，"
                           f"法向{plane['normal_world']}。")
            entries.append('        光轴深度差分位数'+str(depth['optical_z_recession_m'])+
                           '；沿平面法向的首个表面深度差'+str(depth['first_surface_plane_normal_recession_m'])+
                           '。None表示未提供；这些深度不是可自由前进距离。')
        return entries

    for run in review['runs']:
        lines.append('运行：'+run['run'])
        for episode in run['episodes']:
            lines.append(f"  {episode['episode']}：{episode['record_count']}条稀疏记录")
            for phase in episode['phases']:
                lines.append(f"  阶段 {phase['phase']}：可比较的新报告{phase['usable_timestamped_observations']}，"
                             f"最多深度支持候选数={phase['maximum_supported_candidates']}；新鲜度={phase['freshness_counts']}")
                saved = phase['latest_saved_snapshot']
                if saved:
                    lines.append(f"    最后保存报告（{saved['freshness']['status']}，年龄{saved['freshness']['age_s']}秒）："
                                 f"各相机候选数{saved['metrics']['supported_candidate_counts_by_camera']}；"
                                 f"拒绝计数{saved['metrics']['opening_candidate_rejections']}")
                    for region in saved['metrics']['grasp_regions']:
                        lines.append(f"      R{region['grasp_index']}原报告布料支持{region['observed_cloth_point_count']}，"
                                     f"内/外边界{region['internal_image_boundary_point_count']}/"
                                     f"{region['external_image_boundary_point_count']}；未证明这是该阶段的新观测。"
                                     if not saved['usable_for_comparison'] else
                                     f"      R{region['grasp_index']}布料支持{region['observed_cloth_point_count']}，"
                                     f"内/外边界{region['internal_image_boundary_point_count']}/"
                                     f"{region['external_image_boundary_point_count']}。")
                if phase.get('latest_saved_cavity_snapshot'):
                    lines.append(f"    可比较的新凹陷报告{phase['usable_cavity_observations']}，"
                                 f"最多未分类候选={phase['maximum_unclassified_cavity_candidates']}；"
                                 f"新鲜度={phase['cavity_freshness_counts']}")
                    lines.extend(cavity_lines(phase['latest_saved_cavity_snapshot'], '最后保存'))
            for axis, axis_name in [('roll', '滚转'), ('pitch', '俯仰')]:
                windows = episode.get(axis+'_windows', [])
                if not windows:
                    lines.append(f'  尚无 pair_observe_{axis} 阶段记录，不能评估{axis_name}的前后变化。')
                for window in windows:
                    lines.append(f"  {axis_name}记录步骤 {window['first_recorded_step']}–{window['last_recorded_step']}")
                    lines.append(f"    前/后报告距{axis_name}记录边界："
                                 f"{window['before_gap_to_first_recorded_'+axis+'_s']} / "
                                 f"{window['after_gap_from_last_recorded_'+axis+'_s']}秒；"
                                 f"间隔内可能有其他动作，不能归因于{axis_name}。")
                    if window.get('next_orientation_phase_excluded'):
                        lines.append('    未将后续'+window['next_orientation_phase_excluded']+'阶段的观测算作本次动作后的证据。')
                    for suffix, key in [('前', 'before'), ('中候选最多', 'during_peak'), ('后', 'after')]:
                        label, snapshot = axis_name+suffix, window[key]
                        if snapshot is None:
                            lines.append(f'    {label}：没有可比较的新鲜完整开口报告。')
                        else:
                            metrics = snapshot['metrics']
                            lines.append(f"    {label}：步骤{snapshot['step']}，报告年龄{snapshot['freshness']['age_s']:.3f}秒，"
                                         f"各相机开口候选数{metrics['supported_candidate_counts_by_camera']}，"
                                         f"拒绝计数{metrics['opening_candidate_rejections']}")
                            for region in metrics['grasp_regions']:
                                lines.append(f"      R{region['grasp_index']}：布料支持{region['observed_cloth_point_count']}像素，"
                                             f"内边界{region['internal_image_boundary_point_count']}，外边界{region['external_image_boundary_point_count']}")
                                for view in region['views']:
                                    lines.append(f"        相机{view['camera_index']}：布料{view['measured_cloth_pixels']}，"
                                                 f"边界{view['measured_boundary_pixels']}，内/外分项"
                                                 f"{view['measured_internal_boundary_pixels']}/{view['measured_external_boundary_pixels']}")
                        lines.extend(cavity_lines(window.get('cavity_'+key), label))
                    motion = window['last_'+axis+'_measurement']
                    if motion:
                        lines.append(f"    实测累计绝对{axis_name}角：各机器人{motion['measured_absolute_'+axis+'_degrees']}°，"
                                     f"合计{motion['measured_total_absolute_'+axis+'_degrees']}° / "
                                     f"预算{motion['total_absolute_'+axis+'_budget_degrees']}°；"
                                     f"测量新鲜度{motion['freshness']['status']}")
                    lines.append(f'    {axis_name}后开口候选变化：'+str(window['comparison_after']['candidate_count_delta_by_camera'])+
                                 '；缺少新报告时不能判断改善，也不能沿用旧报告作为动作后证据。')
                    if 'cavity_comparison_after' in window:
                        lines.append(f'    {axis_name}后未分类凹陷候选变化：'+str(
                            window['cavity_comparison_after']['candidate_count_delta_by_camera'])+
                            '；凹陷与深度支持开口分别统计，均不提供穿入许可。')
            if episode['latest_snapshot'] and episode['latest_snapshot']['freshness']:
                last = episode['latest_snapshot']
                lines.append(f"  最后保留报告：步骤{last['step']}，{last['freshness']['status']}，"
                             f"原始报告年龄{last['freshness']['age_s']}秒；保留状态{last.get('retention')}。")
            lines.extend('  读取提醒：'+warning for warning in episode['warnings'])
        lines.extend('  读取提醒：'+warning for warning in run['warnings'])
        lines.append('')
    return '\n'.join(lines)+'\n'


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='append', required=True, help='results/下的运行目录名；可重复以比较多个运行')
    args = parser.parse_args(argv)
    runs = []
    for name in args.run:
        if not name or Path(name).name != name or name in ('.', '..'):
            parser.error('--run must be a basename inside results/')
        run = ROOT/'results'/name
        if not run.is_dir():
            parser.error('run directory does not exist: '+name)
        runs.append(run)
    report = dict(schema='public-sleeve-observation-review-v1',
        generated_at_utc=datetime.now(timezone.utc).isoformat(), public_diagnostics_only=True,
        controller_feedback=False, inference_note=NOTE, runs=[review_run(run) for run in runs])
    target = (runs[0]/'sleeve_observation_review' if len(runs) == 1
              else ROOT/'validation'/'sleeve_observation_comparison')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.with_suffix('.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    target.with_suffix('.txt').write_text(render_chinese(report))
    print(str(target.with_suffix('.json')))
    print(str(target.with_suffix('.txt')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
