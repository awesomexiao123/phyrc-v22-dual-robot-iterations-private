#!/usr/bin/env python3
"""Offline review of official measurements and public actor diagnostics.

This is an analysis-only consumer of files already written by the evaluator.
It imports neither the actor nor the simulator and never sends data to either.
"""
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
BOUNDARY_NOTE = (
    "仅离线读取官方评测日志；附着状态、锚点误差和评分属于评测测量，"
    "未作为公共观测提供给控制器，本工具也不向控制器回传这些数据。")


def read_json(path):
    if not path.exists():
        return None, None
    try:
        value = json.loads(path.read_text())
        if not isinstance(value, dict):
            raise ValueError("expected JSON object")
        return value, None
    except (OSError, ValueError) as exc:
        return None, f"{path.name}: {exc}"


def read_jsonl(path):
    if not path.exists():
        return [], [f"missing {path.name}"]
    # Read one byte snapshot. A writer may append afterward; the report is
    # explicitly stamped as a snapshot, not a claim that the episode ended.
    try:
        data = path.read_bytes()
    except OSError as exc:
        return [], [f"{path.name}: {exc}"]
    records, warnings = [], []
    for index, line in enumerate(data.splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            if not isinstance(record, dict):
                raise ValueError("expected JSON object")
            records.append(record)
        except (ValueError, UnicodeDecodeError) as exc:
            # Keep a break marker: skipping a bad line must not join two
            # healthy holding intervals into a fictitious continuous span.
            records.append({"_unreadable_line": index})
            warnings.append(f"{path.name} line {index}: {exc}")
    return records, warnings


def finite_number(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        return None
    return float(value) if math.isfinite(float(value)) else None


def finite_vector(value, length):
    if not isinstance(value, list) or len(value) != length:
        return None
    result = [finite_number(item) for item in value]
    return result if all(item is not None for item in result) else None


def two_world_vectors(value):
    if not isinstance(value, list) or len(value) != 2:
        return None
    result = [finite_vector(item, 3) for item in value]
    return result if all(item is not None for item in result) else None


def _skin_timestamp(value, log_time, age_limit, scope):
    stamp = finite_number(value)
    delta = None if stamp is None or log_time is None else log_time-stamp
    status = ('unknown_timestamp' if delta is None else 'future_timestamp_invalid' if delta < -1e-7
              else 'within_declared_age_limit' if delta <= age_limit+1e-7 else 'older_than_declared_age_limit')
    return dict(observation_time_s=stamp, age_at_log_record_s=None if delta is None or delta < -1e-7 else max(0., delta),
                clock_delta_s=delta, declared_max_age_s=age_limit, status=status, scope=scope)


def hypothesis_contact_statistics(records):
    """Read actor contact diagnostics without promoting them to task success.

    A pulse list is cumulative, not a fresh event per diagnostic row. There is
    no nested experiment timestamp in this schema; log time is explicitly a
    record clock, and old skin observations keep their own original times.
    """
    snapshots, transitions, pulses, conflicts, clearances = [], [], [], [], []
    previous_phase = None
    for record in records:
        debug = record.get('debug')
        if not isinstance(debug, dict):
            continue
        contact = debug.get('hypothesis_contact')
        if not isinstance(contact, dict) or not contact:
            continue
        now = finite_number(record.get('simulation_time_s'))
        skin = contact.get('skin') if isinstance(contact.get('skin'), dict) else {}
        checks = contact.get('own_geometry_clearance')
        checks = checks if isinstance(checks, list) else []
        valid_checks = []
        for check in checks:
            if not isinstance(check, dict):
                continue
            distance = finite_number(check.get('observed_minimum_clearance_m'))
            if check.get('valid') is True and distance is not None:
                valid_checks.append(dict(robot=check.get('robot'), checked_segment=check.get('checked_segment'),
                    observed_minimum_clearance_m=distance, skin_observed_at=finite_number(check.get('skin_observed_at')),
                    reported_skin_age_s=finite_number(check.get('skin_age_s'))))
                clearances.append(distance)
        skin_current = _skin_timestamp(skin.get('retained_observation_time_s'), now, 20.,
                                       'recent retained visible skin; original timestamp, not restamped')
        skin_anchor = _skin_timestamp(skin.get('fixed_stationary_anchor_observation_time_s'), now, 180.,
                                      'fixed historical skin under stationary-human assumption; not current visibility')
        snapshot = dict(step=record.get('step'), diagnostic_record_public_time_s=now,
            experiment_observation_time_s=finite_number(contact.get('observation_time_s')),
            phase=contact.get('phase'), pending_failure=contact.get('pending_failure'),
            failure=contact.get('failure') or debug.get('failure') or record.get('failure'),
            commanded_advance_from_distal_goal_m=finite_number(contact.get('commanded_advance_from_distal_goal_m')),
            nominal_advance_beyond_distal_surface_m=finite_number(contact.get('nominal_advance_beyond_distal_surface_m')),
            observed_skin_clearance_min_m=min((item['observed_minimum_clearance_m'] for item in valid_checks), default=None),
            valid_saved_clearance_checks=len(valid_checks), unavailable_or_invalid_saved_clearance_checks=len(checks)-len(valid_checks),
            saved_clearance_checks=valid_checks, current_skin=skin_current, fixed_skin_anchor=skin_anchor,
            actual_sleeve_entry_verified=False)
        snapshots.append(snapshot)
        if snapshot['phase'] != previous_phase:
            transitions.append({key: snapshot[key] for key in ('step', 'diagnostic_record_public_time_s', 'phase')})
            previous_phase = snapshot['phase']
        reported_pulses = contact.get('pulse_results')
        if not isinstance(reported_pulses, list):
            continue
        for index, pulse in enumerate(reported_pulses):
            if not isinstance(pulse, dict):
                normalized = dict(measured_grasp_shift_world=None, fixed_cloth_shift_world=None, malformed=True)
            else:
                normalized = dict(measured_grasp_shift_world=two_world_vectors(pulse.get('measured_grasp_shift_world')),
                    fixed_cloth_shift_world=two_world_vectors(pulse.get('fixed_cloth_shift_world')),
                    cloth_proximal_progress_m=finite_vector(pulse.get('cloth_proximal_progress_m'), 2),
                    cloth_vs_grasp_error_m=finite_vector(pulse.get('cloth_vs_grasp_error_m'), 2),
                    current_proximal_cloth_voxels=finite_vector(pulse.get('current_proximal_cloth_voxels'), 2),
                    previous_proximal_cloth_voxels=finite_vector(pulse.get('previous_proximal_cloth_voxels'), 2))
            normalized['actual_sleeve_entry_verified'] = False
            if index < len(pulses):
                if normalized != pulses[index]['response']:
                    conflict = dict(pulse_index=index+1, diagnostic_step=record.get('step'),
                                    reason='same_cumulative_pulse_index_has_conflicting_saved_values')
                    if conflict not in conflicts:
                        conflicts.append(conflict)
            else:
                pulses.append(dict(pulse_index=index+1, first_logged_step=record.get('step'),
                    first_logged_public_time_s=now, pulse_measurement_time_s=None,
                    response=normalized))
    if not snapshots:
        return None
    return dict(present=True, diagnostic_records=len(snapshots), latest=snapshots[-1], phase_transitions=transitions,
        snapshots=snapshots, pulse_responses=pulses, pulse_response_count=len(pulses), pulse_conflicts=conflicts,
        minimum_saved_observed_skin_clearance_m=min(clearances, default=None),
        actual_sleeve_entry_verified=False, success_inferred_from_contact_diagnostics=False,
        official_success_source='valid official result.json score/success/dressing_complete only',
        definitions=dict(pulses='Cumulative list positions deduplicated across records; first-log time is not pulse measurement time.',
            advance='Advance from the distal goal includes the initial gap. Nominal advance beyond the modeled distal surface is not measured penetration.',
            coverage='Visible proximal cloth voxels can change with visibility; growth is not a dressing-success label.',
            clearance='Saved model distances to observed skin only; neither full-body clearance nor physical safety is established.',
            freshness='Nested contact payload may be retained. Record time never replaces the skin observation timestamps.'))


def bool_at(value, robot):
    if not isinstance(value, list) or len(value) != 2:
        return None
    return value[robot] if type(value[robot]) is bool else None


def diagnostics_at(record, robot):
    value = record.get("pickup_diagnostics")
    if isinstance(value, list) and len(value) == 2 and isinstance(value[robot], dict):
        return value[robot]
    return {}


def percentiles(values):
    if not values:
        return dict(count=0, min=None, median=None, p95=None, max=None)
    values = sorted(values)
    location = .95*(len(values)-1)
    low = int(location)
    high = min(low+1, len(values)-1)
    p95 = values[low]*(high-location) + values[high]*(location-low) if high != low else values[low]
    return dict(count=len(values), min=values[0], median=statistics.median(values),
                p95=p95, max=values[-1])


def event_statistics(records, flag, max_gap):
    intervals = []
    count = unknown = 0
    first = last = None
    start = end = None
    streak_count = 0
    previous_time = None

    def close():
        nonlocal start, end, streak_count
        if start is not None:
            intervals.append(dict(start_time_s=start, end_time_s=end,
                                  observed_span_s=max(0., end-start), samples=streak_count))
        start = end = None
        streak_count = 0

    for record in records:
        time = finite_number(record.get("time_s"))
        value = flag(record)
        if time is None or value is None:
            unknown += 1
            close()
            previous_time = None
            continue
        discontinuous = (previous_time is not None and
                         (time < previous_time or (max_gap is not None and time-previous_time > max_gap)))
        if discontinuous:
            close()
        if value:
            count += 1
            first = time if first is None else first
            last = time
            if start is None:
                start = time
            end = time
            streak_count += 1
        else:
            close()
        previous_time = time
    close()
    longest = max(intervals, key=lambda i: (i['observed_span_s'], i['samples']), default=None)
    return dict(ever_observed=count > 0, true_samples=count, unknown_samples=unknown,
                first_observed_time_s=first, last_observed_time_s=last,
                longest_continuous_observed_span_s=0. if longest is None else longest['observed_span_s'],
                longest_interval=longest, interval_count=len(intervals), intervals=intervals,
                total_continuous_observed_span_s=sum(i['observed_span_s'] for i in intervals))


def measured_statistics(records):
    times = [finite_number(r.get('time_s')) for r in records]
    finite_times = [t for t in times if t is not None]
    deltas = [b-a for a, b in zip(times, times[1:]) if a is not None and b is not None and b > a]
    median_gap = statistics.median(deltas) if deltas else None
    max_gap = median_gap*1.5 + 1e-8 if median_gap is not None else None
    robots = []
    for robot in (0, 1):
        raw = lambda r, i=robot: diagnostics_at(r, i).get('attached') if type(diagnostics_at(r, i).get('attached')) is bool else None
        healthy = lambda r, i=robot: bool_at(r.get('gripper_holding'), i)
        attached_errors = [finite_number(diagnostics_at(r, robot).get('anchor_p95_error_m'))
                           for r in records if raw(r) is True]
        errors = [v for v in attached_errors if v is not None]
        inconsistent = sum(healthy(r) is True and raw(r) is not True for r in records)
        robots.append(dict(robot=robot, raw_attachment=event_statistics(records, raw, max_gap),
                           healthy_holding=event_statistics(records, healthy, max_gap),
                           anchor_p95_error_m_when_attached=percentiles(errors),
                           attached_samples_missing_anchor_error=sum(v is None for v in attached_errors),
                           healthy_flag_without_raw_attachment_samples=inconsistent))

    def pair_flag(record, raw=False):
        flags = ([diagnostics_at(record, r).get('attached') for r in (0, 1)] if raw else
                 [bool_at(record.get('gripper_holding'), r) for r in (0, 1)])
        if any(type(value) is not bool for value in flags):
            return None
        return all(flags)

    return dict(sample_records=len(records), readable_sample_records=sum('_unreadable_line' not in r for r in records),
                first_time_s=finite_times[0] if finite_times else None,
                last_time_s=finite_times[-1] if finite_times else None,
                median_sample_interval_s=median_gap, maximum_joined_sample_gap_s=max_gap,
                nonmonotonic_time_steps=sum(b < a for a, b in zip(times, times[1:]) if a is not None and b is not None),
                robots=robots,
                simultaneous_raw_attachment=event_statistics(records, lambda r: pair_flag(r, True), max_gap),
                simultaneous_healthy_holding=event_statistics(records, pair_flag, max_gap),
                definitions={
                    'raw_attachment': 'pickup_diagnostics[r].attached; attachment exists, irrespective of anchor tracking health',
                    'healthy_holding': 'official gripper_holding[r]; preserves evaluator interval-wide health checks instead of treating closed fingers as a grasp',
                    'anchor_error': 'each sample already contains anchor p95 error; reported p95 here is across those sample-level values',
                    'continuous_span': 'last true sample time minus first true sample time in an uninterrupted observed run; no extra sampling interval added',
                    'gaps': 'missing/malformed flags or lines, reversed time, or gaps >1.5 times median sampling interval break continuity',
                    'clock': 'official episode time_s; different origin from public actor simulation_time_s'})


def actor_statistics(path):
    records, warnings = read_jsonl(path)
    phases, failures, visual, roles = [], [], [], []
    previous_phase = None
    for record in records:
        if '_unreadable_line' in record:
            continue
        debug = record.get('debug') or {}
        phase = debug.get('phase', record.get('phase'))
        point = dict(step=record.get('step'), public_simulation_time_s=record.get('simulation_time_s'))
        if phase != previous_phase:
            phases.append(dict(point, phase=phase))
            previous_phase = phase
        failure = debug.get('failure') or record.get('failure')
        if failure and not any(i['reason'] == str(failure) for i in failures):
            failures.append(dict(point, reason=str(failure)))
        if debug.get('visual_dual_grasp_candidate') is True:
            visual.append(point)
        role = (debug.get('active_robot'), debug.get('helper_robot'))
        if role != (None, None) and role not in roles:
            roles.append(role)
    good = [r for r in records if '_unreadable_line' not in r]
    latest = good[-1] if good else {}
    latest_debug = latest.get('debug') or {}
    output = dict(progress_records=len(good), phase_transitions=phases, failures=failures,
                latest_phase=latest_debug.get('phase', latest.get('phase')),
                latest_step=latest.get('step'), latest_public_simulation_time_s=latest.get('simulation_time_s'),
                visual_dual_grasp_candidate_ever=bool(visual), visual_candidate_diagnostic_samples=len(visual),
                first_visual_candidate=visual[0] if visual else None,
                observed_roles=[dict(active_robot=a, helper_robot=h) for a, h in roles], warnings=warnings,
                definitions={'visual_candidate': 'actor hypothesis from public RGB-D, not a measured attachment or official task-success label',
                             'sampling': 'actor diagnostics are sparse; their record counts are not policy-step counts',
                             'clock': 'public simulation time; do not directly equate it to official episode time_s'})
    contact = hypothesis_contact_statistics(records)
    if contact is not None:
        output['hypothesis_contact'] = contact
    return output


def official_result(path):
    data, warning = read_json(path)
    if data is None:
        return dict(present=path.exists(), valid=None, usable_score=False,
                    reason='missing_or_unreadable_result', warning=warning)
    valid = data.get('valid') is True
    output = dict(present=True, valid=data.get('valid'), usable_score=valid,
                  reason=data.get('reason'), seed=(data.get('metadata') or {}).get('seed'))
    if valid:
        result = data.get('result') or {}
        keys = ('raw_points', 'max_raw_points', 'score_items', 'dressing_complete', 'success',
                'success_evaluated', 'success_basis', 'final_score', 'score_status', 'score_unit',
                'rate_points', 'excluded_pickup_points', 'task_time_s', 'elapsed_episode_time_s',
                'sample_count', 'rate_rule')
        output['score'] = {key: result.get(key) for key in keys if key in result}
        output['max_anchor_p95_error_m'] = (data.get('metadata') or {}).get('max_anchor_p95_error_m')
    else:
        output['note'] = 'Invalid result: its score and success fields are intentionally not quoted.'
    return output


def summarize_run(run):
    launch, launch_warning = read_json(run/'launch.json')
    completion, completion_warning = read_json(run/'completion.json')
    stopped, stopped_warning = read_json(run/'stop_requested.json')
    iteration_stop, iteration_warning = read_json(run/'iteration_stop.json')
    if stopped is None:
        stopped = iteration_stop
    warnings = [w for w in (launch_warning, completion_warning, stopped_warning, iteration_warning) if w]
    if stopped is not None:
        state, label = 'stop_requested_or_interrupted', '已请求停止/中断；不能视为完整计划测试'
    elif completion is None:
        state, label = 'unfinished_no_completion_record', '运行中或异常中断；尚无完成记录'
    elif completion.get('exit_code') != 0:
        state, label = 'finished_with_error', '进程已结束但退出异常；不能视为完整测试'
    else:
        state, label = 'process_finished', '进程正常结束，需逐场检查有效结果'
    episodes = []
    for index, folder in enumerate(sorted((run/'official_evaluation/episodes').glob('*')), 1):
        if not folder.is_dir():
            continue
        records, sample_warnings = read_jsonl(folder/'samples.jsonl')
        measurements = measured_statistics(records)
        diagnostic_dir = run/'diagnostics'/f'episode_{index:03d}'
        actor = actor_statistics(diagnostic_dir/'progress.jsonl')
        result = official_result(folder/'result.json')
        measured_dual = measurements['simultaneous_healthy_holding']['ever_observed']
        visual_dual = actor['visual_dual_grasp_candidate_ever']
        episodes.append(dict(episode=folder.name, official=result, measurements=measurements,
                             actor=actor, sample_warnings=sample_warnings,
                             diagnostic_directory=str(diagnostic_dir.relative_to(run)),
                             diagnostic_pairing='episode creation order; independent public and official clocks',
                             comparison=dict(visual_candidate_ever=visual_dual,
                                             measured_simultaneous_healthy_holding_ever=measured_dual,
                                             visual_candidate_without_measured_dual_holding=visual_dual and not measured_dual,
                                             note='Episode-wide presence comparison; sparse diagnostics do not establish exact event simultaneity.')))
    requested = (launch or {}).get('seeds', [])
    full_plan = bool(state == 'process_finished' and episodes and len(episodes) == len(requested) and
                     all(e['official']['valid'] is True and e['official'].get('reason') in ('policy_horizon', 'development_horizon') for e in episodes))
    return dict(schema='v23-offline-iteration-review-v1', generated_at=datetime.now(timezone.utc).isoformat(),
                run=run.name, run_directory=str(run), run_state=state, run_state_label=label,
                complete_requested_plan=full_plan, requested_seeds=requested,
                requested_budget_seconds=(launch or {}).get('seconds'),
                completion_exit_code=(completion or {}).get('exit_code'),
                episode_count=len(episodes), episodes=episodes, warnings=warnings,
                evaluation_data_boundary=BOUNDARY_NOTE,
                limitations=['This is a snapshot of available logs, possibly while the run is still appending.',
                             'Raw attachment, healthy holding, visual hypothesis, pickup points, and complete dressing are separate claims.',
                             'Only result.json with valid exactly true contributes official score/success.',
                             'A valid per-episode result does not prove the entire requested multi-episode plan completed.',
                             'Observed continuous spans are first-to-last sample spans; a single true sample has span zero.'])


def chinese_report(review):
    lines = [f"V23 离线迭代结果：{review['run']}", f"生成时间：{review['generated_at']}",
             f"运行状态：{review['run_state_label']}",
             f"完整执行本次计划：{'是' if review['complete_requested_plan'] else '尚未确认'}", '',
             BOUNDARY_NOTE, '',
             '判定区别：raw attachment 是存在附着；healthy holding 采用官方 gripper_holding 健康标志。',
             '最长连续观测跨度按连续真值记录的最后时间减第一时间计算，不额外补一个采样间隔。',
             '闭夹命令、视觉候选、取衣得分、完整穿衣是不同概念。', '']
    if not review['episodes']:
        lines.append('尚未发现官方 episode 日志，不能报告成败或分数。')
    for index, episode in enumerate(review['episodes'], 1):
        measured, actor, official = episode['measurements'], episode['actor'], episode['official']
        lines += [f"场景 {index}：{episode['episode']}",
                  f"官方采样：{measured['readable_sample_records']} 条；最后评测时间 {measured['last_time_s']} 秒。"]
        for robot in measured['robots']:
            raw, health = robot['raw_attachment'], robot['healthy_holding']
            error = robot['anchor_p95_error_m_when_attached']
            lines += [f"R{robot['robot']}：曾有原始附着={'是' if raw['ever_observed'] else '未观测到'}（{raw['true_samples']} 条）；"
                      f"曾有健康持衣={'是' if health['ever_observed'] else '未观测到'}（{health['true_samples']} 条）；"
                      f"健康持衣最长连续观测跨度={health['longest_continuous_observed_span_s']:.3f} 秒。",
                      f"  附着期间每条记录的锚点 p95 误差：中位值={error['median']} m，最大值={error['max']} m。"]
        dual = measured['simultaneous_healthy_holding']
        raw_dual = measured['simultaneous_raw_attachment']
        lines += [f"双机同时原始附着：{raw_dual['true_samples']} 条。",
                  f"双机同时健康持衣：{dual['true_samples']} 条；最长连续观测跨度 {dual['longest_continuous_observed_span_s']:.3f} 秒。",
                  f"公开控制器最后阶段：{actor['latest_phase']}；最后步数：{actor['latest_step']}。",
                  f"公开视觉双持候选：{'曾出现（仅假设）' if actor['visual_dual_grasp_candidate_ever'] else '尚未出现'}。",
                  '控制器阶段：' + ' → '.join(str(i['phase']) for i in actor['phase_transitions']),
                  '控制器失败原因：' + ('；'.join(i['reason'] for i in actor['failures']) or '当前日志中无')]
        contact = actor.get('hypothesis_contact')
        if contact:
            current = contact['latest']
            skin, anchor = current['current_skin'], current['fixed_skin_anchor']
            lines += [f"接触假设实验：阶段={current['phase']}；待停止原因={current['pending_failure']}；失败={current['failure']}。",
                f"从手端前方目标开始的累计推进={current['commanded_advance_from_distal_goal_m']} m；"
                f"名义上超过可见手端={current['nominal_advance_beyond_distal_surface_m']} m（不是实测穿入）。",
                f"已记录皮肤模型间隙最小值={contact['minimum_saved_observed_skin_clearance_m']} m；"
                f"最新记录值={current['observed_skin_clearance_min_m']} m，仅覆盖已观测皮肤。",
                f"近期皮肤观测时间={skin['observation_time_s']} s、日志时年龄={skin['age_at_log_record_s']} s（{skin['status']}）；"
                f"固定皮肤观测时间={anchor['observation_time_s']} s、日志时年龄={anchor['age_at_log_record_s']} s（{anchor['status']}，静止人体假设）。"]
            for pulse in contact['pulse_responses']:
                response = pulse['response']
                lines.append(f"  脉冲 {pulse['pulse_index']}：实测双夹爪位移（世界坐标 m）={response['measured_grasp_shift_world']}；"
                             f"原固定特征布料位移={response['fixed_cloth_shift_world']}。")
            if contact['pulse_conflicts']:
                lines.append('接触日志存在相同脉冲序号的冲突记录，不能将其累计为额外脉冲。')
            lines.append('初始约20 mm间隔的接近、名义推进和可见布料增长均不计为穿入或成功；实际袖口进入未验证，成败仍以有效官方评分和穿衣结果为准。')
        if official['usable_score']:
            score = official['score']
            lines += [f"官方结果有效，结束原因：{official.get('reason')}。",
                      f"官方原始得分：{score.get('raw_points')}/{score.get('max_raw_points')}；"
                      f"完整穿衣成功：{score.get('success')}。",
                      f"官方效率分：{score.get('final_score')}；状态：{score.get('score_status')}（null/None 不视为 0）。"]
        elif official['present']:
            lines.append(f"官方结果无效或不可读（valid={official.get('valid')}，原因={official.get('reason')}）；不引用其分数或成功字段。")
        else:
            lines.append('尚无官方 result.json；当前日志不能作为已完成的官方成败结论。')
        if episode['comparison']['visual_candidate_without_measured_dual_holding']:
            lines.append('注意：曾出现视觉双持候选，但已有官方采样未观测到双机同时健康持衣。')
        warns = episode['sample_warnings'] + actor['warnings']
        if warns:
            lines.append('日志完整性提示：' + '；'.join(warns))
        lines.append('')
    lines.append('此工具只汇总文件，不改变仿真、模型、参数、录制状态或控制指令。')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', help='Run directory name below results; defaults to latest_run.txt')
    args = parser.parse_args()
    results = (ROOT/'results').resolve()
    if args.run:
        if Path(args.run).name != args.run:
            parser.error('--run must be a run directory name, not an arbitrary path')
        run = (results/args.run).resolve()
    elif (results/'latest_run.txt').exists():
        run = Path((results/'latest_run.txt').read_text().strip()).resolve()
    else:
        candidates = sorted(path for path in results.glob('evaluate_*') if path.is_dir())
        if not candidates:
            parser.error('No run directories found')
        run = candidates[-1].resolve()
    if run.parent != results or not run.is_dir():
        parser.error('Run must be an existing direct child of this experiment results directory')
    review = summarize_run(run)
    outputs = {'iteration_review.json': json.dumps(review, ensure_ascii=False, indent=2, allow_nan=False)+'\n',
               '迭代结果.txt': chinese_report(review)}
    for name, content in outputs.items():
        target = run/name
        temporary = target.with_name(target.name+'.tmp')
        temporary.write_text(content)
        temporary.replace(target)
    print(json.dumps(dict(run=run.name, state=review['run_state'], complete_requested_plan=review['complete_requested_plan'],
                          episode_count=len(review['episodes']), outputs=[str(run/name) for name in outputs]),
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
